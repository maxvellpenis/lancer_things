/* ============================== v38: Киберпанк RED ==============================
   «очень классные хб от максвелла»: вкладка «Персонаж» — полный лист Cyberpunk RED (создание тремя методами,
   навыки, роли и ролевые способности, бой, снаряжение, киберимпланты, жизненный путь) с автоматикой.
   Библиотека: переключатель «Lancer / Киберпанк RED» — свои НИП, быстрый генератор и импорт личного пакета.
   Неофициальный фанатский материал по Homebrew Content Policy R. Talsorian Games: только таблицы и краткие пересказы. */
const CPR=/*@@CPR@@*/null||{};
const CRS=Object.fromEntries((CPR.STATS||[]).map(s=>[s[0],s]));
const CSTK=(CPR.STATS||[]).map(s=>s[0]);
const CSK=Object.fromEntries((CPR.SK||[]).map(s=>[s[0],{id:s[0],n:s[1],st:s[2],cat:s[3],x2:!!s[4],basic:!!s[5],multi:!!s[6],d:s[7]}]));
const CROLE=Object.fromEntries((CPR.ROLES||[]).map(r=>[r.id,r]));
const CRW=Object.fromEntries((CPR.RW||[]).map(w=>[w[0],{id:w[0],n:w[1],sk:w[2],dmg:w[3],mag:w[4],am:w[5],rof:w[6],h:w[7],con:w[8],c:w[9],dv:w[10],f:w[11]||''}]));
const CMW=Object.fromEntries((CPR.MW||[]).map(w=>[w[0],{id:w[0],n:w[1],dmg:w[2],rof:w[3],con:w[4],c:w[5],ex:w[6],melee:1,sk:'melee'}]));
const CEXO=Object.fromEntries((CPR.EXO||[]).map(x=>[x[0],{id:x[0],n:x[1],base:x[2],c:x[3],d:x[4]}]));
const CAR=Object.fromEntries((CPR.ARMOR||[]).map(a=>[a[0],{id:a[0],n:a[1],sp:a[2],pen:a[3],c:a[4]}]));
const CGR=Object.fromEntries((CPR.GEAR||[]).map(g=>[g[0],{id:g[0],n:g[1],c:g[2],d:g[3]}]));
const CCY=Object.fromEntries((CPR.CY||[]).map(x=>[x[0],{id:x[0],n:x[1],cat:x[2],par:x[3],sl:x[4],ins:x[5],c:x[6],hl:x[7],hld:x[8],pair:x[9],d:x[10],fx:x[11]||{}}]));
const CCAT=Object.fromEntries((CPR.CAT||[]).map(x=>[x[0],{id:x[0],n:x[1],found:x[2],sl:x[3]}]));
const CPRG=Object.fromEntries((CPR.PROG||[]).map(x=>[x[0],{id:x[0],n:x[1],cls:x[2],atk:x[3],def:x[4],rez:x[5],c:x[6],d:x[7]}]));
const CHW=Object.fromEntries((CPR.HW||[]).map(x=>[x[0],{id:x[0],n:x[1],sl:x[2],c:x[3],d:x[4]}]));
const CAMT=Object.fromEntries((CPR.AMT||[]).map(x=>[x[0],{id:x[0],n:x[1],c:x[2],d:x[3]}]));
const CAMMO=Object.fromEntries((CPR.AMMO||[]).map(x=>[x[0],x[1]]));
const CATT=Object.fromEntries((CPR.ATT||[]).map(x=>[x[0],{id:x[0],n:x[1],c:x[2],sl:x[3],d:x[4]}]));
const CLP=Object.fromEntries((CPR.LP||[]).map(x=>[x.id,x]));
const CMEAT=new Set(['stdhand','bigknux','rippers','scratchers','slicedice','smartlink','toolhand','wolvers','stdfoot','talon']);
const CCOVER=new Set(['hardened','plastic','realskin','superchrome']);
const CR_TABS=[['main','Главная'],['skills','Навыки'],['role','Роль'],['combat','Бой'],['gear','Снаряжение'],['cyber','Киберимпланты'],['life','Жизненный путь'],['make','Создание'],['notes','Заметки']];
let CRLAST=null,CR_SKCAT=LS.get('cr_skcat','all');
const crU=()=>Math.random().toString(36).slice(2,9);
const crN=(v,lo,hi,d)=>num(v,lo,hi,d);
const crS=(v,n)=>typeof v==='string'?v.slice(0,n||200):'';
const skK=(id,spec)=>spec?id+'|'+spec:id;
const skP=k=>{const i=String(k).indexOf('|');return i<0?{id:k,spec:''}:{id:k.slice(0,i),spec:k.slice(i+1)}};
const skName=k=>{const {id,spec}=skP(k);const s=CSK[id]||(id==='surgery'?{n:'Хирургия'}:id==='medtech'?{n:'Медицинские технологии'}:{n:id});return s.n+(spec?' ('+spec+')':'')};
const crDice=s=>{const m=String(s||'').match(/(\d+)d6(?:\s*\/\s*2)?/);return m?{n:+m[1],half:/\/\s*2/.test(s)}:null};
function crRollDice(n){const a=[];for(let i=0;i<n;i++)a.push(rnd(6));return a}
function crD10(){const r=rnd(10);let x=0;if(r===10)x=rnd(10);else if(r===1)x=-rnd(10);return {r,x}}

/* ---------- данные персонажа ---------- */
function crBasicSk(){const o={};Object.values(CSK).filter(s=>s.basic).forEach(s=>{o[s.id==='lang'?'lang|Уличный сленг':s.id==='local'?'local|Свой район':s.id]=2});return o}
function crNew(p){return {v:1,handle:(p&&(p.callsign||p.name))||'',role:'solo',rank:4,roles2:[],method:'',done:0,free:0,
  st:{int:6,ref:6,dex:6,tech:6,cool:6,will:6,luck:6,move:6,body:6,emp:6},luck:6,hum:60,hp:null,dsPen:0,ip:0,ipT:0,rep:0,eb:0,
  sk:crBasicSk(),ab:{},wpn:[],arm:{head:{id:'',sp:0},body:{id:'',sp:0}},cyl:{head:0,body:0},shield:-1,crit:[],cy:[],gear:[],ammo:{},fash:[],house:'container',life:'kibble',
  deck:{pr:[],hw:[]},lp:{},notes:'',nx:{luck:0,mod:0},init:null,sand:0,stim:0,sub:'main',cr:{pts:62,kit:{}}}}
function crOf(p){if(!p.cpr||typeof p.cpr!=='object')p.cpr=crNew(p);return p.cpr}
const crRank=(c,id)=>c.role===id?c.rank:((c.roles2||[]).find(r=>r.id===id)||{rank:0}).rank;
const crHas=(c,id)=>c.cy.filter(x=>x.id===id).length;

/* ---------- очистка (данные из хранилища и импорта) ---------- */
function crClean(raw,p){const c=crNew(p);if(!raw||typeof raw!=='object')return c;const o=x=>!!x&&typeof x==='object'&&!Array.isArray(x),A=x=>Array.isArray(x)?x:[];
  c.handle=crS(raw.handle,80);c.role=CROLE[raw.role]?raw.role:'solo';c.rank=crN(raw.rank,1,10,4);
  c.roles2=A(raw.roles2).filter(r=>o(r)&&CROLE[r.id]&&r.id!==c.role).slice(0,9).map(r=>({id:r.id,rank:crN(r.rank,1,10,1)}));
  c.method=['','sr','er','cp'].includes(raw.method)?raw.method:'';c.done=raw.done?1:0;c.free=raw.free?1:0;
  if(o(raw.st))CSTK.forEach(k=>c.st[k]=crN(raw.st[k],0,20,6));
  c.luck=crN(raw.luck,0,20,c.st.luck);c.hum=crN(raw.hum,-200,200,c.st.emp*10);c.hp=raw.hp===null||raw.hp===undefined?null:crN(raw.hp,-99,200,null);
  c.dsPen=crN(raw.dsPen,0,30,0);c.ip=crN(raw.ip,0,99999,0);c.ipT=crN(raw.ipT,0,99999,0);c.rep=crN(raw.rep,0,10,0);c.eb=crN(raw.eb,-9999999,99999999,0);
  if(o(raw.sk)){c.sk={};Object.keys(raw.sk).slice(0,300).forEach(k=>{const {id,spec}=skP(String(k).slice(0,120));if(!CSK[id])return;c.sk[skK(id,crS(spec,60).replace(/\|/g,'/'))]=crN(raw.sk[k],0,10,0)})}
  if(o(raw.ab)){const a=raw.ab,r={};
    if(o(a.solo)){r.solo={};['dd','fr','ir','pa','sw','td'].forEach(k=>r.solo[k]=crN(a.solo[k],0,10,0))}
    if(o(a.tech)){r.tech={};['field','upg','fab','inv'].forEach(k=>r.tech[k]=crN(a.tech[k],0,10,0))}
    if(o(a.med)){r.med={};['surg','pharma','cryo'].forEach(k=>r.med[k]=crN(a.med[k],0,10,0))}
    if(Array.isArray(a.team))r.team=a.team.filter(o).slice(0,6).map(t=>({u:crS(t.u,12)||crU(),t:CPR.ROLES&&AB_TEAM()[t.t]?t.t:'bodyguard',n:crS(t.n,60),row:crN(t.row,1,6,1),loy:crN(t.loy,-20,30,2),hp:crN(t.hp,-99,200,null)}));
    if(Array.isArray(a.veh))r.veh=a.veh.filter(x=>typeof x==='string').slice(0,20).map(x=>x.slice(0,120));
    if(Array.isArray(a.fans))r.fans=a.fans.filter(x=>typeof x==='string').slice(0,30).map(x=>x.slice(0,120));
    c.ab=r}
  c.wpn=A(raw.wpn).filter(o).slice(0,40).map(w=>({u:crS(w.u,12)||crU(),id:crS(w.id,30),n:crS(w.n,80),q:['poor','std','exc'].includes(w.q)?w.q:'std',att:A(w.att).filter(x=>CATT[x]).slice(0,3),
    mag:crN(w.mag,0,999,0),am:CAMT[w.am]?w.am:'basic',band:crN(w.band,0,7,0),aim:w.aim?1:0,dmg:crS(w.dmg,12),rof:crN(w.rof,1,3,1),sk:CSK[w.sk]?w.sk:'',note:crS(w.note,200),cyb:w.cyb?1:0}));
  if(o(raw.arm))['head','body'].forEach(l=>{const x=o(raw.arm[l])?raw.arm[l]:{};c.arm[l]={id:CAR[x.id]?x.id:'',sp:crN(x.sp,0,30,0)}});
  if(o(raw.cyl))['head','body'].forEach(l=>c.cyl[l]=crN(raw.cyl[l],0,30,0));
  c.shield=crN(raw.shield,-1,10,-1);
  c.crit=A(raw.crit).filter(o).slice(0,30).map(x=>({l:x.l==='head'?'head':'body',r:crN(x.r,2,12,2)}));
  const ids=new Set();c.cy=A(raw.cy).filter(x=>o(x)&&CCY[x.id]).slice(0,80).map(x=>{const u=crS(x.u,12)||crU();ids.add(u);return {u,id:x.id,p:crS(x.p,12),hl:crN(x.hl,0,99,0),s:crS(x.s,80)}});
  c.cy.forEach(x=>{if(x.p&&x.p!=='meat'&&!ids.has(x.p))x.p=''});
  c.gear=A(raw.gear).filter(o).slice(0,200).map(g=>({id:CGR[g.id]?g.id:'',n:crS(g.n,80),q:crN(g.q,0,9999,1)}));
  if(o(raw.ammo)){c.ammo={};Object.keys(raw.ammo).slice(0,60).forEach(k=>{const [t,a]=String(k).split(':');if(CAMMO[t]&&CAMT[a])c.ammo[t+':'+a]=crN(raw.ammo[k],0,99999,0)})}
  c.fash=A(raw.fash).filter(o).slice(0,100).map(f=>({s:crN(f.s,0,9,0),i:crN(f.i,0,8,0),q:crN(f.q,1,99,1)}));
  c.house=(CPR.HOUSING||[]).some(h=>h[0]===raw.house)?raw.house:'container';c.life=(CPR.LIFESTYLE||[]).some(h=>h[0]===raw.life)?raw.life:'kibble';
  if(o(raw.deck))c.deck={q:['deckp','deck','decke',''].includes(raw.deck.q)?raw.deck.q:'',pr:A(raw.deck.pr).filter(x=>CPRG[x]).slice(0,20),hw:A(raw.deck.hw).filter(x=>CHW[x]).slice(0,10)};
  if(o(raw.lp)){const l=raw.lp,r={};Object.keys(l).slice(0,80).forEach(k=>{const v=l[k];
      if(typeof v==='number'||typeof v==='string')r[String(k).slice(0,40)]=typeof v==='number'?crN(v,0,20,0):v.slice(0,200);
      else if(Array.isArray(v))r[String(k).slice(0,40)]=v.slice(0,12).map(e=>Array.isArray(e)?e.slice(0,5).map(n=>crN(n,0,20,0)):crN(e,0,20,0))});c.lp=r}
  c.notes=crS(raw.notes,20000);c.init=raw.init===null||raw.init===undefined?null:crN(raw.init,-50,99,null);c.sand=raw.sand?1:0;c.stim=raw.stim?1:0;c.sub=CR_TABS.some(t=>t[0]===raw.sub)?raw.sub:'main';
  if(o(raw.nx))c.nx={luck:crN(raw.nx.luck,0,20,0),mod:crN(raw.nx.mod,-30,30,0)};
  if(o(raw.cr)){c.cr={pts:crN(raw.cr.pts,40,90,62),kit:{}};if(o(raw.cr.kit))Object.keys(raw.cr.kit).slice(0,30).forEach(k=>c.cr.kit[String(k).slice(0,20)]=crN(raw.cr.kit[k],0,5,0))}
  return c}
function AB_TEAM(){return ((CROLE.exec||{}).abx||{}).team||{}}
{const o=cleanPilot;cleanPilot=function(raw,k){const p=o(raw,k);try{if(raw&&raw.cpr)p.cpr=crClean(raw.cpr,p)}catch(e){}return p}}

/* ---------- расчёт ---------- */
function crCalc(c){
  const st={...c.st};let body=st.body;const m=crHas(c,'muscle');if(m)body=Math.max(body,Math.min(10,body+2*m));
  if(crHas(c,'exobeta'))body=Math.max(body,14);else if(crHas(c,'exosig'))body=Math.max(body,12);
  const pen=Math.max(0,...['head','body'].map(l=>CAR[c.arm[l].id]?CAR[c.arm[l].id].pen:0));
  const cr=c.crit.map(x=>((CPR.CRIT||{})[x.l]||[]).find(r=>r[0]===x.r)).filter(Boolean);
  const cf=k=>cr.reduce((s,r)=>s+((r[5]||{})[k]||0),0);
  const eff={...st,body,ref:Math.max(0,st.ref-pen),dex:Math.max(0,st.dex-pen),move:Math.max(0,st.move-pen),emp:Math.max(0,Math.min(st.emp,Math.floor(c.hum/10)))};
  if(cf('move'))eff.move=Math.max(1,eff.move+cf('move'));
  const hpMax=10+5*Math.ceil((body+st.will)/2),sw=Math.ceil(hpMax/2),hp=c.hp===null?hpMax:c.hp;
  const wound=hp>=hpMax?0:hp>=sw?1:hp>=1?2:3;
  const noSW=crHas(c,'paineditor')||c.stim;
  if(wound===3)eff.move=Math.max(1,eff.move-6);
  const all=(wound===2&&!noSW?-2:0)+(wound===3?-4:0)+cf('all');
  const cyl=crHas(c,'subarmor')?11:crHas(c,'skinweave')?7:0;
  const sp={};['head','body'].forEach(l=>sp[l]=Math.max(c.arm[l].id?c.arm[l].sp:0,cyl?c.cyl[l]:0));
  const mods={};const add=(o,src)=>Object.entries(o||{}).forEach(([k,v])=>{(mods[k]=mods[k]||[]).push([src,v])});
  const seen=new Set();c.cy.forEach(x=>{const d=CCY[x.id];if(d&&d.fx.sk&&!seen.has(x.id)){seen.add(x.id);add(d.fx.sk,d.n)}});
  const gseen=new Set();c.gear.forEach(g=>{if(g.id&&CPR.GMOD[g.id]&&!gseen.has(g.id)){gseen.add(g.id);add(CPR.GMOD[g.id],CGR[g.id].n)}});
  if(crHas(c,'chemskin')&&crHas(c,'techhair'))add({groom:2},'Химкожа + техноволосы');
  if(crHas(c,'lighttat')>=3)add({wardr:2},'3+ светящихся тату');
  const ab=c.ab||{};
  const mr=crRank(c,'nomad');if(mr)add({drive:mr,pilot:mr,sea:mr,landt:mr,airt:mr,seat:mr},'Мото');
  const fe=crRank(c,'tech')&&ab.tech?ab.tech.field||0:0;if(fe)add({basict:fe,cybert:fe,elec:fe,weapt:fe,landt:fe,seat:fe,airt:fe},'Полевая экспертиза');
  const so=crRank(c,'solo')&&ab.solo?ab.solo:{};if(so.td)add({perc:so.td},'Обнаружение угроз');
  const chips={};c.cy.filter(x=>x.id==='skillchip'&&x.s).forEach(x=>chips[x.s]=1);
  const med=crRank(c,'med')&&ab.med?ab.med:{};
  const init=(crHas(c,'kerenz')?2:0)+(c.sand&&crHas(c,'sandev')?3:0)+(so.ir||0);
  const atk=Math.min(3,Math.floor((so.pa||0)/3));
  return {st,eff,pen,hpMax,sw,hp,wound,all,noSW,dsBase:body,dsPen:cf('ds')+c.dsPen,sp,cyl,mods,chips,init,atk,
    surg:Math.min(10,(med.surg||0)*2),medt:Math.min(10,(med.pharma||0)+(med.cryo||0)),cf,humMax:st.emp*10,ranged:cf('ranged'),melee:cf('melee')}}
function crSkLv(c,k){const {id}=skP(k);if(id==='surgery')return crCalc(c).surg;if(id==='medtech')return crCalc(c).medt;return c.sk[k]||0}
function crSkTot(c,k,K){K=K||crCalc(c);const {id}=skP(k);const s=CSK[id]||{st:'tech'};let lv=id==='surgery'?K.surg:id==='medtech'?K.medt:(c.sk[k]||0);
  if(K.chips[k]||K.chips[id])lv=Math.max(lv,3);const m=(K.mods[id]||[]).reduce((a,x)=>a+x[1],0);return {lv,stat:K.eff[s.st]||0,mod:m,tot:(K.eff[s.st]||0)+lv+m,src:K.mods[id]||[]}}
const crWound=w=>(CPR.WOUND||[])[w===0?0:w]||['','',0];

/* ---------- броски ---------- */
function crLog(who,title,html){try{addLog('',logHead(who+' — '+title)+`<div class="bd">${html}</div>`)}catch(e){}}
function crRoll(p,c,label,parts,opt){opt=opt||{};const nx=c.nx||{luck:0,mod:0};const luck=Math.min(nx.luck||0,c.luck),mod=nx.mod||0;
  const d=crD10();const base=parts.reduce((a,x)=>a+x[1],0);const tot=base+d.r+d.x+luck+mod;c.luck-=luck;c.nx={luck:0,mod:0};
  const ps=parts.filter(x=>x[1]).map(x=>`${esc(x[0])} ${sgn(x[1])}`).concat(luck?[`Удача +${luck}`]:[]).concat(mod?[`мод. ${sgn(mod)}`]:[]);
  const dTxt=`d10 [${d.r}${d.x>0?' + '+d.x+' крит. успех':d.x<0?' − '+(-d.x)+' крит. провал':''}]`;
  let res='';if(opt.dv!==undefined&&opt.dv!==null)res=tot>opt.dv?` → <b class="cr-ok">попадание</b> (СЛ ${opt.dv}, превышение ${tot-opt.dv})`:` → <b class="cr-no">промах</b> (СЛ ${opt.dv})`;
  const html=`${dTxt}${ps.length?' · '+ps.join(' · '):''} = <b class="cr-tot">${tot}</b>${res}${opt.note?`<div class="muted">${opt.note}</div>`:''}`;
  CRLAST={t:label,html};crLog(opt.who||crWho(p,c),label,html);return {tot,d}}
function crWho(p,c){return (c&&c.handle)||(p&&(p.callsign||p.name))||'Персонаж'}
function crDmg(p,c,label,dice,opt){opt=opt||{};const dd=crDice(dice);if(!dd){CRLAST={t:label,html:'Нет урона'};return null}
  let a=crRollDice(dd.n),sum=a.reduce((x,y)=>x+y,0);if(dd.half)sum=Math.ceil(sum/2);const six=a.filter(x=>x===6).length,crit=six>=2;
  let total=sum*(opt.mult||1)+(opt.bonus||0);let html=`${dice}${opt.mult>1?' × '+opt.mult:''} [${a.join(', ')}]${opt.bonus?` + ${opt.bonus} (Выявление слабостей — только первая успешная атака за раунд)`:''} = <b class="cr-tot">${total}</b>`;
  if(opt.halfArmor)html+=' · <span class="muted">игнорирует половину брони цели</span>';
  if(crit){const loc=opt.head?'head':'body',r=rnd(6)+rnd(6),ci=(CPR.CRIT[loc]||[]).find(x=>x[0]===r);html+=`<div><b class="cr-no">Критическая травма!</b> +5 урона в ПЗ цели. ${loc==='head'?'Голова':'Тело'}, 2d6 = ${r}: <b>${esc(ci?ci[1]:'')}</b> — ${esc(ci?ci[2]:'')}</div>`}
  CRLAST={t:label,html};crLog(opt.who||crWho(p,c),label,html);return {total,crit}}

/* ---------- шапка листа ---------- */
function crView(p){const c=crOf(p);const K=crCalc(c);if(c.hp===null)c.hp=K.hpMax;
  const W=crWound(K.wound),R=CROLE[c.role]||{};
  const top=`<div class="cr-head">
    <div class="cr-id"><input class="pc-big" data-cf="handle" value="${esc(c.handle)}" placeholder="Погоняло">
      <div class="cr-role">${esc(R.n||'')} <span class="muted">· ${esc(R.ab||'')} ${c.rank}</span>${(c.roles2||[]).map(r=>` <span class="ntag">${esc((CROLE[r.id]||{}).n||'')} ${r.rank}</span>`).join('')}</div></div>
    <div class="cr-hpbox"><div class="cr-hpl">Пункты здоровья</div>
      <div class="cr-hprow"><button class="pm" data-cr="hp" data-d="-1">−</button><input type="number" class="cr-hpin" data-cf="hp" value="${c.hp}"><span class="cr-hpmax">/ ${K.hpMax}</span><button class="pm" data-cr="hp" data-d="1">+</button></div>
      <div class="cr-wound w${K.wound}">${esc(W[0])}${K.wound>=2?' · '+esc(W[1]):''}</div></div>
    <div class="cr-hbtn"><button class="btn red" data-cr="init">⚡ Инициатива</button>${K.wound===3?`<button class="btn red" data-cr="ds">☠ Спасбросок от смерти</button>`:''}
      <button class="btn" data-cr="stab">✚ Стабилизировать</button><button class="btn" data-cr="sess" title="Удача восстанавливается полностью">Новая сессия</button></div>
  </div>
  <div class="cr-next"><span>Следующий бросок:</span>
    <span class="ntag">Удача <button class="pm" data-cr="nxl" data-d="-1">−</button><b>${c.nx.luck}</b><button class="pm" data-cr="nxl" data-d="1">+</button> из ${c.luck}/${c.st.luck}</span>
    <span class="ntag">Мод. <button class="pm" data-cr="nxm" data-d="-1">−</button><b>${sgn(c.nx.mod)}</b><button class="pm" data-cr="nxm" data-d="1">+</button></span>
    ${K.all?`<span class="cr-warn">Штраф ко всем действиям ${K.all}</span>`:''}
    ${CRLAST?`<span class="cr-last"><b>${esc(CRLAST.t)}:</b> ${CRLAST.html}</span>`:''}</div>
  <div class="pc-tabs cr-tabs">${CR_TABS.map(([k,l])=>`<button class="tab ${c.sub===k?'on':''}" data-cr="sub" data-v="${k}">${l}</button>`).join('')}</div>`;
  let body='';try{body=({main:crMain,skills:crSkills,role:crRole,combat:crCombat,gear:crGear,cyber:crCyber,life:crLife,make:crMake,notes:crNotes}[c.sub]||crMain)(p,c,K)}catch(e){body=`<div class="crashbox">Ошибка вкладки: ${esc(e.message)}</div>`}
  return `<div class="cr-sheet">${top}${body}<p class="cr-legal muted">Неофициальный фанатский материал по Homebrew Content Policy R. Talsorian Games, не одобрен RTG. Ссылается на материалы, принадлежащие R. Talsorian Games и её лицензиатам. Числа и таблицы — Cyberpunk RED, тексты — краткие пересказы; подробности в книге (номера страниц указаны).</p></div>`}

/* ---------- Главная ---------- */
function crMain(p,c,K){
  const stats=CPR.STATS.map(([k,l,full])=>{const b=c.st[k],e=K.eff[k];return `<div class="cr-st"><button class="cr-stb" data-cr="rstat" data-v="${k}" title="${esc(full)}: бросок d10 + ${l}">${l}</button>
     <div class="cr-sv">${k==='luck'?`${c.luck}<small>/${b}</small>`:e}${k!=='luck'&&e!==b?` <small class="cr-base">(${b})</small>`:''}</div>
     ${k==='luck'?`<div><button class="pm" data-cr="luck" data-d="-1">−</button><button class="pm" data-cr="luck" data-d="1">+</button></div>`:''}
     ${c.free||(!c.done&&c.method==='cp')?`<div class="cr-ed"><button class="pm" data-cr="st" data-v="${k}" data-d="-1">−</button><button class="pm" data-cr="st" data-v="${k}" data-d="1">+</button></div>`:''}</div>`}).join('');
  const crits=c.crit.map(x=>{const r=(CPR.CRIT[x.l]||[]).find(y=>y[0]===x.r);return r?`<span class="ntag cr-crit">${esc(r[1])}</span>`:''}).join(' ');
  return `<h2>Характеристики ${!c.done&&c.method==='cp'?`<span class="muted cr-small">очки: ${CSTK.reduce((a,k)=>a+c.st[k],0)}/${c.cr.pts} · каждая 2–8</span>`:''}</h2>
  <div class="cr-stats">${stats}</div>
  ${K.pen?`<p class="muted">Броня: −${K.pen} к РЕА, ЛВК и СКО (в скобках — без штрафа).</p>`:''}
  <h2>Производные</h2>
  <div class="cr-der">
    <div class="cr-dc"><b>Испытание против смерти</b><div class="cr-big">${K.dsBase}</div><div class="muted">штраф +${K.dsPen} <button class="pm" data-cr="dsp" data-d="-1">−</button><button class="pm" data-cr="dsp" data-d="1">+</button></div></div>
    <div class="cr-dc"><b>Тяжёлое ранение</b><div class="cr-big">${K.sw}</div><div class="muted">ПЗ меньше — −2 ко всем действиям</div></div>
    <div class="cr-dc"><b>Человечность</b><div class="cr-big">${c.hum}</div><div class="muted">максимум ${K.humMax} · ЭМП ${K.eff.emp} <button class="pm" data-cr="hum" data-d="-1">−</button><button class="pm" data-cr="hum" data-d="1">+</button></div></div>
    <div class="cr-dc"><b>Очки улучшения</b><div class="cr-big">${c.ip}</div><div class="muted">всего ${c.ipT} · <input type="number" class="cr-sm" id="crIpAdd" placeholder="+ОУ"><button class="btn sm" data-cr="ipadd">Начислить</button></div></div>
    <div class="cr-dc"><b>Скорость</b><div class="cr-big">${K.eff.move}</div><div class="muted">гексов за перемещение (1 гекс = 2 м, ${K.eff.move*2} м); бег — ещё столько же</div></div>
    <div class="cr-dc"><b>Репутация</b><div class="cr-big">${c.rep}</div><div class="muted"><button class="pm" data-cr="rep" data-d="-1">−</button><button class="pm" data-cr="rep" data-d="1">+</button></div></div>
  </div>
  ${c.hum<=0?`<p class="cr-warn">Человечность 0 или ниже — киберпсихоз: персонаж переходит под контроль ГМа (стр. 230).</p>`:''}
  ${crits?`<h2>Критические травмы</h2><div>${crits} <button class="btn sm" data-cr="sub" data-v="combat">Подробнее →</button></div>`:''}
  <h2>Как пользоваться</h2><p class="muted cr-small">Клик по характеристике или навыку — проверка: d10 + сумма (на 10 добавляется ещё d10, на 1 — вычитается). Удача и модификатор выше применяются к следующему броску. Создание персонажа — вкладка «Создание». ${c.free?'':'Свободная правка чисел — переключатель ниже.'}</p>
  <label class="cr-chk"><input type="checkbox" data-cf="free" ${c.free?'checked':''}> Свободная правка (для ГМа: менять характеристики и навыки без правил и очков)</label>`}

/* ---------- Навыки ---------- */
function crSkCost(id,lv){return (CSK[id]&&CSK[id].x2?2:1)*lv}
function crSkBudget(c){const R=CROLE[c.role];let used=0;Object.entries(c.sk).forEach(([k,lv])=>{const {id,spec}=skP(k);let l=lv;if(id==='lang'&&c.lp&&c.lp.langFree&&spec===c.lp.langFree)l=Math.max(0,lv-4);used+=crSkCost(id,l)});return {used,max:86}}
function crSkRoleSet(c){const R=CROLE[c.role];return new Set((R.sr||[]).map(x=>x[0]))}
function crSkills(p,c,K){
  const mode=c.free?'free':(!c.done&&(c.method==='er'||c.method==='cp'))?'make':c.done?'ip':'view';
  const keys=new Set(Object.keys(c.sk));Object.values(CSK).forEach(s=>{if(!s.multi)keys.add(s.id)});
  if(crRank(c,'med')){keys.add('surgery');keys.add('medtech')}
  const roleSet=crSkRoleSet(c);
  const list=[...keys].map(k=>({k,...skP(k)})).filter(x=>CSK[x.id]||x.id==='surgery'||x.id==='medtech');
  const cat=CR_SKCAT;const shown=list.filter(x=>cat==='all'||(cat==='mine'?crSkLv(c,x.k)>0:(CSK[x.id]||{cat:'tech'}).cat===cat))
    .sort((a,b)=>skName(a.k).localeCompare(skName(b.k),'ru'));
  const bud=crSkBudget(c);
  const card=x=>{const s=CSK[x.id]||{n:skName(x.k),st:'tech',x2:0,basic:0};const T=crSkTot(c,x.k,K);const lv=T.lv;const spec=x.id==='surgery'||x.id==='medtech';
    let ctl='';
    if(!spec&&mode==='free')ctl=`<button class="pm" data-cr="sk" data-v="${esc(x.k)}" data-d="-1">−</button><button class="pm" data-cr="sk" data-v="${esc(x.k)}" data-d="1">+</button>`;
    else if(!spec&&mode==='make'){const ok=c.method==='cp'||roleSet.has(x.id);ctl=ok?`<button class="pm" data-cr="sk" data-v="${esc(x.k)}" data-d="-1">−</button><button class="pm" data-cr="sk" data-v="${esc(x.k)}" data-d="1">+</button>`:'<span class="muted cr-small">не для роли</span>'}
    else if(!spec&&mode==='ip'&&lv<10){const cost=(CPR.IPCOST[s.x2?'skill2':'skill']||[])[lv];ctl=`<button class="btn sm" data-cr="skip" data-v="${esc(x.k)}" ${c.ip<cost?'disabled':''} title="Повысить до ${lv+1}">+ за ${cost} ОУ</button>`}
    const mods=T.src.map(m=>`${m[0]} ${sgn(m[1])}`).join(', ');
    return `<div class="cr-sk ${lv?'has':''}"><button class="cr-skn" data-cr="rsk" data-v="${esc(x.k)}" title="${esc(s.d||'')}${mods?'\nБонусы: '+esc(mods):''}">${esc(skName(x.k))}${s.x2?' <i>×2</i>':''}${s.basic?' <i class="cr-bas">баз.</i>':''}</button>
      <div class="cr-skm">ур. <b>${lv}</b> · ${esc((CRS[s.st]||['',''])[1])} ${T.stat}${T.mod?` · ${sgn(T.mod)}`:''}</div><div class="cr-skt">${T.tot}</div>
      <div class="cr-skc">${ctl}${CSK[x.id]&&CSK[x.id].multi&&(mode==='free'||mode==='make')&&!CSK[x.id].basic?`<button class="pm" data-cr="skdel" data-v="${esc(x.k)}" title="Убрать">✕</button>`:''}</div></div>`};
  const multis=Object.values(CSK).filter(s=>s.multi);
  return `<h2>Навыки ${mode==='make'?`<span class="muted cr-small">очки ${bud.used}/${bud.max} · 2–6 · ×2 стоят вдвое · базовые не ниже 2${c.method==='er'?' · только 20 навыков роли':''}</span>`:mode==='ip'?`<span class="muted cr-small">ОУ: ${c.ip}. Повышение на 1 уровень: 20 × новый уровень (×2 — 40 ×)</span>`:''}</h2>
  ${mode==='view'?`<p class="muted">Персонаж ещё не создан — откройте вкладку «Создание».</p>`:''}
  <div class="cr-cats"><button class="tab ${cat==='all'?'on':''}" data-cr="skcat" data-v="all">Все</button><button class="tab ${cat==='mine'?'on':''}" data-cr="skcat" data-v="mine">Изученные</button>${CPR.CATS.map(([k,l])=>`<button class="tab ${cat===k?'on':''}" data-cr="skcat" data-v="${k}">${l}</button>`).join('')}</div>
  <div class="cr-sks">${shown.map(card).join('')||'<p class="muted">Нет навыков</p>'}</div>
  ${mode==='free'||mode==='make'?`<div class="row-btns">Добавить: <select id="crMulti">${multis.map(s=>`<option value="${s.id}">${esc(s.n)}</option>`).join('')}</select><input id="crMultiSpec" placeholder="уточнение (язык, район, стиль…)"><button class="btn sm" data-cr="skadd">＋</button></div>`:''}`}

/* ---------- Роль ---------- */
function crRole(p,c,K){const R=CROLE[c.role]||{};const A=R.abx||{};
  const rankCtl=c.free?`<button class="pm" data-cr="rank" data-d="-1">−</button><b>${c.rank}</b><button class="pm" data-cr="rank" data-d="1">+</button>`
    :c.done&&c.rank<10?`<b>${c.rank}</b> <button class="btn sm" data-cr="rankip" ${c.ip<CPR.IPCOST.role[c.rank]?'disabled':''}>+ за ${CPR.IPCOST.role[c.rank]} ОУ</button>`:`<b>${c.rank}</b>`;
  let h=`<h2>Роль</h2><div class="row-btns"><select data-cf="role" ${c.done&&!c.free?'disabled':''}>${CPR.ROLES.map(r=>`<option value="${r.id}" ${r.id===c.role?'selected':''}>${esc(r.n)}</option>`).join('')}</select>
    <span>${esc(R.ab)}: ${rankCtl}</span><span class="muted">стр. ${R.abp}</span></div><p class="muted">${esc(R.d||'')}</p>
    <div class="row-btns">${(c.roles2||[]).map(r=>`<span class="ntag">${esc(CROLE[r.id].n)} · ${esc(CROLE[r.id].ab)} ${r.rank} <button class="pm" data-cr="r2" data-v="${r.id}" data-d="1" title="+ранг за ОУ">+</button><button class="pm" data-cr="r2del" data-v="${r.id}" title="Убрать">✕</button></span>`).join('')}
    ${c.rank>=4&&(!c.roles2.length||c.roles2.every(r=>r.rank>=4))?`<select id="crR2">${CPR.ROLES.filter(r=>r.id!==c.role&&!c.roles2.some(x=>x.id===r.id)).map(r=>`<option value="${r.id}">${esc(r.n)}</option>`).join('')}</select><button class="btn sm" data-cr="r2add" title="Мультикласс: новая роль с 1 ранга за 60 ОУ">＋ вторая роль (60 ОУ)</button>`:''}</div>`;
  const roles=[c.role,...(c.roles2||[]).map(r=>r.id)];
  roles.forEach(id=>{h+=crAbBlock(p,c,K,id)});return h}
function crTbl(cols,rows){return `<table class="gl-tab cr-tab"><tr>${cols.map(x=>`<th>${esc(x)}</th>`).join('')}</tr>${rows.map(r=>`<tr>${r.map(x=>`<td>${esc(x)}</td>`).join('')}</tr>`).join('')}</table>`}
function crAbBlock(p,c,K,id){const R=CROLE[id],A=R.abx||{},rk=crRank(c,id);const ab=c.ab=c.ab||{};
  let h=`<h2>${esc(R.ab)} <span class="muted cr-small">${esc(R.n)} · ранг ${rk} · стр. ${R.abp}</span></h2><p>${esc(A.txt||'')}</p>`;
  const hiRow=(rows,col)=>rows.findIndex(r=>{const s=String(r[col||0]);const m=s.match(/(\d+)(?:–(\d+))?/);return m&&rk>=+m[1]&&rk<=(+(m[2]||m[1]))});
  if(id==='rocker'){h+=`<div class="row-btns"><button class="btn" data-cr="abroll" data-v="rocker" data-dv="8">Один фанат (СЛ 8)</button><button class="btn" data-cr="abroll" data-v="rocker" data-dv="10">Группа до 6 (СЛ 10)</button><button class="btn" data-cr="abroll" data-v="rocker" data-dv="12">Толпа (СЛ 12)</button></div>`+crTblHi(A.cols,A.tbl,hiRow(A.tbl))}
  if(id==='solo'){const s=ab.solo=ab.solo||{dd:0,fr:0,ir:0,pa:0,sw:0,td:0};const used=Object.values(s).reduce((a,b)=>a+b,0);
    h+=`<p class="muted">Распределено ${used}/${rk}</p><div class="cr-opts">${A.opts.map(([k,n,d,step])=>`<div class="cr-opt"><b>${esc(n)}</b> <span class="ntag"><button class="pm" data-cr="solo" data-v="${k}" data-d="-${step}">−</button><b>${s[k]}</b><button class="pm" data-cr="solo" data-v="${k}" data-d="${step}" ${used+step>rk?'disabled':''}>+</button></span><div class="muted">${esc(d)}</div></div>`).join('')}</div>
     <p class="muted">Сейчас: ${s.dd>=2?`урон −${Math.min(5,Math.floor(s.dd/2))} (первый в раунде); `:''}${s.fr>=4?'игнор критпровалов; ':''}${s.ir?`инициатива +${s.ir}; `:''}${s.pa>=3?`атаки +${Math.min(3,Math.floor(s.pa/3))}; `:''}${s.sw?`урон +${s.sw} (первая атака); `:''}${s.td?`Внимательность +${s.td}`:''}</p>`}
  if(id==='net'){const a=(A.acts||[]).find(x=>rk>=x[0]&&rk<=x[1]);h+=`<p><b>СЕТевых действий за ход: ${a?a[2]:2}</b></p><div class="cr-opts">${A.fx.map(([n,d])=>`<div class="cr-opt"><button class="btn sm" data-cr="abroll" data-v="net" data-n="${esc(n)}">${esc(n)}</button><div class="muted">${esc(d)}</div></div>`).join('')}</div>
     <p class="muted">Каждая способность: ранг Интерфейса + 1d10. Кибердека и программы — во вкладке «Снаряжение».</p>`}
  if(id==='tech'){const t=ab.tech=ab.tech||{field:0,upg:0,fab:0,inv:0};const used=Object.values(t).reduce((a,b)=>a+b,0);
    h+=`<p class="muted">Очков специализаций ${used}/${rk*2} (каждый ранг — по 1 в две разные; в одной не больше ранга)</p><div class="cr-opts">${A.spec.map(([k,n,d])=>`<div class="cr-opt"><b>${esc(n)}</b> <span class="ntag"><button class="pm" data-cr="tech" data-v="${k}" data-d="-1">−</button><b>${t[k]}</b><button class="pm" data-cr="tech" data-v="${k}" data-d="1" ${used>=rk*2||t[k]>=rk?'disabled':''}>+</button></span>
       ${k!=='field'?`<button class="btn sm" data-cr="techroll" data-v="${k}">Бросок</button>`:''}<div class="muted">${esc(d)}</div></div>`).join('')}</div>
      <div class="row-btns">Навык для броска: <select id="crTechSk">${['basict','cybert','elec','weapt','landt','seat','airt'].map(k=>`<option value="${k}">${esc(CSK[k].n)}</option>`).join('')}</select></div>${crTbl(['Ценовая категория','СЛ','Время'],A.tbl)}`}
  if(id==='med'){const m=ab.med=ab.med||{surg:0,pharma:0,cryo:0};const used=m.surg+m.pharma+m.cryo;
    h+=`<p class="muted">Очков специализаций ${used}/${rk}</p><div class="cr-opts">${[['surg','Хирургия',5,`навык Хирургия ${K.surg}`],['pharma','Медтехнологии: фармацевтика',5,`навык Медтехнологии ${K.medt}`],['cryo','Медтехнологии: криосистемы',5,'']].map(([k,n,mx,d])=>`<div class="cr-opt"><b>${n}</b> <span class="ntag"><button class="pm" data-cr="med" data-v="${k}" data-d="-1">−</button><b>${m[k]}</b><button class="pm" data-cr="med" data-v="${k}" data-d="1" ${used>=rk||m[k]>=mx?'disabled':''}>+</button></span><div class="muted">${d}</div></div>`).join('')}</div>
      <div class="row-btns"><button class="btn" data-cr="rsk" data-v="surgery">Бросок: Хирургия</button><button class="btn" data-cr="rsk" data-v="medtech">Бросок: Медтехнологии</button></div>
      ${m.pharma?`<h3>Препараты</h3><p class="muted">${esc(A.pharmaTxt)}</p>${crTbl(['Препарат','Эффект'],A.pharma)}`:''}
      ${m.cryo?`<h3>Криосистемы</h3>${crTbl(['Очков','Что даёт'],A.cryo.filter(x=>x[0]<=m.cryo))}`:''}`}
  if(id==='media'){h+=`<div class="row-btns"><button class="btn" data-cr="abroll" data-v="media" data-n="Слухи (пассивно, бросает ГМ)">Слухи: ранг + 1d10</button><button class="btn" data-cr="believe">Поверят ли (1d10)</button></div>`+crTbl(['Слух','Пассивная СЛ','Активная СЛ'],A.rum)+crTblHi(A.cols,A.tbl,hiRow(A.tbl))+`<p class="muted">${esc(A.bel)}</p>`}
  if(id==='exec'){const team=ab.team=ab.team||[];const T=A.team;const max=rk>=9?3:rk>=5?2:rk>=3?1:0;
    h+=crTbl(['Ранг','Бонус'],A.perks.filter(x=>x[0]<=rk).map(x=>[x[0],x[1]]))+`<h3>Команда (${team.length}/${max})</h3><p class="muted">${esc(A.loyTxt)}</p>`;
    h+=team.map((m,i)=>{const t=T[m.t]||{},row=(t.stats||[])[m.row-1]||[];const ks=['ИНТ','РЕА','ЛВК','ТЕХ','ХАР','ВОЛЯ','СКО','ТЕЛ','ЭМП'];const body=row[7]||5,will=row[5]||5,hpm=10+5*Math.ceil((body+will)/2);
      return `<div class="cr-mem"><div><input data-cf="team.n" data-i="${i}" value="${esc(m.n)}" placeholder="${esc(t.n||'')}"> <span class="muted">${esc(t.n||'')} · прикрытие: ${esc(t.cover||'')}</span></div>
        <div class="mini-core">${ks.map((k,j)=>`<span>${k} <b>${row[j]??'—'}</b></span>`).join('')}<span>ПЗ <b>${hpm}</b></span></div>
        <div class="row-btns">Лояльность <button class="pm" data-cr="loy" data-i="${i}" data-d="-1">−</button><b>${m.loy}</b><button class="pm" data-cr="loy" data-i="${i}" data-d="1">+</button><button class="btn sm" data-cr="loychk" data-i="${i}">Проверка лояльности (1d6)</button><button class="btn sm" data-cr="memdel" data-i="${i}">✕</button></div>
        <div class="muted cr-small">Навыки 2: ${t.sk2.map(k=>CSK[k].n).join(', ')}${t.iface?', Интерфейс':''}. Навыки 4: ${t.sk4.map(k=>CSK[k].n).join(', ')}${t.sk6.length?'. Навыки 6: '+t.sk6.map(k=>CSK[k].n).join(', '):''}.<br>Импланты: ${esc(t.cy)}. Снаряжение: ${esc(t.gear)}.</div></div>`}).join('');
    if(team.length<max)h+=`<div class="row-btns"><select id="crMem">${Object.entries(T).map(([k,t])=>`<option value="${k}">${esc(t.n)} — ${esc(t.job)}</option>`).join('')}</select><button class="btn sm" data-cr="memadd">＋ Нанять (характеристики 1d6, лояльность 1d6+1)</button></div>`;
    h+=`<details><summary>Как менять лояльность</summary>${crTbl(['Повысить','Очки'],A.loyUp)}${crTbl(['Понизить','Очки'],A.loyDn)}</details>`}
  if(id==='law'){h+=`<div class="row-btns"><button class="btn red" data-cr="backup">Вызвать подкрепление (d10 ≤ ${rk})</button></div>`+crTblHi(A.cols,A.tbl,hiRow(A.tbl))}
  if(id==='fixer'){h+=`<div class="row-btns"><button class="btn" data-cr="haggle">Торг: ХАР + Торговля + ранг + 1d10</button></div>`+crTblHi(A.cols,A.tbl,hiRow(A.tbl))}
  if(id==='nomad'){const v=ab.veh=ab.veh||[];h+=crTblHi(A.cols,A.tbl,hiRow(A.tbl))+`<h3>Семейный автопарк</h3>${v.map((x,i)=>`<div class="row-btns"><input data-cf="veh" data-i="${i}" value="${esc(x)}" style="flex:1"><button class="pm" data-cr="vehdel" data-i="${i}">✕</button></div>`).join('')}<button class="btn sm" data-cr="vehadd">＋ Транспорт или улучшение</button>`}
  return h}
function crTblHi(cols,rows,hi){return `<table class="gl-tab cr-tab"><tr>${cols.map(x=>`<th>${esc(x)}</th>`).join('')}</tr>${rows.map((r,i)=>`<tr class="${i===hi?'cr-hi':''}">${r.map(x=>`<td>${esc(x)}</td>`).join('')}</tr>`).join('')}</table>`}

/* ---------- Бой ---------- */
function crWDef(w){return CRW[w.id]||CMW[w.id]||(CEXO[w.id]?(CRW[CEXO[w.id].base]||CMW[CEXO[w.id].base]):null)}
function crWInfo(c,w){const d=crWDef(w)||{};const ex=CEXO[w.id];const melee=!!(d.melee||(w.sk==='melee'))||(!d.id&&/1d6|2d6|3d6|4d6/.test(w.dmg)&&w.sk==='melee');
  let dmg=w.dmg||d.dmg||'';if(w.id==='malorian')dmg='5d6';if(w.id==='flamer')dmg='3d6';
  let sk=w.sk||d.sk||'hand';if(w.id==='flamer'||w.id==='railgun')sk='heavy';
  let rof=w.rof>1?w.rof:(d.rof||1);if(w.id==='hurricane'||w.id==='cowboy')rof=2;
  let mag=d.mag||0;const mi=(CPR.MAGS||{})[w.id];if(mi&&!ex){if(w.att.includes('drum'))mag=mi[2];else if(w.att.includes('ext'))mag=mi[1]}
  if(w.id==='hurricane')mag=16;if(w.id==='cowboy'||w.id==='railgun')mag=4;if(w.id==='helix')mag=40;if(w.id==='dartgun'||w.id==='microwaver'||w.id==='shrieker'||w.id==='taser')mag=8;
  const amT=w.id==='dartgun'?'arrow':d.am||'';
  return {d,ex,melee:!!d.melee,dmg,sk,rof,mag,amT,auto:/auto(\d)/.test(d.f||'')?+d.f.match(/auto(\d)/)[1]:w.id==='helix'?5:0,dv:d.dv||'',name:w.n||(ex?ex.n:d.n)||'Оружие',q:w.id==='malorian'||w.id==='kendachi'?'exc':w.q}}
function crCombat(p,c,K){
  const so=crRank(c,'solo')&&c.ab.solo?c.ab.solo:{};
  const armRow=l=>{const a=c.arm[l];const A=CAR[a.id];return `<tr><td>${l==='head'?'Голова':'Тело'}</td><td><select data-cf="arm" data-v="${l}"><option value="">— нет —</option>${CPR.ARMOR.map(x=>`<option value="${x[0]}" ${x[0]===a.id?'selected':''}>${esc(x[1])} (ОС ${x[2]}${x[3]?', −'+x[3]:''})</option>`).join('')}</select></td>
    <td>${A?`<button class="pm" data-cr="sp" data-v="${l}" data-d="-1">−</button><b>${a.sp}</b>/${A.sp}<button class="pm" data-cr="sp" data-v="${l}" data-d="1">+</button>`:'—'}</td>
    <td>${K.cyl?`<button class="pm" data-cr="cyl" data-v="${l}" data-d="-1">−</button><b>${c.cyl[l]}</b>/${K.cyl}<button class="pm" data-cr="cyl" data-v="${l}" data-d="1">+</button>`:'—'}</td><td><b class="cr-big2">${K.sp[l]}</b></td></tr>`};
  const brawl=(()=>{const b=K.eff.body;let d=(CPR.BRAWL||[]).find(x=>b<=x[0]);d=d?d[1]:'1d6';if(crHas(c,'cyberarm')&&d==='1d6')d='2d6';return d})();
  const wrow=(w,i)=>{const I=crWInfo(c,w);const isR=!I.melee&&I.d&&I.d.id&&CRW[I.d.id];const T=crSkTot(c,I.sk,K);
    const amKey=I.amT?I.amT+':'+w.am:'';const inv=amKey?(c.ammo[amKey]||0):0;
    const dvRow=isR?(CPR.DVS[I.dv]||[]):[];const dv=dvRow[w.band];
    return `<div class="cr-w"><div class="cr-wh"><input data-cf="w.n" data-i="${i}" value="${esc(w.n||I.name)}"><span class="muted">${esc(CSK[I.sk]?CSK[I.sk].n:'')} ${T.tot} · урон <b>${esc(I.dmg)}</b> · СКА ${I.rof}${I.ex?' · экзотика':''}</span>
      <select data-cf="w.q" data-i="${i}">${[['poor','Плохое'],['std','Обычное'],['exc','Отличное (+1)']].map(([k,l])=>`<option value="${k}" ${I.q===k?'selected':''}>${l}</option>`).join('')}</select><button class="pm" data-cr="wdel" data-i="${i}" title="Убрать">✕</button></div>
      ${isR?`<div class="row-btns">Дистанция <select data-cf="w.band" data-i="${i}">${CPR.BANDS.map((b,j)=>`<option value="${j}" ${j===w.band?'selected':''} ${dvRow[j]==null?'disabled':''}>${b} (${Math.ceil([6,12,25,50,100,200,400,800][j]/2)} гекс.) СЛ ${dvRow[j]??'—'}</option>`).join('')}</select>
        <label class="cr-chk"><input type="checkbox" data-cf="w.aim" data-i="${i}" ${w.aim?'checked':''}> прицельный (−8)</label>
        Магазин <b>${w.mag}</b>/${I.mag} <select data-cf="w.am" data-i="${i}">${CPR.AMT.map(a=>`<option value="${a[0]}" ${a[0]===w.am?'selected':''}>${esc(a[1])}</option>`).join('')}</select> <span class="muted">в запасе ${inv}</span>
        <button class="btn sm" data-cr="reload" data-i="${i}">Перезарядка</button></div>`:''}
      <div class="row-btns"><button class="btn red" data-cr="atk" data-i="${i}">${I.melee?'Атака (ЛВК + навык)':'Выстрел'}${dv!=null&&isR?' · СЛ '+dv:''}</button><button class="btn" data-cr="dmg" data-i="${i}">Урон ${esc(I.dmg)}</button>
        ${I.auto?`<button class="btn" data-cr="autofire" data-i="${i}">Автоогонь (10 патр.)</button><button class="btn" data-cr="supp" data-i="${i}">Подавление</button>`:''}
        ${I.d&&/shell/.test(I.d.f||'')?`<button class="btn" data-cr="shell" data-i="${i}">Дробь (СЛ 13, 3d6)</button>`:''}</div>
      ${isR&&!I.ex?`<div class="row-btns cr-small">Обвес (3 слота): ${CPR.ATT.map(a=>`<label class="cr-chk"><input type="checkbox" data-cf="w.att" data-i="${i}" data-v="${a[0]}" ${w.att.includes(a[0])?'checked':''}> ${esc(a[1])}</label>`).join('')}</div>`:''}
      ${I.ex?`<div class="muted cr-small">${esc(I.ex.d)}</div>`:''}</div>`};
  const ca=c.crit.map((x,i)=>{const r=(CPR.CRIT[x.l]||[]).find(y=>y[0]===x.r)||[];return `<tr><td>${x.l==='head'?'Голова':'Тело'}</td><td><b>${esc(r[1]||'')}</b><div class="muted">${esc(r[2]||'')}</div></td><td>${esc(r[3]||'')}</td><td>${esc(r[4]||'')}</td><td><button class="pm" data-cr="critdel" data-i="${i}">✕</button></td></tr>`}).join('');
  return `<h2>Состояние</h2><div class="cr-der">
    <div class="cr-dc"><b>Инициатива</b><div class="cr-big">РЕА ${K.eff.ref}${K.init?' '+sgn(K.init):''}</div><div class="muted">${crHas(c,'sandev')?`<label class="cr-chk"><input type="checkbox" data-cf="sand" ${c.sand?'checked':''}> Сандвистан включён (+3)</label>`:''}</div></div>
    <div class="cr-dc"><b>ОС головы / тела</b><div class="cr-big">${K.sp.head} / ${K.sp.body}</div></div>
    <div class="cr-dc"><b>Рукопашный бой</b><div class="cr-big">${brawl}</div><div><button class="btn sm" data-cr="brawl">Удар</button><button class="btn sm" data-cr="brawldmg">Урон</button></div></div>
    <div class="cr-dc"><b>Уклонение</b><div class="cr-big">${crSkTot(c,'evade',K).tot}</div><div class="muted">${K.eff.ref>=8?'РЕА 8+: можно уклоняться от пуль':'от пуль — только с РЕА 8+'}</div></div>
  </div>
  <h2>Получить урон</h2><div class="row-btns cr-dmgin"><input type="number" id="crDmgN" placeholder="урон" min="0">
    <select id="crDmgLoc"><option value="body">в тело</option><option value="head">в голову (прицельный ×2)</option></select>
    <select id="crDmgT"><option value="n">обычный</option><option value="half">ближний/боевые иск. (½ брони)</option><option value="ap">бронебойный (броня −2)</option><option value="ign">мимо брони (яд, огонь)</option></select>
    <label class="cr-chk"><input type="checkbox" id="crDmgCrit"> крит (+5 и травма)</label>${so.dd>=2?`<label class="cr-chk"><input type="checkbox" id="crDmgFirst" checked> первый урон в раунде (Отражение)</label>`:''}<button class="btn red" data-cr="takedmg">Применить</button>
    ${c.shield>=0?`<span class="ntag">Щит ${c.shield}/10 <button class="pm" data-cr="shield" data-d="-1">−</button><button class="pm" data-cr="shield" data-d="1">+</button></span>`:''}</div>
  <p class="muted cr-small">Урон минус ОС брони в месте попадания; если хоть 1 прошёл — ОС −1 (бронебойные −2). Смертельно раненый получает травму от каждой атаки. ${so.dd>=2?`Соло: первый урон в раунде −${Math.min(5,Math.floor(so.dd/2))}.`:''}</p>
  <h2>Броня</h2><table class="gl-tab cr-tab"><tr><th>Место</th><th>Броня</th><th>ОС</th><th>Кибер</th><th>Итог</th></tr>${armRow('head')}${armRow('body')}</table>
  <div class="row-btns"><button class="btn sm" data-cr="armfix">Починить броню</button>${c.shield<0?`<button class="btn sm" data-cr="shieldadd">＋ Пуленепробиваемый щит</button>`:`<button class="btn sm" data-cr="shielddel">Убрать щит</button>`}</div>
  <h2>Оружие</h2>${c.wpn.map(wrow).join('')||'<p class="muted">Нет оружия</p>'}
  <div class="row-btns"><select id="crWAdd"><optgroup label="Дальнего боя">${CPR.RW.map(w=>`<option value="${w[0]}">${esc(w[1])} — ${w[3]}</option>`).join('')}</optgroup>
    <optgroup label="Ближнего боя">${CPR.MW.map(w=>`<option value="${w[0]}">${esc(w[1])} — ${w[2]}</option>`).join('')}</optgroup><optgroup label="Экзотическое">${CPR.EXO.filter(x=>x[2]).map(x=>`<option value="${x[0]}">${esc(x[1])}</option>`).join('')}</optgroup></select>
    <label class="cr-chk"><input type="checkbox" id="crWBuy"> купить</label><button class="btn sm" data-cr="wadd">＋ Оружие</button></div>
  <h2>Критические травмы</h2>${ca?`<table class="gl-tab cr-tab"><tr><th></th><th>Травма</th><th>Быстрая помощь</th><th>Лечение</th><th></th></tr>${ca}</table>`:'<p class="muted">Нет</p>'}
  <div class="row-btns"><button class="btn sm" data-cr="critroll" data-v="body">Бросить травму тела (2d6)</button><button class="btn sm" data-cr="critroll" data-v="head">Бросить травму головы (2d6)</button>
    <select id="crCritSel">${['body','head'].map(l=>(CPR.CRIT[l]||[]).map(r=>`<option value="${l}:${r[0]}">${l==='head'?'Голова':'Тело'} ${r[0]} — ${esc(r[1])}</option>`).join('')).join('')}</select><button class="btn sm" data-cr="critadd">＋</button></div>
  <h2>Лечение</h2><div class="row-btns"><button class="btn sm" data-cr="rest">День отдыха (+${crHas(c,'antibody')?K.eff.body*2:K.eff.body} ПЗ)</button><button class="btn sm" data-cr="speedheal">Спидхил (+${K.eff.body+K.eff.will})</button>
    <label class="cr-chk"><input type="checkbox" data-cf="stim" ${c.stim?'checked':''}> Стимулятор / без штрафа тяжёлого ранения</label></div>
  <p class="muted cr-small">Стабилизация: Лёгкое — СЛ 10, Тяжёлое — СЛ 13, Смертельное — СЛ 15 (Первая помощь или Парамедик). Стабилизированный восстанавливает ТЕЛ ПЗ за день отдыха. Спасбросок: d10 + штраф не больше ТЕЛ; 10 — всегда провал; каждый спасбросок увеличивает штраф на 1 до стабилизации.</p>`}

/* ---------- Снаряжение ---------- */
function crGear(p,c,K){
  const amRows=Object.entries(c.ammo).filter(([k,v])=>v>0||true).map(([k,v])=>{const [t,a]=k.split(':');return `<span class="ntag">${esc(CAMMO[t])} · ${esc((CAMT[a]||{}).n||a)}: <button class="pm" data-cr="ammo" data-v="${esc(k)}" data-d="-10">−</button><b>${v}</b><button class="pm" data-cr="ammo" data-v="${esc(k)}" data-d="10">+</button></span>`}).join(' ');
  const H=(CPR.HOUSING||[]).find(h=>h[0]===c.house)||[],L=(CPR.LIFESTYLE||[]).find(h=>h[0]===c.life)||[];
  const deckQ=c.deck.q||(c.gear.find(g=>/^deck/.test(g.id))||{}).id||'';const slots=(deckQ==='deckp'?5:deckQ==='decke'?9:deckQ?7:0)+(crHas(c,'armdeck')?1:0)+(c.arm.body.id==='bodyw'?1:0);
  const usedSl=c.deck.pr.reduce((a,x)=>a+1,0)+c.deck.hw.reduce((a,x)=>a+(CHW[x]?CHW[x].sl:1),0);
  return `<h2>Деньги</h2><div class="row-btns"><span class="cr-big ${c.eb<0?'cr-no':''}">${c.eb} eb</span>${c.eb<0?'<span class="cr-warn">в минусе</span>':''}${!c.done&&c.method==='cp'?`<span class="muted">+ 800eb только на стиль при создании</span>`:''}<input type="number" id="crEb" placeholder="сумма"><button class="btn sm" data-cr="eb" data-d="1">＋ Получить</button><button class="btn sm" data-cr="eb" data-d="-1">− Потратить</button></div>
  <h2>Жильё и образ жизни</h2><div class="row-btns"><select data-cf="house">${CPR.HOUSING.map(h=>`<option value="${h[0]}" ${h[0]===c.house?'selected':''}>${esc(h[1])}${h[2]?` — ${h[2]}eb/мес`:''}</option>`).join('')}</select>
    <select data-cf="life">${CPR.LIFESTYLE.map(h=>`<option value="${h[0]}" ${h[0]===c.life?'selected':''}>${esc(h[1])} — ${h[2]}eb/мес</option>`).join('')}</select>
    <span class="muted">в месяц: ${(H[2]||0)+(L[2]||0)}eb</span><button class="btn sm" data-cr="month">Оплатить месяц</button></div><p class="muted cr-small">${esc(L[3]||'')}</p>
  <h2>Боеприпасы</h2><div>${amRows||'<span class="muted">Нет</span>'}</div>
  <div class="row-btns"><select id="crAmT">${CPR.AMMO.map(a=>`<option value="${a[0]}">${esc(a[1])}</option>`).join('')}</select><select id="crAmA">${CPR.AMT.map(a=>`<option value="${a[0]}">${esc(a[1])} — ${a[2]}eb</option>`).join('')}</select>
    <input type="number" id="crAmN" value="10" class="cr-sm"><label class="cr-chk"><input type="checkbox" id="crAmBuy"> купить</label><button class="btn sm" data-cr="ammoadd">＋</button></div>
  <p class="muted cr-small">Патроны продаются по 10 штук, гранаты и ракеты — поштучно (цена указана за 10 / за штуку).</p>
  <h2>Снаряжение</h2><table class="gl-tab cr-tab"><tr><th>Предмет</th><th>Кол-во</th><th>Что делает</th><th></th></tr>${c.gear.map((g,i)=>{const G=CGR[g.id];return `<tr><td>${G?esc(G.n):`<input data-cf="g.n" data-i="${i}" value="${esc(g.n)}">`}</td><td><button class="pm" data-cr="gq" data-i="${i}" data-d="-1">−</button>${g.q}<button class="pm" data-cr="gq" data-i="${i}" data-d="1">+</button></td><td class="muted">${esc(G?G.d:'')}</td><td><button class="pm" data-cr="gdel" data-i="${i}">✕</button></td></tr>`}).join('')}</table>
  <div class="row-btns"><select id="crGAdd"><option value="">Своё…</option>${CPR.GEAR.map(g=>`<option value="${g[0]}">${esc(g[1])} — ${g[2]}eb</option>`).join('')}</select><label class="cr-chk"><input type="checkbox" id="crGBuy"> купить</label><button class="btn sm" data-cr="gadd">＋</button></div>
  <h2>Кибердека и программы</h2><div class="row-btns"><select data-cf="deckq"><option value="">— нет —</option>${[['deckp','Плохая (5)'],['deck','Обычная (7)'],['decke','Отличная (9)']].map(([k,l])=>`<option value="${k}" ${k===deckQ?'selected':''}>${l}</option>`).join('')}</select>
    <span class="muted">слотов ${usedSl}/${slots}${crHas(c,'armdeck')?' (+1 рука)':''}${c.arm.body.id==='bodyw'?' (+1 Бодивейт)':''}</span>${crHas(c,'plugs')?'':' <span class="cr-warn">нужен личный порт</span>'}</div>
  <table class="gl-tab cr-tab"><tr><th>Программа</th><th>Класс</th><th>АТК/ЗАЩ/REZ</th><th>Эффект</th><th></th></tr>${c.deck.pr.map((x,i)=>{const P=CPRG[x];return `<tr><td>${esc(P.n)}</td><td>${esc(P.cls)}</td><td>${P.atk}/${P.def}/${P.rez}</td><td class="muted">${esc(P.d)}</td><td><button class="pm" data-cr="prdel" data-i="${i}">✕</button></td></tr>`}).join('')}
   ${c.deck.hw.map((x,i)=>{const P=CHW[x];return `<tr><td>${esc(P.n)}</td><td>Оборудование (${P.sl} сл.)</td><td>—</td><td class="muted">${esc(P.d)}</td><td><button class="pm" data-cr="hwdel" data-i="${i}">✕</button></td></tr>`}).join('')}</table>
  <div class="row-btns"><select id="crPrAdd"><optgroup label="Программы">${CPR.PROG.map(x=>`<option value="p:${x[0]}">${esc(x[1])} — ${x[6]}eb</option>`).join('')}</optgroup><optgroup label="Оборудование">${CPR.HW.map(x=>`<option value="h:${x[0]}">${esc(x[1])} — ${x[3]}eb</option>`).join('')}</optgroup></select><label class="cr-chk"><input type="checkbox" id="crPrBuy"> купить</label><button class="btn sm" data-cr="pradd">＋</button></div>
  <h2>Одежда и стиль</h2><table class="gl-tab cr-tab"><tr><th>Стиль</th><th>Вещь</th><th>Кол-во</th><th></th></tr>${c.fash.map((f,i)=>`<tr><td>${esc(CPR.FASHION[f.s][0])}</td><td>${esc(CPR.FASHION_ITEMS[f.i])}</td><td>${f.q}</td><td><button class="pm" data-cr="fdel" data-i="${i}">✕</button></td></tr>`).join('')}</table>
  <div class="row-btns"><select id="crFs">${CPR.FASHION.map((f,i)=>`<option value="${i}">${esc(f[0])} — ${esc(f[1])}</option>`).join('')}</select><select id="crFi">${CPR.FASHION_ITEMS.map((f,i)=>`<option value="${i}">${esc(f)}</option>`).join('')}</select><label class="cr-chk"><input type="checkbox" id="crFBuy"> купить</label><button class="btn sm" data-cr="fadd">＋</button></div>
  <h2>Уличные наркотики</h2>${crTbl(['Наркотик','Цена','Действие','Эффект','СЛ зависим.','Зависимость'],CPR.DRUGS.map(d=>[d[1],d[2]+'eb',d[3],d[4],d[5],d[6]]))}
  <p class="muted cr-small">Стр. 99–102, 340–357, 368–371, 377.</p>`}

/* ---------- Киберимпланты ---------- */
function crCyKids(c,u){return c.cy.filter(x=>x.p===u)}
function crCySlots(c,x){const d=CCY[x.id];let s=d.id==='nlink'?5:d.id==='cybereye'?3:d.id==='caudio'?3:d.id==='cyberarm'?4:d.id==='cyberleg'?3:0;if(d.id==='caudio'&&crHas(c,'sensarray'))s+=5;return s}
function crCyUsed(c,u){return crCyKids(c,u).reduce((a,k)=>a+(CCY[k.id].par==='chipsock'?0:CCOVER.has(k.id)?0:CCY[k.id].sl||1),0)}
function crCyber(p,c,K){
  const tree=x=>{const d=CCY[x.id];const kids=crCyKids(c,x.u);const sl=crCySlots(c,x);
    return `<div class="cr-cy"><div class="cr-cyh"><b>${esc(d.n)}</b>${x.s?` <span class="ntag">${esc(skName(x.s))}</span>`:''} <span class="muted">ПЧ ${x.hl} · ${esc(d.ins)}${sl?` · слоты ${crCyUsed(c,x.u)}/${sl}`:''}</span><button class="pm" data-cr="cydel" data-v="${x.u}" title="Удалить (человечность не возвращается)">✕</button></div>
      <div class="muted cr-small">${esc(d.d)}</div>${kids.length?`<div class="cr-cyk">${kids.map(tree).join('')}</div>`:''}</div>`};
  const roots=c.cy.filter(x=>!x.p||x.p==='meat');
  const byCat={};roots.forEach(x=>{const k=CCY[x.id].cat;(byCat[k]=byCat[k]||[]).push(x)});
  const free7=k=>c.cy.filter(x=>CCY[x.id].cat===k&&!x.p).length;
  const sel=CPR.CAT.map(([k,n])=>`<optgroup label="${esc(n)}">${CPR.CY.filter(x=>x[2]===k).map(x=>`<option value="${x[0]}">${esc(x[1])} — ${x[6]}eb, ПЧ ${x[7]}${x[8]?' ('+x[8]+')':''}</option>`).join('')}</optgroup>`).join('');
  const fnd=c.cy.filter(x=>crCySlots(c,x)||['cyberarm','cyberleg','chipsock'].includes(x.id)).map(x=>`<option value="${x.u}">${esc(CCY[x.id].n)} #${x.u.slice(0,3)}</option>`).join('');
  return `<h2>Человечность ${c.hum} / ${K.humMax} <span class="muted cr-small">ЭМП ${K.eff.emp}</span></h2>
  ${c.hum<=0?'<p class="cr-warn">Киберпсихоз!</p>':''}
  <div class="cr-cyform"><select id="crCyAdd">${sel}</select><select id="crCyPar"><option value="">(основа / сам по себе)</option><option value="meat">в мясную руку/ногу</option>${fnd}</select>
    <select id="crCyHl"><option value="fix">ПЧ фиксированная (создание)</option><option value="roll">ПЧ бросить кости</option></select><span class="muted cr-small">щепка навыка:</span><select id="crCySk" title="Только для «Щепки навыка»">${Object.values(CSK).map(s=>`<option value="${s.id}">${esc(s.n)}</option>`).join('')}</select>
    <label class="cr-chk"><input type="checkbox" id="crCyBuy"> купить</label><button class="btn red" data-cr="cyadd">Установить</button></div>
  <p class="muted cr-small">Опция ставится в основу (нейролинк 5 слотов, киберглаз 3, кибераудио 3, киберрука 4, кибернога 3); стилевые, внутренние и внешние — до 7 каждой группы. Щепки — в разъём для щепок. Парные модули (глаза, ноги) покупаются дважды. Модули «можно в мясную руку» ставьте с выбором «в мясную руку/ногу».</p>
  ${CPR.CAT.map(([k,n,f,sl])=>byCat[k]?`<h3>${esc(n)}${!f&&sl?` <span class="muted cr-small">${free7(k)}/${sl}</span>`:''}</h3>${byCat[k].map(tree).join('')}`:'').join('')||'<p class="muted">Имплантов нет</p>'}`}

/* ---------- Жизненный путь ---------- */
function crLpSel(c,key,rows,isObj){const v=c.lp[key];return `<select data-cf="lp" data-v="${esc(key)}"><option value="">—</option>${rows.map((r,i)=>`<option value="${i+1}" ${v===i+1?'selected':''}>${i+1}. ${esc(Array.isArray(r)?r[0]:r)}</option>`).join('')}</select>`}
function crLife(p,c,K){
  const one=t=>{if(t.count||t.multi)return '';const v=c.lp[t.id];const r=v?t.rows[v-1]:null;
    return `<div class="cr-lp"><b>${esc(t.n)}</b> <button class="btn sm" data-cr="lproll" data-v="${t.id}">🎲 ${t.d}</button> ${crLpSel(c,t.id,t.rows)}${r&&Array.isArray(r)?`<div class="muted">${esc(r[1])}</div>`:''}
      ${t.id==='origin'&&v?`<div class="row-btns">Родной язык (уровень 4): <input data-cf="langFree" value="${esc(c.lp.langFree||'')}" placeholder="например, Русский"></div>`:''}${t.note&&!v?`<div class="muted cr-small">${esc(t.note)}</div>`:''}</div>`};
  const lst=(id,label)=>{const t=CLP[id];const arr=Array.isArray(c.lp[id+'s'])?c.lp[id+'s']:[];
    return `<div class="cr-lp"><b>${esc(label)}</b> <button class="btn sm" data-cr="lpcount" data-v="${id}">🎲 сколько (1d10 − 7)</button> <button class="btn sm" data-cr="lpadd" data-v="${id}">＋</button>
      ${arr.map((e,i)=>{if(id==='enemy'){const ee=Array.isArray(e)?e:[0,0,0,0];return `<div class="cr-lpi">${t.multi.map((m,j)=>`<select data-cf="lpm" data-v="${id}" data-i="${i}" data-j="${j}"><option value="0">${esc(m[0])}…</option>${m[1].map((x,q)=>`<option value="${q+1}" ${ee[j]===q+1?'selected':''}>${esc(x)}</option>`).join('')}</select>`).join('')}
         <select data-cf="lpm" data-v="${id}" data-i="${i}" data-j="3"><option value="0">Кто пострадал…</option><option value="1" ${ee[3]===1?'selected':''}>Вы</option><option value="2" ${ee[3]===2?'selected':''}>Они</option></select><button class="btn sm" data-cr="lpre" data-v="${id}" data-i="${i}">🎲</button><button class="pm" data-cr="lpdel" data-v="${id}" data-i="${i}">✕</button></div>`}
        const v=typeof e==='number'?e:0;return `<div class="cr-lpi"><select data-cf="lpl" data-v="${id}" data-i="${i}"><option value="0">—</option>${t.rows.map((x,q)=>`<option value="${q+1}" ${v===q+1?'selected':''}>${esc(x)}</option>`).join('')}</select><button class="btn sm" data-cr="lpre" data-v="${id}" data-i="${i}">🎲</button><button class="pm" data-cr="lpdel" data-v="${id}" data-i="${i}">✕</button></div>`}).join('')}</div>`};
  const R=CROLE[c.role],rl=(CPR.LPR||{})[c.role]||[];
  return `<h2>Жизненный путь <button class="btn sm" data-cr="lpall">🎲 Бросить всё пустое</button></h2><p class="muted cr-small">Стр. 44–53. Если выпало то, что не подходит персонажу, выберите другое.</p>
  <div class="cr-lps">${CPR.LP.filter(t=>!['friend','enemy','love','revenge'].includes(t.id)).map(one).join('')}</div>
  <h3>Друзья, враги, любовь</h3><div class="cr-lps">${lst('friend','Друзья')}${lst('enemy','Враги')}${one({...CLP.revenge})}${lst('love','Трагическая любовь')}</div>
  <h2>Ролевой путь: ${esc(R.n)}</h2><div class="cr-lps">${rl.map((t,i)=>{const key='r_'+c.role+'_'+i;const v=c.lp[key];return `<div class="cr-lp"><b>${esc(t[0])}</b> ${t[1]!=='выбор'?`<button class="btn sm" data-cr="lproll" data-v="${key}">🎲 ${t[1]}</button>`:''} ${crLpSel(c,key,t[2])}</div>`}).join('')}</div>`}

/* ---------- Создание ---------- */
function crKitHtml(c,R){const kit=R.kit;const ch=c.cr.kit||{};let n=0;
  const opt=(lst,pre)=>lst.map(x=>{const alts=x.split('|');const i=n++;return alts.length>1?`<select data-cf="kit" data-v="${i}">${alts.map((a,j)=>`<option value="${j}" ${(ch[i]||0)===j?'selected':''}>${esc(crKitName(a))}</option>`).join('')}</select>`:`<span class="ntag">${esc(crKitName(x))}</span>`}).join(' ');
  return `<div><b>Оружие и броня:</b> ${opt(kit.w)} <span class="ntag">Лёгкий бронекостюм (тело, ОС 11)</span> <span class="ntag">Лёгкий бронекостюм (голова, ОС 11)</span></div>
    <div><b>Снаряжение:</b> ${opt(kit.g)}</div><div><b>Одежда:</b> ${esc(kit.f)}</div><div><b>Киберимпланты:</b> ${opt(kit.cy)} <span class="muted">(ПЧ всего ${kit.hl})</span></div><div><b>Деньги:</b> 500eb</div>`}
function crKitName(a){const k=a.split(':');if(k[0]==='am')return `Патроны ${CAMMO[k[1]]||k[1]} ×${k[3]}${k[2]!=='basic'?' ('+((CAMT[k[2]]||{}).n||'')+')':''}`;if(k[0]==='g')return `Граната (${({flashbang:'светошумовая',teargas:'слезоточивая',smoke:'дымовая'})[k[1]]||k[1]})${k[2]?' ×'+k[2]:''}`;
  if(k[0]==='pr')return 'Программа «'+((CPRG[k[1]]||{}).n||k[1])+'»';const d=CRW[k[0]]||CMW[k[0]]||CGR[k[0]]||CCY[k[0]];return (d?d.n:k[0])+(k[1]?' ×'+k[1]:'')}
function crMake(p,c,K){const R=CROLE[c.role];
  const m=c.method;const meth=[['sr','Уличная крыса (шаблоны)','Бросок 1d10 по таблице роли: характеристики и навыки готовые. Снаряжение и импланты по роли, 500eb.'],
    ['er','Эджраннер (быстро и грязно)','Каждая характеристика — отдельный 1d10 по колонке таблицы роли. 86 очков на 20 навыков роли (2–6). Снаряжение по роли, 500eb.'],
    ['cp','Полный пакет (калькуляция)','Очки характеристик (обычно 62, каждая 2–8), 86 очков навыков на любые навыки (2–6, базовые не ниже 2). 2550eb на всё + 800eb только на стиль.']];
  return `<h2>Создание персонажа <span class="muted cr-small">стр. 40–117</span></h2>
  ${c.done?`<p>Персонаж создан методом «${esc((meth.find(x=>x[0]===m)||['',''])[1])}». Дальше — развитие за очки улучшения (навыки и ранг роли).</p><button class="btn" data-cr="undone">Вернуться к созданию</button>`:`
  <ol class="cr-steps"><li>Выберите роль: <select data-cf="role">${CPR.ROLES.map(r=>`<option value="${r.id}" ${r.id===c.role?'selected':''}>${esc(r.n)}</option>`).join('')}</select> — ролевая способность «${esc(R.ab)}» начинается с ранга 4.</li>
   <li>Пройдите жизненный путь (вкладка «Жизненный путь»): регион даёт родной язык на уровне 4.</li>
   <li>Выберите метод:<div class="cr-meth">${meth.map(([k,n,d])=>`<label class="cr-mt ${m===k?'on':''}"><input type="radio" name="crm" data-cf="method" value="${k}" ${m===k?'checked':''}> <b>${n}</b><div class="muted cr-small">${d}</div></label>`).join('')}</div></li></ol>
  ${m==='sr'?`<h3>Уличная крыса</h3><div class="row-btns"><button class="btn red" data-cr="srroll">🎲 Бросить шаблон 1d10</button>${CPR.ROLES&&R.stats.map((r,i)=>`<button class="btn sm" data-cr="srpick" data-v="${i}" title="${CSTK.map((k,j)=>CRS[k][1]+' '+r[j]).join(', ')}">${i+1}</button>`).join('')}</div>
     ${crTbl(['1d10',...CPR.STATS.map(s=>s[1])],R.stats.map((r,i)=>[i+1,...r]))}`:''}
  ${m==='er'?`<h3>Эджраннер</h3><div class="row-btns"><button class="btn red" data-cr="erroll">🎲 Бросить каждую характеристику</button></div><p class="muted">Навыки: вкладка «Навыки» (86 очков на навыки роли). Стартовые уровни сейчас: все навыки роли по 2.</p><button class="btn sm" data-cr="erskreset">Сбросить навыки роли на 2</button>`:''}
  ${m==='cp'?`<h3>Полный пакет</h3><div class="row-btns">Очки характеристик: <select data-cf="crpts">${CPR.STATPTS.map(([n,v])=>`<option value="${v}" ${c.cr.pts===v?'selected':''}>${v} — ${esc(n)}</option>`).join('')}</select> <span>потрачено ${CSTK.reduce((a,k)=>a+c.st[k],0)}</span></div>
     <p class="muted">Характеристики меняйте на вкладке «Главная», навыки — на «Навыки». Покупки: галочка «купить» у оружия, снаряжения и имплантов списывает eb. ПЧ при создании — фиксированная.</p>
     <div class="row-btns"><button class="btn" data-cr="cpstart">Начать: характеристики по 6, навыки базовые 2, 2550eb</button></div>`:''}
  ${m==='sr'||m==='er'?`<h3>Стартовый набор роли</h3>${crKitHtml(c,R)}<div class="row-btns"><button class="btn red" data-cr="kitapply">Выдать набор (заменит оружие, броню, снаряжение и импланты)</button></div>`:''}
  ${m?`<h3>Проверка</h3>${crCheck(c).map(x=>`<div class="${x[0]?'cr-ok':'cr-warn'}">${x[0]?'✓':'⚠'} ${esc(x[1])}</div>`).join('')}<div class="row-btns"><button class="btn red" data-cr="finish">Завершить создание</button></div>`:''}`}`}
function crCheck(c){const out=[];const s=CSTK.reduce((a,k)=>a+c.st[k],0);
  if(c.method==='cp'){out.push([s===c.cr.pts,`Очки характеристик: ${s}/${c.cr.pts}`]);out.push([CSTK.every(k=>c.st[k]>=2&&c.st[k]<=8),'Каждая характеристика от 2 до 8'])}
  if(c.method==='er'||c.method==='cp'){const b=crSkBudget(c);out.push([b.used===86,`Очки навыков: ${b.used}/86`]);out.push([Object.entries(c.sk).every(([k,v])=>{const {id,spec}=skP(k);return v<=6||(id==='lang'&&spec===c.lp.langFree&&v<=10)}),'Навыки не выше 6']);
    out.push([Object.values(CSK).filter(x=>x.basic).every(x=>Object.entries(c.sk).some(([k,v])=>skP(k).id===x.id&&v>=2)),'Базовые навыки не ниже 2'])}
  out.push([!!c.lp.origin,'Жизненный путь: регион выбран'+(c.lp.langFree?` (язык ${c.lp.langFree} 4)`:'')]);
  out.push([c.rank===4||c.free,'Ранг ролевой способности 4']);return out}

function crNotes(p,c){return `<h2>Заметки</h2><textarea class="cr-notes" data-cf="notes" placeholder="Внешность, контакты, долги, планы…">${esc(c.notes)}</textarea>`}

/* ---------- действия: клики ---------- */
function crRe(){const m=document.getElementById('main');const y=window.scrollY,my=m?m.scrollTop:0;renderMain();pcSave();try{window.scrollTo(0,y);if(m)m.scrollTop=my}catch(e){}}
function crBuy(c,cost,on){if(on)c.eb-=cost}
function crAddCy(c,id,par,hlMode,sk){const d=CCY[id];if(!d)return 'Нет такого импланта';
  if(!par&&d.par&&!CCOVER.has(id)){const fits=c.cy.filter(x=>x.id===d.par||(d.cat==='arm'&&x.id==='cyberarm')||(d.cat==='leg'&&x.id==='cyberleg'));
    const free=fits.find(x=>d.par==='chipsock'||crCyUsed(c,x.u)+(d.sl||1)<=crCySlots(c,x));par=free?free.u:(CMEAT.has(id)?'meat':(fits[0]||{}).u||'')}
  if(!par&&CCOVER.has(id)){const f=c.cy.find(x=>x.id==='cyberarm'||x.id==='cyberleg');par=f?f.u:''}
  if(d.par&&!CCOVER.has(id)){let pu=par;if(pu==='meat'){if(!CMEAT.has(id))return 'Этот модуль нельзя поставить в мясную руку/ногу'}
    else{const P=c.cy.find(x=>x.u===pu);if(!P)return `Нужна основа: ${CCY[d.par].n}`;if(P.id!==d.par&&!(d.par==='cyberarm'&&P.id==='cyberarm')&&!(d.cat==='leg'&&P.id==='cyberleg'))return `Модуль ставится в «${CCY[d.par].n}», а не в «${CCY[P.id].n}»`;
      if(d.par!=='chipsock'){const sl=crCySlots(c,P);if(crCyUsed(c,P.u)+(d.sl||1)>sl)return `Нет свободных слотов в «${CCY[P.id].n}»`}}}
  else if(CCOVER.has(id)){const P=c.cy.find(x=>x.u===par);if(!P||!['cyberarm','cyberleg'].includes(P.id))return 'Покрытие ставится на киберруку или киберногу'}
  else{const cat=CCAT[d.cat];if(cat&&!cat.found&&cat.sl&&c.cy.filter(x=>CCY[x.id].cat===d.cat&&!x.p).length>=cat.sl)return `В группе «${cat.n}» уже ${cat.sl} имплантов`;
    if(['caudio','shoulders','multioptic','sensarray'].includes(id)&&crHas(c,id))return 'Можно только один';
    if((id==='kerenz'||id==='sandev')&&(crHas(c,'kerenz')||crHas(c,'sandev')))return 'Ускоритель может быть только один';
    if(id==='exosig'&&(c.st.body<6||!crHas(c,'muscle')))return 'Нужны ТЕЛ 6 и искусственные мышцы';if(id==='exobeta'&&(c.st.body<8||crHas(c,'muscle')<2))return 'Нужны ТЕЛ 8 и двое искусственных мышц'}
  if((id==='kerenz'||id==='sandev')&&(crHas(c,'kerenz')||crHas(c,'sandev')))return 'Ускоритель может быть только один';
  if(d.cat==='neural'&&d.par==='nlink'&&!crHas(c,'nlink'))return 'Нужен нейролинк';
  let hl=d.hl;let txt=`ПЧ ${hl} (фиксированная)`;if(hlMode==='roll'&&d.hld){const dd=crDice(d.hld);const a=crRollDice(dd.n);let s=a.reduce((x,y)=>x+y,0);if(dd.half)s=Math.ceil(s/2);hl=s;txt=`ПЧ ${d.hld} [${a.join(', ')}] = ${hl}`}
  const u=crU();c.cy.push({u,id,p:d.par||CCOVER.has(id)?par:'',hl,s:id==='skillchip'?sk:''});c.hum-=hl;
  if(id==='subarmor'||id==='skinweave'){c.cyl.head=Math.max(c.cyl.head,d.fx.sp);c.cyl.body=Math.max(c.cyl.body,d.fx.sp)}
  return {txt}}
function crApplyKit(p,c){const R=CROLE[c.role],kit=R.kit,ch=c.cr.kit||{};let n=0;const pick=x=>{const a=x.split('|');return a[ch[n++]||0]||a[0]};
  c.wpn=[];c.gear=[];c.ammo={};c.cy=[];c.deck={q:'',pr:[],hw:[]};c.shield=-1;
  kit.w.forEach(x=>{const a=pick(x);const k=a.split(':');
    if(k[0]==='am'){const key=k[1]+':'+k[2];c.ammo[key]=(c.ammo[key]||0)+(+k[3]||0)}
    else if(k[0]==='g'){const key='gren:'+({flashbang:'flash',teargas:'tear',smoke:'smoke'}[k[1]]||'basic');c.ammo[key]=(c.ammo[key]||0)+(+k[2]||1)}
    else if(k[0]==='shield')c.shield=10;
    else if(CRW[k[0]]||CMW[k[0]])c.wpn.push(crNewW(k[0]))});
  kit.g.forEach(x=>{const a=pick(x);const k=a.split(':');if(k[0]==='pr'){c.deck.pr.push(k[1]);return}if(/^deck/.test(k[0]))c.deck.q=k[0];if(k[0]==='shield'){c.shield=10;return}
    const g=c.gear.find(y=>y.id===k[0]);if(g)g.q+=(+k[1]||1);else c.gear.push({id:k[0],n:'',q:+k[1]||1})});
  c.arm={head:{id:'ljack',sp:11},body:{id:'ljack',sp:11}};
  c.hum=c.st.emp*10;const nl={};
  kit.cy.forEach(x=>{const id=pick(x);const d=CCY[id];let par='';
    if(d.par){let P=c.cy.find(y=>y.id===d.par);if(!P&&CMEAT.has(id))par='meat';else{if(!P){const pu=crU();c.cy.push({u:pu,id:d.par,p:'',hl:0,s:''});P=c.cy[c.cy.length-1]}par=P.u}}
    c.cy.push({u:crU(),id,p:par,hl:0,s:''})});
  c.hum=c.st.emp*10-kit.hl;c.eb=500;
  c.wpn.forEach(w=>{const I=crWInfo(c,w);if(I.amT){const key=I.amT+':basic';const take=Math.min(I.mag,c.ammo[key]||0);w.mag=take;c.ammo[key]=(c.ammo[key]||0)-take}})}
function crNewW(id){return {u:crU(),id,n:'',q:'std',att:[],mag:0,am:'basic',band:1,aim:0,dmg:'',rof:1,sk:'',note:'',cyb:0}}
function crSetSr(c,row){const R=CROLE[c.role];CSTK.forEach((k,j)=>c.st[k]=R.stats[row][j]);c.luck=c.st.luck;c.hum=c.st.emp*10;c.hp=null;
  c.sk={};R.sr.forEach(([id,spec,lv])=>{c.sk[skK(id,spec)]=lv});if(c.lp.langFree)c.sk['lang|'+c.lp.langFree]=4;c.rank=4}
function crErSk(c){const R=CROLE[c.role];c.sk={};R.sr.forEach(([id,spec])=>{c.sk[skK(id,spec)]=2});if(c.lp.langFree)c.sk['lang|'+c.lp.langFree]=4}

document.addEventListener('click',e=>{const b=e.target.closest('[data-cr]');if(!b||b.disabled)return;if(!document.querySelector('.cr-sheet'))return;
  const p=curP();if(!p)return;const c=crOf(p);const a=b.dataset.cr,v=b.dataset.v,d=+b.dataset.d||0,i=+b.dataset.i;const K=crCalc(c);const val=id=>{const el=document.getElementById(id);return el?el.value:''};const chk=id=>{const el=document.getElementById(id);return !!(el&&el.checked)};
  if(a==='sub'){c.sub=v;CRLAST=null;crRe();window.scrollTo(0,0);return}
  if(a==='hp'){c.hp=Math.max(-99,Math.min(K.hpMax,(c.hp??K.hpMax)+d))}
  else if(a==='nxl')c.nx.luck=Math.max(0,Math.min(c.luck,c.nx.luck+d));
  else if(a==='nxm')c.nx.mod=Math.max(-30,Math.min(30,c.nx.mod+d));
  else if(a==='luck')c.luck=Math.max(0,Math.min(c.st.luck,c.luck+d));
  else if(a==='sess'){c.luck=c.st.luck;CRLAST={t:'Новая сессия',html:'Удача восстановлена'}}
  else if(a==='st'){c.st[v]=Math.max(c.free?0:2,Math.min(c.free?20:8,c.st[v]+d));if(v==='luck')c.luck=c.st.luck;if(v==='emp'&&!c.done)c.hum=c.st.emp*10-c.cy.reduce((s,x)=>s+x.hl,0);c.hp=null}
  else if(a==='dsp')c.dsPen=Math.max(0,c.dsPen+d);
  else if(a==='hum')c.hum=Math.max(-99,Math.min(K.humMax,c.hum+d));
  else if(a==='rep')c.rep=Math.max(0,Math.min(10,c.rep+d));
  else if(a==='ipadd'){const n=Math.round(+val('crIpAdd')||0);if(n){c.ip=Math.max(0,c.ip+n);if(n>0)c.ipT+=n;CRLAST={t:'Очки улучшения',html:`${sgn(n)} ОУ`}}}
  else if(a==='rstat'){const s=CRS[v];crRoll(p,c,'Проверка '+s[1],[[s[1],v==='luck'?c.luck:K.eff[v]],['штраф',K.all]])}
  else if(a==='rsk'){const T=crSkTot(c,v,K);const s=CSK[skP(v).id]||{st:'tech'};crRoll(p,c,skName(v),[[CRS[s.st][1],T.stat],['навык',T.lv],['бонусы',T.mod],['штраф',K.all]],{note:T.src.length?esc(T.src.map(x=>x[0]+' '+sgn(x[1])).join(', ')):''})}
  else if(a==='init'){const r=crRoll(p,c,'Инициатива',[['РЕА',K.eff.ref],['бонусы',K.init]]);c.init=r.tot}
  else if(a==='ds'){const r=rnd(10),need=K.dsBase,tot=r+K.dsPen;const ok=r!==10&&tot<=need;c.dsPen++;const html=`d10 [${r}] + штраф ${K.dsPen} = <b class="cr-tot">${tot}</b> против ТЕЛ ${need} → ${ok?'<b class="cr-ok">жив</b>':'<b class="cr-no">МЁРТВ</b>'}`;CRLAST={t:'Спасбросок от смерти',html};crLog(crWho(p,c),'Спасбросок от смерти',html)}
  else if(a==='stab'){if(c.hp<1)c.hp=1;c.dsPen=0;CRLAST={t:'Стабилизация',html:'Штраф спасброска сброшен'+(K.wound===3?', ПЗ = 1':'')}}
  else if(a==='sk'){const cur=c.sk[v]||0;let nv=cur+d;const id=skP(v).id;
    if(!c.free){const mn=(CSK[id]&&CSK[id].basic)||(c.method==='er'&&crSkRoleSet(c).has(id))?2:0;if(nv>6||nv<mn)return;const b=crSkBudget(c);if(d>0&&b.used+crSkCost(id,1)>86)return}
    nv=Math.max(0,Math.min(10,nv));if(nv)c.sk[v]=nv;else delete c.sk[v]}
  else if(a==='skip'){const id=skP(v).id,lv=c.sk[v]||0;const cost=CPR.IPCOST[CSK[id].x2?'skill2':'skill'][lv];if(c.ip<cost||lv>=10)return;c.ip-=cost;c.sk[v]=lv+1;CRLAST={t:skName(v),html:`повышен до ${lv+1} за ${cost} ОУ`}}
  else if(a==='skdel')delete c.sk[v];
  else if(a==='skadd'){const id=val('crMulti'),spec=crS(val('crMultiSpec'),60).replace(/\|/g,'/').trim();if(!CSK[id]||!spec)return;const k=skK(id,spec);if(!(k in c.sk))c.sk[k]=c.free||c.done?1:2}
  else if(a==='skcat'){CR_SKCAT=v;LS.set('cr_skcat',v)}
  else if(a==='rank')c.rank=Math.max(1,Math.min(10,c.rank+d));
  else if(a==='rankip'){const cost=CPR.IPCOST.role[c.rank];if(c.ip<cost||c.rank>=10)return;c.ip-=cost;c.rank++}
  else if(a==='r2add'){const id=val('crR2');if(!CROLE[id]||c.ip<60&&!c.free)return;if(!c.free)c.ip-=60;c.roles2.push({id,rank:1})}
  else if(a==='r2'){const r=c.roles2.find(x=>x.id===v);if(!r||r.rank>=10)return;const cost=CPR.IPCOST.role[r.rank];if(!c.free){if(c.ip<cost)return;c.ip-=cost}r.rank++}
  else if(a==='r2del')c.roles2=c.roles2.filter(x=>x.id!==v);
  else if(a==='abroll'){const rk=crRank(c,v);const dv=b.dataset.dv?+b.dataset.dv:null;crRoll(p,c,(b.dataset.n||CROLE[v].ab),[[CROLE[v].ab,rk]],{dv})}
  else if(a==='solo'){const s=c.ab.solo;const used=Object.values(s).reduce((x,y)=>x+y,0);const nv=s[v]+d;if(nv<0||used+d>crRank(c,'solo'))return;s[v]=nv}
  else if(a==='tech'){const t=c.ab.tech;const used=Object.values(t).reduce((x,y)=>x+y,0);const rk=crRank(c,'tech');const nv=t[v]+d;if(nv<0||nv>rk||(d>0&&used>=rk*2))return;t[v]=nv}
  else if(a==='techroll'){const sk=val('crTechSk')||'basict';const T=crSkTot(c,sk,K);const r=c.ab.tech[v]||0;crRoll(p,c,({upg:'Модернизация',fab:'Изготовление',inv:'Изобретение'})[v]+' ('+CSK[sk].n+')',[['ТЕХ',T.stat],['навык',T.lv],['бонусы',T.mod],['ранг',r],['штраф',K.all]])}
  else if(a==='med'){const m=c.ab.med;const used=m.surg+m.pharma+m.cryo;const nv=m[v]+d;if(nv<0||nv>5||(d>0&&used>=crRank(c,'med')))return;m[v]=nv}
  else if(a==='believe'){const rk=crRank(c,'media');const ch=rk>=10?7:rk>=9?6:rk>=7?5:rk>=5?4:rk>=3?3:2;const r=rnd(10);const html=`1d10 [${r}] против ${ch} из 10 → ${r<=ch?'<b class="cr-ok">поверили</b>':'<b class="cr-no">не поверили</b>'} <span class="muted">(+1/+2 за доказательства — добавьте сами)</span>`;CRLAST={t:'Поверят ли',html};crLog(crWho(p,c),'Доверие',html)}
  else if(a==='memadd'){const t=val('crMem');const T=AB_TEAM()[t];if(!T)return;const row=rnd(6),loy=rnd(6)+1;c.ab.team.push({u:crU(),t,n:'',row,loy,hp:null});CRLAST={t:'Нанят: '+T.n,html:`характеристики — строка ${row}, лояльность ${loy}`}}
  else if(a==='memdel')c.ab.team.splice(i,1);
  else if(a==='loy'){const m=c.ab.team[i];if(m)m.loy+=d}
  else if(a==='loychk'){const m=c.ab.team[i];if(!m)return;const r=rnd(6);const html=`1d6 [${r}] против лояльности ${m.loy} → ${r<=m.loy?'<b class="cr-ok">выполнит</b>':'<b class="cr-no">может отказаться или сорвать</b>'}`;CRLAST={t:'Лояльность',html};crLog(crWho(p,c),'Проверка лояльности',html)}
  else if(a==='backup'){const rk=crRank(c,'law');const r=rnd(10);let html=`d10 [${r}] против ранга ${rk} → `;if(r<=rk){const t=rnd(6);html+=`<b class="cr-ok">откликнулись</b>, прибудут через ${t} раунд(а)${t===6?' — <b>группа на уровень выше</b>'+(rk>=10?' (две группы)':''):''}`}else html+='<b class="cr-no">никто не ответил</b> (можно снова в следующем раунде)';CRLAST={t:'Подкрепление',html};crLog(crWho(p,c),'Подкрепление',html)}
  else if(a==='haggle'){const T=crSkTot(c,'trade',K);crRoll(p,c,'Торг',[['ХАР',T.stat],['Торговля',T.lv],['бонусы',T.mod],['Воротила',crRank(c,'fixer')],['штраф',K.all]],{note:'Против ХАР + Торговля (+ ранг Воротилы) + 1d10 собеседника'})}
  else if(a==='vehadd')(c.ab.veh=c.ab.veh||[]).push('');
  else if(a==='vehdel')c.ab.veh.splice(i,1);
  else if(a==='atk'||a==='autofire'||a==='supp'||a==='shell'){const w=c.wpn[i];if(!w)return;const I=crWInfo(c,w);const so=crRank(c,'solo')&&c.ab.solo?c.ab.solo:{};
    const q=I.q==='exc'?1:0;const smart=w.att.includes('smartl')&&(crHas(c,'plugs')||crHas(c,'smartlink'))?1:0;
    if(I.melee){const T=crSkTot(c,I.sk,K);crRoll(p,c,'Атака: '+(w.n||I.name),[['ЛВК',T.stat],['навык',T.lv],['бонусы',T.mod],['качество',q],['точная атака',K.atk],['травмы',K.melee],['прицельный',w.aim?-8:0],['штраф',K.all]],{note:'Против ЛВК + Уклонение + 1d10 цели (ничья — защищающемуся)'});return crRe()}
    const need=a==='autofire'||a==='supp'?10:a==='shell'?1:1;if(I.mag&&w.mag<need){CRLAST={t:w.n||I.name,html:'<b class="cr-no">Мало патронов</b> — перезарядитесь'};return crRe()}
    if(I.mag)w.mag-=need;
    const far=w.band>=4;const fx=(far&&(w.att.includes('scope')||crHas(c,'teleoptics'))?1:0)+(w.aim&&crHas(c,'tscope')?1:0);
    if(a==='supp'){const T=crSkTot(c,'auto',K);crRoll(p,c,'Огонь на подавление',[['РЕА',T.stat],['Автоогонь',T.lv],['бонусы',T.mod],['штраф',K.all]],{note:'Все в 25 м на линии огня вне укрытия: ВОЛЯ + Концентрация + 1d10 против этого, провал — бегут в укрытие'});return crRe()}
    if(a==='shell'){const T=crSkTot(c,'shoul',K);const r=crRoll(p,c,'Дробь',[['РЕА',T.stat],['навык',T.lv],['бонусы',T.mod],['качество',q],['штраф',K.all]],{dv:13});if(r.tot>13)crDmg(p,c,'Урон дробью (всем в 6 м перед вами)','3d6');return crRe()}
    if(a==='autofire'){const T=crSkTot(c,'auto',K);const dv=(CPR.DVA[I.dv]||[])[Math.min(4,w.band)];const r=crRoll(p,c,'Автоогонь: '+(w.n||I.name),[['РЕА',T.stat],['Автоогонь',T.lv],['бонусы',T.mod],['качество',q],['смарт',smart],['точная атака',K.atk],['травмы',K.ranged],['штраф',K.all]],{dv});
      if(dv!=null&&r.tot>dv){const mult=Math.min(I.auto||3,r.tot-dv);crDmg(p,c,'Урон автоогнём','2d6',{mult})}return crRe()}
    const T=crSkTot(c,I.sk,K);const dv=(CPR.DVS[I.dv]||[])[w.band];
    const r=crRoll(p,c,'Выстрел: '+(w.n||I.name),[['РЕА',T.stat],['навык',T.lv],['бонусы',T.mod],['качество',q],['смарт',smart],['прицел',fx],['точная атака',K.atk],['травмы',K.ranged],['прицельный',w.aim?-8:0],['штраф',K.all]],{dv,note:K.eff.ref>=8?'':'Цель с РЕА 8+ может вместо СЛ уклониться: ЛВК + Уклонение + 1d10'});
    if(I.q==='poor'&&r.d.r===1)CRLAST.html+=' <b class="cr-no">Оружие заклинило</b> — действие на устранение.'}
  else if(a==='dmg'){const w=c.wpn[i];if(!w)return;const I=crWInfo(c,w);const so=crRank(c,'solo')&&c.ab.solo?c.ab.solo:{};crDmg(p,c,'Урон: '+(w.n||I.name),I.dmg,{halfArmor:I.melee,head:!!w.aim,bonus:so.sw||0})}
  else if(a==='brawl'){const T=crSkTot(c,'brawl',K);crRoll(p,c,'Рукопашная атака',[['ЛВК',T.stat],['навык',T.lv],['бонусы',T.mod],['травмы',K.melee],['штраф',K.all]],{note:'Против ЛВК + Уклонение + 1d10'})}
  else if(a==='brawldmg'){const bb=K.eff.body;let dd=(CPR.BRAWL.find(x=>bb<=x[0])||[0,'1d6'])[1];if(crHas(c,'cyberarm')&&dd==='1d6')dd='2d6';crDmg(p,c,'Урон кулаком',dd,{bonus:(c.ab.solo||{}).sw||0})}
  else if(a==='reload'){const w=c.wpn[i];if(!w)return;const I=crWInfo(c,w);if(!I.amT)return;const key=I.amT+':'+w.am;const need=I.mag-w.mag;const have=c.ammo[key]||0;const take=Math.min(need,have);w.mag+=take;c.ammo[key]=have-take;CRLAST={t:'Перезарядка',html:take?`+${take} (${esc((CAMT[w.am]||{}).n||'')}), в запасе ${c.ammo[key]}`:'<b class="cr-no">Нет патронов этого типа</b>'}}
  else if(a==='wdel')c.wpn.splice(i,1);
  else if(a==='wadd'){const id=val('crWAdd');const W=CRW[id]||CMW[id]||CEXO[id];if(!W)return;c.wpn.push(crNewW(id));crBuy(c,W.c,chk('crWBuy'))}
  else if(a==='takedmg'){let n=Math.max(0,Math.round(+val('crDmgN')||0));const loc=val('crDmgLoc')||'body',t=val('crDmgT')||'n',crit=chk('crDmgCrit');
    const so=crRank(c,'solo')&&c.ab.solo?c.ab.solo:{};const red=so.dd>=2&&chk('crDmgFirst')?Math.min(5,Math.floor(so.dd/2)):0;const wasMortal=K.wound===3;
    let txt=`Входящий урон ${n}${red?` − ${red} (Отражение урона)`:''}`;n=Math.max(0,n-red);
    let through=n;const sp=K.sp[loc];if(c.shield>0&&t!=='ign'){const s=Math.min(c.shield,n);c.shield-=s;n-=s;through=n;txt+=`; щит поглотил ${s}`}
    if(t!=='ign'){const eff=t==='half'?Math.floor(sp/2):sp;through=Math.max(0,n-eff);txt+=`; ОС ${eff}${t==='half'?' (половина брони игнорируется)':''}`}
    if(loc==='head'&&through)through*=c.crit.some(x=>x.l==='head'&&x.r===9)?3:2;
    if(through>0&&t!=='ign'){const ab=t==='ap'?2:1;if(c.arm[loc].id)c.arm[loc].sp=Math.max(0,c.arm[loc].sp-ab);if(K.cyl)c.cyl[loc]=Math.max(0,c.cyl[loc]-ab);txt+=`; броня −${ab}`}
    c.hp=(c.hp??K.hpMax)-through;txt+=` → <b class="cr-tot">−${through} ПЗ</b>`;
    if(crit||(wasMortal&&through>0)){c.hp-=crit?5:0;const r=rnd(6)+rnd(6);c.crit.push({l:loc,r});const ci=(CPR.CRIT[loc]||[]).find(x=>x[0]===r);txt+=`<div><b class="cr-no">Критическая травма</b>${crit?' (+5 урона)':' (смертельное ранение)'}: ${esc(ci?ci[1]:'')}</div>`}
    const K2=crCalc(c);txt+=` · ПЗ ${c.hp}/${K2.hpMax} — ${esc(crWound(K2.wound)[0])}`;CRLAST={t:'Получен урон',html:txt};crLog(crWho(p,c),'Получен урон',txt)}
  else if(a==='shield')c.shield=Math.max(0,Math.min(10,c.shield+d));
  else if(a==='shieldadd')c.shield=10;else if(a==='shielddel')c.shield=-1;
  else if(a==='sp'){const A=CAR[c.arm[v].id];if(A)c.arm[v].sp=Math.max(0,Math.min(A.sp,c.arm[v].sp+d))}
  else if(a==='cyl')c.cyl[v]=Math.max(0,Math.min(K.cyl,c.cyl[v]+d));
  else if(a==='armfix'){['head','body'].forEach(l=>{const A=CAR[c.arm[l].id];if(A)c.arm[l].sp=A.sp});CRLAST={t:'Броня',html:'Починена'}}
  else if(a==='critroll'){const r=rnd(6)+rnd(6);c.crit.push({l:v,r});const ci=(CPR.CRIT[v]||[]).find(x=>x[0]===r);const html=`2d6 = ${r}: <b>${esc(ci?ci[1]:'')}</b> — ${esc(ci?ci[2]:'')}`;CRLAST={t:'Критическая травма',html};crLog(crWho(p,c),'Критическая травма',html)}
  else if(a==='critadd'){const [l,r]=String(val('crCritSel')).split(':');if(l)c.crit.push({l,r:+r})}
  else if(a==='critdel')c.crit.splice(i,1);
  else if(a==='rest'){const h=crHas(c,'antibody')?K.eff.body*2:K.eff.body;c.hp=Math.min(K.hpMax,c.hp+h);CRLAST={t:'Отдых',html:`+${h} ПЗ`}}
  else if(a==='speedheal'){if(K.wound===3)return;const h=K.eff.body+K.eff.will;c.hp=Math.min(K.hpMax,c.hp+h);CRLAST={t:'Спидхил',html:`+${h} ПЗ`}}
  else if(a==='eb'){const n=Math.abs(Math.round(+val('crEb')||0));c.eb+=d*n}
  else if(a==='month'){const H=CPR.HOUSING.find(h=>h[0]===c.house)||[],L=CPR.LIFESTYLE.find(h=>h[0]===c.life)||[];const s=(H[2]||0)+(L[2]||0);c.eb-=s;CRLAST={t:'Месяц оплачен',html:`−${s}eb`}}
  else if(a==='ammo'){c.ammo[v]=Math.max(0,(c.ammo[v]||0)+d);if(!c.ammo[v])delete c.ammo[v]}
  else if(a==='ammoadd'){const t=val('crAmT'),am=val('crAmA'),n=Math.max(1,Math.round(+val('crAmN')||10));if(!CAMMO[t]||!CAMT[am])return;const k=t+':'+am;c.ammo[k]=(c.ammo[k]||0)+n;
    const per=t==='gren'||t==='rocket'?1:10;crBuy(c,Math.ceil(n/per)*CAMT[am].c,chk('crAmBuy'))}
  else if(a==='gq'){const g=c.gear[i];if(g){g.q=Math.max(0,g.q+d);if(!g.q)c.gear.splice(i,1)}}
  else if(a==='gdel')c.gear.splice(i,1);
  else if(a==='gadd'){const id=val('crGAdd');if(id&&CGR[id]){const g=c.gear.find(x=>x.id===id);if(g)g.q++;else c.gear.push({id,n:'',q:1});if(/^deck/.test(id)&&!c.deck.q)c.deck.q=id;crBuy(c,CGR[id].c,chk('crGBuy'))}else c.gear.push({id:'',n:'Предмет',q:1})}
  else if(a==='pradd'){const [t,id]=String(val('crPrAdd')).split(':');if(t==='p'&&CPRG[id]){c.deck.pr.push(id);crBuy(c,CPRG[id].c,chk('crPrBuy'))}if(t==='h'&&CHW[id]){c.deck.hw.push(id);crBuy(c,CHW[id].c,chk('crPrBuy'))}}
  else if(a==='prdel')c.deck.pr.splice(i,1);else if(a==='hwdel')c.deck.hw.splice(i,1);
  else if(a==='fadd'){const s=+val('crFs'),it=+val('crFi');const f=c.fash.find(x=>x.s===s&&x.i===it);if(f)f.q++;else c.fash.push({s,i:it,q:1});crBuy(c,CPR.FASHION[s][2][it],chk('crFBuy'))}
  else if(a==='fdel')c.fash.splice(i,1);
  else if(a==='cyadd'){const r=crAddCy(c,val('crCyAdd'),val('crCyPar'),val('crCyHl'),val('crCySk'));if(typeof r==='string'){CRLAST={t:'Установка',html:`<b class="cr-no">${esc(r)}</b>`}}else{const d=CCY[val('crCyAdd')];crBuy(c,d.c,chk('crCyBuy'));CRLAST={t:'Установлено: '+d.n,html:r.txt+` · человечность ${c.hum}`};crLog(crWho(p,c),'Киберимплант: '+d.n,r.txt)}}
  else if(a==='cydel'){const kill=u=>{c.cy.filter(x=>x.p===u).forEach(x=>kill(x.u));c.cy=c.cy.filter(x=>x.u!==u)};kill(v);if(!crHas(c,'subarmor')&&!crHas(c,'skinweave'))c.cyl={head:0,body:0}}
  else if(a==='lproll'){if(v.startsWith('r_')){const [,role,idx]=v.split('_');const t=(CPR.LPR[role]||[])[+idx];if(!t)return;const n=t[2].length;c.lp[v]=rnd(n);CRLAST={t:t[0],html:esc(t[2][c.lp[v]-1])}}else{const t=CLP[v];if(!t)return;c.lp[v]=rnd(t.rows.length);const r=t.rows[c.lp[v]-1];CRLAST={t:t.n,html:esc(Array.isArray(r)?r[0]:r)}}}
  else if(a==='lpall'){CPR.LP.forEach(t=>{if(!t.count&&!t.multi&&!c.lp[t.id])c.lp[t.id]=rnd(t.rows.length)});(CPR.LPR[c.role]||[]).forEach((t,j)=>{const k='r_'+c.role+'_'+j;if(t[1]!=='выбор'&&!c.lp[k])c.lp[k]=rnd(t[2].length)});
    ['friend','enemy','love'].forEach(id=>{if(!Array.isArray(c.lp[id+'s'])){const n=Math.max(0,rnd(10)-7);c.lp[id+'s']=[];for(let j=0;j<n;j++)c.lp[id+'s'].push(crLpRand(id))}});CRLAST={t:'Жизненный путь',html:'Брошено всё пустое'}}
  else if(a==='lpcount'){const n=Math.max(0,rnd(10)-7);c.lp[v+'s']=[];for(let j=0;j<n;j++)c.lp[v+'s'].push(crLpRand(v));CRLAST={t:CLP[v].n,html:`1d10 − 7 → ${n}`}}
  else if(a==='lpadd'){(c.lp[v+'s']=Array.isArray(c.lp[v+'s'])?c.lp[v+'s']:[]).push(crLpRand(v))}
  else if(a==='lpre'){const arr=c.lp[v+'s'];if(arr)arr[i]=crLpRand(v)}
  else if(a==='lpdel'){const arr=c.lp[v+'s'];if(arr)arr.splice(i,1)}
  else if(a==='srroll'||a==='srpick'){const row=a==='srroll'?rnd(10)-1:+v;crSetSr(c,row);CRLAST={t:'Уличная крыса',html:`строка ${row+1}: ${CSTK.map((k,j)=>CRS[k][1]+' '+c.st[k]).join(', ')}`}}
  else if(a==='erroll'){const R=CROLE[c.role];CSTK.forEach((k,j)=>{c.st[k]=R.stats[rnd(10)-1][j]});c.luck=c.st.luck;c.hum=c.st.emp*10;c.hp=null;if(!Object.keys(c.sk).length||Object.keys(c.sk).every(k=>c.sk[k]===2))crErSk(c);c.rank=4;CRLAST={t:'Эджраннер',html:CSTK.map(k=>CRS[k][1]+' '+c.st[k]).join(', ')}}
  else if(a==='erskreset')crErSk(c);
  else if(a==='cpstart'){CSTK.forEach(k=>c.st[k]=6);c.st.luck=6;c.luck=6;c.sk=crBasicSk();if(c.lp.langFree)c.sk['lang|'+c.lp.langFree]=4;c.eb=2550;c.hum=60;c.hp=null;c.rank=4;c.cy=[];c.wpn=[];c.gear=[];c.ammo={};CRLAST={t:'Полный пакет',html:'Характеристики по 6 (60 из 62), 2550eb + 800eb на стиль'}}
  else if(a==='kitapply'){crApplyKit(p,c);CRLAST={t:'Стартовый набор',html:'Выдан: оружие, броня, снаряжение, импланты, 500eb'}}
  else if(a==='finish'){c.done=1;c.hp=null;c.luck=c.st.luck;CRLAST={t:'Персонаж создан',html:'Развитие — за очки улучшения'}}
  else if(a==='undone')c.done=0;
  else return;
  crRe()},true);
function crLpRand(id){const t=CLP[id];if(id==='enemy')return [rnd(10),rnd(10),rnd(10),rnd(2)];return rnd(t.rows.length)}

/* ---------- поля ввода ---------- */
document.addEventListener('change',e=>{const f=e.target.closest('[data-cf]');if(!f||!document.querySelector('.cr-sheet')||!f.closest('.cr-sheet'))return;const p=curP();if(!p)return;const c=crOf(p);
  const k=f.dataset.cf,v=f.value,i=+f.dataset.i;
  if(k==='handle')c.handle=crS(v,80);
  else if(k==='hp'){const K=crCalc(c);c.hp=Math.max(-99,Math.min(K.hpMax,Math.round(+v||0)))}
  else if(k==='free')c.free=f.checked?1:0;
  else if(k==='role'&&CROLE[v]){if(c.role!==v){c.role=v;c.roles2=c.roles2.filter(r=>r.id!==v);c.cr.kit={}}}
  else if(k==='method')c.method=v;
  else if(k==='crpts')c.cr.pts=crN(v,40,90,62);
  else if(k==='kit')c.cr.kit[f.dataset.v]=crN(v,0,5,0);
  else if(k==='team.n'){const m=c.ab.team[i];if(m)m.n=crS(v,60)}
  else if(k==='veh'){if(c.ab.veh)c.ab.veh[i]=crS(v,120)}
  else if(k==='w.n'){const w=c.wpn[i];if(w)w.n=crS(v,80)}
  else if(k==='w.q'){const w=c.wpn[i];if(w)w.q=['poor','std','exc'].includes(v)?v:'std'}
  else if(k==='w.band'){const w=c.wpn[i];if(w)w.band=crN(v,0,7,0)}
  else if(k==='w.aim'){const w=c.wpn[i];if(w)w.aim=f.checked?1:0}
  else if(k==='w.am'){const w=c.wpn[i];if(w&&CAMT[v]){const I=crWInfo(c,w);if(I.amT&&w.mag){const key=I.amT+':'+w.am;c.ammo[key]=(c.ammo[key]||0)+w.mag;w.mag=0}w.am=v}}
  else if(k==='w.att'){const w=c.wpn[i];const id=f.dataset.v;if(!w||!CATT[id])return;if(f.checked){const used=w.att.reduce((s,x)=>s+CATT[x].sl,0);if(used+CATT[id].sl>3){f.checked=false;CRLAST={t:'Обвес',html:'<b class="cr-no">Нет свободных слотов (3)</b>'};return crRe()}if(id==='drum')w.att=w.att.filter(x=>x!=='ext');if(id==='ext')w.att=w.att.filter(x=>x!=='drum');w.att.push(id)}else w.att=w.att.filter(x=>x!==id);
    const I=crWInfo(c,w);if(w.mag>I.mag)w.mag=I.mag}
  else if(k==='arm'){const A=CAR[v];c.arm[f.dataset.v]={id:A?v:'',sp:A?A.sp:0};if(v==='bodyw'){c.arm.head={id:'bodyw',sp:11};c.arm.body={id:'bodyw',sp:11}}}
  else if(k==='sand')c.sand=f.checked?1:0;
  else if(k==='stim')c.stim=f.checked?1:0;
  else if(k==='house')c.house=v;else if(k==='life')c.life=v;
  else if(k==='deckq')c.deck.q=['deckp','deck','decke'].includes(v)?v:'';
  else if(k==='g.n'){const g=c.gear[i];if(g)g.n=crS(v,80)}
  else if(k==='lp'){const n=+v;if(n)c.lp[f.dataset.v]=n;else delete c.lp[f.dataset.v]}
  else if(k==='langFree'){const old=c.lp.langFree;const nv=crS(v,40).replace(/\|/g,'/').trim();if(old&&c.sk['lang|'+old]===4&&!c.done)delete c.sk['lang|'+old];c.lp.langFree=nv;if(nv&&!c.sk['lang|'+nv])c.sk['lang|'+nv]=4}
  else if(k==='lpl'){const arr=c.lp[f.dataset.v+'s'];if(arr)arr[i]=+v}
  else if(k==='lpm'){const arr=c.lp[f.dataset.v+'s'];if(arr&&Array.isArray(arr[i]))arr[i][+f.dataset.j]=+v}
  else if(k==='notes'){c.notes=crS(v,20000);pcSave();return}
  else return;
  crRe()});

/* ---------- вкладка «Персонаж»: подмена прежнего листа хоумбрю ---------- */
charView=crView;

/* ============================== Библиотека: Киберпанк RED ============================== */
let CRLIB=LS.get('cpr_npcs',[]);if(!Array.isArray(CRLIB))CRLIB=[];
let CRLIB_MODE=LS.get('lib_mode','lancer')==='cpr'?'cpr':'lancer',CRLIB_SEL=null,CRLIB_LAST=null;
function crNpcNew(o){return {u:crU(),n:'Новый НИП',tier:'Шестёрка',role:'',rank:0,page:0,st:{int:5,ref:5,dex:5,tech:5,cool:5,will:5,luck:0,move:5,body:5,emp:5},hp:null,hpMax:null,
  sp:{head:7,body:7},spMax:{head:7,body:7},armor:'Кевлар',w:[],sk:[],cy:'',gear:'',notes:'',crit:[],dsPen:0,pack:0,...(o||{})}}
function crNpcClean(x){if(!x||typeof x!=='object'||Array.isArray(x))return null;const n=crNpcNew();const A=v=>Array.isArray(v)?v:[];
  n.u=crS(x.u,12)||crU();n.n=crS(x.n,80)||'НИП';n.tier=crS(x.tier,30);n.role=CROLE[x.role]?x.role:'';n.rank=crN(x.rank,0,10,0);n.page=crN(x.page,0,500,0);
  if(x.st&&typeof x.st==='object')CSTK.forEach(k=>n.st[k]=crN(x.st[k],0,20,k==='luck'?0:5));
  n.hp=x.hp===null||x.hp===undefined?null:crN(x.hp,-99,300,null);n.hpMax=x.hpMax===null||x.hpMax===undefined?null:crN(x.hpMax,1,300,null);
  ['head','body'].forEach(l=>{n.sp[l]=crN(x.sp&&x.sp[l],0,30,0);n.spMax[l]=crN(x.spMax&&x.spMax[l],0,30,n.sp[l])});n.armor=crS(x.armor,60);
  n.w=A(x.w).filter(w=>w&&typeof w==='object').slice(0,12).map(w=>({n:crS(w.n,80),dmg:crS(w.dmg,12),rof:crN(w.rof,1,3,1),sk:crN(w.sk,0,40,10),melee:w.melee?1:0,dv:(CPR.DVS||{})[w.dv]?w.dv:'',auto:crN(w.auto,0,5,0),note:crS(w.note,160)}));
  n.sk=A(x.sk).filter(s=>Array.isArray(s)).slice(0,60).map(s=>[crS(s[0],60),crN(s[1],0,40,0)]);
  n.cy=crS(x.cy,2000);n.gear=crS(x.gear,2000);n.notes=crS(x.notes,6000);n.crit=A(x.crit).filter(c=>c&&typeof c==='object').slice(0,20).map(c=>({l:c.l==='head'?'head':'body',r:crN(c.r,2,12,2)}));n.dsPen=crN(x.dsPen,0,30,0);n.pack=x.pack?1:0;return n}
CRLIB=CRLIB.map(crNpcClean).filter(Boolean).slice(0,300);
const crLibSave=()=>LS.set('cpr_npcs',CRLIB);
const crNpcHpMax=n=>n.hpMax||(10+5*Math.ceil((n.st.body+n.st.will)/2));
function crNpcGen(role,tier){const R=CROLE[role];const row=R.stats[rnd(10)-1];const st={};CSTK.forEach((k,j)=>st[k]=row[j]);
  const sk=R.sr.map(([id,spec,lv])=>{const s=CSK[id];return [skName(skK(id,spec)),(st[s.st]||0)+lv]});
  const w=[];R.kit.w.forEach(x=>{const id=x.split('|')[0].split(':')[0];const W=CRW[id]||CMW[id];if(W){const s=W.melee?'melee':W.sk;const lv=(R.sr.find(r=>r[0]===s)||[0,0,0])[2];w.push({n:W.n,dmg:W.dmg,rof:W.rof,sk:(W.melee?st.dex:st.ref)+lv,melee:W.melee?1:0,dv:W.dv||'',auto:/auto(\d)/.test(W.f||'')?+W.f.match(/auto(\d)/)[1]:0,note:''})}});
  return crNpcNew({n:R.n+' ('+tier.toLowerCase()+')',tier,role,rank:tier==='Шестёрка'?0:tier==='Лейтенант'?4:tier==='Мини-босс'?6:8,st,sk,w,sp:{head:11,body:11},spMax:{head:11,body:11},armor:'Лёгкий бронекостюм',
    cy:R.kit.cy.map(x=>CCY[x.split('|')[0]].n).join(', '),gear:R.kit.g.map(x=>crKitName(x.split('|')[0])).join(', '),notes:'Сгенерирован по таблицам роли (Уличная крыса, стр. 74–87).'})}
function crLibSide(){const grp={};CRLIB.forEach(n=>{const g=n.pack?'Из личного пакета книги':'Свои НИП';(grp[g]=grp[g]||[]).push(n)});
  return `${crLibSwitch()}<div class="clist">${Object.entries(grp).map(([g,l])=>`<div class="cgrp">${esc(g)}</div>`+l.map(n=>`<button class="citem ${n.u===CRLIB_SEL?'on':''}" data-crl="sel" data-v="${n.u}"><span class="ic">◆</span><span><b>${esc(n.n)}</b><small>${esc(n.tier||'')}${n.page?' · стр. '+n.page:''}</small></span></button>`).join('')).join('')||'<div class="muted">Пока пусто</div>'}
   <div class="cgrp">Книга: «Шестёрки и засранцы»</div>${(CPR.MOOKS||[]).map(m=>`<button class="citem" data-crl="mook" data-v="${m[0]}"><span class="ic">＋</span><span><b>${esc(m[1])}</b><small>${esc(m[2])} · стр. ${m[3]}</small></span></button>`).join('')}</div>
   <div class="side-btns"><button class="btn red" data-crl="new">＋ Новый НИП</button>
    <div class="row-btns"><select id="crlRole">${CPR.ROLES.map(r=>`<option value="${r.id}">${esc(r.n)}</option>`).join('')}</select><select id="crlTier">${['Шестёрка','Лейтенант','Мини-босс','Босс'].map(t=>`<option>${t}</option>`).join('')}</select><button class="btn" data-crl="gen">⚡ Быстрый НИП</button></div>
    <button class="btn" data-crl="imp">⇪ Импорт НИП / пакета (JSON)</button><button class="btn" data-crl="exp">⇩ Экспорт НИП</button><input type="file" id="crlFile" accept=".json,application/json" hidden></div>
   <p class="muted" style="font-size:12px;margin-top:10px">Всё хранится в этом браузере. Полные статблоки из книги программа не содержит (правила фан-контента R. Talsorian): заполните сами по книге или импортируйте личный пакет.</p>`}
function crLibSwitch(){return `<div class="cr-libsw"><button class="tab ${CRLIB_MODE==='lancer'?'on':''}" data-crl="mode" data-v="lancer">Lancer</button><button class="tab ${CRLIB_MODE==='cpr'?'on':''}" data-crl="mode" data-v="cpr">Киберпанк RED</button></div>`}
function crLibView(){const n=CRLIB.find(x=>x.u===CRLIB_SEL);if(!n)return `${CRLIB_LAST?`<div class="cr-next"><span class="cr-last"><b>${esc(CRLIB_LAST.t)}:</b> ${CRLIB_LAST.html}</span></div>`:''}<div class="empty">Киберпанк RED: выберите НИП слева, создайте нового или сгенерируйте «Быстрый НИП».<br><br>Книжные шестёрки и боссы (стр. 412–416) — кнопки «＋» в списке: создаётся заготовка с именем и страницей, характеристики впишите из книги.</div>`;
  const hpm=crNpcHpMax(n);if(n.hp===null)n.hp=hpm;const sw=Math.ceil(hpm/2);const wound=n.hp>=hpm?0:n.hp>=sw?1:n.hp>=1?2:3;const pen=wound===2?-2:wound===3?-4:0;
  return `<div class="cr-sheet cr-npc"><div class="cr-head"><div class="cr-id"><input class="pc-big" data-cl="n" value="${esc(n.n)}"><div class="cr-role"><input data-cl="tier" value="${esc(n.tier)}" placeholder="Шестёрка / Лейтенант / Босс" style="width:180px">
      <select data-cl="role"><option value="">без роли</option>${CPR.ROLES.map(r=>`<option value="${r.id}" ${r.id===n.role?'selected':''}>${esc(r.n)}</option>`).join('')}</select> ранг <input type="number" class="cr-sm" data-cl="rank" value="${n.rank}">${n.page?` <span class="muted">книга, стр. ${n.page}</span>`:''}</div></div>
    <div class="cr-hpbox"><div class="cr-hpl">ПЗ</div><div class="cr-hprow"><button class="pm" data-crl="hp" data-d="-1">−</button><input type="number" class="cr-hpin" data-cl="hp" value="${n.hp}"><span class="cr-hpmax">/ ${hpm}</span><button class="pm" data-crl="hp" data-d="1">+</button></div>
      <div class="cr-wound w${wound}">${esc(crWound(wound)[0])}</div><div class="muted cr-small">Тяж. ранение ${sw} · Спасбросок ${n.st.body}${n.dsPen?' (штраф +'+n.dsPen+')':''}</div></div>
    <div class="cr-hbtn"><button class="btn red" data-crl="init">⚡ Инициатива</button>${wound===3?`<button class="btn red" data-crl="ds">☠ Спасбросок</button>`:''}<button class="btn" data-crl="dup">⧉ Копия</button><button class="btn" data-crl="del">✕ Удалить</button></div></div>
  ${CRLIB_LAST?`<div class="cr-next"><span class="cr-last"><b>${esc(CRLIB_LAST.t)}:</b> ${CRLIB_LAST.html}</span></div>`:''}
  <h2>Характеристики</h2><div class="cr-stats">${CPR.STATS.map(([k,l])=>`<div class="cr-st"><button class="cr-stb" data-crl="rst" data-v="${k}">${l}</button><input type="number" class="cr-stin" data-cl="st" data-v="${k}" value="${n.st[k]}"></div>`).join('')}</div>
  <p class="muted cr-small">ПЗ считаются по ТЕЛ и ВОЛЕ: 10 + 5 × ((ТЕЛ + ВОЛЯ)/2, вверх). Свои ПЗ: <input type="number" class="cr-sm" data-cl="hpMax" value="${n.hpMax??''}" placeholder="авто"></p>
  <h2>Броня</h2><div class="row-btns"><input data-cl="armor" value="${esc(n.armor)}" placeholder="Тип брони">${['head','body'].map(l=>`<span class="ntag">${l==='head'?'Голова':'Тело'} <button class="pm" data-crl="sp" data-v="${l}" data-d="-1">−</button><b>${n.sp[l]}</b>/<input type="number" class="cr-sm" data-cl="spMax" data-v="${l}" value="${n.spMax[l]}"><button class="pm" data-crl="sp" data-v="${l}" data-d="1">+</button></span>`).join('')}</div>
  <div class="row-btns cr-dmgin"><input type="number" id="crlDmgN" placeholder="урон"><select id="crlDmgLoc"><option value="body">в тело</option><option value="head">в голову (×2)</option></select><select id="crlDmgT"><option value="n">обычный</option><option value="half">ближний (½ брони)</option><option value="ap">бронебойный</option><option value="ign">мимо брони</option></select><label class="cr-chk"><input type="checkbox" id="crlDmgCrit"> крит</label><button class="btn red" data-crl="dmgin">Получить урон</button></div>
  <h2>Оружие</h2>${n.w.map((w,i)=>`<div class="cr-w"><div class="cr-wh"><input data-cl="w.n" data-i="${i}" value="${esc(w.n)}"> урон <input class="cr-sm" data-cl="w.dmg" data-i="${i}" value="${esc(w.dmg)}"> СКА <input type="number" class="cr-sm" data-cl="w.rof" data-i="${i}" value="${w.rof}"> сумма навыка <input type="number" class="cr-sm" data-cl="w.sk" data-i="${i}" value="${w.sk}">
      <label class="cr-chk"><input type="checkbox" data-cl="w.melee" data-i="${i}" ${w.melee?'checked':''}> ближнее</label><select data-cl="w.dv" data-i="${i}"><option value="">таблица СЛ…</option>${Object.keys(CPR.DVS).map(k=>`<option value="${k}" ${w.dv===k?'selected':''}>${({pistol:'Пистолет',smg:'ПП',slug:'Дробовик',ar:'Штурм. винтовка',sniper:'Снайперская',bow:'Лук',gl:'Гранатомёт',rl:'Ракетомёт'})[k]}</option>`).join('')}</select><button class="pm" data-crl="wdel" data-i="${i}">✕</button></div>
      <div class="row-btns"><button class="btn red" data-crl="atk" data-i="${i}">Атака ${w.sk}+1d10${pen?' '+pen:''}</button><button class="btn" data-crl="dmg" data-i="${i}">Урон ${esc(w.dmg)}</button>${w.auto?`<button class="btn" data-crl="auto" data-i="${i}">Автоогонь ×${w.auto}</button>`:''}${w.dv?`<span class="muted cr-small">СЛ: ${(CPR.DVS[w.dv]||[]).map((x,j)=>CPR.BANDS[j]+' '+(x??'—')).join(' · ')}</span>`:''}</div></div>`).join('')}
  <div class="row-btns"><select id="crlW">${CPR.RW.map(w=>`<option value="${w[0]}">${esc(w[1])}</option>`).join('')}${CPR.MW.map(w=>`<option value="${w[0]}">${esc(w[1])}</option>`).join('')}</select><button class="btn sm" data-crl="wadd">＋ Оружие</button></div>
  <h2>Навыки (суммы)</h2><div class="cr-sks">${n.sk.map((s,i)=>`<div class="cr-sk has"><button class="cr-skn" data-crl="rsk" data-i="${i}">${esc(s[0])}</button><input type="number" class="cr-sm" data-cl="sk" data-i="${i}" value="${s[1]}"><button class="pm" data-crl="skdel" data-i="${i}">✕</button></div>`).join('')}</div>
  <div class="row-btns"><select id="crlSk">${Object.values(CSK).map(s=>`<option value="${s.id}">${esc(s.n)}</option>`).join('')}</select><input type="number" id="crlSkLv" class="cr-sm" value="4" title="Уровень навыка"><button class="btn sm" data-crl="skadd">＋ Навык (стат + уровень)</button></div>
  <h2>Критические травмы</h2><div class="row-btns">${n.crit.map((x,i)=>{const r=(CPR.CRIT[x.l]||[]).find(y=>y[0]===x.r)||[];return `<span class="ntag" title="${esc(r[2]||'')}">${esc(r[1]||'')} <button class="pm" data-crl="critdel" data-i="${i}">✕</button></span>`}).join('')}<button class="btn sm" data-crl="critroll" data-v="body">🎲 Тело</button><button class="btn sm" data-crl="critroll" data-v="head">🎲 Голова</button></div>
  <h2>Импланты и снаряжение</h2><textarea class="cr-notes cr-ta" data-cl="cy" placeholder="Киберимпланты">${esc(n.cy)}</textarea><textarea class="cr-notes cr-ta" data-cl="gear" placeholder="Снаряжение">${esc(n.gear)}</textarea>
  <h2>Заметки</h2><textarea class="cr-notes cr-ta" data-cl="notes">${esc(n.notes)}</textarea>
  <p class="cr-legal muted">Неофициальный фанатский материал по Homebrew Content Policy R. Talsorian Games, не одобрен RTG.</p></div>`}
{const o=renderSide;renderSide=function(){if(S.view==='lib'&&CRLIB_MODE==='cpr'){const el=document.getElementById('side');if(el)el.innerHTML=crLibSide();return}o();
  if(S.view==='lib'){const el=document.getElementById('side');if(el&&!el.querySelector('.cr-libsw'))el.insertAdjacentHTML('afterbegin',crLibSwitch())}}}
{const o=viewLib;viewLib=function(){return CRLIB_MODE==='cpr'?crLibView():o()}}
function crlRe(){renderSide();renderMain();crLibSave()}
function crNpcRoll(n,label,base,pen,dv){const d=crD10();const tot=base+(pen||0)+d.r+d.x;const html=`d10 [${d.r}${d.x>0?' + '+d.x+' крит':d.x<0?' − '+(-d.x)+' провал':''}] + ${base}${pen?' '+pen:''} = <b class="cr-tot">${tot}</b>${dv!=null?(tot>dv?` → <b class="cr-ok">попадание</b> (СЛ ${dv})`:` → <b class="cr-no">промах</b> (СЛ ${dv})`):''}`;CRLIB_LAST={t:label,html};crLog(n.n,label,html);return tot}
document.addEventListener('click',e=>{const b=e.target.closest('[data-crl]');if(!b)return;const a=b.dataset.crl,v=b.dataset.v,i=+b.dataset.i,d=+b.dataset.d||0;const val=id=>{const el=document.getElementById(id);return el?el.value:''};
  if(a==='mode'){CRLIB_MODE=v;LS.set('lib_mode',v);CRLIB_LAST=null;renderSide();renderMain();return}
  if(a==='sel'){CRLIB_SEL=v;CRLIB_LAST=null;return crlRe()}
  if(a==='new'){CRLIB_LAST=null;const n=crNpcNew();CRLIB.unshift(n);CRLIB_SEL=n.u;return crlRe()}
  if(a==='mook'){CRLIB_LAST=null;const m=(CPR.MOOKS||[]).find(x=>x[0]===v);if(!m)return;const n=crNpcNew({n:m[1],tier:m[2],page:m[3],notes:'Впишите характеристики, навыки, оружие и импланты из книги (стр. '+m[3]+').'});CRLIB.unshift(n);CRLIB_SEL=n.u;return crlRe()}
  if(a==='gen'){CRLIB_LAST=null;const r=val('crlRole')||'solo',t=val('crlTier')||'Шестёрка';const n=crNpcGen(r,t);CRLIB.unshift(n);CRLIB_SEL=n.u;return crlRe()}
  if(a==='imp'){const f=document.getElementById('crlFile');if(f){f.value='';f.click()}return}
  if(a==='exp'){try{const blob=new Blob([JSON.stringify({format:'cpr-npc-pack',v:1,npcs:CRLIB},null,1)],{type:'application/json'});const u=URL.createObjectURL(blob);const l=document.createElement('a');l.href=u;l.download='cpr-npc.json';document.body.appendChild(l);l.click();setTimeout(()=>{URL.revokeObjectURL(u);l.remove()},500)}catch(err){}return}
  const n=CRLIB.find(x=>x.u===CRLIB_SEL);if(!n)return;const hpm=crNpcHpMax(n);const sw=Math.ceil(hpm/2);const wound=n.hp>=hpm?0:n.hp>=sw?1:n.hp>=1?2:3;const pen=wound===2?-2:wound===3?-4:0;
  if(a==='hp')n.hp=Math.max(-99,Math.min(hpm,n.hp+d));
  else if(a==='del'){CRLIB=CRLIB.filter(x=>x!==n);CRLIB_SEL=null}
  else if(a==='dup'){CRLIB_LAST=null;const c2=crNpcClean(JSON.parse(JSON.stringify(n)));c2.u=crU();c2.n=n.n+' (копия)';c2.hp=null;c2.crit=[];c2.pack=0;CRLIB.splice(CRLIB.indexOf(n)+1,0,c2);CRLIB_SEL=c2.u}
  else if(a==='init')crNpcRoll(n,'Инициатива',n.st.ref,0);
  else if(a==='ds'){const r=rnd(10);const ok=r!==10&&r+n.dsPen<=n.st.body;n.dsPen++;const html=`d10 [${r}] + ${n.dsPen-1} против ТЕЛ ${n.st.body} → ${ok?'<b class="cr-ok">жив</b>':'<b class="cr-no">мёртв</b>'}`;CRLIB_LAST={t:'Спасбросок',html};crLog(n.n,'Спасбросок',html)}
  else if(a==='rst'){crNpcRoll(n,'Проверка '+CRS[v][1],n.st[v],pen)}
  else if(a==='rsk'){const s=n.sk[i];if(s)crNpcRoll(n,s[0],s[1],pen)}
  else if(a==='atk'){const w=n.w[i];if(w)crNpcRoll(n,'Атака: '+w.n,w.sk,pen)}
  else if(a==='auto'){const w=n.w[i];if(!w)return;const tot=crNpcRoll(n,'Автоогонь: '+w.n,w.sk,pen);CRLIB_LAST.html+=' <span class="muted">— урон: 2d6 × превышение СЛ (до ×'+w.auto+')</span>'}
  else if(a==='dmg'){const w=n.w[i];if(!w)return;const dd=crDice(w.dmg);if(!dd)return;const arr=crRollDice(dd.n);const s=arr.reduce((x,y)=>x+y,0);const crit=arr.filter(x=>x===6).length>=2;const html=`${esc(w.dmg)} [${arr.join(', ')}] = <b class="cr-tot">${s}</b>${w.melee?' · игнорирует половину брони':''}${crit?' · <b class="cr-no">Крит! +5 и травма</b>':''}`;CRLIB_LAST={t:'Урон: '+w.n,html};crLog(n.n,'Урон: '+w.n,html)}
  else if(a==='wdel')n.w.splice(i,1);
  else if(a==='wadd'){const id=val('crlW');const W=CRW[id]||CMW[id];if(!W)return;n.w.push({n:W.n,dmg:W.dmg,rof:W.rof,sk:(W.melee?n.st.dex:n.st.ref)+4,melee:W.melee?1:0,dv:W.dv||'',auto:/auto(\d)/.test(W.f||'')?+W.f.match(/auto(\d)/)[1]:0,note:''})}
  else if(a==='skadd'){const id=val('crlSk');const s=CSK[id];if(!s)return;n.sk.push([s.n,(n.st[s.st]||0)+Math.round(+val('crlSkLv')||0)])}
  else if(a==='skdel')n.sk.splice(i,1);
  else if(a==='sp'){n.sp[v]=Math.max(0,Math.min(n.spMax[v],n.sp[v]+d))}
  else if(a==='critroll'){const r=rnd(6)+rnd(6);n.crit.push({l:v,r});const ci=(CPR.CRIT[v]||[]).find(x=>x[0]===r);CRLIB_LAST={t:'Критическая травма',html:`2d6 = ${r}: <b>${esc(ci?ci[1]:'')}</b> — ${esc(ci?ci[2]:'')}`}}
  else if(a==='critdel')n.crit.splice(i,1);
  else if(a==='dmgin'){let x=Math.max(0,Math.round(+val('crlDmgN')||0));const loc=val('crlDmgLoc')||'body',t=val('crlDmgT')||'n';const crit=(document.getElementById('crlDmgCrit')||{}).checked;
    let th=x;if(t!=='ign'){const sp=t==='half'?Math.floor(n.sp[loc]/2):n.sp[loc];th=Math.max(0,x-sp)}if(loc==='head')th*=2;if(th>0&&t!=='ign')n.sp[loc]=Math.max(0,n.sp[loc]-(t==='ap'?2:1));
    const mortal=wound===3;n.hp-=th+(crit?5:0);let html=`${x} урона → <b class="cr-tot">−${th}${crit?' −5':''} ПЗ</b>, ПЗ ${n.hp}/${hpm}`;
    if(crit||(mortal&&th>0)){const r=rnd(6)+rnd(6);n.crit.push({l:loc,r});const ci=(CPR.CRIT[loc]||[]).find(y=>y[0]===r);html+=` · травма: <b>${esc(ci?ci[1]:'')}</b>`}
    CRLIB_LAST={t:'Получен урон',html};crLog(n.n,'Получен урон',html)}
  else return;
  crlRe()});
document.addEventListener('change',e=>{if(e.target.id==='crlFile'){const f=e.target.files&&e.target.files[0];if(!f)return;if(f.size>3e6){alertBox('Файл слишком большой');return}
    const r=new FileReader();r.onload=()=>{try{const j=JSON.parse(r.result);const arr=Array.isArray(j)?j:Array.isArray(j.npcs)?j.npcs:j&&typeof j==='object'?[j]:[];let k=0;
      arr.slice(0,300).forEach(x=>{const n=crNpcClean(x);if(n){if(CRLIB.some(y=>y.u===n.u))n.u=crU();CRLIB.push(n);k++}});CRLIB=CRLIB.slice(0,300);crLibSave();CRLIB_LAST={t:'Импорт',html:`добавлено НИП: ${k}`};crlRe()}catch(err){CRLIB_LAST={t:'Импорт',html:'<b class="cr-no">Не удалось прочитать файл</b>'};renderMain()}};r.readAsText(f);return}
  const f=e.target.closest('[data-cl]');if(!f)return;const n=CRLIB.find(x=>x.u===CRLIB_SEL);if(!n)return;const k=f.dataset.cl,v=f.value,i=+f.dataset.i;
  if(k==='n')n.n=crS(v,80)||'НИП';else if(k==='tier')n.tier=crS(v,30);else if(k==='role')n.role=CROLE[v]?v:'';else if(k==='rank')n.rank=crN(v,0,10,0);
  else if(k==='hp')n.hp=crN(v,-99,300,n.hp);else if(k==='hpMax')n.hpMax=v===''?null:crN(v,1,300,null);
  else if(k==='st')n.st[f.dataset.v]=crN(v,0,20,5);else if(k==='armor')n.armor=crS(v,60);
  else if(k==='spMax'){n.spMax[f.dataset.v]=crN(v,0,30,0);n.sp[f.dataset.v]=Math.min(n.sp[f.dataset.v],n.spMax[f.dataset.v])||n.spMax[f.dataset.v]}
  else if(k.startsWith('w.')){const w=n.w[i];if(!w)return;const kk=k.slice(2);if(kk==='n')w.n=crS(v,80);else if(kk==='dmg')w.dmg=crS(v,12);else if(kk==='rof')w.rof=crN(v,1,3,1);else if(kk==='sk')w.sk=crN(v,0,40,10);else if(kk==='melee')w.melee=f.checked?1:0;else if(kk==='dv')w.dv=CPR.DVS[v]?v:''}
  else if(k==='sk'){const s=n.sk[i];if(s)s[1]=crN(v,0,40,0)}
  else if(k==='cy'||k==='gear'||k==='notes'){n[k]=crS(v,k==='notes'?6000:2000);crLibSave();return}
  else return;crlRe()});
function alertBox(t){CRLIB_LAST={t:'Ошибка',html:esc(t)};try{renderMain()}catch(e){}}

/* ---------- справочник ---------- */
{const C=(t,b)=>({t,b});const CR_REF={id:'cpr',t:'Киберпанк RED — персонажи вне мехов',items:[
  C('Гексы и метры','В книге расстояния в метрах, а клетка — 2 м. **Для персонажей вне мехов 1 гекс = 2 метра.** Перемещение — СКО гексов (СКО × 2 м); бег — ещё столько же. Дистанции стрельбы: 0–6 м = до 3 гексов, 7–12 м = 4–6, 13–25 м = 7–13, 26–50 м = 14–25, 51–100 м = 26–50 гексов. Досягаемость ближнего боя 2 м = 1 гекс, взрыв 10×10 м = 5×5 гексов (радиус ~2 гекса), дробь — 6 м перед вами (3 гекса).'),
  C('Проверка навыка','**ХАР + навык + 1d10** против СЛ или против броска противника (ничья — у защищающегося). Натуральная 10 — бросьте ещё d10 и прибавьте; натуральная 1 — бросьте d10 и вычтите. Без навыка — только характеристика. Удача: перед броском +1 за очко, пул восстанавливается в начале сессии. Дополнительное время ×4 — +1. (стр. 128–130)'),
  {t:'Сложность (СЛ)',table:[['Сложность','СЛ'],...(CPR.DVTBL||[])]},
  {t:'Модификаторы',table:[['Обстоятельство','Мод.'],...(CPR.NEGMOD||[])]},
  C('Ход','Инициатива: **РЕА + 1d10**. В ход — **1 перемещение** и **1 действие**. Действия: атака, бег (второе перемещение), перезарядка, захват, удушение, бросок, встать, достать/убрать щит, стабилизировать, применить навык, использовать предмет, СЕТевые действия, завести транспорт, отложить действие. Атаки с СКА 2 можно разделить перемещением. За ход не больше двух атак. (стр. 168–170)'),
  {t:'СЛ одиночного выстрела',table:[['Оружие',...(CPR.BANDS||[])],...Object.entries(CPR.DVS||{}).map(([k,r])=>[({pistol:'Пистолеты',smg:'ПП',slug:'Дробовик (жакан)',ar:'Штурмовая винтовка',sniper:'Снайперская',bow:'Луки и арбалеты',gl:'Гранатомёт',rl:'Ракетомёт'})[k],...r.map(x=>x??'—')])]},
  {t:'СЛ автоогня',table:[['Оружие',...(CPR.BANDS||[]).slice(0,5)],['ПП',...(CPR.DVA.smg||[])],['Штурмовая винтовка',...(CPR.DVA.ar||[])]]},
  C('Дальний бой','**РЕА + навык оружия + 1d10** против СЛ по дистанции (с РЕА 8+ цель может вместо этого уклониться: ЛВК + Уклонение + 1d10). Прицельный выстрел −8: голова — прошедший урон ×2; рука — уронить предмет; нога — травма «Сломанная нога». Автоогонь: 10 патронов, навык «Автоогонь», урон 2d6 × превышение СЛ (ПП до ×3, винтовка до ×4). Подавление: 10 патронов, все в 25 м на линии огня кидают ВОЛЯ + Концентрация + 1d10 или бегут в укрытие. Дробь: СЛ 13, 3d6 всем в 6 м перед вами. Взрыв: 10×10 м. (стр. 170–174)'),
  C('Ближний бой','**ЛВК + навык + 1d10** против ЛВК + Уклонение + 1d10. Оружие ближнего боя и боевые искусства игнорируют половину брони (вверх). СКА 2, кроме очень тяжёлого. ТЕЛ 8+ — двуручное одной рукой. Рукопашный урон по ТЕЛ: до 4 — 1d6, 5–6 — 2d6, 7–10 — 3d6, 11+ — 4d6 (с киберрукой не меньше 2d6). Захват: ЛВК + Рукопашный бой, оба −2; удушение — урон = ТЕЛ мимо брони; бросок — урон = ТЕЛ, цель лежит. (стр. 175–180)'),
  C('Броня','Голова и тело отдельно. Броня не складывается — работает лучшая на месте. Если урон прошёл сквозь ОС — ОС этого места −1 (бронебойные −2). Тяжёлая броня даёт штраф к РЕА, ЛВК и СКО (наибольший, один раз). (стр. 184–186)'),
  {t:'Броня',table:[['Тип','ОС','Штраф','Цена'],...(CPR.ARMOR||[]).map(a=>[a[1],a[2],a[3]?'−'+a[3]+' РЕА/ЛВК/СКО':'нет',a[4]+'eb'])]},
  {t:'Укрытия (ПЗ на гекс)',table:[['Материал','Толстое','Тонкое'],...(CPR.COVER||[])]},
  {t:'Ранения',table:[['Состояние','Когда','Эффект','Стабилизация'],['Лёгкое','ПЗ меньше максимума','нет','СЛ 10'],['Тяжёлое','ПЗ меньше половины','−2 ко всем действиям','СЛ 13'],['Смертельное','ПЗ меньше 1','−4 ко всем действиям, −6 СКО; спасбросок каждый ход; травма от каждой атаки','СЛ 15']]},
  C('Спасбросок от смерти','В начале хода при смертельном ранении: **d10 + штраф ≤ ТЕЛ** — живы. 10 — всегда провал. Каждый спасбросок +1 к штрафу до стабилизации. Некоторые травмы добавляют постоянный штраф. Один провал — смерть. (стр. 188)'),
  C('Критические травмы','Если на кубах урона две и больше шестёрок — критическая травма: 2d6 по таблице тела (или головы при прицельном в голову), +5 урона в ПЗ мимо брони. Повторяйте бросок, пока не выпадет новая травма. (стр. 187–188)'),
  {t:'Травмы тела (2d6)',table:[['2d6','Травма','Эффект'],...((CPR.CRIT||{}).body||[]).map(r=>[r[0],r[1],r[2]])]},
  {t:'Травмы головы (2d6)',table:[['2d6','Травма','Эффект'],...((CPR.CRIT||{}).head||[]).map(r=>[r[0],r[1],r[2]])]},
  C('Лечение','Стабилизация — действие (Первая помощь / Парамедик против СЛ ранения). Стабилизированный восстанавливает ТЕЛ ПЗ за день отдыха. Травмы снимают быстрой помощью (временно) и лечением. (стр. 222–226)'),
  C('Человечность','Человечность = ЭМП × 10. Импланты при установке отнимают ПЧ (при создании — фиксированная, потом — бросок кубов). Каждые потерянные 10 — −1 ЭМП. 0 и ниже — киберпсихоз. Терапия возвращает человечность. (стр. 79–80, 108, 229–230)'),
  {t:'Очки улучшения',table:[['Уровень',1,2,3,4,5,6,7,8,9,10],['Навык',...CPR.IPCOST.skill],['Навык ×2',...CPR.IPCOST.skill2],['Ранг роли',...CPR.IPCOST.role]]},
  C('Права','«Лансеровские штучки» — неофициальный материал по Homebrew Content Policy R. Talsorian Games, не одобрен RTG. Ссылается на материалы, принадлежащие R. Talsorian Games и её лицензиатам. Cyberpunk — товарный знак CD PROJEKT RED S.A. Тексты — краткие пересказы, подробности в книге Cyberpunk RED (страницы указаны).'),
 ]};REF.push(CR_REF)}
