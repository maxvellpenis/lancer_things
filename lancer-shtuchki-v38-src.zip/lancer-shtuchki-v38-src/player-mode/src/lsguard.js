/* v33: проверка всего, что читается из хранилища браузера, ещё ДО запуска программы.
   Битые или подменённые записи не роняют программу и не попадают в разметку: типы верхнего уровня
   проверяются по ключу, значения-идентификаторы и цвета очищаются (ключи объектов — только без __proto__/constructor), глубина и размеры ограничены. */
{const g=LS.get;
 const sid=v=>String(v??'').replace(/[^\w\-~#.:]/g,'').slice(0,120);
 const obj=v=>!!v&&typeof v==='object'&&!Array.isArray(v);
 const n=(v,lo,hi)=>{const x=Number(v);return Number.isFinite(x)?Math.min(hi,Math.max(lo,Math.round(x))):undefined};
 const IDK=/^(id|uid|gid|sid|cls|team|hull|cap|esc|ace|kind|type|dt|tpl|cur|sel|key|frame|bgId|mechId|adjT|addTeam|k|w|tab|view|phase)$|Id$/;
 const BADK=new Set(['__proto__','constructor','prototype']);
 const deep=(v,d,key)=>{if(d>14)return undefined;
   if(v===null||typeof v==='boolean')return v;if(typeof v==='number')return Number.isFinite(v)?v:0;
   if(typeof v==='string'){if(key==='color'||/Color$/.test(key))return /^#[0-9a-fA-F]{3,8}$/.test(v)?v:'#888888';return IDK.test(key)?sid(v):v.slice(0,20000)}
   if(Array.isArray(v))return v.slice(0,600).map(x=>deep(x,d+1,key==='swFus'||key==='systems'||key==='conds'?key:'')).filter(x=>x!==undefined);
   if(typeof v==='object'){const r={};Object.keys(v).slice(0,600).forEach(k=>{const kk=String(k).slice(0,200);if(!kk||BADK.has(kk))return;const x=deep(v[k],d+1,kk);if(x!==undefined)r[kk]=x});return r}
   return undefined};
 const arr=v=>Array.isArray(v)?v.filter(obj):undefined;
 const word=v=>typeof v==='string'&&/^[a-z]{1,16}$/.test(v)?v:undefined;
 const TOP={npc_view:word,pc_tab:word,npc_cls:v=>typeof v==='string'&&sid(v)||undefined,pc_sel:v=>typeof v==='string'?sid(v):v===null?null:undefined,
  npc_tier:v=>n(v,1,3),npc_round:v=>n(v,1,9999),
  npc_sel:v=>obj(v)?v:undefined,npc_tplsel:v=>obj(v)?v:undefined,gm_res:v=>obj(v)?v:undefined,fold:v=>obj(v)?v:undefined,wf_enc_sel:v=>obj(v)?v:undefined,dg_rel:v=>obj(v)?v:undefined,
  npc_custom:arr,npc_ctpl:arr,npc_enc:v=>{const a=arr(v);return a&&a.slice(0,200)},pc_pilots:v=>{const a=arr(v);return a&&a.slice(0,60)},
  npc_teams:v=>{const a=arr(v);if(!a)return undefined;const t=a.slice(0,20).map(x=>({...x,id:sid(x.id),name:typeof x.name==='string'?x.name.slice(0,60):'Команда'})).filter(x=>x.id);return t.length?t:undefined},
  bg_state:v=>{if(!obj(v))return undefined;const r={...v};r.groups=arr(v.groups)||[];r.battle=obj(v.battle)?{...v.battle,units:arr(v.battle.units)||[],pls:Array.isArray(v.battle.pls)?v.battle.pls:[],brd:Array.isArray(v.battle.brd)?v.battle.brd:[]}:undefined;if(!r.battle)delete r.battle;r.add=obj(v.add)?v.add:{};return r},
  wf_eid:v=>v,cpr_npcs:v=>{const a=arr(v);return a&&a.slice(0,300)},lib_mode:word,cr_skcat:word};
 LS.get=function(k,d){const v=g.call(LS,k,d);if(!(k in TOP)||v===d)return v;try{const c=deep(v,0,'');const r=TOP[k](c);return r===undefined?d:r}catch(e){return d}};
}
