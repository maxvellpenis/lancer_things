/* ---------- v18: лицензии, навыки меха и таланты в духе Comp/Con ---------- */
const ART=/*@@ART@@*/null||{};
const ROLE_RU={Striker:'Нападающий',Defender:'Защитник',Support:'Поддержка',Controller:'Оператор',Artillery:'Артиллерист',Balanced:'Универсальный'};
const IC={w:'⚔',s:'⬢',m:'✚',f:'◭'};
function licItems(f,r){
  const out=[];
  PCD.weapons.filter(x=>x.lic===f.id&&x.ll===r&&!x.tal).forEach(x=>out.push({k:'w',x}));
  PCD.mods.filter(x=>x.lic===f.id&&x.ll===r).forEach(x=>out.push({k:'m',x}));
  PCD.systems.filter(x=>x.lic===f.id&&x.ll===r&&!x.tal).forEach(x=>out.push({k:'s',x}));
  if(r===2){out.push({k:'f',x:f});PCD.frames.filter(v=>v.variant===f.id).forEach(v=>out.push({k:'f',x:v,variant:1}))}
  return out;
}
function frameRoles(f){return String(f.role||'').split(/[\/,]\s*/).filter(Boolean)}
function artStyle(id){return ART[id]?`style="--art:url('${ART[id]}')"`:''}
function licHtml(p){
  const b=budgets(p).lc,free=b.max-b.used;
  const gms=PCD.frames.filter(f=>f.src==='GMS').sort((a,b)=>(a.variant?1:0)-(b.variant?1:0)),bk=f=>`<span class="lic-src">${esc(f.book&&BOOKS[f.book]?BOOKS[f.book].name:'Lancer')} · стр. ${f.page||'—'}</span>`;
  const gh=gms.length?`<div class="lic-man lic-gms" style="--mc:${MANU_COL.GMS}"><div class="lic-mh"><span class="lic-dia">◆</span>${esc(MANU_FULL.GMS)}<span class="lic-mr">доступно всегда</span></div>
   ${gms.map(f=>`<div class="lic-card has"><button class="lic-ban" data-pa="licitem" data-k="f" data-v="${f.id}" data-book="${f.book||''}" ${artStyle(f.id)}>${bk(f)}
     <span class="lic-txt"><small>${esc(MANU.GMS)}</small><b>${esc(f.name)}</b><span class="lic-roles">${frameRoles(f).map(x=>`<i>${esc(x)}</i>`).join('')}</span></span>
     <span class="lic-rank"><em class="on">∞</em></span></button></div>`).join('')}</div>`:'';
  return gh+MANU_ORDER.filter(mn=>mn!=='GMS'&&mn!=='EXOTIC').map(mn=>`<div class="lic-man" style="--mc:${MANU_COL[mn]}"><div class="lic-mh"><span class="lic-dia">◆</span>${esc(MANU_FULL[mn])}<span class="lic-mr">рангов ${licRanksOf(p,mn)}</span></div>
   ${PCD.frames.filter(f=>f.src===mn&&!f.variant).map(f=>{const r=p.lic[f.id]||0,op=PS.open['lic-'+f.id];
     return `<div class="lic-card ${r?'has':''} ${op?'open':''}">
      <button class="lic-ban" data-pa="licopen" data-v="${f.id}" ${artStyle(f.id)}>
        <span class="lic-txt"><small>${esc(MANU[mn])}</small><b>${esc(f.name)}</b><span class="lic-roles">${frameRoles(f).map(x=>`<i>${esc(x)}</i>`).join('')}</span></span>
        <span class="lic-rank">${[1,2,3].map(i=>`<em class="${i<=r?'on':''}">${'I'.repeat(i)}</em>`).join('')}</span></button>
      ${op?`<div class="lic-body">
        <div class="lic-cols">${[1,2,3].map(i=>`<div class="lic-col ${i<=r?'got':'lock'}"><div class="lic-ch">РАНГ ${'I'.repeat(i)} ${i<=r?'<span class="ok">✓</span>':'<span class="lk">🔒</span>'}</div>
          ${licItems(f,i).map(it=>`<button class="lic-it k${it.k}" data-pa="licitem" data-k="${it.k}" data-v="${it.x.id}"><span class="ic">${IC[it.k]}</span><span>${esc(it.k==='f'?(it.variant?'Вариант рамы: '+it.x.name:'Рама '+it.x.name):it.x.name)}</span></button>`).join('')}</div>`).join('')}</div>
        <div class="lic-acts">
          <button class="lic-rm" data-pa="lr" data-v="${f.id}" data-r="${r-1}" ${r?'':'disabled'}>— ${r?'Снять '+esc(f.name)+' '+'I'.repeat(r):'Нет рангов'}</button>
          <button class="lic-add" data-pa="lr" data-v="${f.id}" data-r="${r+1}" ${r>=3?'disabled':''}>＋ ${r>=3?'Лицензия получена полностью':'Открыть '+esc(f.name)+' '+'I'.repeat(r+1)}${r<3&&free<=0?' <small>(нет свободных рангов — будет ⚠)</small>':''}</button></div>
        <div class="lic-hint">Ранг II открывает раму. Каждый уровень лицензии — один ранг. Свободно рангов: <b>${Math.max(0,free)}</b>.</div>
      </div>`:''}</div>`}).join('')}</div>`).join('');
}
const HASE_FX={
  hull:[['ПЗ',v=>'+'+2*v],['Лимит Ремонта',v=>'+'+Math.floor(v/2)]],
  agi:[['Уклонение',v=>'+'+v],['Скорость',v=>'+'+Math.floor(v/2)]],
  sys:[['Э-Защита',v=>'+'+v],['Тех. Атака',v=>'+'+v],['СП',v=>'+'+Math.floor(v/2)]],
  eng:[['Тепл. Макс.',v=>'+'+v],['Доп. заряды',v=>'+'+Math.floor(v/2)]]};
const HASE_L={hull:'К',agi:'М',sys:'С',eng:'И'};
function haseHtml(p){
  return `<div class="hs-grid">${HASE.map(([k,l])=>{const v=p.hase[k];return `<div class="hs">
    <div class="hs-name kw" data-tt="${l}" data-tip="${esc(HASE_TIP[k])}">${l}</div>
    <div class="hs-ctl"><button class="pm" data-pa="hase" data-v="${k}" data-d="-1" ${v<=0?'disabled':''}>−</button>
      <div class="hs-bar"><span class="hs-ic">${HASE_L[k]}</span><span class="hs-num">${v}<small>/6</small></span>
        <span class="hs-cells">${[1,2,3,4,5,6].map(i=>`<i class="${i<=v?'on':''}" data-pa="hset" data-v="${k}" data-n="${i===v?i-1:i}"></i>`).join('')}</span></div>
      <button class="pm" data-pa="hase" data-v="${k}" data-d="1" ${v>=6?'disabled':''}>+</button></div>
    <div class="hs-fx">${HASE_FX[k].map(([n,f])=>`${n} <b>${f(v)}</b>`).join(' <span>//</span> ')}</div></div>`}).join('')}</div>`}
function talentHtml(p){
  const TB=[['','Основная книга Lancer'],['LR','Дополнение · The Long Rim'],['KTB','Дополнение · Торговые Баронства Карракина'],['WF','Дополнение · No Room for a Wallflower'],['DG','Дополнение · Dustgrave'],['SS',"Дополнение · Siren's Song"],['SR','Дополнение · Operation Solstice Rain']];
  return TB.filter(([b])=>PCD.talents.some(t=>(t.book||'')===b)).map(([b,lbl])=>`<div class="tl-book ${b?'dlc':''}"><b>${lbl}</b><span class="muted">${PCD.talents.filter(t=>(t.book||'')===b).length} талантов · взято ${PCD.talents.filter(t=>(t.book||'')===b&&(p.talents[t.id]||0)).length}</span></div><div class="tl-grid">${PCD.talents.filter(t=>(t.book||'')===b).map(t=>{const r=p.talents[t.id]||0;
    const rk=(rr,i)=>`<div class="trank ${i<r?'on':''}"><div class="trn">${'I'.repeat(i+1)} · ${esc(rr.name)}</div><div>${pfmt(rr.text)}</div></div>`;
    const rest=t.ranks.map((rr,i)=>i>=r?rk(rr,i):'').join('');const op=PS.open['t-'+t.id];
    return `<div class="talent ${r?'sel':''}"><div class="th"><b>${esc(t.name)}</b><span class="pp">${rankPips(r,3,'tr',t.id)}</span></div>
      ${t.ranks.map((rr,i)=>i<r?rk(rr,i):'').join('')}
      ${rest?`<button class="tl-more" data-pa="tlopen" data-v="${t.id}">${op?'▾ скрыть':'▸ '+(r?'следующие ранги':'показать ранги')}</button>${op?rest:''}`:''}</div>`}).join('')}</div>`).join('')}
/* окно предмета в стиле Comp/Con */
const KIND_RU={w:'Оружие меха',s:'Система меха',m:'Мод оружия',f:'Рама'};
const RNG_IC={Range:'⟋',Threat:'⚔',Line:'━',Cone:'◢',Blast:'◎',Burst:'✺'};
const DT_LBL={kinetic:'кинетический',energy:'энергетический',explosive:'взрывной',burn:'горение',heat:'нагрев',variable:'на выбор'};
function ioTags(tags){const tg=(tags||[]).filter(t=>PCD.tags[t[0]]);if(!tg.length)return '';
  return `<div class="io-sec">//МЕТКИ</div>${tg.map(t=>{const d=PCD.tags[t[0]];return `<div class="io-tag"><b>▰ ${esc(tagName(t))}</b><div>${pfmt(String(d.d||'').replace(/\{VAL\}|\bX\b/g,t[1]??'X'))}</div></div>`}).join('')}`}
function ioHead(k,x,right){return `<div class="io-hd"><span class="io-ic">${IC[k]}</span><b>${esc(k==='f'?'Рама '+x.name:x.name)}</b><span class="io-chips"><i>${esc(MANU[x.src]||x.src||'')}</i><i>${esc(KIND_RU[k])}</i></span><button class="io-x" data-pa="iox">✕</button></div>`}
function ioFlav(x){return x.flav?`<div class="io-sec">//ИЗ КНИГИ</div><div class="io-flav">${esc(x.flav).replace(/\n/g,'<br>')}</div>`:''}
function itemOverlay(k,id){
  const x=k==='w'?P.W[id]:k==='s'?P.SY[id]:k==='m'?P.MO[id]:P.F[id];if(!x)return;
  let h=ioHead(k,x);
  if(k==='w'){const w=(x.profiles&&x.profiles.length&&!(x.dmg||[]).length)?{...x,dmg:x.profiles[0].dmg||[],rng:x.profiles[0].rng||[]}:x;
    h+=`<div class="io-top"><div class="io-stats">${(w.rng||[]).map(r=>`<div class="io-st"><span><em>${RNG_IC[r.t]||''}</em>${esc(r.v)}</span><small>${esc(RNG_RU[r.t]||r.t)}</small></div>`).join('')}
      ${(w.dmg||[]).map(d=>`<div class="io-st dmg"><span>${esc(String(d.v).toUpperCase())}</span><small>${esc(DT_LBL[d.t]||d.t)}</small></div>`).join('')}</div>
      <div class="io-meta"><b>${esc((WSIZE_RU[x.mount]||x.mount)+' · '+(WTYPE_RU[x.type]||x.type))}</b><span>${esc(licLabel(x))}</span>${x.sp?`<span>${x.sp} СП</span>`:''}</div></div>
      ${x.profiles&&x.profiles.length>1?`<div class="io-sec">//РЕЖИМЫ</div>${x.profiles.map(pr=>`<div class="io-tag"><b>▰ ${esc(profRu(pr.name))}</b><div>${esc(rngTxt(pr.rng||[]))}${pr.dmg&&pr.dmg.length?' · '+esc(dmgTxt(pr.dmg)):''}</div></div>`).join('')}`:''}
      ${ioTags(x.tags)}${x.text?`<div class="io-sec">//ЭФФЕКТ</div><div class="io-txt">${pfmt(x.text)}</div>`:''}${ioFlav(x)}`}
  else if(k==='s'||k==='m'){
    h+=`<div class="io-top"><div class="io-stats">${x.sp!=null?`<div class="io-st"><span>${x.sp}</span><small>системных очков</small></div>`:''}</div>
      <div class="io-meta"><b>${k==='m'?'Мод':esc(SYSTYPE_RU[x.type]||'Система')}</b><span>${esc(licLabel(x))}</span>${k==='m'&&x.types?`<span>для: ${esc(x.types.map(t=>WTYPE_RU[t]||t).join(', '))}</span>`:''}</div></div>
      ${ioTags(x.tags)}${x.text?`<div class="io-sec">//ЭФФЕКТ</div><div class="io-txt">${pfmt(x.text)}</div>`:''}
      ${(x.deps||[]).length?`<div class="io-sec">//РАЗМЕЩАЕМОЕ</div>${x.deps.map(d=>`<div class="io-tag"><b>▰ ${esc(d.n)}</b><div>Размер ${sizeTxt(d.size)} · ПЗ ${esc(d.hp)}${d.ev!=null?' · Уклонение '+esc(d.ev):''}${d.ed!=null?' · Э-Защита '+esc(d.ed):''}${d.inst>1?' · ×'+d.inst:''}</div></div>`).join('')}`:''}${ioFlav(x)}`}
  else{const st=x.stats;
    h+=`<div class="io-art" ${artStyle(x.id)}></div><div class="io-top fr"><div class="io-meta"><b>${esc(x.role)}</b><span>${esc(MANU_FULL[x.src])}</span><span>Слоты: ${x.mounts.map(m=>esc(MOUNT_RU[m]||m)).join(', ')}</span></div></div>
    <div class="mstats" style="margin:8px 0">${[['ПЗ',st.hp],['Броня',st.armor],['Структура',st.structure],['Нагрузка',st.stress],['Уклонение',st.evasion],['Э-Защита',st.edef],['Скорость',st.speed],['Размер',sizeTxt(st.size)],['Тепл. Макс.',st.heatcap],['Лимит Ремонта',st.repcap],['Сенсоры',st.sensor_range],['Спас. Цель',st.save],['Тех. Атака',sgn(st.tech_attack)],['СП',st.sp]].map(([a,b])=>`<div class="sc"><span>${a}</span><b>${b}</b></div>`).join('')}</div>
    <div class="io-sec">//ЧЕРТЫ</div>${x.traits.map(t=>`<div class="io-tag"><b>▰ ${esc(t.name)}</b><div>${pfmt(t.text)}</div></div>`).join('')}<div class="io-sec">//СИСТЕМА ЯДРА — ${esc(x.core.name)}</div>${coreHtml(x)}`}
  let o=document.getElementById('itemov');if(!o){o=document.createElement('div');o.id='itemov';document.body.appendChild(o)}
  o.innerHTML=`<div class="io-box k${k}">${h}</div>`;o.classList.add('on');o.scrollTop=0;
}
/* кнопка ⓘ на карточках предметов в сборке меха и в бою */
{const o=itemCard;itemCard=function(x,kind,opts){const k=kind==='w'?'w':kind==='mod'?'m':'s';const h=o(x,kind,opts);
  return h.replace('</summary>',`<span class="io-btn" data-pa="licitem" data-k="${k}" data-v="${esc(x.id)}" title="Подробно">ⓘ</span></summary>`)}}
document.addEventListener('click',e=>{
  const ov=document.getElementById('itemov');if(ov&&ov.classList.contains('on')&&(e.target===ov||e.target.closest('[data-pa="iox"]'))){ov.classList.remove('on');return}
  const el=e.target.closest('[data-pa]');if(!el)return;const a=el.dataset.pa,v=el.dataset.v,p=curP();if(!p)return;
  if(a==='licitem'&&el.classList.contains('io-btn')){e.preventDefault()}
  if(a==='licopen'){PS.open['lic-'+v]=!PS.open['lic-'+v];pcRender()}
  else if(a==='licitem')itemOverlay(el.dataset.k,v);
  else if(a==='tlopen'){PS.open['t-'+v]=!PS.open['t-'+v];pcRender()}
  else if(a==='hset'){p.hase[v]=Math.max(0,Math.min(6,+el.dataset.n));pcRender()}
});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){const o=document.getElementById('itemov');if(o)o.classList.remove('on')}});
/* арт рамы в сборке меха */
{const o=viewMech;viewMech=function(p){const h=o(p);const m=curM(p);return ART[m.frame]?h.replace('<section class="pbox"><h3 style="display:flex;gap:8px;align-items:center">',`<section class="pbox mech-art" ${artStyle(m.frame)}><h3 style="display:flex;gap:8px;align-items:center">`):h}}
