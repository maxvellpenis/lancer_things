const {chromium}=require('/opt/npm-tools/node_modules/playwright');const SP='/tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad/';
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1400,height:950}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text().slice(0,200))});
 const cl=async s=>{await pg.click(s)};const ev=f=>pg.evaluate(f);const last=()=>ev(()=>{const e=document.querySelector('.cr-last');return e?e.innerText.replace(/\s+/g,' ').slice(0,160):''});
 await pg.goto('file:///home/claude/lancer-shtuchki-v38.html');await cl('[data-role="gm"]');await cl('[data-act="view"][data-v="pc"]');await cl('[data-pa="pnew"]');
 await cl('[data-hb="tog"]');await cl('[data-pa="ptab"][data-v="bond"]');
 console.log('tab',await ev(()=>document.querySelector('[data-pa="ptab"][data-v="bond"]').textContent),!!(await pg.$('.cr-sheet')));
 // creation
 await cl('[data-cr="sub"][data-v="life"]');await cl('[data-cr="lpall"]');
 await pg.selectOption('[data-cf="lp"][data-v="origin"]','4');await pg.fill('[data-cf="langFree"]','Русский');await pg.dispatchEvent('[data-cf="langFree"]','change');
 console.log('lp',await ev(()=>JSON.stringify(curP().cpr.lp).slice(0,300)));
 await cl('[data-cr="sub"][data-v="make"]');await pg.selectOption('.cr-sheet select[data-cf="role"]','solo');
 await cl('input[data-cf="method"][value="sr"]');await cl('[data-cr="srpick"][data-v="5"]');console.log('sr',await last());
 await cl('[data-cr="kitapply"]');console.log('kit',await ev(()=>{const c=curP().cpr;return JSON.stringify({w:c.wpn.map(w=>w.id+':'+w.mag),am:c.ammo,g:c.gear,cy:c.cy.map(x=>x.id+'<'+(x.p?'p':'')),hum:c.hum,eb:c.eb,sk:Object.keys(c.sk).length})}));
 console.log('check',await ev(()=>[...document.querySelectorAll('.cr-ok,.cr-warn')].map(e=>e.textContent).join(' | ')));
 await cl('[data-cr="finish"]');
 // main
 await cl('[data-cr="sub"][data-v="main"]');await cl('[data-cr="rstat"][data-v="ref"]');console.log('roll',await last());
 await cl('[data-cr="nxl"][data-d="1"]');await cl('[data-cr="nxm"][data-d="1"]');await cl('[data-cr="rstat"][data-v="cool"]');console.log('luck roll',await last(),await ev(()=>curP().cpr.luck));
 await pg.fill('#crIpAdd','200');await cl('[data-cr="ipadd"]');
 await cl('[data-cr="sub"][data-v="skills"]');await cl('[data-cr="skcat"][data-v="mine"]');const n1=await ev(()=>document.querySelectorAll('.cr-sk').length);
 await cl('[data-cr="rsk"][data-v="hand"]');console.log('skill',n1,await last());
 await cl('[data-cr="skip"][data-v="hand"]');console.log('ip up',await last(),await ev(()=>[curP().cpr.sk.hand,curP().cpr.ip]));
 await cl('[data-cr="sub"][data-v="role"]');await cl('[data-cr="solo"][data-v="pa"][data-d="3"]');await cl('[data-cr="solo"][data-v="ir"][data-d="1"]');console.log('solo',await ev(()=>JSON.stringify(curP().cpr.ab.solo)));
 // combat
 await cl('[data-cr="sub"][data-v="combat"]');await cl('[data-cr="init"]');console.log('init',await last());
 await cl('.cr-w [data-cr="atk"]');console.log('shot',await last());await cl('.cr-w [data-cr="dmg"]');console.log('dmg',await last());
 await cl('[data-cr="autofire"]');console.log('auto',await last());await cl('[data-cr="reload"]');console.log('reload',await last());
 await pg.fill('#crDmgN','25');await cl('[data-cr="takedmg"]');console.log('take',await last());
 await pg.fill('#crDmgN','40');await pg.check('#crDmgCrit');await cl('[data-cr="takedmg"]');console.log('take2',await last());
 const hp=await ev(()=>curP().cpr.hp);console.log('hp',hp,await ev(()=>document.querySelector('.cr-wound').textContent));
 if(await pg.$('[data-cr="ds"]')){await cl('[data-cr="ds"]');console.log('ds',await last())}
 await cl('[data-cr="stab"]');
 // cyber
 await cl('[data-cr="sub"][data-v="cyber"]');await pg.selectOption('#crCyAdd','kerenz');await cl('[data-cr="cyadd"]');console.log('cy kerenz',await last());
 const nl=await ev(()=>curP().cpr.cy.find(x=>x.id==='nlink').u);await pg.selectOption('#crCyAdd','chipsock');await pg.selectOption('#crCyPar',nl);await cl('[data-cr="cyadd"]');console.log('cy sock',await last());
 await pg.selectOption('#crCyAdd','muscle');await pg.selectOption('#crCyHl','roll');await cl('[data-cr="cyadd"]');console.log('muscle',await last());
 await cl('[data-cr="sub"][data-v="gear"]');await pg.selectOption('#crGAdd','techscan');await pg.check('#crGBuy');await cl('[data-cr="gadd"]');
 await pg.selectOption('#crPrAdd','p:sword');await cl('[data-cr="pradd"]');
 await cl('[data-cr="sub"][data-v="main"]');console.log('stats',await ev(()=>[...document.querySelectorAll('.cr-st')].map(e=>e.innerText.replace(/\s+/g,'')).join(' ')));
 await pg.screenshot({path:SP+'t38_main.png',fullPage:false});
 for(const t of ['skills','role','combat','gear','cyber','life','make','notes']){await cl(`[data-cr="sub"][data-v="${t}"]`);await pg.screenshot({path:SP+'t38_'+t+'.png'})}
 // reload persistence
 const before=await ev(()=>JSON.stringify(curP().cpr));await pg.reload();await cl('[data-role="gm"]');await cl('[data-act="view"][data-v="pc"]');await cl('[data-pa="ptab"][data-v="bond"]');
 const after=await ev(()=>JSON.stringify(curP().cpr)||'NONE '+JSON.stringify(Object.keys(curP()))+' raw:'+!!JSON.parse(localStorage.getItem('pc_pilots'))[0].cpr);console.log('errs so far',errs);console.log('persist same',before===after,before.length,after.slice(0,300));
 if(before!==after&&!after.startsWith('NONE')){const A=JSON.parse(before),B=JSON.parse(after);for(const k in A)if(JSON.stringify(A[k])!==JSON.stringify(B[k]))console.log('diff',k,String(JSON.stringify(A[k])).slice(0,200),'|',String(JSON.stringify(B[k])).slice(0,200))}
 // library
 await cl('[data-act="view"][data-v="lib"]');await cl('[data-crl="mode"][data-v="cpr"]');await cl('[data-crl="gen"]');console.log('npc',await ev(()=>document.querySelector('#main .pc-big').value));
 await cl('#main [data-crl="atk"]');await cl('#main [data-crl="dmg"]');await pg.fill('#crlDmgN','20');await cl('[data-crl="dmgin"]');console.log('npc last',await ev(()=>document.querySelector('.cr-last').innerText));
 await cl('[data-crl="mook"][data-v="cyberpsycho"]');await cl('[data-crl="dup"]');console.log('lib count',await ev(()=>CRLIB.length));
 await pg.screenshot({path:SP+'t38_lib.png'});
 await cl('[data-crl="mode"][data-v="lancer"]');console.log('lancer back',await ev(()=>!!document.querySelector('.npc-head')||document.querySelector('#main').innerText.slice(0,60)));
 await cl('[data-act="view"][data-v="ref"]');console.log('ref',await ev(()=>!!document.getElementById('ref-cpr')));
 await pg.setViewportSize({width:390,height:844});await cl('[data-act="view"][data-v="pc"]');await cl('[data-pa="ptab"][data-v="bond"]');
 for(const t of ['main','skills','combat','cyber','life','gear','make']){await cl(`[data-cr="sub"][data-v="${t}"]`);const w=await ev(()=>document.documentElement.scrollWidth);if(w>390)console.log('WIDE',t,w)}
 await pg.screenshot({path:SP+'t38_m.png'});
 console.log('errs',errs);await b.close()})();
