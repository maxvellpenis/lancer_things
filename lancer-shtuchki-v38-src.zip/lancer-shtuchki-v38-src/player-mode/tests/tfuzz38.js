const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1400,height:900}});const errs=[];pg.on('pageerror',e=>errs.push(e.message.slice(0,160)));pg.on('dialog',d=>{errs.push('DIALOG');d.dismiss()});
 await pg.goto('file:///home/claude/lancer-shtuchki-v38.html');
 await pg.evaluate(()=>{const X='"><img src=x onerror=alert(1)><script>alert(2)</script>';const J=[X,{a:X},null,-1e9,NaN,'__proto__',[[X]]];
  const cpr={handle:X,role:X,rank:X,roles2:[{id:'solo',rank:99},X],method:X,st:{int:X,ref:1e9,emp:-5},luck:X,hum:'x',hp:{},sk:{[X]:5,['lang|'+X]:7,'__proto__':3,conc:'9'},ab:{solo:{dd:X},team:[{t:X,n:X,row:99,loy:X}],veh:[X,1],fans:[X]},
   wpn:[{id:X,n:X,q:X,att:[X,'drum'],mag:-5,am:X,band:99,dmg:X},X],arm:{head:{id:X,sp:X},body:X},cyl:X,shield:X,crit:[{l:X,r:X}],cy:[{id:'nlink',u:X,p:X,hl:X,s:X},{id:X}],gear:[{id:X,n:X,q:X}],ammo:{[X]:5,'vhp:basic':X},
   fash:[{s:99,i:99,q:X}],house:X,life:X,deck:{q:X,pr:[X,'sword'],hw:[X]},lp:{[X]:X,friends:[X,[X]],enemys:[[X,X]],langFree:X},notes:X,sub:X,nx:X,cr:{pts:X,kit:{[X]:X}}};
  localStorage.setItem('pc_pilots',JSON.stringify([{id:'p1',name:X,cpr},{id:'p2',name:'b',cpr:X},{id:'p3',cpr:J}]));localStorage.setItem('hb_on','true');
  localStorage.setItem('cpr_npcs',JSON.stringify([{n:X,st:X,w:[X,{n:X,dmg:X}],sk:[[X,X]],cy:X,crit:[X]},X,null,[X]]));localStorage.setItem('lib_mode',JSON.stringify(X));localStorage.setItem('cr_skcat',JSON.stringify(X))});
 await pg.reload();await pg.click('[data-role="gm"]');await pg.click('[data-act="view"][data-v="pc"]');
 for(const pid of ['p1','p2','p3']){await pg.evaluate(id=>{PS.sel=id;PS.tab='bond';pcRender()},pid);
  for(const t of ['main','skills','role','combat','gear','cyber','life','make','notes']){const bt=await pg.$(`[data-cr="sub"][data-v="${t}"]`);if(bt)await bt.click()}}
 const bad=await pg.evaluate(()=>document.querySelectorAll('#main img[src="x"],#main script,#side img[src="x"]').length);
 await pg.click('[data-act="view"][data-v="lib"]');const sw=await pg.$('[data-crl="mode"][data-v="cpr"]');if(sw)await sw.click();const s=await pg.$('.citem[data-crl="sel"]');if(s)await s.click();
 const bad2=await pg.evaluate(()=>document.querySelectorAll('#main img[src="x"],#main script,#side img[src="x"]').length);
 console.log('xss nodes',bad,bad2,'errs',errs);await b.close()})();
