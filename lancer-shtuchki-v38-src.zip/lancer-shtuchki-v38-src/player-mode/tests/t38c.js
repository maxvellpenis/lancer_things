const {chromium}=require('/opt/npm-tools/node_modules/playwright');const SP='/tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad/';
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1400,height:950}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
 const cl=async s=>{await pg.click(s)};const ev=f=>pg.evaluate(f);
 await pg.goto('file:///home/claude/lancer-shtuchki-v38.html');await cl('[data-role="gm"]');await cl('[data-act="view"][data-v="lib"]');await cl('[data-crl="mode"][data-v="cpr"]');
 await pg.setInputFiles('#crlFile','/home/claude/cpr-npc-book-personal.json');await pg.waitForTimeout(300);
 console.log(await ev(()=>[CRLIB.length,document.querySelector('.cr-last')&&document.querySelector('.cr-last').innerText]));
 await cl('.citem[data-crl="sel"]');console.log(await ev(()=>document.querySelector('#main .pc-big').value));
 const sel=await pg.$$('.citem[data-crl="sel"]');await sel[sel.length-1].click();
 console.log(await ev(()=>document.querySelector('#main').innerText.slice(0,300).replace(/\s+/g,' ')));
 await cl('#main [data-crl="atk"]');await cl('#main [data-crl="auto"]');console.log(await ev(()=>document.querySelector('.cr-last').innerText));
 await pg.screenshot({path:SP+'t38c.png'});
 // malicious import
 await pg.evaluate(()=>{});const bad=SP+'bad.json';require('fs').writeFileSync(bad,JSON.stringify({npcs:[{n:'<img src=x onerror=alert(1)>',st:{ref:'<b>'},w:[{n:'<script>',dmg:'9d6"><img>',sk:'x'}],sk:[['<i>x</i>',5]],cy:'<svg onload=1>',__proto__:{x:1}}]}));
 await pg.setInputFiles('#crlFile',bad);await pg.waitForTimeout(300);const s2=await pg.$$('.citem[data-crl="sel"]');await s2[0].click();
 console.log('xss',await ev(()=>document.querySelectorAll('#main img,#main script,#main svg,#side img').length), await ev(()=>document.querySelector('#main .pc-big').value));
 // reload persistence
 await pg.reload();await cl('[data-role="gm"]');await cl('[data-act="view"][data-v="lib"]');console.log('after reload',await ev(()=>[CRLIB.length,CRLIB_MODE]));
 console.log('errs',errs);await b.close()})();
