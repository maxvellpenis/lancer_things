const {chromium}=require('/opt/npm-tools/node_modules/playwright');const SP='/tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad/';
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1400,height:950}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
 const cl=async s=>{await pg.click(s)};const ev=f=>pg.evaluate(f);const last=()=>ev(()=>{const e=document.querySelector('.cr-last');return e?e.innerText.replace(/\s+/g,' ').slice(0,160):''});
 await pg.goto('file:///home/claude/lancer-shtuchki-v38.html');await cl('[data-role="player"]');await cl('[data-pa="pnew"]');
 if(!(await pg.$('.hb-btn.on')))await cl('[data-hb="tog"]');await cl('[data-pa="ptab"][data-v="bond"]');
 await cl('[data-cr="sub"][data-v="make"]');await pg.selectOption('.cr-sheet select[data-cf="role"]','net');await cl('input[data-cf="method"][value="er"]');
 await cl('[data-cr="erroll"]');console.log('er',await last());await pg.screenshot({path:SP+'t38b_make.png',fullPage:true});
 await cl('[data-cr="sub"][data-v="skills"]');await cl('[data-cr="skcat"][data-v="all"]');
 // spend points: elec (x2) up to 6, then check budget
 for(let i=0;i<4;i++)await cl('[data-cr="sk"][data-v="elec"][data-d="1"]');
 console.log('budget',await ev(()=>document.querySelector('h2 .cr-small').textContent),await ev(()=>curP().cpr.sk.elec));
 console.log('non-role ctl',await ev(()=>{const c=[...document.querySelectorAll('.cr-sk')].find(e=>e.textContent.includes('Бухгалтерия'));return c&&c.querySelector('.cr-skc').textContent}));
 await pg.screenshot({path:SP+'t38b_sk.png'});
 // complete package
 await cl('[data-cr="sub"][data-v="make"]');await cl('input[data-cf="method"][value="cp"]');await cl('[data-cr="cpstart"]');
 await cl('[data-cr="sub"][data-v="main"]');await cl('[data-cr="st"][data-v="ref"][data-d="1"]');await cl('[data-cr="st"][data-v="ref"][data-d="1"]');console.log('cp stats',await ev(()=>document.querySelector('h2 .cr-small').textContent));
 await cl('[data-cr="sub"][data-v="cyber"]');for(const id of ['nlink','plugs','kerenz','cyberarm','popranged','wolvers','superchrome','cybereye','imgenh']){await pg.selectOption('#crCyAdd',id);await pg.check('#crCyBuy');await cl('[data-cr="cyadd"]');console.log(id,await last())}
 await pg.screenshot({path:SP+'t38b_cy.png',fullPage:true});
 await cl('[data-cr="sub"][data-v="skills"]');console.log('mods',await ev(()=>{const c=[...document.querySelectorAll('.cr-sk')].find(e=>e.textContent.includes('Внимательность'));return c&&c.innerText.replace(/\s+/g,' ')}));
 await cl('[data-cr="sub"][data-v="role"]');await pg.screenshot({path:SP+'t38b_role.png',fullPage:true});
 for(const r of ['rocker','tech','med','media','exec','law','fixer','nomad']){await pg.selectOption('.cr-sheet select[data-cf="role"]',r);const t=await ev(()=>document.querySelector('#main').innerText.length);const bt=await pg.$$('.cr-sheet [data-cr="abroll"],.cr-sheet [data-cr="backup"],.cr-sheet [data-cr="haggle"],.cr-sheet [data-cr="memadd"],.cr-sheet [data-cr="techroll"],.cr-sheet [data-cr="believe"]');if(bt.length){await bt[0].click();console.log(r,await last())}else console.log(r,'no btn',t)}
 await cl('[data-cr="sub"][data-v="life"]');await pg.screenshot({path:SP+'t38b_life.png',fullPage:true});
 await cl('[data-cr="sub"][data-v="gear"]');await pg.screenshot({path:SP+'t38b_gear.png',fullPage:true});
 console.log('errs',errs);await b.close()})();
