import json,re
P=json.load(open('../cpr/pages.json'))
def grab(n,start,end):
  t=P[str(n)].replace('\n',' ')
  a=t.find(start);b=t.find(end,a)
  return t[a+len(start):b]
s1=grab(86,'Навык Ур Навык Ур Навык Ур Навык Ур Навык Ур','Определения навыков')
s2=grab(87,'Навык Ур Навык Ур Навык Ур Навык Ур Навык Ур','Пример:')
def pairs(s):
  s=s.replace('(выбери 1)','(выбери)').replace('(х2)','').replace('(x2)','')
  s=re.sub(r'\s+',' ',s)
  return [(a.strip(),int(b)) for a,b in re.findall(r'([^\d]+?)\s+(\d+)(?=\s|$)',s)]
p1=pairs(s1);p2=pairs(s2)
print(len(p1),len(p2))
r1=['rocker','solo','net','tech','med'];r2=['media','law','exec','fixer','nomad']
out={}
for roles,pp in ((r1,p1),(r2,p2)):
  for i,(n,l) in enumerate(pp): out.setdefault(roles[i%5],[]).append([n,l])
for k,v in out.items(): print(k,len(v),sum(l for n,l in v),v[13:])
json.dump(out,open('streetrat_sk.json','w'),ensure_ascii=False)
