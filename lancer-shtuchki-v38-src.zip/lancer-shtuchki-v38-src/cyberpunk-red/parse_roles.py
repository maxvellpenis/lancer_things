import json,re
P=json.load(open('../cpr/pages.json'))
txt=' '.join(P[str(n)] for n in (74,75,76,77))
txt=txt.replace('\n',' ')
roles=['Рокербой','Соло','Нетраннер','Техник','Медтехник','Медиа','Законник','Корпорат','Фиксер','Кочевник']
ids=['rocker','solo','net','tech','med','media','law','exec','fixer','nomad']
out={}
for i,r in enumerate(roles):
  a=txt.find('Ü '+r)
  assert a>=0,r
  b=min([x for x in [txt.find('Ü '+rr,a+3) for rr in roles]+[txt.find('ᶩМетоод',a)] if x>a] or [len(txt)])
  seg=txt[a:b]
  nums=[int(x) for x in re.findall(r'(?<![\w-])\d+(?![\w-])',seg)]
  # find sequence starting with 1, 11 per row
  rows=[]
  k=nums.index(1)
  for row in range(10):
    chunk=nums[k+row*11:k+row*11+11]
    assert chunk[0]==row+1,(r,row,chunk)
    rows.append(chunk[1:])
  out[ids[i]]=rows
json.dump(out,open('role_stats.json','w'))
for k,v in out.items():print(k,v[0],v[9])
