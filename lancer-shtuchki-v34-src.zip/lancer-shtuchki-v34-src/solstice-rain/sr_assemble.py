# Добавляет в pcdata.json снаряжение игроков из «Operation Solstice Rain»: числа из @massif/osr-data 1.2.0, тексты из sr_ru.json.
# Повторный запуск безопасен: прежние записи SR удаляются.
import json,os,sys
H=os.path.dirname(os.path.abspath(__file__))
DD=os.environ.get('SRDATA',os.path.join(H,'..','srdata','package','lib'))
PCD=sys.argv[1] if len(sys.argv)>1 else os.path.join(H,'..','pc','pcdata.json')
J=lambda f:json.load(open(os.path.join(DD,f+'.json')))
RU=json.load(open(os.path.join(H,'sr_ru.json')))
d=json.load(open(PCD))
for k in ('frames','weapons','systems','mods','talents','gear','reserves','cbs'):d[k]=[x for x in d[k] if x.get('book')!='SR']
ROLE={'Striker':'Нападающий','Defender':'Защитник','Support':'Поддерживающий','Controller':'Оператор','Artillery':'Артиллерист','Balanced':'Универсальный'}
WS={'Auxiliary':'Вспомогательное','Main':'Основное','Heavy':'Тяжелое','Superheavy':'Сверхтяжелое'}
WT={'Melee':'ОББ','CQB':'ОБД','Rifle':'Винтовка','Launcher':'ПУ','Cannon':'Пушка','Nexus':'Звено'}
TAGRU={k:v['n'] for k,v in d['tags'].items()}
rng=lambda a:[{'t':x['type'],'v':x['val']} for x in (a or [])]
dmg=lambda a:[{'t':x.get('type','variable').lower(),'v':x['val']} for x in (a or [])]
tags=lambda a:[[x['id'],x.get('val')] for x in (a or [])]
tagtxt=lambda tg:[TAGRU.get(t[0],t[0]).replace('{VAL}',str(t[1] if t[1] is not None else 'X')) for t in tg if t[0] in TAGRU]
TRB={'Replaceable Parts':[{'id':'cheap_struct','val':1}]}
for f in J('frames'):
    r=RU['frames'][f['id']];cs=f['core_system'];rc=r['core']
    tr=[dict(name=n,en=t['name'],text=b,bonuses=t.get('bonuses') or TRB.get(t['name']),use=t.get('use')) for (n,b),t in zip(r['traits'],f['traits'])]
    core=dict(name=rc['name'],en=cs['name'],aname=rc.get('aname'),atext=rc.get('atext',''),atags=rc.get('atags',''),act=cs.get('activation'),use=cs.get('use'),
              pname=rc.get('pname'),ptext=rc.get('ptext'),integrated=cs.get('integrated') or [],bonuses=cs.get('active_bonuses'))
    d['frames'].append(dict(id=f['id'],name=r['name'],en=f['name'],src=f['source'],ll=f['license_level'],role='/'.join(ROLE.get(m,m) for m in f['mechtype']),
        mounts=f['mounts'],stats=f['stats'],traits=tr,core=core,page=r['page'],book='SR',variant='mf_standard_pattern_i_everest'))
for w in J('weapons'):
    r=RU['items'][w['id']];tg=tags(w.get('tags'))
    o=dict(id=w['id'],name=r['name'],en=w['name'],src='EXOTIC',lic='',licn='Экзотика',ll=0,mount=w['mount'],type=w['type'],
           dmg=dmg(w.get('damage')),rng=rng(w.get('range')),tags=tg,sp=w.get('sp') or 0,text=r['text'],page=r['page'],book='SR',exo=1)
    o['rutags']=', '.join([f"{WS.get(w['mount'],w['mount'])} {WT.get(w['type'],w['type'])}"]+tagtxt(tg))
    d['weapons'].append(o)
ACTS={'ms_adjutant_class_compcon':[dict(name='Active Assist',act='Free',tech=False)],
      'ms_pattern_c_advanced_charges':[dict(name='Smart Grenade',act='Quick',tech=False)],
      'ms_miniaturized_linac_coherent_beam_cannon':[dict(name='LinAc CBC',act='Full',tech=False)]}
for s in J('systems'):
    r=RU['items'][s['id']];tg=tags(s.get('tags'))
    if s['id']=='ms_adjutant_class_compcon':tg=[['tg_ai',None],['tg_no_cascade',None],['tg_unique',None],['tg_exotic',None]]
    o=dict(id=s['id'],name=r['name'],en=s['name'],src='EXOTIC',lic='',licn='Экзотика',ll=0,sp=s.get('sp') or 0,type=s.get('type','System'),
           tags=tg,rutags=', '.join(([f"{s['sp']} СП"] if s.get('sp') else [])+tagtxt(tg)),text=r['text'],bonuses=s.get('bonuses'),page=r['page'],book='SR',exo=1)
    if s['id'] in ACTS:o['acts']=ACTS[s['id']]
    if s.get('deployables'):o['deploy']=[dict(name=x['name'],type=x.get('type'),size=None,hp=None,eva=None,edef=None) for x in s['deployables']]
    d['systems'].append(o)
for t in J('talents'):
    r=RU['talents'][t['id']]
    rk=[dict(name=n,en=x['name'],text=b,bonuses=x.get('bonuses'),integrated=x.get('integrated') or [],counters=None) for (n,b),x in zip(r['ranks'],t['ranks'])]
    d['talents'].append(dict(id=t['id'],name=r['name'],en=t['name'],ranks=rk,page=r['page'],book='SR'))
EN={x['id']:x['name'] for x in J('reserves')}
for x in J('reserves'):
    n,ty,tx=RU['reserves'][x['id']]
    d['reserves'].append(dict(id=x['id'],type=ty,name=n,en=x['name'],text=tx,page=31,book='SR'))
json.dump(d,open(PCD,'w'),ensure_ascii=False,indent=0)
print('SR:',{k:sum(1 for x in d[k] if x.get('book')=='SR') for k in ('frames','weapons','systems','talents','reserves')})
