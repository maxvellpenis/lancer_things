# -*- coding: utf-8 -*-
# Таблица резервов «Operation Solstice Rain» (стр. 31): d20, по 2 значения на строку. Тексты — из sr_ru.json.
import json,os
H=os.path.dirname(os.path.abspath(__file__))
RU=json.load(open(os.path.join(H,'sr_ru.json')))['reserves']
ORDER=['reserve_up_armoring','reserve_hot_load_ammunition','reserve_recon_drone','reserve_sniper_team','reserve_lookingglass','reserve_leg_enhancements','reserve_high_mobility_pack','reserve_golden_ticket','reserve_personal_touch','reserve_return_to_sender']
rows=[[RU[k][0],RU[k][2].replace('**','')] for k in ORDER]
G=[dict(id='sr_reserves',grp='Operation Solstice Rain · Резервы',name='Резервы за отдых (d20)',die='1d20',page=31,ranges=[[i,i+1] for i in range(1,21,2)],rows=rows,
  note='Награда за действия в даунтайме вместо резервов из основной книги (стр. 50–52). Часть резервов действует всю следующую миссию, часть тратится. Все они есть и в листе пилота (вкладка «Резервы»).',book='SR')]
json.dump(G,open(os.path.join(H,'sr_gmtables.json'),'w'),ensure_ascii=False)
print('ok',len(rows))
