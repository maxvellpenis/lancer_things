import json
D=json.load(open('pcdata.json'));items=json.load(open('qa/items.json'))
G={}
for t in D['talents']:
    for i,r in enumerate(t['ranks']):G[t['id']+'#'+str(i)]=r['text']
for f in D['frames']:
    for i,t in enumerate(f['traits']):G[f['id']+'#t'+str(i)]=t['text']
    G[f['id']+'#active_name']=f['core']['atext'];G[f['id']+'#passive_name']=f['core']['ptext']
for k in ('systems','weapons','mods','cbs','gear'):
    for x in D[k]:G[x['id']]=x['text']
for it in items: it['text']=G.get(it['id'],it['text'])
json.dump(items,open('qa/items.json','w'),ensure_ascii=False)
