import json,re
d=json.load(open('pcdata.json'));T=json.load(open('texts.json'))
K=[(r'adjacent',r'сосед|рядом|примыка|смежн'),(r'resistance',r'сопротивляем'),(r'immun',r'невосприимч|иммун'),(r'accuracy|\[ТОЧН\]',r'точн'),(r'difficulty|\[СЛОЖН\]',r'сложн|неточн'),
 (r'\bAP\b',r'ББ|бронебой'),(r'reaction',r'реакци'),(r'quick action',r'быстр'),(r'full action',r'полн'),(r'free action',r'свобод'),(r'protocol',r'протокол'),
 (r'\[нагрев\]|\bheat\b',r'нагрев|\[нагрев\]|перегрев'),(r'\[кин\]|kinetic',r'\[кин\]|кинет'),(r'\[энерг\]|energy',r'\[энерг\]|энерг'),(r'\[взр\]|explosive',r'\[взр\]|взрыв'),(r'\[горение\]|\bburn\b',r'горени|\[горение\]|жжен|горит|горящ'),
 (r'1/round',r'раунд'),(r'1/turn',r'ход'),(r'\bscene\b',r'сцен'),(r'mission',r'мисси'),(r'prone',r'сбит|упасть|сбива'),(r'stunned',r'ошелом|оглуш'),(r'slowed',r'замедл'),(r'immobilized',r'обездвиж'),
 (r'impaired',r'ослаб'),(r'jammed',r'заклин'),(r'shredded',r'расщеп'),(r'exposed',r'уязвим'),(r'lock on',r'захват'),(r'hidden',r'скрыт'),(r'invisible',r'невидим'),(r'engaged',r'вовлеч'),(r'grappl',r'хват|схвач'),
 (r'\bhalf\b',r'полови|½'),(r'\bdouble|twice',r'дважды|двойн|удво|два раза'),(r'\bsave\b',r'спасбр'),(r'\bcheck\b',r'провер'),(r'critical',r'крит'),(r'\bmiss',r'промах'),(r'cover',r'укрыт'),
 (r'line of sight',r'прям\w* видим|линия обзора|линии видимост|прямой видим'),(r'sensors',r'сенсор'),(r'\bcore power',r'мощ\w* ядра'),(r'structure',r'структур'),(r'\bstress',r'нагрузк|напряж|стресс'),(r'overcharge',r'перегруз'),
 (r'\[Дальн\]|range',r'\[Дальн\]|дальност|дистанц|радиус|предел'),(r'\[Угроза\]|threat',r'\[Угроза\]|угроз'),(r'\[Разрыв\]|burst',r'\[Разрыв\]|разрыв'),(r'\[Взрыв\]|\bblast',r'\[Взрыв\]|взрыв'),(r'\[Линия\]|\bline\b',r'\[Линия\]|лини'),(r'\[Конус\]|\bcone',r'\[Конус\]|конус'),
 (r'\bnot\b|\bcan.t\b|cannot|\bno\b|n.t\b',r'\bне\b|\bнет\b|\bни\b|невозм|без')]
def strip(s): return re.sub(r'⟦A[^⟧]*⟧|⟦T⟧[^⟦]*⟦E⟧|⟦Z⟧','',s or '')
out=[]
def chk(id,ru,name):
    if id not in T: return
    en=strip(T[id]['en']).replace('**','');r=strip(ru).replace('**','')
    if not en.strip() or not r.strip(): return
    flags=[]
    for a,b in K:
        na=len(re.findall(a,en,re.I));nb=len(re.findall(b,r,re.I))
        if na and nb==0: flags.append(a.split('|')[0].replace('\\b','').replace('\\',''))
    if flags: out.append((id,name,flags,en,r))
for k in ('weapons','systems','mods','cbs','gear'):
    for x in d[k]: chk(x['id'],x['text'],x['name'])
for f in d['frames']:
    for i,t in enumerate(f['traits']): chk(f"{f['id']}#t{i}",t['text'],t['name'])
    chk(f['id']+'#active_name',f['core']['atext'],f['core'].get('aname'));chk(f['id']+'#passive_name',f['core'].get('ptext',''),f['core'].get('pname'))
for t in d['talents']:
    for i,r in enumerate(t['ranks']): chk(f"{t['id']}#{i}",r['text'],r['name'])
print(len(out))
with open('../semchk.txt','w') as fo:
    for id,n,fl,en,r in out: fo.write(f"### {id} {n} MISSING:{fl}\nEN: {en}\nRU: {r}\n\n")
