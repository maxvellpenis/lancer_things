const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const fs=require('fs');
const items=JSON.parse(fs.readFileSync('qa/items.json'));
const [,,from,to,per,prefix,filt]=process.argv;
(async()=>{
 const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1300,height:900}});
 await pg.goto('file:///home/claude/lancer-npc-v14.html');
 let list=items;if(filt)list=items.filter(x=>new RegExp(filt).test(x.kind+' '+x.text));
 list=list.slice(+from,+to);
 const P=+per;
 for(let s=0;s<list.length;s+=P){
  const chunk=list.slice(s,s+P);
  await pg.evaluate((chunk)=>{
    document.body.innerHTML='<div style="padding:8px;background:var(--bg);color:var(--text);font:13px Segoe UI,Arial">'+chunk.map(x=>`<div style="display:grid;grid-template-columns:420px 1fr;gap:10px;border-bottom:2px solid #555;padding:6px 0"><div>${x.imgs.map(i=>`<img src="file:///tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad/pc/${i}" style="max-width:410px;display:block">`).join('')}</div><div><b style="color:#fff">${esc(x.name)}</b> <span class="muted">${x.id} стр.${x.page}</span><div class="ptxt">${pfmt(x.text)}</div></div></div>`).join('')+'</div>';
  },chunk);
  await pg.waitForTimeout(200);
  await pg.screenshot({path:`qa/${prefix}_${String(s/P).padStart(2,'0')}.png`,fullPage:true});
 }
 await b.close();
})();
