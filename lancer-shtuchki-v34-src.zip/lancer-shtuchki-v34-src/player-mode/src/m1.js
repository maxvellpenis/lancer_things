/* ============================== РЕЖИМ ИГРОКОВ (v11) ============================== */
const PCD=/*@@PCDATA@@*/null;
const P={F:{},W:{},SY:{},MO:{},T:{},CB:{},G:{},SK:{}};
PCD.frames.forEach(x=>P.F[x.id]=x);PCD.weapons.forEach(x=>P.W[x.id]=x);PCD.systems.forEach(x=>P.SY[x.id]=x);
PCD.mods.forEach(x=>P.MO[x.id]=x);PCD.talents.forEach(x=>P.T[x.id]=x);PCD.cbs.forEach(x=>P.CB[x.id]=x);
PCD.gear.forEach(x=>P.G[x.id]=x);PCD.skills.forEach(x=>P.SK[x.id]=x);
const MANU={GMS:'ДМС','IPS-N':'ИПС-Н',SSC:'СШК',HORUS:'ХОРУС',HA:'ОПХ'};
const MANU_FULL={GMS:'Дженерал Массив Системс','IPS-N':'ИПС-Нордстар',SSC:'Смит-Шимано Корпро',HORUS:'ХОРУС',HA:'Оружейная Палата Харрисона'};
const MANU_COL={GMS:'#7f8a96','IPS-N':'#2f6fd0',SSC:'#b8a030',HORUS:'#4f9a2c',HA:'#d2232a'};
const MANU_ORDER=['GMS','IPS-N','SSC','HORUS','HA'];
const MOUNT_RU={Main:'Основной',Heavy:'Тяжёлый',Flex:'Гибкий','Main/Aux':'Основной/Вспом.','Aux/Aux':'Вспом./Вспом.',Aux:'Вспомогательный',Integrated:'Встроенный'};
const WSIZE_RU={Auxiliary:'Вспомогательное',Main:'Основное',Heavy:'Тяжёлое',Superheavy:'Сверхтяжёлое','Ship-class':'Корабельного класса'};
const WSIZE_S={Auxiliary:'Вспом.',Main:'Осн.',Heavy:'Тяж.',Superheavy:'Сверхтяж.','Ship-class':'Корабл.'};
const WTYPE_RU={Melee:'ОББ',CQB:'ОБД',Rifle:'Винтовка',Launcher:'ПУ',Cannon:'Пушка',Nexus:'Звено','Spool Weapon':'Катушечное','???':'Особое'};
const RNG_RU={Range:'Дальн.',Threat:'Угроза',Line:'Линия',Cone:'Конус',Blast:'Взрыв',Burst:'Разрыв'};
const PDT={kinetic:'kin',energy:'en',explosive:'exp',burn:'burn',heat:'heat',variable:'var'};
const PDT_RU={kin:'кин.',en:'энерг.',exp:'взр.',burn:'горения',heat:'нагрева',var:'(тип на выбор)'};
const SYSTYPE_RU={System:'Система',AI:'ИИ',Tech:'Тех',Deployable:'Размещаемое',Drone:'Дрон',Shield:'Щит','Flight System':'Система Полёта'};
const ACT_RU={Quick:'Быстрое Действие',Full:'Полное Действие',Protocol:'Протокол',Reaction:'Реакция','Quick Tech':'Быстрая Технология','Full Tech':'Полная Технология',Free:'Свободное Действие',Invade:'Вторжение',Passive:'Пассивно',Other:'Особое'};
const PROF_RU={'Standard':'Обычный режим','Spin-Up Mode':'Раскрутка','Siege Mode':'Осадный режим','Direct Fire Mode':'Прямой огонь'};
const profRu=n=>PROF_RU[n]||n.replace(/^Charge Rail: (\d)/,'Заряд Апокалипсиса $1').replace(/^(\d) Charges?$/,'$1 заряд(а)');
const HASE=[['hull','Корпус'],['agi','Маневренность'],['sys','Системы'],['eng','Инженерия']];
const HASE_TIP={hull:'+2 ПЗ за каждое очко, +1 Лимит Ремонта за каждые 2 очка.',agi:'+1 Уклонение за каждое очко, +1 Скорость за каждые 2 очка.',
  sys:'+1 Э-Защита и Тех. Атака за каждое очко, +1 СП за каждые 2 очка.',eng:'+1 Тепловой Максимум за каждое очко, +1 использование Ограниченных систем и оружия за каждые 2 очка.'};
const OC_DEF=['1','1d3','1d6','1d6+4'];
const SIZE_STEPS=[0.5,1,2,3];
const sizeTxt=v=>v===0.5?'½':String(v);
const grit=p=>Math.ceil((p.ll||0)/2);
const puid=()=>Math.random().toString(36).slice(2,9);

/* ---------- текст: значки книги ---------- */
const ICO_RU={'ТОЧН':['acc','точн.'],'СЛОЖН':['dif','неточн.'],'кин':['','кин.'],'энерг':['','энерг.'],'взр':['','взр.'],'горение':['','горения'],'нагрев':['','нагрева'],
  'Дальн':['rg','Дальн.'],'Угроза':['rg','Угроза'],'Линия':['rg','Линия'],'Конус':['rg','Конус'],'Взрыв':['rg','Взрыв'],'Разрыв':['rg','Разрыв']};
function pfmt1(s){
  let h=fmt(String(s||''));
  h=h.replace(/(^|[\s(>])\*([^*<\n]+?)\*(?=[\s.,;:)<]|$)/gm,'$1<i>$2</i>');
  h=h.replace(/\[(ТОЧН|СЛОЖН|кин|энерг|взр|горение|нагрев|Дальн|Угроза|Линия|Конус|Взрыв|Разрыв)\]\s*/g,(m,k)=>{const v=ICO_RU[k];return `<span class="ico ${v[0]}">${v[1]}</span>${v[0]==='rg'?'&nbsp;':' '}`});
  return h.replace(/\n/g,'<br>');
}
const BOXK={w:'Оружие',s:'Система',r:'Реакция',t:'Технология',o:'Протокол',c:'Черта',x:'Особое'};
function pfmt(s){
  s=String(s||'');let h='';let k=0;
  const re=/⟦A(?::(\w))?⟧([\s\S]*?)⟦T⟧([\s\S]*?)⟦E⟧([\s\S]*?)(?:⟦Z⟧|(?=⟦A)|$)/g;let m;
  while((m=re.exec(s))){
    const pre=s.slice(k,m.index).trim();if(pre)h+=pfmt1(pre);
    const kind=m[1]||'r',name=m[2].trim(),tags=m[3].trim(),body=m[4].trim();
    h+=`<div class="abox k${kind}">${name||tags?`<div class="ah">${name?`<b>${esc(name)}</b>`:''}${tags?`<span>${pfmt1(tags)}</span>`:''}</div>`:''}${body?`<div class="ab">${pfmt1(body)}</div>`:''}</div>`;
    k=re.lastIndex;
  }
  const rest=s.slice(k).trim();if(rest)h+=pfmt1(rest);
  return h;
}
function tagName(t){const d=PCD.tags[t[0]];if(!d)return t[0];return d.n.replace('{VAL}',t[1]??'X')}
function tagChip(t){const d=PCD.tags[t[0]];return `<span class="kw" data-tt="${esc(tagName(t))}" data-tip="${esc(d&&d.d||'')}">${esc(tagName(t))}</span>`}
const tagVal=(tags,id)=>{const t=(tags||[]).find(x=>x[0]===id);return t?(t[1]===undefined||t[1]===null?true:t[1]):null};
function rngTxt(r){return (r||[]).map(x=>`${RNG_RU[x.t]||x.t} ${x.v}`).join(', ')}
/* дальность с бонусами отдельным цветом: «Дальн. 10 +3» (подсказка — откуда) */
function rngHtml(r){return (r||[]).map(x=>{const b=x._b||[];const add=b.reduce((a,y)=>a+(+y.v||0),0);const base=typeof x.v==='number'?x.v-add:x.v;
  return `${esc(RNG_RU[x.t]||x.t)} ${esc(String(base))}${b.map(y=>` <span class="cbb" title="${esc(y.src)}">${y.v<0?'−'+Math.abs(y.v):'+'+y.v}</span>`).join('')}`}).join(', ')}
function dmgTxt(d){return (d||[]).map(x=>`${x.v} ${PDT_RU[PDT[x.t]]||x.t}`).join(' + ')}

/* ---------- состояние ---------- */
const PS={pilots:LS.get('pc_pilots',[]),sel:LS.get('pc_sel',null),tab:LS.get('pc_tab','pilot'),showAll:false,flt:'',open:{}};
function pcSave(){LS.set('pc_pilots',PS.pilots);LS.set('pc_sel',PS.sel);LS.set('pc_tab',PS.tab)}
const curP=()=>PS.pilots.find(p=>p.id===PS.sel)||PS.pilots[0]||null;
const curM=p=>p&&p.mechs[Math.min(p.mech||0,p.mechs.length-1)];
function newMech(fid){return{id:puid(),name:'',frame:fid||'mf_standard_pattern_i_everest',load:{},mods:{},sh:{},systems:[],retro:0,autostab:'',overpower:'',sigDt:{},varDt:{}}}
function newPilot(){
  return{id:puid(),name:'Новый пилот',callsign:'',bg:'',ll:0,skills:{},custom:[],talents:{},hase:{hull:0,agi:0,sys:0,eng:0},lic:{},cbs:[],
    gear:{armor:'pg_light_hardsuit',weapons:['pg_medium_signature',''],items:['','','']},sigDt:{},notes:'',mechs:[newMech()],mech:0,cb:null};
}
function migratePilot(p){
  p.skills=p.skills||{};p.custom=p.custom||[];p.talents=p.talents||{};p.hase=Object.assign({hull:0,agi:0,sys:0,eng:0},p.hase||{});p.lic=p.lic||{};p.cbs=p.cbs||[];
  p.gear=p.gear||{armor:'',weapons:['',''],items:['','','']};p.sigDt=p.sigDt||{};p.mechs=p.mechs&&p.mechs.length?p.mechs:[newMech()];
  p.mechs.forEach(m=>{m.load=m.load||{};m.mods=m.mods||{};m.sh=m.sh||{};m.systems=m.systems||[];m.varDt=m.varDt||{};if(!P.F[m.frame])m.frame='mf_standard_pattern_i_everest'});
}
PS.pilots.forEach(migratePilot);

/* ---------- лицензии, доступность ---------- */
function licRanksOf(p,man){return PCD.frames.filter(f=>f.src===man&&!f.variant).reduce((a,f)=>a+(p.lic[f.id]||0),0)}
function frameOk(p,f){return f.ll===0||(p.lic[f.variant||f.id]||0)>=2}
function itemOk(p,x){
  if(x.tal)return (p.talents[x.tal[0]]||0)>=x.tal[1];
  if(!x.lic||x.src==='GMS'||!x.ll)return true;
  return (p.lic[x.lic]||0)>=x.ll;
}
function licLabel(x){if(x.tal){const t=P.T[x.tal[0]];return `талант ${t?t.name:''} ${'I'.repeat(x.tal[1])}`}
  if(!x.lic||x.src==='GMS'||!x.ll)return 'ДМС';const f=P.F[x.lic];return `${f?f.name:x.licn} ${'I'.repeat(x.ll)}`}
function cbOk(p,cbId){
  const c=P.CB[cbId];if(!c)return{ok:false,why:'нет данных'};
  if(c.src==='GMS'||c.src==='EXOTIC')return{ok:true};
  const have=p.cbs.filter(id=>id!==cbId&&P.CB[id]&&P.CB[id].src===c.src).length+1,ranks=licRanksOf(p,c.src);
  return ranks>=have*3?{ok:true}:{ok:false,why:`нужно ${have*3} рангов лицензий ${MANU[c.src]} (сейчас ${ranks})`};
}
function budgets(p){
  const sum=o=>Object.values(o).reduce((a,b)=>a+(+b||0),0);
  return{
    sk:{used:sum(p.skills)+p.custom.reduce((a,c)=>a+(+c.rank||0),0),max:4+p.ll,label:'Навыки-триггеры',hint:'На УЛ0 — четыре триггера по +2; каждый УЛ даёт ещё один шаг +2 (новый триггер или повышение, максимум +6).'},
    tl:{used:sum(p.talents),max:3+p.ll,label:'Ранги талантов',hint:'На УЛ0 — три таланта ранга I; каждый УЛ — ещё один ранг (новый талант или следующий ранг).'},
    hs:{used:sum(p.hase),max:2+p.ll,label:'Навыки меха (КМСИ)',hint:'На УЛ0 — 2 очка; каждый УЛ — ещё одно. Максимум 6 в одном навыке.'},
    lc:{used:sum(p.lic),max:p.ll,label:'Ранги лицензий',hint:'Каждый УЛ — один ранг лицензии. Ранг II требует I, ранг III требует II. Рама открывается на ранге II.'},
    cb:{used:p.cbs.filter(id=>!(P.CB[id]&&P.CB[id].exo)).length,max:Math.floor(p.ll/3),label:'Бонусы Ядра',hint:'Один бонус на УЛ3, 6, 9 и 12. ДМС — всегда; для другого производителя нужно 3 ранга его лицензий на каждый бонус.'}
  };
}

/* ---------- слоты меха ---------- */
const SLOTS={Main:[['Main','Auxiliary']],Heavy:[['Superheavy','Heavy','Main','Auxiliary']],Flex:[['Main','Auxiliary'],['Auxiliary']],
  'Main/Aux':[['Main','Auxiliary'],['Auxiliary']],'Aux/Aux':[['Auxiliary'],['Auxiliary']],Aux:[['Auxiliary']],Integrated:[[]]};
function mechMounts(p,m){
  const f=P.F[m.frame];let ms=f.mounts.map((t,i)=>({type:t,key:'f'+i}));
  if(p.cbs.includes('cb_mount_retrofitting')&&ms.length){const i=Math.min(+m.retro||0,ms.length-1);ms[i]={type:'Main/Aux',key:ms[i].key,note:P.CB.cb_mount_retrofitting.name}}
  if(p.cbs.includes('cb_improved_armament')&&f.mounts.length<3)ms.push({type:'Flex',key:'cbIA',note:P.CB.cb_improved_armament.name});
  if(p.cbs.includes('cb_integrated_weapon'))ms.push({type:'Aux',key:'cbIW',note:P.CB.cb_integrated_weapon.name+': 1/раунд свободным действием, когда стреляете другим оружием; без модов',noMod:1});
  (f.core.integrated||[]).filter(id=>P.W[id]).forEach(id=>ms.push({type:'Integrated',key:'int-'+id,fixed:id,note:'Система Ядра: '+f.core.name}));
  PCD.weapons.filter(w=>w.tal&&(p.talents[w.tal[0]]||0)>=w.tal[1]).forEach(w=>ms.push({type:'Integrated',key:'tal-'+w.id,fixed:w.id,note:'Талант: '+P.T[w.tal[0]].name}));
  return ms;
}
function shUsedBy(m,key){return Object.entries(m.sh||{}).find(([k,v])=>v===key&&(m.load[k]||[])[0]&&P.W[(m.load[k]||[])[0]]&&P.W[m.load[k][0]].mount==='Superheavy')}
function slotAllowed(m,mt,si){
  const base=(SLOTS[mt.type]||[[]])[si]||[];
  if((mt.type==='Flex')&&si===1){const w0=P.W[(m.load[mt.key]||[])[0]];if(w0&&w0.mount==='Main')return[]}
  if(mt.type==='Flex'&&si===0){const w1=P.W[(m.load[mt.key]||[])[1]];if(w1)return['Auxiliary']}
  return base;
}
function mechWeapons(p,m){
  const out=[];
  mechMounts(p,m).forEach(mt=>{
    if(mt.fixed){const fw=mt.w||P.W[mt.fixed];if(!fw)return;out.push({w:fw,key:mt.key,si:0,uid:mt.key+'#0',mt,fixed:1});return}
    if(shUsedBy(m,mt.key))return;
    (m.load[mt.key]||[]).forEach((wid,si)=>{const w=P.W[wid];if(w&&si<(SLOTS[mt.type]||[]).length)out.push({w,key:mt.key,si,uid:mt.key+'#'+si,mt,mod:P.MO[m.mods[mt.key+'#'+si]]||null})});
  });
  return out;
}
function mechSystems(p,m){
  const out=(m.systems||[]).map((id,i)=>({s:P.SY[id],uid:'s'+i+'-'+id})).filter(x=>x.s);
  PCD.systems.filter(s=>s.tal&&(p.talents[s.tal[0]]||0)>=s.tal[1]).forEach(s=>out.push({s,uid:'tal-'+s.id,fixed:1}));
  return out;
}
function talentRanks(p){const out=[];Object.entries(p.talents).forEach(([id,r])=>{const t=P.T[id];if(!t)return;for(let i=0;i<Math.min(r,3);i++)out.push({t,i,r:t.ranks[i]})});return out}
function pcBonuses(p,m){
  const B=[];const add=(list,src)=>(list||[]).forEach(b=>B.push({...b,src}));
  p.cbs.forEach(id=>P.CB[id]&&add(P.CB[id].bonuses,P.CB[id].name));
  if(m){const f=P.F[m.frame];f.traits.forEach(t=>add(t.bonuses,t.name));mechSystems(p,m).forEach(x=>add(x.s.bonuses,x.s.name))}
  talentRanks(p).forEach(x=>add(x.r.bonuses,x.r.name));
  return B;
}
function mechStats(p,m){
  const f=P.F[m.frame],s=f.stats,g=grit(p),h=p.hase,B=pcBonuses(p,m);
  const plain=b=>!b.weapon_types&&!b.range_types&&!b.damage_types;
  const bs=id=>B.filter(b=>b.id===id&&plain(b));
  const sum=id=>bs(id).reduce((a,b)=>a+(+b.val||0),0);
  const src=id=>bs(id).map(b=>`${sgn(+b.val)} ${b.src}`);
  const W={};const st={};
  const put=(k,v,parts)=>{st[k]=v;W[k]=parts.filter(Boolean).join(' · ')};
  let si=SIZE_STEPS.indexOf(s.size);if(si<0)si=1;si=Math.min(3,si+sum('size'));
  put('size',SIZE_STEPS[si],[`рама ${sizeTxt(s.size)}`,...src('size').map(x=>x+' (шаг размера)')]);
  const arm=s.armor+sum('armor');put('armor',Math.min(4,arm),[`рама ${s.armor}`,...src('armor'),arm>4?'максимум 4':'']);
  put('hp',s.hp+g+2*h.hull+sum('hp'),[`рама ${s.hp}`,`Стойкость +${g}`,`Корпус ${h.hull}×2 = +${2*h.hull}`,...src('hp')]);
  put('repcap',s.repcap+Math.floor(h.hull/2),[`рама ${s.repcap}`,`Корпус/2 = +${Math.floor(h.hull/2)}`]);
  put('evasion',s.evasion+h.agi+sum('evasion'),[`рама ${s.evasion}`,`Маневренность +${h.agi}`,...src('evasion')]);
  put('speed',s.speed+Math.floor(h.agi/2),[`рама ${s.speed}`,`Маневренность/2 = +${Math.floor(h.agi/2)}`]);
  put('edef',s.edef+h.sys+sum('edef'),[`рама ${s.edef}`,`Системы +${h.sys}`,...src('edef')]);
  put('tech',s.tech_attack+h.sys,[`рама ${sgn(s.tech_attack)}`,`Системы +${h.sys}`]);
  put('sp',s.sp+g+Math.floor(h.sys/2),[`рама ${s.sp}`,`Стойкость +${g}`,`Системы/2 = +${Math.floor(h.sys/2)}`]);
  put('heatcap',s.heatcap+h.eng+sum('heatcap'),[`рама ${s.heatcap}`,`Инженерия +${h.eng}`,...src('heatcap')]);
  put('limited',Math.floor(h.eng/2)+sum('limited_bonus'),[`Инженерия/2 = +${Math.floor(h.eng/2)}`,...src('limited_bonus')]);
  put('save',s.save+g+sum('save'),[`рама ${s.save}`,`Стойкость +${g}`,...src('save')]);
  put('sensors',s.sensor_range,[`рама ${s.sensor_range}`]);
  put('struct',s.structure,['рама']);put('stress',s.stress,['рама']);
  put('attack',g,[`Стойкость +${g}`]);put('ai',1+sum('ai_cap'),['1',...src('ai_cap')]);
  st.why=W;st.oc=(B.find(b=>b.id==='overcharge')||{}).val||OC_DEF;st.ocSrc=(B.find(b=>b.id==='overcharge')||{}).src||'';
  st.cheapStruct=B.some(b=>b.id==='cheap_struct');
  st.rangeB=B.filter(b=>b.id==='range'&&(b.range_types||b.weapon_types||b.damage_types));
  return st;
}
function weaponRanges(st,w,mod){
  const r=(w.rng||[]).map(x=>({...x,_b:[]}));
  (mod&&mod.addRng||[]).forEach(a=>{const t=r.find(x=>x.t===a.t);if(t){t.v=+t.v+ +a.v;t._b.push({v:+a.v,src:'Мод «'+mod.name+'»'})}});
  (st.rangeB||[]).forEach(b=>{
    if(b.weapon_types&&!b.weapon_types.includes(w.type))return;
    if(b.damage_types&&!(w.dmg||[]).some(d=>b.damage_types.map(x=>x.toLowerCase()).includes(d.t)))return;
    r.forEach(x=>{if((b.range_types||[]).includes(x.t)&&typeof x.v==='number'){x.v+= +b.val;x._b.push({v:+b.val,src:b.src||'бонус'})}});
  });
  return r;
}
function spUsed(p,m){
  let n=0;mechSystems(p,m).forEach(x=>{if(!x.fixed)n+=+x.s.sp||0});
  mechWeapons(p,m).forEach(x=>{if(!x.fixed)n+=+x.w.sp||0;if(x.mod)n+=+x.mod.sp||0});
  return n;
}
function pilotStats(p){
  const g=grit(p),a=P.G[p.gear.armor];const st={hp:6+g,armor:0,evasion:10,edef:10,speed:4,grit:g};
  if(a)(a.bonuses||[]).forEach(b=>{const k=b.id.replace('pilot_','');const v=typeof b.val==='string'?String(b.val).replace(/\{grit\}/g,grit(p)).split('+').reduce((x,y)=>x+(+y||0),0):b.val;if(b.replace)st[k]=v;else st[k]=(st[k]||0)+v});
  return st;
}
function buildWarnings(p,m){
  const W=[],b=budgets(p),st=mechStats(p,m),f=P.F[m.frame];
  Object.values(b).forEach(x=>{if(x.used>x.max)W.push(`${x.label}: использовано ${x.used} из ${x.max}`)});
  Object.entries(p.hase).forEach(([k,v])=>{if(v>6)W.push(`${HASE.find(h=>h[0]===k)[1]}: максимум 6`)});
  if(!frameOk(p,f))W.push(`Рама ${f.name}: нужна лицензия ${f.name} ранга II`);
  const used=spUsed(p,m);if(used>st.sp)W.push(`СП: занято ${used} из ${st.sp}`);
  mechWeapons(p,m).forEach(x=>{if(!x.fixed&&!itemOk(p,x.w))W.push(`${x.w.name}: нужна лицензия ${licLabel(x.w)}`);if(x.mod&&!itemOk(p,x.mod))W.push(`${x.mod.name}: нужна лицензия ${licLabel(x.mod)}`)});
  mechSystems(p,m).forEach(x=>{if(!x.fixed&&!itemOk(p,x.s))W.push(`${x.s.name}: нужна лицензия ${licLabel(x.s)}`)});
  const cnt={};[...mechWeapons(p,m).map(x=>x.w),...mechSystems(p,m).map(x=>x.s)].forEach(x=>{if(tagVal(x.tags,'tg_unique')){cnt[x.id]=(cnt[x.id]||0)+1;if(cnt[x.id]===2)W.push(`${x.name}: Уникальное — можно установить только одно`)}});
  const ai=mechSystems(p,m).filter(x=>tagVal(x.s.tags,'tg_ai')).length;if(ai>st.ai)W.push(`ИИ: установлено ${ai}, можно ${st.ai}`);
  p.cbs.forEach(id=>{const o=cbOk(p,id);if(!o.ok)W.push(`${P.CB[id].name}: ${o.why}`)});
  Object.entries(p.talents).forEach(([id,r])=>{if(r>3)W.push(`${P.T[id].name}: максимум 3 ранга`)});
  mechMounts(p,m).forEach(mt=>{const l=m.load[mt.key]||[];const w0=P.W[l[0]];if(w0&&w0.mount==='Superheavy'){const o=m.sh[mt.key];if(!o||!mechMounts(p,m).some(x=>x.key===o&&!x.fixed&&x.key!==mt.key))W.push(`${w0.name}: Сверхтяжёлому нужен ещё один слот — выберите его`)}});
  return W;
}
