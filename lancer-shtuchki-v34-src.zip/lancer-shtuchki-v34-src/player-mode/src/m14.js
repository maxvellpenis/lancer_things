/* ============================== v22: Battlegroup — флотские сражения ==============================
   m14: данные, словарь терминов, Справочник и ГМ tools, сборка группы (очки, слоты, проверки).
   m15: трекер боя (раунды, фазы, счётчики, атаки, ракеты, перехват, абордаж).
   m16: экраны «Флот» (сборка / бой / каталог), боковая панель, обработчики.                         */
const BG=/*@@BG@@*/null||{hulls:[],weapons:[],systems:[],escorts:[],wings:[],aceUps:[],npcCap:[],npcEsc:[],npcAce:[],ref:[],gm:[]};
const BGART=/*@@BGART@@*/null||{};
const bgImg=(id,cls)=>BGART[id]?`<img class="${cls||'bg-img'}" src="${BGART[id]}" alt="" loading="lazy" draggable="false">`:'';
BOOKS.BG={name:'Battlegroup',ru:'Флот',full:'Дополнение «Lancer: Battlegroup» (Massif Press)'};
const bgMap=a=>Object.fromEntries(a.map(x=>[x.id,x]));
const BH=bgMap(BG.hulls),BW=bgMap(BG.weapons),BSY=bgMap(BG.systems),BE=bgMap(BG.escorts),BWG=bgMap(BG.wings),BAU=bgMap(BG.aceUps),
      BNC=bgMap(BG.npcCap),BNE=bgMap(BG.npcEsc),BNA=bgMap(BG.npcAce);
const BG_CLS={fr:'Фрегат',cv:'Авианосец',bb:'Линкор'};
const BG_CLS_MAX={fr:3,cv:2,bb:1};
const BG_SLOT={sh:'Сверхтяжёлое',pr:'Основное',aux:'Вспомогательное',sys:'Система',esc:'Эскорт',wing:'Крыло'};
const BG_BAND=['В упор','Ближняя','Сближение','Прицельная','Дальняя','Предельная'];
const bgBand=n=>`${n} · ${BG_BAND[n]}`;
const bgRng=r=>r?`${r[0]}–${r[1]}`:'—';
const bgInRng=(r,b)=>!r||(b<=r[0]&&b>=r[1]);

/* ---------- словарь терминов (подсказки по наведению) ---------- */
const BG_GLOSS=[
 [/^захват/i,'Захват (Lock On)','Статус корабля. Атакующий по одной цели может израсходовать Захват: Точность +1 к атаке, затем Захват снимается. Держится до расхода или до конца следующей фазы удара. Не складывается.'],
 [/^укреплён|^укреплен/i,'Укреплён','+1d6 к Перехвату группы и +2 к Защите всех её кораблей до конца её следующего хода. Не складывается.'],
 [/^сверхщит/i,'Сверхщит','Временные ПЗ: урон сначала идёт по Сверхщиту. Лечение его не восстанавливает. Не складывается — остаётся наибольшее значение.'],
 [/^грейвош/i,'Грейвош','Счётчики нанороя: в конце фазы удара корабль получает урон, равный их числу (Сверхщит игнорируется), затем снимает 1. Манёвром группа снимает весь Грейвош.'],
 [/^перехват/i,'Перехват','Бросок группы против урона ракет и атак по площади: результат вычитается из урона. В фазе удара бросается один раз против всего входящего урона.'],
 [/^упорств/i,'Упорство','Абордажный отряд. Взятый на абордаж корабль в конце хода бросает d20 против Упорства, чтобы выбить отряд.'],
 [/^оборонительн\S* заслон/i,'Оборонительный заслон','Тактика: фрегат прикрывает корабль — атаки и способности против него с вероятностью 50% перехватываются (отмена или удар по фрегату).'],
 [/^заряд/i,'Заряд X','Оружие начинает с X счётчиками заряда, снимает 1 в каждой логистике; на 0 стреляет в фазе удара (без манёвра) или держит выстрел.'],
 [/^ракет|^payload/i,'Ракета (Payload)','Без броска атаки: стартует со счётчиками полёта по диапазону (5/4/3/2/1, в упор — сразу), снимает 1 в логистике, на 0 попадает в фазе удара. Обычно перехватывается.'],
 [/^перезарядк/i,'Перезарядка X','После использования — X счётчиков перезарядки, снимаются по одному в каждой логистике.'],
 [/^надёжн|^надежн/i,'Надёжное X','Всегда наносит минимум X урона — даже при промахе или перехвате.'],
 [/^избыточн/i,'Избыточное (Overkill)','Кубики урона с 1 перебрасываются, пока единицы не перестанут выпадать.'],
 [/^критическ/i,'Критическое','20+ на броске атаки — крит, весь урон удваивается.'],
 [/^неточн/i,'Неточное','Атаки получают Сложность +1.'],
 [/^точн(ое|ая)$/i,'Точное','Атаки получают Точность +1.'],
 [/^уникальн/i,'Уникальное','В группе может быть только один экземпляр.'],
 [/^шаблон/i,'Шаблон','Эскорт НИП, напрямую меняющий ПЗ и Защиту своего капитального корабля; не атакуется отдельно.'],
 [/^легионн/i,'Легионное','Связано с флотским легионом (сетевым разумом флота). Некоторые эффекты такие способности усиливают или блокируют.'],
 [/^по площади/i,'По площади','Без броска атаки: урон минус Перехват группы цели получает каждый её капитальный корабль и эскорт; крылья не получают.'],
 [/^абордаж/i,'Абордаж','Отряд высаживается на вражеский капитальный корабль; в фазе абордажа — команда и d20 против 8.'],
 [/^полный вперёд/i,'Полный вперёд','Манёвр: продвинуться на диапазон и выстрелить из одного основного оружия (до или после).'],
 [/^обратн\S* тяг/i,'Обратная тяга','Манёвр: отойти на диапазон или игнорировать следующее принудительное перемещение; группа Укреплена до конца следующего хода.'],
 [/^открыть огонь/i,'Открыть огонь','Манёвр: одно сверхтяжёлое или до двух разных основных орудий.'],
];
function bgTip(w){const n=String(w).replace(/&[a-z]+;/g,'').trim();const g=BG_GLOSS.find(x=>x[0].test(n));return g?[g[1],g[2]]:null}
const bgTipAttr=g=>` class="kw" data-tt="${esc(g[0])}" data-tip="${esc(g[1])}"`;
const BG_AUTO=/(^|[\s(«,;:])((?:Захват|Укреплён|Сверхщит|Грейвош|Перехват|Упорств)[а-яё]*)/g;
function bgfmt(s){
  let h=esc(String(s||''));
  h=h.replace(/\*\*(.+?)\*\*/g,(m,x)=>{const g=bgTip(x);return g?`<b${bgTipAttr(g)}>${x}</b>`:`<b>${x}</b>`});
  h=h.replace(/(^|[\s(>])\*([^*<\n]+?)\*(?=[\s.,;:)<]|$)/gm,'$1<i>$2</i>');
  h=h.split(/(<[^>]+>[^<]*<\/b>|<[^>]+>)/).map(part=>part.startsWith('<')?part:part.replace(BG_AUTO,(m,a,w)=>{const g=bgTip(w);return g?`${a}<span${bgTipAttr(g)}>${w}</span>`:m})).join('');
  return h.replace(/\n/g,'<br>')}
const bgTags=t=>String(t||'').split(/,\s*/).filter(Boolean).map(x=>{const g=bgTip(x.replace(/\s*[−+-]?\d.*$/,''));return g?`<span${bgTipAttr(g)}>${esc(x)}</span>`:esc(x)}).join(', ');

/* ---------- Справочник и ГМ tools ---------- */
BG.ref.forEach(s=>REF.push({...s,dlc:'BG'}));
GMT.push(...BG.gm);
{const o=refCard;refCard=function(it){
  if(!(it.src&&it.src[0]==='BG'))return o(it);
  const body=it.table?`<table class="gl-tab">${it.table.map((r,i)=>`<tr>${r.map(c=>i?`<td>${bgfmt(c)}</td>`:`<th>${esc(c)}</th>`).join('')}</tr>`).join('')}</table>`:`<div class="gl-body" data-atd="1">${bgfmt(it.b)}</div>`;
  return `<div class="gl-card bgc"><b class="gl-t">${esc(it.t)}</b>${body}${srcTag('BG',it.src[1])}</div>`}}
{const o=viewRef;viewRef=function(){const first=(BG.ref[0]||{}).id;let h=o();
  return first?h.replace(`<h2 id="ref-${first}">`,`<div class="dlc-hd bg-hd"><b>Дополнение · Lancer: Battlegroup</b><span>Флотские сражения — отдельная игра. Режим боя — во вкладке «Флот».</span></div><h2 id="ref-${first}">`):h}}
{const o=refSide;refSide=function(){const first=(BG.ref[0]||{}).id;let h=o();
  return first?h.replace(`<button class="citem" data-ref="${first}">`,`<div class="side-sub">Дополнение · Battlegroup</div><button class="citem" data-ref="${first}">`):h}}

/* ---------- состояние ---------- */
const bgUid=()=>Math.random().toString(36).slice(2,10);
const BGS=(()=>{const d={tab:'build',cur:null,groups:[],cat:'hulls',battle:{round:1,phase:0,ticked:1,units:[],pls:[],brd:[]},atk:null,add:{}};
  const v=LS.get('bg_state',null);return v&&typeof v==='object'?{...d,...v,battle:{...d.battle,...(v.battle||{})},atk:null,add:v.add||{}}:d})();
function bgSave(){LS.set('bg_state',BGS)}

/* ---------- сборка группы ---------- */
function bgNewGroup(){const g={id:bgUid(),name:'Боевая группа '+(BGS.groups.length+1),cmdr:'',traits:'',notes:'',ships:[]};BGS.groups.push(g);BGS.cur=g.id;return g}
function bgNewShip(g,hull){const h=BH[hull];if(!h)return;g.ships.push({id:bgUid(),hull,name:'',flag:!g.ships.some(s=>s.flag),eq:{},ace:[]})}
const bgGroup=id=>BGS.groups.find(g=>g.id===id);
const bgHasSys=(s,id)=>(s.eq.sys||[]).includes(id);
function bgSlots(s){const h=BH[s.hull];if(!h)return{};const n={sh:0,pr:0,aux:0,sys:0,esc:0,wing:0,...h.sl};delete n.mod;
  if(s.flag)n.sys++;
  (s.eq.sys||[]).slice(0,n.sys).forEach(id=>{if(id==='catapult')n.wing++;if(id==='berth')n.esc++});
  return n}
const bgModKinds=s=>{const h=BH[s.hull];return h&&h.sl.mod?h.modk||[]:[]};
function bgItem(k,id){return k==='sh'||k==='pr'||k==='aux'?BW[id]:k==='sys'?BSY[id]:k==='esc'?BE[id]:k==='wing'?BWG[id]:null}
function bgShipItems(s){const out=[];const n=bgSlots(s);
  ['sh','pr','aux','sys','esc','wing'].forEach(k=>{const a=s.eq[k]||[];for(let i=0;i<n[k];i++){const id=a[i];const it=id&&bgItem(k,id);if(it)out.push({k,i,id,it})}});
  if(bgModKinds(s).length&&s.eq.mod&&s.eq.mod.id){const it=bgItem(s.eq.mod.k,s.eq.mod.id);if(it)out.push({k:s.eq.mod.k,i:'m',id:s.eq.mod.id,it,mod:1})}
  return out}
function bgItemCost(s,k,it){let c=+it.pts||0;if(k==='sh'&&s.hull==='creighton')c=Math.max(0,c-1);return c}
function bgCost(g){let main=0,bonusUsed=0,bonusMax=0;const lines=[];
  g.ships.forEach(s=>{const h=BH[s.hull];if(!h)return;main+=h.pts;
    let ewCost=0,escOnly=0;
    bgShipItems(s).forEach(({k,it})=>{const c=bgItemCost(s,k,it);if(k==='esc'||k==='wing'){ewCost+=c;if(k==='esc')escOnly+=c}else main+=c});
    let bonus=h.cls==='cv'?(h.bonus||3):0;let esc2=s.hull==='eiland'?3:0;
    const useE=Math.min(esc2,escOnly);ewCost-=useE;const useB=Math.min(bonus,ewCost);ewCost-=useB;main+=ewCost;
    bonusUsed+=useE+useB;bonusMax+=bonus+esc2});
  return{main,bonusUsed,bonusMax,left:20-main}}
function bgHp(s){const h=BH[s.hull];let hp=h?h.hp:0;if(s.flag)hp+=3;if(bgHasSys(s,'bulwark'))hp+=3;return hp}
function bgWarn(g){const w=[];const cnt={fr:0,cv:0,bb:0};g.ships.forEach(s=>{const h=BH[s.hull];if(h)cnt[h.cls]++});
  if(g.ships.length<2)w.push('Нужно минимум 2 капитальных корабля.');
  Object.keys(cnt).forEach(k=>{if(cnt[k]>BG_CLS_MAX[k])w.push(`${BG_CLS[k]}ов слишком много: ${cnt[k]} (максимум ${BG_CLS_MAX[k]}).`)});
  const fl=g.ships.filter(s=>s.flag).length;if(g.ships.length&&fl!==1)w.push(fl?'Флагман должен быть один.':'Назначьте флагман (★).');
  const c=bgCost(g);if(c.left<0)w.push(`Перерасход очков: ${-c.left}.`);
  const uq={};g.ships.forEach(s=>bgShipItems(s).forEach(({it})=>{if(it.tg&&it.tg.uniq){uq[it.id]=(uq[it.id]||0)+1}}));
  Object.entries(uq).forEach(([id,n])=>{if(n>1){const it=BW[id]||BSY[id]||BE[id]||BWG[id];w.push(`«${it.ru}» — Уникальное: в группе только один экземпляр (сейчас ${n}).`)}});
  g.ships.forEach(s=>{const h=BH[s.hull];if(!h)return;const nm=s.name||h.ru;const items=bgShipItems(s);
    if(s.hull==='creighton')items.filter(x=>x.k==='sh'&&!x.it.tg.ch).forEach(x=>w.push(`${nm}: Крейтон несёт только сверхтяжёлое с меткой «Заряд» («${x.it.ru}» не подходит).`));
    if(s.hull==='laho')items.filter(x=>x.k==='pr'&&x.it.tg.pl==null).forEach(x=>w.push(`${nm}: Лахо несёт только основное оружие с меткой «Ракета» («${x.it.ru}»).`));
    if(s.hull==='tolumnia')items.filter(x=>x.it.tg&&x.it.tg.pl!=null).forEach(x=>w.push(`${nm}: Толумния не может нести ракетное оружие («${x.it.ru}»).`));
    if(s.hull==='calendula'&&!items.some(x=>x.k==='sh'&&x.it.tg.ch))w.push(`${nm}: Календула обязана нести сверхтяжёлое оружие с «Зарядом».`);
    if(s.hull==='minokawa'&&s.eq.mod&&s.eq.mod.id){const it=bgItem(s.eq.mod.k,s.eq.mod.id);if(it&&!(it.tg&&it.tg.brd))w.push(`${nm}: в модульный слот Минокавы — только эскорт или крыло с меткой «Абордаж».`)}
    if((s.eq.sys||[]).filter(x=>x==='bulwark').length>1)w.push(`${nm}: «Резервирование бастиона» — не больше одного на корабль.`);
    if(items.some(x=>x.id==='ace')&&(s.ace||[]).filter(Boolean).length!==3)w.push(`${nm}: у эскадрильи аса должно быть ровно 3 улучшения.`);
    const n=bgSlots(s);['sh','pr','aux','sys','esc','wing'].forEach(k=>{const a=s.eq[k]||[];if(a.slice(n[k]).some(Boolean))w.push(`${nm}: лишние предметы в слотах «${BG_SLOT[k]}» не учитываются.`)})});
  return w}
function bgBanked(g){const c=bgCost(g);return Math.max(0,Math.min(2,c.left))}

/* ---------- экспорт / импорт сборок (с проверкой по каталогу) ---------- */
function bgClean(raw){if(!raw||typeof raw!=='object')return null;const str=(v,n)=>String(v??'').slice(0,n||200);
  const ids=(a,map,n)=>Array.isArray(a)?a.slice(0,n||8).map(x=>map[x]?x:''):[];
  const g={id:bgUid(),name:str(raw.name,120)||'Импорт',cmdr:str(raw.cmdr,120),traits:str(raw.traits,600),notes:str(raw.notes,4000),ships:[]};
  (Array.isArray(raw.ships)?raw.ships.slice(0,8):[]).forEach(s=>{if(!s||!BH[s.hull])return;const e=s.eq||{};
    const W2={...BW};const sh={id:bgUid(),hull:s.hull,name:str(s.name,120),flag:!!s.flag,ace:ids(s.ace,BAU,3),
      eq:{sh:ids(e.sh,W2),pr:ids(e.pr,W2),aux:ids(e.aux,W2),sys:ids(e.sys,BSY),esc:ids(e.esc,BE),wing:ids(e.wing,BWG)}};
    if(e.mod&&['aux','sys','esc','wing'].includes(e.mod.k)&&bgItem(e.mod.k,e.mod.id))sh.eq.mod={k:e.mod.k,id:e.mod.id};
    g.ships.push(sh)});
  if(g.ships.length&&!g.ships.some(s=>s.flag))g.ships[0].flag=true;
  return g}
