/* ============================== v24: «No Room for a Wallflower, Act 1» ==============================
   Снаряжение игроков (рамы Кидд и Сагарматха, варианты Энкиду, Чингис Мк I, Ласточкин Хвост рейнджеров, экзотика, Эмпат, снаряжение пилота, резервы) — в pcdata (book:'WF').
   Здесь: экзотика, классы НИП и враги кампании в библиотеке, бои кампании одной кнопкой, эйдолоны (справочник и трекер), правила и таблицы. */
BOOKS.WF={name:'No Room for a Wallflower',ru:'Нет места для тихони',full:'Кампания «Lancer: No Room for a Wallflower, Act 1» (Massif Press)'};
const WFNPC=/*@@WFNPC@@*/null||[],WFEID=/*@@WFEID@@*/null||{layers:[],rules:{},base:{},core:{},presets:[]},WFENC=/*@@WFENC@@*/null||[],WFGMT=/*@@WFGMT@@*/null||[];
try{GL.push([/^экзотическ\S* снаряжени/,'Экзотическое Снаряжение',(PCD.tags.tg_exotic||{}).d||'']);
  GL.push([/^меметическ/,'Меметическое оружие','Оружие Эйдолонов: дальнее, игнорирует вовлечение и не задевает союзных персонажей, даже если они в зоне эффекта.']);
  GL.push([/^зон\S* пелены/,'Зона пелены','Шторм нанитов Скрытника (Разрыв 1): лёгкое укрытие; Скрытники внутри Невидимы и Сопротивляются всему урону и нагреву, враги внутри Расщеплены и Ослаблены. Целью — только технологические атаки и оружие против Э-Защиты; рассеивается от успешной атаки.'])}catch(e){}

/* ---------- экзотика ---------- */
MANU.EXOTIC='Экзотика';MANU_FULL.EXOTIC='Экзотическое снаряжение (выдаёт ГМ)';MANU_COL.EXOTIC='#9b59b6';if(!MANU_ORDER.includes('EXOTIC'))MANU_ORDER.push('EXOTIC');
{const o=licLabel;licLabel=function(x){return x&&x.src==='EXOTIC'?'экзотика — выдаёт ГМ':o(x)}}
{const o=buildWarnings;buildWarnings=function(p,m){const W=o(p,m);try{const n=[...mechWeapons(p,m).map(x=>x.w),...mechSystems(p,m).map(x=>x.s),...Object.values(m.mods||{}).map(id=>P.MO[id]),...p.cbs.map(id=>P.CB[id])].filter(x=>x&&x.exo).length;
  if(n>2)W.push(`Экзотическое снаряжение: установлено ${n}, одновременно можно не больше 2`)}catch(e){}return W}}
{const o=pcDamage;pcDamage=function(p,n,dt,opt){const m=curM(p);if(dt==='burn'&&m&&m.frame==='mf_genghis_alt_worldkiller_genghis_mk_i'){pcLog(p,'Горение',`${n} горения не действует: Невосприимчивость (Теплоизолированный).`,'hit');return}return o(p,n,dt,opt)}}

/* ---------- библиотека НИП ---------- */
WFNPC.forEach(c=>{if(BUILTIN.some(b=>b.id===c.id))return;const cc=JSON.parse(JSON.stringify(c));if(cc.group==='Wallflower · враги кампании')cc.group='Wallflower · враги';
  cc.base=cc.base.flatMap(s=>{if(!s.copy)return[s];const [ci,si]=s.copy.split(':');const src=(BUILTIN.find(b=>b.id===ci)||{base:[],optional:[]});const x=[...src.base,...src.optional].find(y=>y.id===si);return x?[JSON.parse(JSON.stringify(x))]:[]});
  cc.book='WF';BUILTIN.push(cc)});
{const o=viewLib;viewLib=function(){let h=o();try{const c=cls(S.cls);if(c&&c.book==='WF'&&c.page)h=h.replace(`<h1>${esc(c.name)}</h1>`,`<h1>${esc(c.name)}</h1>${srcTag('WF',c.page)}`)}catch(e){}return h}}

/* ---------- Справочник ---------- */
const WT=(t,b,page)=>({t,b,src:['WF',page]});
const WF_REF={id:'wf',t:'Дополнение · No Room for a Wallflower',dlc:'WF',items:[
 WT('О книге','**No Room for a Wallflower** — кампания Lancer (Акт 1). Из неё в программе только то, что пригодится в любой игре:\n• рамы **Кидд** (ИПС-Н, лицензия) и **Сагарматха** (ДМС, с УЛ0); варианты **Энкиду** (Токугава), **Чингис Мк I «Убийца Миров»** (Чингис), **Ласточкин Хвост рейнджеров**;\n• **экзотическое снаряжение** мехов и пилотов, талант **Эмпат**;\n• классы НИП **Мститель**, **Скрытник**, **Странник**, **Злоба** и враги из книги — в библиотеке НИП;\n• **Эйдолоны** — раздел ниже и трекер в **ГМ tools**;\n• случайные таблицы (пейзажи, резервы, как получить раму УЛ2) — в ГМ tools.',6),
 WT('Часы','Простой инструмент для повествовательной игры: круг, разделённый на чётное число сегментов (4, 6, 8, 10, 12). Чем больше сегментов, тем сложнее и дольше задача; базовые — 4–6, 10–12 — только для самых долгих целей. Подходят вместо испытаний навыков (Lancer, стр. 47), но не для боя мехов.\n**Часы задачи**: успешное/эффективное действие (обычно 10–19) — **2 сегмента**; провал (0–9) — **1 или 0** (хорошо давать 1 даже на провале, чтобы сцена не стояла); очень эффективное (20+) — **3**.\n**Часы прогресса**: ситуации в мире (война, влияние фракции, заговор) — двигаются сами, обычно после даунтайма: 1 сегмент — немного, 2 — как обычно, 3 — большой прогресс.\n**Заполнение**: когда все сегменты закрашены, исход наступает; часто одни часы запускают другие («Погоня» → «Допрос»).',8),
 WT('Часы: провалы, откат, идеи','**Часы провала** заполняются от провалов и осложнений рискованных бросков: например, при бегстве — «Побег» (успехи) и «Поймали» (2 сегмента за провал, 1 за успех рискованного броска).\n**Откат**: сегменты можно стирать, если действие обращает ситуацию вспять (ложный след, заблокированная дверь, разделиться).\n**Ещё идеи**: угрозы (манёвр врага, стая хищников, бомба, реактор, запас кислорода); давление времени — 2 сегмента за **Полный Ремонт**, 1 за отдых; трудные враги вне боя мехов; долгие проекты ИП и фракций; погони и повествовательные сражения; отношение фракций к ИП.\n**Видимость**: часы показывают игрокам, когда они важны сейчас; часы фракций можно держать в тайне — или показывать прогресс, скрывая название.',9),
 WT('Награды и экзотическое снаряжение','ИП получают награды за миссии и некоторые действия в даунтайм — от повествовательных бонусов до уникальных шасси. Обычно награду можно использовать только со следующей миссии.\n**Экзотическое снаряжение** — метка оружия и систем вне системы лицензий; выдаётся за определённые миссии. Можно выдать так и существующее снаряжение (например, Шоковые Ножи Металмарка без лицензии). Щедрая раздача быстро поднимает силу ИП.\n• Становится постоянной частью персонажа, но **не повышает УЛ** и **не считается рангом лицензии** для бонусов ядра.\n• Уничтоженное чинится и перепечатывается как обычно.\n• Ставится и снимается только при **Полном Ремонте**.\n• Одновременно можно установить **не больше двух** предметов с меткой (владеть — сколько угодно). Программа предупреждает о превышении.',10),
 WT('Резервы, УЛ и бои','**Резервы**: некоторые миссии дают ИП резервы (артудары, подкрепления, припасы) — часто только на определённое время или текущую миссию. Без ограничений резерв можно взять на любую миссию, но он сгорает после миссии, даже если не потрачен. Дополнительные резервы — в даунтайм (таблица «Резервы» в ГМ tools; они же — в листе пилота).\n**УЛ**: растёт в конце каждой миссии, как обычно.\n**Сложность боёв**: сложнее — шаблоны **Ветеран** и **Элита** или ещё волна подкреплений; проще — придержать часть сил в подкреплениях или убрать часть НИП. Главное — экономия действий: у врагов должно быть 1–1,5 хода на каждый ход ИП.',10),
 WT('Советы по боям','• Игроки должны видеть классы и шаблоны всех НИП (Ас, Салага, Элита…).\n• Не больше 4–5 разных классов НИП в одном бою.\n• Карты с разнообразным рельефом, опасной и труднопроходимой местностью, обилием укрытий.\n• Атакуйте разные защиты (Уклонение, Э-Защиту, нагрев, спасброски), но не отключайте все возможности игроков.\n• Истощение: 2–3 боя между Полными Ремонтами; с одним боем ИП слишком сильны (ядро, ремонты, заряды).\n**Структура боя в книге**: ситреп (Lancer, стр. 267), цель, силы противника (по числу ИП, отдельно — подкрепления), детали, исход (победа/поражение и часы), награды.',11),
 WT('Варианты рам (Wallflower)','Эти рамы ИП получают как **экзотическое снаряжение** по ходу Акта 1 и могут свободно переключаться между вариантом и основной рамой при каждом **Полном Ремонте**.\nВ других кампаниях вариант берут вместо основной рамы на **ранге II** её лицензии — с другими чертами и системой ядра; всё прочее снаряжение лицензии то же. Вариант и основная рама взаимоисключающи. При повышении УЛ можно сменить вариант на основную раму и обратно.\n• **Сагарматха** (ДМС) — вариант **Эвереста**; исключение: доступна всем с **УЛ0** вместе с Эверестом и не исключает его.\n• **Энкиду** — вариант **Токугавы** (ОПХ).\n• **Чингис Мк I «Убийца Миров»** — вариант **Чингиса** (ОПХ).\n• **Ласточкин Хвост (вариант рейнджеров)** — вариант **Ласточкина Хвоста** (СШК).',182),
 WT('Игра за эгрегорианца','Правила для людей и эгрегорианцев одинаковы: эгрегорианцы — люди, просто не человеческого рода. Тонкие манипуляторы позволяют им пользоваться человеческим оружием и техникой и говорить на человеческих языках; с некоторым трудом они могут и пилотировать мехи (хотя культурно могут быть к этому сдержанны). Для связи с культурой подходит талант **Эмпат**.\nРазумная инопланетная жизнь во вселенной Lancer не воспринимается как должное: за пределами Герцинии к эгрегорианцу будут относиться иначе. ГМу стоит следить, чтобы такие встречи были в целом позитивными или интересно разрешались.',176),
 WT('Новые классы НИП','**Мститель** (Нападающий/Защитник) — становится опаснее, когда гибнут союзники (**Месть**).\n**Скрытник** (Нападающий) — медленный, но страшный в своих **зонах пелены**; их рассеивают взломом и умным оружием.\n**Странник** (Артиллерист/Нападающий) — меняет **наборы** оружия под дистанцию.\n**Злоба** (Защитник) — технологический защитник: **Заточение** не даёт сбрасывать нагрев.\nВсе четыре — в библиотеке НИП (группа «Wallflower · классы»); уникальные враги кампании (Яд, [Трансляция], СОЖАЛЕНИЕ, [Оружие], [Конец], [Аккумуляция]) — в группе «Wallflower · враги кампании».',190),
 WT('Даунтайм: проекты на часах','Если ИП хотят долгих проектов (личные планы, программы, изобретения) — как в действиях «Собрать сведения» и «Творчество», — вместо обычных правил можно вести их на часах на 4 или 6 сегментов: **9 и меньше** — 1 сегмент, **10–19** — 2, **20+** — 3.',58),
]};
const EIDR=WFEID.rules||{};
const eidSys=s=>`**${s.n}** (${s.t})${s.p?' — '+s.p:''}${s.x?':\n'+s.x:''}`;
const WF_EREF={id:'wf-eid',t:'Эйдолоны (No Room for a Wallflower)',dlc:'WF',items:[
 WT('Эйдолоны',EIDR.intro||'',196),WT('Эйдолоны как враги',EIDR.asenemy||'',198),WT('Осколки',EIDR.shards||'',198),
 {t:'Базовые статы слоя и осколка',table:[['','Тир 1','Тир 2','Тир 3'],['Все проверки','+1 / +1','+2 / +2','+3 / +3'],['ПЗ слоя','10 +5/игрок','15 +5/игрок','20 +5/игрок'],['ПЗ осколка','5','6','8'],['Размер','2 (осколок ½)','2 (½)','2 (½)'],['Броня','0','0','0'],['Тепл. Макс.','10 (осколок 5)','10 (5)','10 (5)'],['Уклонение / Э-Защита','10','12','14'],['Спас. Цель','12','14','16'],['Скорость / Сенсоры','5 / 20','5 / 20','5 / 20']],src:['WF',198]},
 WT('Статы слоёв',EIDR.base||'',198),
 WT('Постоянные черты',[EIDR.order,EIDR.meta,EIDR.predict,EIDR.memetic,EIDR.bonus,EIDR.hover,EIDR.incomp].filter(Boolean).join('\n'),199),
 WT('Ядро',(WFEID.core.rules||'')+'\n'+(WFEID.core.sys||[]).map(eidSys).join('\n'),199),
 WT('Слои',(EIDR.layers||'')+'\nТрекер Эйдолона — в **ГМ tools**: бросок слоёв, ПЗ, броня, Усиление Щита, осколки и Метаморфоза.',199),
 {t:'Таблица слоёв (1d20)',table:[['d20','Слой','d20','Слой'],...Array.from({length:10},(_,i)=>{const a=WFEID.layers[i],b=WFEID.layers[i+10];return [String(i+1),a?a.name:'',String(i+11),b?b.name:'']})],src:['WF',199]},
 ...WFEID.layers.map(L=>WT(`${L.n}: ${L.name}`,`*${L.appear}*\n**Подсказки**: ${L.hints}\n**Правила**: ${L.rules}\n${L.sys.map(eidSys).join('\n')}\n**Осколки** (новых: ${L.sh}): ${L.shtext}${L.shsys.length?'\n'+L.shsys.map(eidSys).join('\n'):''}`,199+Math.ceil(L.n/2))),
]};
{const bi=REF.findIndex(s=>s.dlc==='BG');REF.splice(bi<0?REF.length:bi,0,WF_REF,WF_EREF)}
{const o=viewRef;viewRef=function(){return o().replace('<h2 id="ref-wf">','<div class="dlc-hd"><b>Дополнение · No Room for a Wallflower</b><span>Нет места для тихони</span></div><h2 id="ref-wf">')}}

/* ---------- ГМ tools: таблицы ---------- */
/* только универсальные таблицы; сюжетные таблицы кампании (места, слухи, симптомы, жители) не включаются */
const WF_GMT_KEEP={wf_land:'Wallflower · Пейзажи',wf_reserves:'Wallflower · Резервы',wf_lic2_ipsn:'Wallflower · Как получить раму УЛ2',wf_lic2_ha:'Wallflower · Как получить раму УЛ2',wf_lic2_horus:'Wallflower · Как получить раму УЛ2',wf_lic2_ssc:'Wallflower · Как получить раму УЛ2'};
{const add=WFGMT.filter(t=>WF_GMT_KEEP[t.id]&&!GMT.some(x=>x.id===t.id)).map(t=>({...t,grp:WF_GMT_KEEP[t.id],name:t.id==='wf_reserves'?'Резервы':t.name}));const bi=GMT.findIndex(t=>t.book==='BG');GMT.splice(bi<0?GMT.length:bi,0,...add)}

/* ---------- Эйдолон: трекер ---------- */
const EIDL=Object.fromEntries((WFEID.layers||[]).map(L=>[L.n,L]));
function eidNew(){return{cls:1,tier:1,pcs:4,preset:'',hpb:0,layers:[0,0,0],idx:-1,hp:0,over:0,armor:0,shards:0,turnsUsed:0,round:1,purity:0}}
function eidClean(r){const e=eidNew();if(!r||typeof r!=='object')return e;const n=(v,a,z,d)=>{v=+v;return isFinite(v)?Math.max(a,Math.min(z,Math.round(v))):d};
  e.cls=n(r.cls,1,3,1);e.tier=n(r.tier,1,3,1);e.pcs=n(r.pcs,1,8,4);e.preset=WFEID.presets.some(p=>p.id===r.preset)?r.preset:'';e.hpb=n(r.hpb,0,20,0);
  e.layers=(Array.isArray(r.layers)?r.layers:[]).slice(0,5).map(x=>n(x,0,20,0));while(e.layers.length<e.cls+2)e.layers.push(0);e.layers=e.layers.slice(0,e.cls+2);
  e.idx=n(r.idx,-1,e.layers.length,-1);if(e.layers.some(x=>!x))e.idx=-1;e.hp=n(r.hp,0,999,0);e.over=n(r.over,0,999,0);e.armor=n(r.armor,0,40,0);e.shards=n(r.shards,0,60,0);e.round=n(r.round,1,99,1);e.purity=n(r.purity,0,99,0);return e}
let EIDS=eidClean(LS.get('wf_eid',null));const eidSave=()=>LS.set('wf_eid',EIDS);
const eidTv=(v,t)=>Array.isArray(v)?v[t-1]:v;
function eidCur(){const e=EIDS;if(e.idx<0)return null;if(e.idx>=e.layers.length)return{core:1};return EIDL[e.layers[e.idx]]||null}
function eidMaxHp(L){const e=EIDS,B=WFEID.base.layer||{};if(!L)return 0;if(L.core)return 1;if(L.hp)return eidTv(L.hp,e.tier);if(L.hp1)return 1;return eidTv(B.hp,e.tier)+(B.hpp||5)*e.pcs+e.hpb}
function eidShardsNew(L){const e=EIDS;if(!L||L.core)return 0;const s=String(L.sh);if(/мех/.test(s))return e.pcs;const m=s.split('/').map(Number);return m.length===3?m[e.tier-1]:(+s||0)}
function eidTurns(){return Math.max(1,Math.min(4,Math.floor(EIDS.pcs/2)))}
function eidLog(t,b,c){addLog(c||'',logHead('Эйдолон — '+t)+`<div class="bd">${b}</div>`)}
function eidStart(i){const e=EIDS;e.idx=i;const L=eidCur();if(!L)return;
  if(L.core){e.shards=0;e.hp=1;e.over=0;e.armor=0;eidLog('Ядро','Обнажено ядро (Размер ½, 1 ПЗ). Все осколки испаряются.','hit');return}
  e.hp=eidMaxHp(L);e.armor=L.armor?eidTv(L.armor,e.tier):0;e.over=0;e.purity=0;
  const ns=eidShardsNew(L);e.shards+=ns;
  if(L.hp1){e.over=[10,15,20][e.tier-1]+5*e.shards}
  const pr=WFEID.presets.find(p=>p.id===e.preset);const fl=pr&&pr.flavor&&pr.flavor[String(L.n)];
  eidLog(`Слой ${L.n}: ${L.name}`,`ПЗ ${e.hp}${e.armor?`, Броня ${e.armor}`:''}${e.over?`, Усиление Щита ${e.over}`:''}. Новых осколков: ${ns} (всего ${e.shards}).${fl?'<br>'+pfmt1(fl):''}`,'hit')}
function eidRoll(){const e=EIDS;e.preset='';e.hpb=0;e.layers=Array.from({length:e.cls+2},(_,i)=>i<e.cls+2?rnd(20):0);eidLog('Слои',`Класс ${e.cls}: ${e.layers.map(n=>`${n} ${EIDL[n].name}`).join(' → ')} → ядро`)}
function eidPreset(id){const pr=WFEID.presets.find(p=>p.id===id);if(!pr)return;const e=EIDS;const ls=pr.classes[String(e.cls)]||pr.classes['1'];e.preset=id;e.layers=[...ls];e.hpb=(pr.hpbonus||{})[String(e.cls)]||0;e.idx=-1}
function eidDamage(n,ap,half,type){const e=EIDS,L=eidCur();if(!L||!n||n<0)return;let d=n;const parts=[`${n}`];
  if(e.armor&&!ap&&type!=='burn'){const a=Math.min(e.armor,d);d-=a;parts.push(`−${a} Броня`)}else if(ap)parts.push('ББ');
  if(half){d=Math.ceil(d/2);parts.push('½ Сопротивляемость')}
  if(e.over){const s=Math.min(e.over,d);e.over-=s;d-=s;if(s)parts.push(`щит −${s}`)}
  e.hp=Math.max(0,e.hp-d);parts.push(`итого −${d} → ${e.hp} ПЗ`);
  if(L.n===1&&n>0&&e.armor>0){e.armor=Math.max(0,e.armor-2);parts.push(`Несгибаемый: −2 Брони (теперь ${e.armor}) → обломки [Разрыв]2: 2 кин всем рядом, каждый осколок — [Разрыв]1: 2 кин`)}
  eidLog(L.core?'Ядро':`${L.name}: урон`,parts.join(' · '),d?'hit':'');
  if(e.hp<=0){if(L.core)eidLog('ПОБЕДА','Ядро уничтожено — Эйдолон побеждён.','hit');else eidLog('Метаморфоза','Слой уничтожен. Эйдолон и осколки снимают все статусы и состояния, все эффекты на них кончаются; до начала его следующего хода — Невосприимчивость ко всему урону и эффектам. В начале хода проявится новый слой (кнопка «Следующий слой»).','miss')}}
function eidSysHtml(s){const k={w:'w',c:'c',s:'s',t:'t',r:'r'}[s.k]||'c';return `<div class="abox k${k}"><div class="ah"><b>${esc(s.n)}</b><span>${pfmt1(s.t)}</span></div><div class="ab">${s.p?`<div class="eid-prof">${pfmt1(s.p)}</div>`:''}${pfmt1(s.x||'')}</div></div>`}
function eidView(){const e=EIDS,L=eidCur(),B=WFEID.base.layer||{},SB=WFEID.base.shard||{},t=e.tier;
  const opt=(a,v)=>a.map(([x,l])=>`<option value="${x}" ${String(x)===String(v)?'selected':''}>${esc(l)}</option>`).join('');
  const lsel=(i)=>`<select data-wff="layer" data-i="${i}"><option value="0">— слой —</option>${WFEID.layers.map(l=>`<option value="${l.n}" ${e.layers[i]===l.n?'selected':''}>${l.n}: ${esc(l.name)}</option>`).join('')}</select>`;
  const setup=`<div class="eid-setup">
   <label>Класс <select data-wff="cls">${opt([[1,'1 — 3 слоя'],[2,'2 — 4 слоя'],[3,'3 — 5 слоёв']],e.cls)}</select></label>
   <label>Тир <select data-wff="tier">${opt([[1,'1'],[2,'2'],[3,'3']],t)}</select></label>
   <label>Мехов ИП <input type="number" min="1" max="8" data-wff="pcs" value="${e.pcs}"></label>
   <label>Готовый <select data-wff="preset"><option value="">— свой —</option>${WFEID.presets.map(p=>`<option value="${p.id}" ${e.preset===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}</select></label>
   <button class="btn sm" data-wf="eroll">🎲 Бросить слои (d20)</button></div>
   <div class="eid-order">${e.layers.map((n,i)=>`<span class="eid-l ${i===e.idx?'on':''} ${i<e.idx?'done':''}">${lsel(i)}</span>`).join('<span class="eid-ar">→</span>')}<span class="eid-ar">→</span><span class="eid-l ${e.idx>=e.layers.length?'on':''}">ядро</span></div>
   ${e.preset?`<div class="muted eid-pre">${pfmt1((WFEID.presets.find(p=>p.id===e.preset)||{}).desc||'')}${e.hpb?`<br>Бонус к базовым ПЗ слоёв: +${e.hpb}`:''}</div>`:''}
   <div class="row-btns">${e.idx<0?`<button class="btn red" data-wf="estart" ${e.layers.every(x=>x)?'':'disabled'}>▶ Начать бой: первый слой</button>`:`<button class="btn" data-wf="enext">⟳ Следующий слой (Метаморфоза)</button><button class="btn sm" data-wf="ereset">Сбросить</button>`}
   <span class="muted">Ходов за раунд: <b>${eidTurns()}</b> (по одному на каждых двух враждебных мехов, максимум 4)</span></div>`;
  let cur='';
  if(L){const mx=eidMaxHp(L);
   const st=L.core?'Размер ½ · 1 ПЗ':`Уклонение ${L.evasion||eidTv(B.evasion,t)} · Э-Защита ${L.edef||eidTv(B.edef,t)} · Спас. Цель ${eidTv(B.save,t)} · Скорость ${L.speed||B.speed} · Размер ${L.size===0.5?'½':(L.size||B.size)} · Тепл. Макс. ${B.heat} · Сенсоры ${B.sensors} · проверки +${eidTv(B.all,t)} · 1 Структура, 1 Нагрузка`;
   cur=`<div class="eid-cur"><div class="eid-hd"><b>${L.core?'Ядро':`Слой ${L.n}: ${esc(L.name)}`}</b>${L.core?'':`<span class="muted">${esc(L.en)}</span>`}${srcTag('WF',L.core?199:199+Math.ceil(L.n/2))}</div>
    <div class="eid-bars"><span class="eid-hp"><i style="width:${Math.max(0,Math.min(100,e.hp/Math.max(1,mx)*100))}%"></i><b>ПЗ ${e.hp}/${mx}</b></span>
     <span>Броня <button class="pm" data-wf="earm" data-d="-1">−</button><b>${e.armor}</b><button class="pm" data-wf="earm" data-d="1">+</button></span>
     <span>Усиление Щита <button class="pm" data-wf="eover" data-d="-1">−</button><b>${e.over}</b><button class="pm" data-wf="eover" data-d="1">+</button></span>
     <span>Осколки <button class="pm" data-wf="esh" data-d="-1">−</button><b>${e.shards}</b><button class="pm" data-wf="esh" data-d="1">+</button></span></div>
    <div class="eid-dmg"><input type="number" min="0" id="eidn" placeholder="урон"><label><input type="checkbox" id="eidap"> ББ</label><label><input type="checkbox" id="eidhalf"> Сопротивляемость</label><button class="btn sm red" data-wf="edmg">Нанести урон</button><button class="btn sm" data-wf="eheal">+ПЗ</button>
     ${L.hp1?`<button class="btn sm" data-wf="epur">Чистота: Усиление Щита ${[10,15,20][t-1]} +5×осколок</button>`:''}</div>
    <div class="muted eid-st">${st}</div>
    ${L.core?'':`<div class="eid-sec"><b class="h">Подсказки</b> (для Сканирования)<div>${pfmt1(L.hints)}</div></div><div class="eid-sec"><b class="h">Правила слоя</b><div>${pfmt1(L.rules)}</div></div>`}
    ${(L.core?WFEID.core.sys:L.sys).map(eidSysHtml).join('')}
    ${L.core?'':`<div class="eid-sec"><b class="h">Осколки</b> <span class="muted">(новых: ${esc(String(L.sh))}; ПЗ ${eidTv(SB.hp,t)}, Уклонение ${eidTv(SB.evasion,t)}, Э-Защита ${eidTv(SB.edef,t)}, Скорость ${SB.speed}, Размер ½)</span><div>${pfmt1(L.shtext)}</div></div>${L.shsys.map(eidSysHtml).join('')}`}</div>`}
  return `<section class="pbox wf-panel" id="wf-eid"><h3>👁 Эйдолон — трекер</h3>
   <div class="muted" style="font-size:12px">Особый враг из слоёв вокруг ядра: активен один слой, после его уничтожения — Метаморфоза и следующий слой. Правила и все 20 слоёв — в Справочнике.</div>${setup}${cur}</section>`}

/* ---------- Бои кампании ---------- */
let WFE={enc:(LS.get('wf_enc_sel',null)||{}).enc||'',pcs:+((LS.get('wf_enc_sel',null)||{}).pcs)||3};
if(typeof WFE.enc!=='string')WFE.enc='';if(![3,4,5].includes(WFE.pcs))WFE.pcs=3;
const wfeSave=()=>LS.set('wf_enc_sel',{enc:WFE.enc,pcs:WFE.pcs});
/* активные усиления позиции боя: upg — объект или список объектов {pc,t,o,ch,note} */
function wfUps(it){return (Array.isArray(it.upg)?it.upg:it.upg?[it.upg]:[]).filter(u=>u&&WFE.pcs>=u.pc)}
function wfMerged(it){const ups=wfUps(it);return {t:[...new Set([...it.t,...ups.flatMap(u=>u.t||[])])],o:[...new Set([...it.o,...ups.flatMap(u=>u.o||[])])],
  ch:[...new Set([...(it.ch||[]),...ups.flatMap(u=>u.ch||[])])],notes:[it.note,...ups.map(u=>u.note)].filter(Boolean)}}
function wfItemTxt(it){const c=cls(it.c),m=wfMerged(it);const tp=m.t.map(id=>(tpl(id)||{}).name||id);
  const os=m.o.map(id=>{const s=c&&[...c.base,...c.optional].find(x=>x.id===id);return s?s.name:id});
  const byT={};m.ch.forEach(id=>{for(const t of m.t){const tt=tpl(t);const x=tt&&tplItems(tt).find(y=>y.id===id);if(x){(byT[tt.name]=byT[tt.name]||[]).push(x.name);return}}});
  const chs=Object.entries(byT).map(([k,v])=>`${k}: ${v.join(', ')}`);
  return `${it.n}× ${tp.length?tp.join(' ')+' ':''}<b>${esc(it.label||(c?c.name:it.c))}</b>${os.length?` (${esc(os.join(', '))})`:''}${chs.length?` <span class="wf-ch">[${esc(chs.join('; '))}]</span>`:''}${m.notes.length?` <span class="muted">— ${esc(m.notes.join('; '))}</span>`:''}`}
const wfCurEnc=()=>WFENC.find(x=>x.id===WFE.enc)||WFENC[0];
function wfEncView(){const E=wfCurEnc();
  return `<section class="pbox wf-panel" id="wf-enc"><h3>⚔ Бои кампаний и модулей</h3>
   <div class="eid-setup"><label>Бой <select data-wff="enc">${[...new Set(WFENC.map(x=>x.book||'WF'))].map(bk=>`<optgroup label="${esc((BOOKS[bk]||{name:bk}).name)}">${WFENC.filter(x=>(x.book||'WF')===bk).map(x=>`<option value="${x.id}" ${E&&x.id===E.id?'selected':''}>${esc(x.mission.replace(/:.*/,''))} · ${esc(x.name)}</option>`).join('')}</optgroup>`).join('')}</select></label>
   <label>ИП <select data-wff="epcs">${[3,4,5].map(n=>`<option ${n===WFE.pcs?'selected':''}>${n}</option>`).join('')}</select></label>
   <span class="muted">Тир НИП — как выбран в Библиотеке (сейчас ${S.tier}). Команда — «${esc(team(S.addTeam).name)}».</span></div>
   ${E?`<div class="wf-enc"><div class="eid-hd"><b>${esc(E.name)}</b><span class="muted">${esc(E.en)} · ${esc(E.mission)}</span>${srcTag(E.book||'WF',E.page)}</div>
    <div><b>Ситреп</b>: ${esc(E.sitrep)}${E.obj?` · <b>Цель</b>: ${esc(E.obj)}`:''}${E.env?` · <b>Окружение</b>: ${esc(E.env)}`:''}</div>
    ${E.groups.map((g,gi)=>{const its=g.items.filter(i=>WFE.pcs>=i.pc);return `<div class="wf-grp"><div class="wf-gh"><b>${esc(g.name)}</b><button class="btn sm red" data-wf="eadd" data-v="${gi}" ${its.length?'':'disabled'}>＋ Добавить в бой</button></div><ul>${its.map(i=>`<li>${wfItemTxt(i)}</li>`).join('')}</ul></div>`}).join('')}
    <div class="eid-sec">${pfmt1(E.details)}</div></div>`:''}</section>`}
function wfAddGroup(gi){const E=wfCurEnc();if(!E)return;const g=E.groups[gi];if(!g)return;
  const keep={cls:S.cls,addN:S.addN,view:S.view,sel:{},tpl:{}};let added=0;
  g.items.filter(i=>WFE.pcs>=i.pc).forEach(it=>{const c=cls(it.c);if(!c)return;
    keep.sel[c.id]=keep.sel[c.id]||getSel(c.id).slice();keep.tpl[c.id]=keep.tpl[c.id]||JSON.parse(JSON.stringify(getTplSel(c.id)));
    const m=wfMerged(it),tps=m.t.filter(id=>tpl(id));
    S.sel[c.id]=m.o.filter(id=>c.optional.some(s=>s.id===id));
    S.tplSel[c.id]={tpls:tps,ch:m.ch.filter(id=>tps.some(t=>tplItems(tpl(t)).some(x=>x.id===id)))};
    S.cls=c.id;S.addN=it.n;const before=S.enc.length;addToEnc();
    S.enc.slice(before).forEach((x,k)=>{if(it.label)x.label=`${it.label}${it.n>1?' #'+(k+1):''}`;const nt=m.notes.join('; ');if(nt)x.notes=nt});added+=S.enc.length-before});
  Object.entries(keep.sel).forEach(([k,v])=>S.sel[k]=v);Object.entries(keep.tpl).forEach(([k,v])=>S.tplSel[k]=v);S.cls=keep.cls;S.addN=keep.addN;S.view=keep.view;
  addLog('hit',logHead('Бой кампании: '+E.name)+`<div class="bd">${esc(g.name)} для ${WFE.pcs} ИП — добавлено НИП: ${added}. Тир ${S.tier}.</div>`);
  if(typeof save==='function')save();render();toast(`Добавлено в бой: ${added}`)}

/* ---------- встраивание в ГМ tools ---------- */
{const o=viewGm;viewGm=function(){let h=o();const k='<div class="dlc-hd" id="gm-dlc-WF">';const i=h.indexOf(k);
  const panels=`<div class="wf-panels">${WFENC.length?wfEncView():''}${eidView()}</div>`;
  if(i<0)return h+panels;const j=h.indexOf('</div>',i)+6;return h.slice(0,j)+panels+h.slice(j)}}
{const o=gmSide;gmSide=function(){return o().replace('<div class="side-sub">Дополнение · No Room for a Wallflower</div>','<div class="side-sub">Дополнение · No Room for a Wallflower</div><button class="citem" data-wf="goto" data-v="wf-eid">👁 Эйдолон</button>')}}
document.addEventListener('click',e=>{const b=e.target.closest('[data-wf]');if(!b||b.disabled)return;const k=b.dataset.wf,v=b.dataset.v,E=EIDS;
  if(k==='goto'){const el=document.getElementById(v);if(el)el.scrollIntoView({behavior:'smooth',block:'start'});return}
  if(k==='eadd'){wfAddGroup(+v);return}
  if(k==='eroll')eidRoll();
  else if(k==='estart'){E.shards=0;E.round=1;eidStart(0)}
  else if(k==='enext'){if(E.idx<E.layers.length)eidStart(E.idx+1)}
  else if(k==='ereset'){E.idx=-1;E.hp=0;E.over=0;E.armor=0;E.shards=0}
  else if(k==='earm')E.armor=Math.max(0,E.armor+ +b.dataset.d);
  else if(k==='eover')E.over=Math.max(0,E.over+ +b.dataset.d);
  else if(k==='esh')E.shards=Math.max(0,E.shards+ +b.dataset.d);
  else if(k==='edmg'){const n=+(document.getElementById('eidn')||{}).value||0;eidDamage(n,(document.getElementById('eidap')||{}).checked,(document.getElementById('eidhalf')||{}).checked)}
  else if(k==='eheal'){const n=+(document.getElementById('eidn')||{}).value||0;const L=eidCur();if(L&&n>0)E.hp=Math.min(eidMaxHp(L),E.hp+n)}
  else if(k==='epur'){E.over+=[10,15,20][E.tier-1]+5*E.shards;eidLog('Чистота',`Усиление Щита теперь ${E.over}`)}
  else return;
  eidSave();render()});
document.addEventListener('change',e=>{const el=e.target.closest('[data-wff]');if(!el)return;const f=el.dataset.wff,E=EIDS;
  if(f==='enc'){WFE.enc=el.value;wfeSave();render();return}
  if(f==='epcs'){WFE.pcs=+el.value;wfeSave();render();return}
  if(f==='cls'){E.cls=+el.value;if(E.preset)eidPreset(E.preset);else{while(E.layers.length<E.cls+2)E.layers.push(0);E.layers=E.layers.slice(0,E.cls+2)}E.idx=-1}
  else if(f==='tier')E.tier=+el.value;
  else if(f==='pcs')E.pcs=Math.max(1,Math.min(8,+el.value||1));
  else if(f==='preset'){if(el.value)eidPreset(el.value);else{E.preset='';E.hpb=0}}
  else if(f==='layer'){E.layers[+el.dataset.i]=+el.value;E.preset=''}
  else return;
  EIDS=eidClean(E);eidSave();render()});
