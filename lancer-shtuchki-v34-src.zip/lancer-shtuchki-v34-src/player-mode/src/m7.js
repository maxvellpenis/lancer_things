/* ---------- v14: предыстории, резервы, прототип Инженера, авто-модификаторы, размещаемые ---------- */
P.BG={};(PCD.backgrounds||[]).forEach(b=>P.BG[b.id]=b);
P.RS={};(PCD.reserves||[]).forEach(r=>P.RS[r.id]=r);
const RS_TYPE={Bonus:'Бонусы (постоянные очки)',Resource:'Ресурсы',Mech:'Экипировка и снаряжение меха',Tactical:'Тактические преимущества'};
const PROTO_TYPES=['Melee','CQB','Rifle','Cannon','Launcher','Nexus'];
const newProto=()=>({type:'Rifle',dt:'kin',lim:null,rev:[]});
function mig7(p){
  if(!Array.isArray(p.reserves))p.reserves=[];if(p.bgId===undefined)p.bgId='';
  (p.mechs||[]).forEach(m=>{m.proto=Object.assign(newProto(),m.proto||{})});
}
PS.pilots.forEach(mig7);
{const o=newPilot;newPilot=function(){const p=o();mig7(p);return p}}
{const o=newMech;newMech=function(f){const m=o(f);m.proto=newProto();return m}}
{const o=migratePilot;migratePilot=function(p){o(p);mig7(p)}}

/* ---- резервы: доступ ---- */
const rsActive=r=>r&&P.RS[r.id]&&(P.RS[r.id].type==='Bonus'||!r.used);
function resCount(p,id){return (p.reserves||[]).filter(r=>r.id===id&&rsActive(r)).length}
function resAll(p,id){return (p.reserves||[]).filter(r=>r.id===id&&rsActive(r))}
const pcWSlots=p=>2+resCount(p,'reserve_extended_harness');
const pcGSlots=p=>3+2*resCount(p,'reserve_extended_harness');

{const o=budgets;budgets=function(p){const b=o(p);
  [['sk','reserve_skill'],['hs','reserve_mechskill'],['tl','reserve_talent'],['lc','reserve_license'],['cb','reserve_corebonus']].forEach(([k,id])=>{const n=resCount(p,id);if(n){b[k].max+=n;b[k].hint+=` Резерв «${P.RS[id].name}»: +${n}.`}});
  return b}}
{const o=itemOk;itemOk=function(p,x){if(o(p,x))return true;return resAll(p,'reserve_rented_gear').some(r=>r.item===x.id)}}
{const o=limMax;limMax=function(p,x){const v=o(p,x);if(v===null)return v;return v+resAll(p,'reserve_ammo').filter(r=>r.item===x.id).reduce((a,r)=>a+(+r.n||1),0)}}
{const o=mechStats;mechStats=function(p,m){const st=o(p,m);const n=resCount(p,'reserve_extra_repairs');
  if(n){st.repcap+=2*n;st.why.repcap+=` · +${2*n} резерв «${P.RS.reserve_extra_repairs.name}»`}
  st.coreUses=1+resCount(p,'reserve_core_battery');return st}}

/* ---- прогрессия: ранги сверх УЛ ---- */
{const o=buildWarnings;buildWarnings=function(p,m){const W=o(p,m);
  const up=(obj)=>Object.values(obj).reduce((a,r)=>a+Math.max(0,(+r||0)-1),0);
  const skUp=up(p.skills)+p.custom.reduce((a,c)=>a+Math.max(0,(+c.rank||0)-1),0),skMax=p.ll+resCount(p,'reserve_skill');
  if(skUp>skMax)W.push(`Навыки-триггеры: повышений до +4/+6 — ${skUp}, а доступно ${skMax} (на УЛ0 все четыре триггера только +2; каждый УЛ — одно повышение или новый триггер)`);
  const tUp=up(p.talents),tMax=p.ll+resCount(p,'reserve_talent');
  if(tUp>tMax)W.push(`Таланты: рангов выше I — ${tUp}, а доступно ${tMax} (на УЛ0 три таланта ранга I; каждый УЛ — новый талант или следующий ранг)`);
  if(protoRank(p)>=2&&(m.proto.rev||[]).length!==2)W.push('Инженер II «Ревизия»: выберите ровно два улучшения прототипа');
  const lic=Object.entries(p.lic).filter(([k,r])=>r>3);lic.forEach(([k])=>W.push(`${P.F[k].name}: максимум 3 ранга лицензии`));
  const wsl=pcWSlots(p),gsl=pcGSlots(p);
  if(p.gear.weapons.slice(wsl).some(Boolean))W.push(`Оружие пилота: можно взять только ${wsl}`);
  if(p.gear.items.slice(gsl).some(Boolean))W.push(`Снаряжение пилота: можно взять только ${gsl}`);
  return W}}

/* ---- прототип Инженера ---- */
const protoRank=p=>Math.min(3,(p.talents&&p.talents.t_engineer)||0);
const DT_FULL={kin:'kinetic',en:'energy',exp:'explosive'};
function protoW(p,m){
  const r=protoRank(p);if(!r)return null;const pr=m.proto||(m.proto=newProto());const melee=pr.type==='Melee',rev=r>=2?(pr.rev||[]):[];
  const lim=pr.lim!=null?pr.lim:(r>=3?7:5);
  const tags=[['tg_limited',lim],['tg_overkill']];if(rev.includes('comp'))tags.push(['tg_smart']);
  const rv={optics:'Улучшенная Оптика: всегда +1 точн. к атакам',comp:'Изменённый Компьютер: оружие Умное',reactor:'Снятая защита реактора: за 2 нагрева — атака '+(melee?'Разрывом 1':'Конусом 3, Линией 5 или Взрывом 1 (Дальн. 10)')};
  return{id:'mw_prototype',name:'Прототип Оружия'+(r>1?' '+'I'.repeat(r):''),en:'Prototype Weapon '+'I'.repeat(r),src:'GMS',mount:'Main',type:pr.type,sp:0,proto:1,
    rng:[melee?{t:'Threat',v:1}:{t:'Range',v:10}],dmg:[{t:DT_FULL[pr.dt]||'kinetic',v:r>=3?'1d6+4':'1d6+2'}],tags,tal:['t_engineer',r],
    text:`Экспериментальный прототип (талант **Инженер**). Тип оружия, тип урона и дальность ([Угроза] 1 для ОББ, иначе [Дальн] 10) выбираются при установке и при каждом **Полном Ремонте**; тогда же перебрасывается **Ограниченное** (${r>=3?'2d6':'1d6+2'}): сейчас **${lim}**. Считается встроенным оружием и не требует слота.`+(rev.length?'\n'+rev.map(k=>'• '+rv[k]).join('\n'):'')}
}
function protoUi(p,m){
  const r=protoRank(p),pr=m.proto;
  const rv=[['optics','Улучшенная Оптика (+1 точн.)'],['comp','Изменённый Компьютер (Умное)'],['reactor','Снятая защита реактора (2 нагрева: площадная атака)']];
  return `<div class="proto-ui"><label>Тип <select data-p7="ptype">${PROTO_TYPES.map(t=>`<option value="${t}" ${pr.type===t?'selected':''}>${esc(WTYPE_RU[t])}</option>`).join('')}</select></label>
    <label>Урон <select data-p7="pdt">${['kin','en','exp'].map(k=>`<option value="${k}" ${pr.dt===k?'selected':''}>${PDT_RU[k]}</option>`).join('')}</select></label>
    <label>Ограниченное <b>${pr.lim??'—'}</b> <button class="btn sm" data-pa="plim">🎲 ${r>=3?'2d6':'1d6+2'}</button></label>
    ${r>=2?`<div class="proto-rev">Ревизия (выберите два): ${rv.map(([k,l])=>`<label><input type="checkbox" data-pa="prev" data-v="${k}" ${(pr.rev||[]).includes(k)?'checked':''}> ${esc(l)}</label>`).join('')}</div>`:''}
    <div class="muted" style="font-size:11px">Менять можно при установке и при каждом Полном Ремонте.</div></div>`;
}
function protoRollLim(p,m,log){const r=protoRank(p);if(!r)return;const x=pcRollExpr(r>=3?'2d6':'1d6+2',{});m.proto.lim=x.v;
  if(log)pcLog(p,'Прототип Оружия',`Ограниченное перебрасывается: ${r>=3?'2d6':'1d6+2'} [${x.txt}] = ${x.v}`)}
{const o=mechMounts;mechMounts=function(p,m){const ms=o(p,m);if(protoRank(p)&&m.proto&&m.proto.lim==null){const x=pcRollExpr(protoRank(p)>=3?'2d6':'1d6+2',{});m.proto.lim=x.v}const w=protoW(p,m);
  if(w)ms.push({type:'Integrated',key:'tal-proto',fixed:'mw_prototype',w,note:'Талант: Инженер',ui:protoUi(p,m)});return ms}}
{const o=pcFullRepair;pcFullRepair=function(p,silent){const m=curM(p);
  if(protoRank(p)&&(!silent||m.proto.lim==null))protoRollLim(p,m,!silent);
  o(p,silent);const st=mechStats(p,m);p.cb.cp=st.coreUses;p.cb.deps=[];
  if(!silent&&st.coreUses>1)pcLog(p,'Батарея Ядра',`Мощь Ядра: ${st.coreUses} активации на эту миссию (резерв).`)}}

/* ---- иммунитеты к состояниям ---- */
function immuneTo(p,cond){const m=curM(p);const out=[];
  if(cond==='Ослаблен'&&p.cbs.includes('cb_superior_by_design'))out.push(P.CB.cb_superior_by_design.name);
  if(cond==='Замедлен'&&resCount(p,'reserve_boosted_servos'))out.push('резерв «'+P.RS.reserve_boosted_servos.name+'»');
  if(cond==='Расщеплен'&&m&&m.frame==='mf_saladin')out.push('черта «'+trName(P.F.mf_saladin,'Reinforced Frame')+'»');
  return out[0]||null}
{const o=pAddCond;pAddCond=function(c,x){const p=PS.pilots.find(q=>q.cb===c);const im=p&&immuneTo(p,x);if(im){pcLog(p,'Невосприимчивость',`«${x}» не действует: ${im}.`);return}o(c,x)}}
{const o=pcStressCheck;pcStressCheck=function(p){o(p);if(p.cbs.includes('cb_stasis_shielding')&&!p.cb.dead)pcLog(p,P.CB.cb_stasis_shielding.name,'Получен нагрузочный урон: Сопротивляемость ко всему урону до начала вашего следующего хода (отмечайте «½ Сопр.» при получении урона).','hit')}}

/* ---- автоматическая сопротивляемость ---- */
const trName=(f,en)=>{const t=f.traits.find(t=>t.en===en);return t?t.name:en};
function autoResist(p,dt,o){
  const m=curM(p),f=P.F[m.frame],c=pcEnsure(p);
  if(p.cbs.includes('cb_briareos_frame')&&c.struct<=1&&dt!=='heat')return P.CB.cb_briareos_frame.name;
  if(f.id==='mf_manticore'&&(dt==='en'||dt==='burn'))return trName(f,'Slag Carapace');
  if(f.id==='mf_black_witch'&&dt==='kin')return trName(f,'Repulsor Field');
  if(f.id==='mf_barbarossa'&&dt==='exp')return trName(f,'Pressure Plating');
  if(f.id==='mf_drake'&&o.area&&['kin','en','exp','burn','heat'].includes(dt))return trName(f,'Blast Plating');
  return null;
}
{const o=pcDamage;pcDamage=function(p,n,dt,opt){opt=Object.assign({},opt||{});const m=curM(p),f=P.F[m.frame];
  if(dt==='burn'&&(f.id==='mf_lancaster'||f.id==='mf_genghis')){pcLog(p,'Горение',`${n} горения не действует: Невосприимчивость (${trName(f,'Insulated')}).`,'hit');return}
  if(!opt.half){const w=autoResist(p,dt,opt);if(w){opt.half=true;opt.why=w}}
  o(p,n,dt,opt)}}
function dmgExtra(p,m,c){return m.frame==='mf_drake'?`<label class="kw" data-tt="Абразивное Напыление" data-tip="Атака Взрывом, Разрывом, Линией или Конусом: Сопротивляемость к урону, горению и нагреву."><input type="checkbox" id="parea"> по площади</label>`:''}

/* ---- авто-модификаторы бросков ---- */
const fixedM=(label,acc,diff)=>({label,acc:acc||0,diff:diff||0,on:true,fixed:1});
const optM=(label,acc,diff,on)=>({label,acc:acc||0,diff:diff||0,on:!!on});
{const o=pcBaseMods;pcBaseMods=function(p,kind,opt){opt=opt||{};let mods=o(p,kind,opt);const m=curM(p),fr=m.frame,cb=id=>p.cbs.includes(id),T=(id,r)=>(p.talents[id]||0)>=r;
  if(cb('cb_superior_by_design'))mods=mods.filter(x=>x.label!=='Вы Ослаблены (состояние)');
  if(kind==='check'){const sk=opt.skill;
    if(sk==='hull'){if(cb('cb_gyges_frame'))mods.push(fixedM(P.CB.cb_gyges_frame.name,1));if(fr==='mf_dusk_wing'||fr==='mf_goblin')mods.push(fixedM('Черта «'+trName(P.F[fr],'Fragile')+'»',0,1))}
    if(sk==='agi'){if(cb('cb_kai_bioplating'))mods.push(fixedM(P.CB.cb_kai_bioplating.name,1));if(fr==='mf_mourning_cloak')mods.push(fixedM('Черта «'+trName(P.F[fr],'Biotic Components')+'»',1));if(T('t_ace',1))mods.push(optM('Ас I: вы летите',1))}
    if(sk==='sys'&&cb('cb_the_lesson_of_disbelief'))mods.push(fixedM(P.CB.cb_the_lesson_of_disbelief.name,1));
    if(sk==='eng'){if(cb('cb_armory_sculpted_chassis'))mods.push(fixedM(P.CB.cb_armory_sculpted_chassis.name,1));if(fr==='mf_sherman')mods.push(fixedM('Черта «'+trName(P.F[fr],'Superior Reactor')+'»',1))}
    resAll(p,'reserve_systems_reinforcement').concat(resAll(p,'reserve_accuracy')).forEach(r=>{if(r.skill===sk)mods.push(fixedM('Резерв «'+P.RS[r.id].name+'»',1))});
    if(T('t_bonded',1))mods.push(optM('Узы I: Партнёр рядом',1));
  }
  if(kind==='tech'&&fr==='mf_goblin')mods.push(fixedM('Черта «'+trName(P.F[fr],'Liturgicode')+'»',1));
  if(kind==='atk'||kind==='tech'){
    if(fr==='mf_tortuga')mods.push(optM('Черта «'+trName(P.F[fr],'Sentinel')+'»: атака реакцией (Наблюдение)',1));
    if(T('t_brutal',3)){const c=pcEnsure(p),v=c.counters.ctr_brutal||0;if(v)mods.push(fixedM(`Брутал III: промахи подряд (${v})`,v))}
  }
  return mods}}
function weaponTalentMods(p,w,tags){
  const T=(id,r)=>(p.talents[id]||0)>=r,out=[],melee=w.type==='Melee',ranged=!melee,c=pcEnsure(p),m=curM(p);
  const lab=(id,r)=>{const t=P.T[id];return t?`${t.name} ${'I'.repeat(r)}: ${t.ranks[r-1].name}`:id};
  if(T('t_gunslinger',1)&&ranged&&w.mount==='Auxiliary')out.push(optM(lab('t_gunslinger',1)+' (первая атака в ход)',1,0,true));
  if(T('t_vanguard',1)&&w.type==='CQB')out.push(optM(lab('t_vanguard',1)+' (цель в пределах 3)',1,0,true));
  if(T('t_duelist',1)&&melee&&w.mount==='Main')out.push(optM(lab('t_duelist',1)+' (первая атака в ход)',1));
  if(T('t_brawler',1)&&melee)out.push(optM(lab('t_brawler',1)+' (цель схвачена вами)',1));
  if(T('t_crack_shot',1)&&w.type==='Rifle')out.push(optM(lab('t_crack_shot',1)+' (вы прицелились)',1));
  if(T('t_crack_shot',2)&&w.type==='Rifle')out.push({label:lab('t_crack_shot',2)+': слабое место (+1 неточн., +1d6 при крите)',diff:1,on:false,critDice:'1d6'});
  if(T('t_tactician',1)&&melee)out.push(optM(lab('t_tactician',1)+' (союзник Вовлечён с целью)',1));
  if(T('t_tactician',2)&&ranged)out.push(optM(lab('t_tactician',2)+' (вы выше цели)',1));
  if(T('t_combined_arms',3))out.push(optM(lab('t_combined_arms',3)+' (попали атакой другого типа)',1));
  if(p.cbs.includes('cb_the_lesson_of_thinking_tomorrows_thought')&&melee)out.push(optM(P.CB.cb_the_lesson_of_thinking_tomorrows_thought.name+' (тех. атака попала)',1));
  if(T('t_nuclear_cavalier',2)&&(c.heat*2>=mechStats(p,m).heatcap))out.push({label:lab('t_nuclear_cavalier',2)+' (Опасная Зона, первая атака в ход): +1d6 энерг.',addDice:'1d6',on:false});
  if(T('t_leader',1))out.push({label:'Кубик Лидерства союзника: +1d6',addDice:'1d6',on:false});
  if(T('t_gunslinger',3)&&ranged&&w.mount==='Auxiliary'&&(c.counters.ctr_gunslinger??6)<=1)out.push({label:lab('t_gunslinger',3)+': сбросить кубик — +2d6, ББ, без укрытия',addDice:'2d6',on:false,gsReset:1});
  const fr=m.frame;
  if(fr==='mf_nelson'&&melee)out.push({label:'Черта «'+trName(P.F[fr],'Momentum')+'» (после Ускорения): +1d6',addDice:'1d6',on:false});
  if(fr==='mf_mourning_cloak'&&melee)out.push({label:'Черта «'+trName(P.F[fr],'Hunter')+'» (цель одна): +1d6',addDice:'1d6',on:false});
  if(fr==='mf_tokugawa'&&pHas(c,'Уязвим'))out.push({label:'Черта «'+trName(P.F[fr],'Limit Break')+'» (Уязвим): +3 энерг.',addDice:'3',on:true});
  if(w.proto){const rev=protoRank(p)>=2?(m.proto.rev||[]):[];
    if(rev.includes('optics'))out.push(fixedM('Прототип: Улучшенная Оптика',1));
    if(rev.includes('reactor'))out.push({label:'Прототип: Снятая защита реактора (+2 нагрева, '+(melee?'Разрыв 1':'Конус 3 / Линия 5 / Взрыв 1')+')',on:false,selfHeat:2,area:1})}
  return out}
{const o=pcSetProfile;pcSetProfile=function(p,x,pi){o(p,x,pi);const m=curM(p),fr=m.frame,w=x.w;
  M.mods.push(...weaponTalentMods(p,w,M.w.tags));
  if(fr==='mf_deaths_head'&&w.type!=='Melee'){M.bonus+=1;M.bwhy+=' · +1 «'+trName(P.F[fr],'Perfected Targeting')+'»'}
}}
{const o=pcOpenBasic;pcOpenBasic=function(p,k){o(p,k);if(!M||M.kind!=='pcroll')return;const T=(id,r)=>(p.talents[id]||0)>=r;
  if(k==='impro'&&T('t_brawler',2)){M.w={name:BASIC.impro.n,dmg:[{t:'kinetic',v:'2d6+2'}],rng:[{t:'Threat',v:1}],tags:[['tg_knockback',2]]};M.note+=' Дебошир II «Кувалда»: 2d6+2 кин., Толчок 2.'}
  if(k==='ram'&&T('t_juggernaut',1))M.mods.push(optM('Джаггернаут I: после Ускорения (+2 отбрасывания)',1));
  if(['impro','ram','grapple'].includes(k)){if(T('t_brawler',1))M.mods.push(optM('Дебошир I (цель схвачена вами)',1));if(T('t_tactician',1))M.mods.push(optM('Тактик I (союзник Вовлечён с целью)',1))}
  renderModal()}}
{const o=pcOpenTrigger;pcOpenTrigger=function(p,name,rank){o(p,name,rank);const bg=P.BG[p.bgId];const bn=bg?bg.name:(p.bg||'');
  M.mods.push({label:'Влияние предыстории'+(bn?' «'+bn+'»':'')+': помогает',acc:1,on:false,grp:'bg'},{label:'Влияние предыстории: мешает (решение ГМ)',diff:1,on:false,grp:'bg'});renderModal()}}
/* Брутал I: максимум урона на натуральной 20; Перебор кубика Стрелка; самонагрев модов */
{const o=pcRollExpr;pcRollExpr=function(expr,opt){opt=opt||{};if(!opt.max)return o(expr,opt);
  const s=String(expr).replace(/\s+/g,'').toLowerCase();let v=0;const terms=s.match(/[+-]?[^+-]+/g)||[];
  terms.forEach(t=>{const sg=t[0]==='-'?-1:1,b=t.replace(/^[+-]/,''),mm=b.match(/^(\d*)d(\d+)$/);v+=sg*(mm?(+(mm[1]||1))*(+mm[2]):(+b||0))});
  return{v:Math.max(0,v),txt:expr+' = максимум '+v,heat:0}}}
{const o=pcDamageRoll;pcDamageRoll=function(crit,hit){
  const p=PS.pilots.find(x=>x.id===M.pid);const brutal=p&&(p.talents.t_brutal||0)>=1&&crit&&M.res&&M.res.d20===20;
  const extra=crit?M.mods.filter(x=>x.on&&x.critDice):[];extra.forEach(x=>x.addDice=x.critDice);
  if(!brutal){const r=o(crit,hit);extra.forEach(x=>delete x.addDice);return r}
  const keep=pcRollExpr;pcRollExpr=(e,opt)=>keep(e,Object.assign({},opt,{max:1}));
  try{const r=o(crit,hit);r.html=r.html.replace('<div class="bd">','<div class="bd">Брутал I «Хищник»: натуральная 20 — максимальный урон · ');return r}finally{pcRollExpr=keep;extra.forEach(x=>delete x.addDice)}}}
{const o=pcRoll;pcRoll=function(dmgOnly){
  if(M&&M.kind==='pcroll'&&!dmgOnly){M.res={d20:0};}
  // натуральная 20 известна только после броска: подменяем rnd для первого d20
  const p=PS.pilots.find(x=>x.id===M.pid);
  if(!dmgOnly&&M.mode!=='check'){const keep=rnd;let first=true;rnd=function(n){const v=keep(n);if(first&&n===20){first=false;M.res={d20:v}}return v};
    try{o(dmgOnly)}finally{rnd=keep}}
  else o(dmgOnly);
  if(!p||!M||!M.res||M.mode==='check'||dmgOnly)return;const c=pcEnsure(p);
  const heat=M.mods.filter(x=>x.on&&x.selfHeat).reduce((a,x)=>a+x.selfHeat,0);if(heat){pcHeat(p,heat,'Снятая защита реактора')}
  if(M.mods.some(x=>x.on&&x.gsReset)){c.counters.ctr_gunslinger=6;pcLog(p,'Кубик Стрелка','Сброшен на 6: +2d6, ББ и игнорирование укрытия применены к этой атаке.')}
  else if((p.talents.t_gunslinger||0)>=3&&M.res.hit===true&&M.w&&M.uid){const x=mechWeapons(p,curM(p)).find(y=>y.uid===M.uid);if(x&&x.w.mount==='Auxiliary'&&x.w.type!=='Melee'){c.counters.ctr_gunslinger=Math.max(1,(c.counters.ctr_gunslinger??6)-1)}}
  if((p.talents.t_brutal||0)>=3&&M.res.hit!==null){c.counters.ctr_brutal=M.res.hit?0:(c.counters.ctr_brutal||0)+1}
  pcSave();renderMain()}}
{const o=renderPcModal;renderPcModal=function(){if(M&&M.mods&&M.mods.some(x=>x.on&&x.area))M.area=true;o()}}

/* ---- размещаемые и дроны ---- */
function depBonus(p,m,type){return pcBonuses(p,m).filter(b=>b.id===(type==='Drone'?'drone_hp':'deployable_hp')).reduce((a,b)=>a+(+b.val||0),0)}
function depSources(p,m){
  const out=[];const st=mechStats(p,m);
  const add=(src,d,key)=>{let hp=d.hp==='5+grit'?5+grit(p):+d.hp||0;hp+=depBonus(p,m,d.type);
    out.push({key,src,n:d.n,hp,ev:d.ev==='mech'?st.evasion:d.ev,ed:d.ed==='mech'?st.edef:d.ed,ar:d.ar||0,size:d.size,inst:d.inst||1,type:d.type})};
  mechSystems(p,m).forEach(x=>(x.s.deps||[]).forEach((d,i)=>add(x.s.name,d,x.uid+'~'+i)));
  mechWeapons(p,m).forEach(x=>(x.w.deps||[]).forEach((d,i)=>add(x.w.name,d,x.uid+'~'+i)));
  ((P.F[m.frame].core||{}).deps||[]).forEach((d,i)=>add(P.F[m.frame].core.name,d,'core~'+i));
  return out}
function depsHtml(p,m,c){
  const src=depSources(p,m);if(!src.length)return '';c.deps=c.deps||[];
  const TY={Drone:'Дрон',Deployable:'Размещаемое'};
  return `<h2>Размещаемые и дроны</h2><div class="deps">${src.map(s=>{const inst=c.deps.filter(d=>d.key===s.key);
    return `<div class="isys"><div class="row"><span class="nm">${esc(s.n)}</span><span class="tag-s">${esc(TY[s.type]||s.type)} · Размер ${sizeTxt(s.size)} · ПЗ ${s.hp}${s.ev!=null?' · Уклонение '+s.ev:''}${s.ed!=null?' · Э-Защита '+s.ed:''}${s.ar?' · Броня '+s.ar:''}${s.inst>1?' · ×'+s.inst+' за раз':''}</span>
      <button class="btn sm" data-pa="depadd" data-v="${esc(s.key)}">＋ Разместить</button></div>
      ${inst.map(d=>`<div class="row dep ${d.hp<=0?'spent':''}"><span>${esc(s.n)} #${d.no}</span><button class="pm" data-pa="dephp" data-v="${d.id}" data-d="-1">−</button><b>${d.hp}</b>/<span>${d.max}</span><button class="pm" data-pa="dephp" data-v="${d.id}" data-d="1">+</button>
        <input type="number" class="dep-dmg" id="dd-${d.id}" placeholder="урон"><button class="btn sm" data-pa="depdmg" data-v="${d.id}">Урон</button>${d.hp<=0?'<span class="badge">уничтожен</span>':''}<button class="btn sm" data-pa="depdel" data-v="${d.id}">✕</button></div>`).join('')}</div>`}).join('')}</div>`}

/* ---- резервы в бою ---- */
function resCombatHtml(p){const rs=(p.reserves||[]).filter(r=>P.RS[r.id]&&P.RS[r.id].type!=='Bonus'||r.id==='custom');
  if(!rs.length)return '';
  return `<h2>Резервы на миссию</h2>${rs.map((r,i)=>{const d=P.RS[r.id];const k=p.reserves.indexOf(r);return `<div class="trait ${r.used?'spent':''}"><label style="float:right" class="ntag"><input type="checkbox" data-pa="resused" data-v="${k}" ${r.used?'checked':''}> использован</label><b>${esc(r.id==='custom'?(r.name||'Свой резерв'):d.name)}</b>${resDetail(r)}<div>${pfmt(r.id==='custom'?(r.note||''):d.text)}</div>${r.note&&r.id!=='custom'?`<div class="muted">${esc(r.note)}</div>`:''}</div>`}).join('')}`}
function resDetail(r){const it=r.item&&(P.W[r.item]||P.SY[r.item]);const sk=r.skill&&HASE.find(h=>h[0]===r.skill);
  return (it?` <span class="ntag">${esc(it.name)}${r.id==='reserve_ammo'?' +'+(r.n||1):''}</span>`:'')+(sk?` <span class="ntag">${esc(sk[1])}</span>`:'')}
{const o=viewCombat;viewCombat=function(p){let h=o(p);const m=curM(p),c=pcEnsure(p),st=mechStats(p,m);
  if(st.coreUses>1)h=h.replace(/<label class="[^"]*"><input type="checkbox" data-pa="cp"[^>]*> Мощь Ядра<\/label>/,`<span class="ntag">Мощь Ядра: <button class="pm" data-pa="cpn" data-d="-1">−</button><b>${c.cp}</b>/${st.coreUses}<button class="pm" data-pa="cpn" data-d="1">+</button></span>`);
  const bg=P.BG[p.bgId];
  h=h.replace('<h2>Пилот вне меха</h2>',`${resCombatHtml(p)}<h2>Пилот вне меха</h2>${bg||p.bg?`<div class="muted" style="margin-bottom:6px">Предыстория: <b>${esc(bg?bg.name:p.bg)}</b>${bg?' · триггеры: '+esc(bg.trig):''}</div>`:''}`);
  h=h.replace('<h2>Ядро — ',depsHtml(p,m,c)+'<h2>Ядро — ');
  return h}}

/* ---- лист пилота: предыстория и резервы ---- */
function bgHtml(p){const b=P.BG[p.bgId];
  return `<label class="fl">Предыстория <span style="display:flex;gap:6px"><select data-p7="bgid" style="flex:1"><option value="">— своя / не выбрана —</option>${PCD.backgrounds.map((x,i)=>`<option value="${x.id}" ${x.id===p.bgId?'selected':''}>${i+1}. ${esc(x.name)}</option>`).join('')}</select><button class="btn sm" data-pa="bgroll" title="Бросок 1d20 по таблице предысторий">🎲 1d20</button></span></label>
   ${b?`<details class="bgd" data-po="bg" ${PS.open.bg?'open':''}><summary><b>${esc(b.name)}</b> · <span class="muted">примеры триггеров: ${esc(b.trig)}</span></summary><div class="ptxt">${b.text.split('\n').map(x=>`<p>${esc(x)}</p>`).join('')}</div>
     <div class="row-btns">${b.skills.map(id=>P.SK[id]?`<button class="btn sm" data-pa="bgsk" data-v="${id}" ${p.skills[id]?'disabled':''}>＋ ${esc(P.SK[id].name)}</button>`:'').join('')}</div></details>`
    :`<input class="bg-own" data-pf="bg" value="${esc(p.bg||'')}" placeholder="своя предыстория, напр. Боевой медик">`}
   <div class="muted kw" style="font-size:11px" data-tt="Влияние предыстории" data-tip="${esc(PCD.bginfo||'')}">Влияние предыстории: +1 точн. или +1 неточн. к проверке навыка вне боя (есть в окне броска триггера).</div>`}
function resHtml(p){
  const opt=Object.entries(RS_TYPE).map(([t,l])=>`<optgroup label="${esc(l)}">${PCD.reserves.filter(r=>r.type===t).map(r=>`<option value="${r.id}">${esc(r.name)}</option>`).join('')}</optgroup>`).join('');
  const limItems=m=>[...mechWeapons(p,m).map(x=>x.w),...mechSystems(p,m).map(x=>x.s)].filter(x=>tagVal(x.tags,'tg_limited')!==null);
  const m=curM(p);
  const row=(r,k)=>{const d=P.RS[r.id]||{name:r.name||'Свой резерв',text:'',type:'custom'};let ex='';
    if(r.id==='reserve_ammo')ex=`<select data-p7="resitem" data-i="${k}"><option value="">— Ограниченное оружие/система —</option>${limItems(m).map(x=>`<option value="${x.id}" ${r.item===x.id?'selected':''}>${esc(x.name)}</option>`).join('')}</select><select data-p7="resn" data-i="${k}"><option value="1" ${(r.n||1)==1?'selected':''}>+1</option><option value="2" ${r.n==2?'selected':''}>+2</option></select>`;
    if(r.id==='reserve_rented_gear')ex=`<select data-p7="resitem" data-i="${k}"><option value="">— что арендовано (лицензия не нужна) —</option>${MANU_ORDER.map(mn=>`<optgroup label="${esc(MANU[mn])}">${[...PCD.weapons,...PCD.systems].filter(x=>x.src===mn&&!x.tal&&!/_integrated$/.test(x.id)).map(x=>`<option value="${x.id}" ${r.item===x.id?'selected':''}>${esc(x.name)}</option>`).join('')}</optgroup>`).join('')}</select>`;
    if(r.id==='reserve_systems_reinforcement'||r.id==='reserve_accuracy')ex=`<select data-p7="resskill" data-i="${k}"><option value="">— навык меха —</option>${HASE.map(([h,l])=>`<option value="${h}" ${r.skill===h?'selected':''}>${esc(l)}</option>`).join('')}</select>${r.id==='reserve_accuracy'?'<span class="muted" style="font-size:11px">(или впишите действие в заметку)</span>':''}`;
    return `<div class="resrow ${r.used?'spent':''}"><div class="rh"><b>${esc(r.id==='custom'?'':d.name)}</b>${r.id==='custom'?`<input data-p7="resname" data-i="${k}" value="${esc(r.name||'')}" placeholder="название резерва">`:''}
      <span class="ntag">${esc(RS_TYPE[d.type]||'свой')}</span>${d.type!=='Bonus'?`<label class="ntag"><input type="checkbox" data-pa="resused" data-v="${k}" ${r.used?'checked':''}> использован</label>`:''}<button class="btn sm" data-pa="resdel" data-v="${k}">✕</button></div>
      ${d.text?`<div class="rt">${pfmt(d.text)}</div>`:''}${ex?`<div class="rx">${ex}</div>`:''}<input class="pin" data-p7="resnote" data-i="${k}" value="${esc(r.note||'')}" placeholder="заметка (откуда, условия)"></div>`};
  return `<h2>Резервы <span class="muted" style="font-size:12px;text-transform:none">действуют на следующую миссию, затем исчезают; бонусные очки — навсегда</span></h2>
   <div class="reslist">${(p.reserves||[]).map(row).join('')||'<div class="muted">Резервов нет. Их выдаёт ГМ — обычно за действия отдыха.</div>'}</div>
   <div class="row-btns"><select data-p7="resadd"><option value="">＋ добавить резерв из книги…</option>${opt}</select><button class="btn sm" data-pa="resaddc">＋ Свой резерв</button><span class="muted" style="font-size:12px">🎲 1d20:</span><button class="btn sm" data-pa="resroll" data-t="Resource">Ресурсы</button><button class="btn sm" data-pa="resroll" data-t="Mech">Снаряжение меха</button><button class="btn sm" data-pa="resroll" data-t="Tactical">Тактика</button></div>`}

/* ---- обработчики ---- */
document.addEventListener('click',e=>{
  const el=e.target.closest('[data-pa]');if(!el||el.disabled)return;
  const a=el.dataset.pa,v=el.dataset.v,p=curP();if(!p)return;const m=curM(p);
  switch(a){
    case 'bgroll':{const r=rnd(20),b=PCD.backgrounds[r-1];p.bgId=b.id;PS.open.bg=true;pcLog(p,'Предыстория',`1d20 = ${r}: <b>${esc(b.name)}</b> (примеры триггеров: ${esc(b.trig)})`);pcRender();break}
    case 'bgsk':{const b=budgets(p).sk;if(b.used>=b.max)toast('Бюджет навыков-триггеров превышен — помечено ⚠');p.skills[v]=1;pcRender();break}
    case 'resaddc':p.reserves.push({id:'custom',name:'',note:''});pcRender();break;
    case 'resdel':p.reserves.splice(+v,1);pcRender();break;
    case 'resused':{const r=p.reserves[+v];if(r){r.used=el.checked;pcRender()}break}
    case 'resroll':{const t=el.dataset.t;const list=PCD.reserves.filter(r=>r.type===t);const d=rnd(20),it=list[Math.min(list.length-1,Math.floor((d-1)/2))];
      p.reserves.push({id:it.id,note:'бросок 1d20 = '+d});pcLog(p,'Резерв: '+RS_TYPE[t],`1d20 = ${d}: <b>${esc(it.name)}</b> — добавлен (✕ чтобы убрать)`);toast(`1d20 = ${d}: «${it.name}» добавлен`);pcRender();break}
    case 'plim':protoRollLim(p,m,true);pcRender();break;
    case 'prev':{const k=v,rv=m.proto.rev||(m.proto.rev=[]);const i=rv.indexOf(k);if(i>=0)rv.splice(i,1);else{rv.push(k);if(rv.length>2)rv.shift()}pcRender();break}
    case 'cpn':{const c=pcEnsure(p),st=mechStats(p,m);c.cp=Math.max(0,Math.min(st.coreUses,c.cp+ +el.dataset.d));pcRender();break}
    case 'depadd':{const c=pcEnsure(p);c.deps=c.deps||[];const s=depSources(p,m).find(x=>x.key===v);if(!s)break;for(let i=0;i<s.inst;i++){const no=c.deps.filter(d=>d.key===v).length+1;c.deps.push({id:puid(),key:v,no,hp:s.hp,max:s.hp})}pcLog(p,'Размещено',`${s.n}${s.inst>1?' ×'+s.inst:''} (ПЗ ${s.hp})`);pcRender();break}
    case 'dephp':{const c=pcEnsure(p),d=(c.deps||[]).find(x=>x.id===v);if(d){d.hp=Math.max(0,Math.min(d.max,d.hp+ +el.dataset.d));pcRender()}break}
    case 'depdmg':{const c=pcEnsure(p),d=(c.deps||[]).find(x=>x.id===v);const n=+(document.getElementById('dd-'+v)||{}).value||0;if(!d||!n)break;
      const s=depSources(p,m).find(x=>x.key===d.key)||{};let dmg=n;const parts=[`${n}`];if(s.ar){const a=Math.min(s.ar,dmg);dmg-=a;parts.push('−'+a+' Броня')}
      if(m.frame==='mf_hydra'){dmg=Math.ceil(dmg/2);parts.push('½ «'+trName(P.F.mf_hydra,'Shepherd Field')+'» (если рядом с Гидрой)')}
      d.hp=Math.max(0,d.hp-dmg);pcLog(p,'Урон по '+(s.n||'размещаемому'),`${parts.join(', ')} → ${d.hp}/${d.max}${d.hp<=0?' — уничтожен':''}`,'miss');pcRender();break}
    case 'depdel':{const c=pcEnsure(p);c.deps=(c.deps||[]).filter(x=>x.id!==v);pcRender();break}
  }
});
document.addEventListener('change',e=>{
  const el=e.target,f=el.dataset.p7;if(!f)return;const p=curP();if(!p)return;const m=curM(p);const i=+el.dataset.i;const r=p.reserves[i];
  switch(f){
    case 'bgid':p.bgId=el.value;PS.open.bg=true;break;
    case 'resadd':if(el.value)p.reserves.push({id:el.value,note:''});break;
    case 'resitem':if(r)r.item=el.value;break;
    case 'resn':if(r)r.n=+el.value;break;
    case 'resskill':if(r)r.skill=el.value;break;
    case 'resnote':if(r){r.note=el.value;pcSave();return}break;
    case 'resname':if(r){r.name=el.value;pcSave();return}break;
    case 'ptype':m.proto.type=el.value;break;
    case 'pdt':m.proto.dt=el.value;break;
  }
  pcRender();
});

/* ---- Ходячая Оружейная: Футляр для Боеприпасов ---- */
const armoryRank=p=>Math.min(3,(p.talents&&p.talents.t_walking_armory)||0);
function armorySys(p){const r=armoryRank(p);if(!r)return null;const t=P.T.t_walking_armory;
  const box=(t.ranks[0].text.match(/⟦E⟧([\s\S]*?)⟦Z⟧/)||[,''])[1];
  const more=t.ranks.slice(1,r).map(x=>x.text).join('\n');
  return{id:'ms_walking_armory',name:'Футляр для Боеприпасов',en:'Ammo Case '+'I'.repeat(r),src:'GMS',sp:0,type:'System',tags:[['tg_limited',6],['tg_turn',1]],rutags:'0 СП, Ограниченное 6, 1/ход',
    text:box+(more?'\n'+more:''),tal:['t_walking_armory',r]}}
{const o=mechSystems;mechSystems=function(p,m){const out=o(p,m);const s=armorySys(p);if(s)out.push({s,uid:'tal-armory',fixed:1});return out}}
const AMMO=[['Громадина',1,'explosive',[['tg_knockback',1]],1],['Шок',1,'energy',[],1],['Дозатор Гранат',1,'kinetic',[['tg_arcing']],1],
  ['Хелфаер',2,'energy',[],2],['Джагер',2,'explosive',[['tg_knockback',2]],2],['Подкалиберный',2,'kinetic',[['tg_ap']],2]];
const AMMO_NOTE={'Шок':'соседние с одной целью персонажи получают 1 энерг. ББ (попадание или промах)','Хелфаер':'бонусный урон наносится как горение','Джагер':'один поражённый персонаж: спасбросок Корпуса или Сбит с ног'};
{const o=weaponTalentMods;weaponTalentMods=function(p,w,tags){const out=o(p,w,tags);const r=armoryRank(p);
  if(r&&w.mount==='Main'&&w.type!=='Melee')AMMO.filter(a=>a[4]<=r).forEach(([n,cost,dt,tg])=>out.push({label:`Футляр для Боеприпасов: ${n} (${cost} заряд${cost>1?'а':''})`,on:false,grp:'ammo',ammo:{n,cost,dt,tags:tg}}));
  return out}}
{const o=pcRoll;pcRoll=function(dmgOnly){
  const am=M&&M.mods&&M.mods.find(x=>x.on&&x.ammo);const p=M&&PS.pilots.find(x=>x.id===M.pid);
  if(!am||!p)return o(dmgOnly);
  const c=pcEnsure(p),s=armorySys(p),left=c.uses['tal-armory']??limMax(p,s);
  if(left<am.ammo.cost){alert(`В Футляре для Боеприпасов осталось ${left} заряд(ов), нужно ${am.ammo.cost}.`);return}
  const keep=M.w;M.w={...M.w,dmg:M.w.dmg.map((d,i)=>i===0?{...d,t:am.ammo.dt}:d),tags:[...(M.w.tags||[]),...am.ammo.tags]};
  try{o(dmgOnly)}finally{M.w=keep}
  const free=armoryRank(p)>=3&&M.res&&M.res.crit;
  if(!free)c.uses['tal-armory']=left-am.ammo.cost;
  pcLog(p,'Футляр для Боеприпасов',`${am.ammo.n}: ${free?'критическое попадание — заряды не тратятся (Эффективность)':'−'+am.ammo.cost+' заряд(а), осталось '+c.uses['tal-armory']}${AMMO_NOTE[am.ammo.n]?'. '+AMMO_NOTE[am.ammo.n]:''}.`);
  pcSave();renderMain()}}

/* ---- каскад НЧЛ: при проверке структуры или перегрева мех с меткой ИИ бросает d20, на 1 — каскад ---- */
function pcCascade(p){const m=curM(p),c=p.cb;if(!c||c.dead)return;
  const ai=mechSystems(p,m).filter(x=>tagVal(x.s.tags,'tg_ai')!==null&&tagVal(x.s.tags,'tg_no_cascade')===null);if(!ai.length)return;
  if((p.talents.t_technophile||0)>=3){pcLog(p,'Каскад НЧЛ','Технофил III: ваш ИИ не входит в каскад, если вы сами этого не позволите — бросок не нужен.');return}
  const d=rnd(20);pcLog(p,'Каскад НЧЛ',d===1?`<div class="bd">d20 [<span class="nat1">1</span>]: <b>${esc(ai.map(x=>x.s.name).join(', '))}</b> входит в каскад — берёт управление мехом и становится НИП под контролем ГМ. Стабилизировать можно, если пилот Выключит меха.</div>`:`d20 [${d}]: каскада нет (только на 1).`,d===1?'miss':'')}
{const o=pcStructCheck;pcStructCheck=function(p){o(p);pcCascade(p)}}
{const o=pcStressCheck;pcStressCheck=function(p){o(p);pcCascade(p)}}

/* ---- окна браузера (alert/confirm/prompt) в превью часто заблокированы: свои уведомления ---- */
function toast(msg){let box=document.getElementById('toasts');if(!box){box=document.createElement('div');box.id='toasts';document.body.appendChild(box)}
  const t=document.createElement('div');t.className='toast';t.textContent=msg;box.appendChild(t);setTimeout(()=>t.classList.add('out'),3800);setTimeout(()=>t.remove(),4400)}
window.alert=m=>toast(String(m));
/* двойное нажатие вместо confirm: первое — «нажмите ещё раз», второе в течение 4 с — выполнить */
function armed(el,msg){const now=Date.now();if(el&&el.dataset.armed&&now-+el.dataset.armed<4000){delete el.dataset.armed;el.classList.remove('armed');return true}
  if(el){el.dataset.armed=now;el.classList.add('armed');setTimeout(()=>{if(el.dataset.armed&&Date.now()-+el.dataset.armed>=4000){delete el.dataset.armed;el.classList.remove('armed')}},4100)}
  toast((msg||'Подтвердите')+' — нажмите ещё раз');return false}
{let lastEl=null;document.addEventListener('click',e=>{lastEl=e.target.closest('button,[data-act],[data-pa]')},true);
 window.confirm=m=>armed(lastEl,String(m).replace(/\?$/,''));}

/* ---- v15: перерыв и ремонты по книге (стр. 82) ---- */
function restHtml(p,m,c,st){
  const dead=Object.keys(c.destroyed||{}).filter(k=>c.destroyed[k]);
  const nm=u=>{const x=[...mechWeapons(p,m).map(y=>({u:y.uid,n:y.w.name})),...mechSystems(p,m).map(y=>({u:y.uid,n:y.s.name}))].find(y=>y.u===u);return x?x.n:u};
  const sc=st.cheapStruct?1:2;
  return `<div class="restbox"><div class="rhd"><button class="btn" data-pa="rest">☕ Перерыв (час отдыха)</button>
     <span class="muted">снимает нагрев, горение, статусы и состояния меха; пилот восстанавливает половину ПЗ. Ремонтов: <b>${c.rep}</b>/${st.repcap}</span></div>
    <div class="row-btns">
     <button class="btn sm" data-pa="rrep" data-v="hp" ${c.rep<1||c.dead?'disabled':''}>1 Ремонт: все ПЗ</button>
     <button class="btn sm" data-pa="rrep" data-v="struct" ${c.rep<sc||c.struct>=st.struct||c.dead?'disabled':''}>${sc} Ремонт${sc>1?'а':''}: +1 Структура${sc<2?' («'+((P.F[m.frame].traits.find(t=>(t.bonuses||[]).some(b=>b.id==='cheap_struct'))||{}).name||'Заменяемые Детали')+'»)':''}</button>
     <button class="btn sm" data-pa="rrep" data-v="stress" ${c.rep<2||c.stress>=st.stress||c.dead?'disabled':''}>2 Ремонта: +1 Нагрузка</button>
     ${dead.length?`<select id="rfix">${dead.map(u=>`<option value="${esc(u)}">${esc(nm(u))}</option>`).join('')}</select><button class="btn sm" data-pa="rrep" data-v="fix" ${c.rep<1?'disabled':''}>1 Ремонт: починить</button>`:''}
     ${(p.talents.t_grease_monkey||0)>=1?`<button class="btn sm" data-pa="rrep" data-v="grease" ${c.rep<2?'disabled':''}>2 Ремонта: +1 заряд всем Ограниченным (Чумазый Механик)</button>`:''}
     ${c.dead?`<button class="btn sm red" data-pa="rrep" data-v="wreck">4 Ремонта: восстановить уничтоженный мех</button>`:''}
    </div></div>`}
{const o=viewCombat;viewCombat=function(p){let h=o(p);const m=curM(p),c=pcEnsure(p),st=mechStats(p,m);
  return h.replace('<div class="conds">',restHtml(p,m,c,st)+'<div class="conds">')}}
document.addEventListener('click',e=>{
  const el=e.target.closest('[data-pa]');if(!el||el.disabled)return;const a=el.dataset.pa;if(a!=='rest'&&a!=='rrep')return;
  const p=curP();if(!p)return;const m=curM(p),c=pcEnsure(p),st=mechStats(p,m),ps=pilotStats(p),out=[];
  if(a==='rest'){
    if(c.heat){out.push(`нагрев ${c.heat} → 0`);c.heat=0}if(c.burn){out.push('горение снято');c.burn=0}
    if(c.conds.length){out.push('сняты: '+c.conds.join(', '));c.conds=[]}
    const ph=Math.min(ps.hp,c.phit+Math.ceil(ps.hp/2));if(ph!==c.phit){out.push(`ПЗ пилота ${c.phit} → ${ph}`);c.phit=ph}
    if(m.frame==='mf_balor'&&!c.dead&&c.hp<st.hp){c.hp=st.hp;out.push('Балор: все ПЗ без Ремонта (Самовосстановление)')}
    if(m.frame==='mf_hydra'){(c.deps||[]).forEach(d=>{if(d.key.startsWith('core~'))d.hp=d.max});out.push('дроны ОРОЧИ отремонтированы')}
    if((p.talents.t_brawler||0)>=3){c.counters.ctr_brawler=6;out.push('Кубик Драки → 6')}
    if((p.talents.t_leader||0)>=1){c.counters.ctr_leader=Math.min(6,(c.counters.ctr_leader||0)+1);out.push('+1 кубик Лидерства')}
    pcLog(p,'Перерыв',(out.join(' · ')||'нечего восстанавливать')+'. Ремонты можно тратить кнопками ниже.','hit');pcRender();return}
  const k=el.dataset.v,spend=n=>{c.rep-=n};
  if(k==='hp'){spend(1);c.hp=st.hp;out.push(`все ПЗ (${st.hp})`)}
  if(k==='struct'){const n=st.cheapStruct?1:2;spend(n);c.struct++;out.push(`+1 Структура (${c.struct}/${st.struct}) за ${n}`)}
  if(k==='stress'){spend(2);c.stress++;out.push(`+1 Нагрузка (${c.stress}/${st.stress})`)}
  if(k==='fix'){const u=(document.getElementById('rfix')||{}).value;if(!u)return;spend(1);delete c.destroyed[u];out.push('починено')}
  if(k==='grease'){spend(2);[...mechWeapons(p,m).map(y=>({u:y.uid,i:y.w})),...mechSystems(p,m).map(y=>({u:y.uid,i:y.s}))].forEach(x=>{const lm=limMax(p,x.i);if(lm!==null&&c.uses[x.u]!=null)c.uses[x.u]=Math.min(lm,c.uses[x.u]+1)});out.push('+1 заряд всем Ограниченным')}
  if(k==='wreck'){const own=Math.min(4,c.rep);spend(own);c.dead=false;c.meltdown=0;c.struct=1;c.stress=1;c.hp=st.hp;
    out.push(`мех восстановлен: 1 Структура, 1 Нагрузка, все ПЗ${own<4?` (из своих ${own}, остальные ${4-own} отдали союзники)`:''}; уничтоженное оружие и системы чинятся отдельно`)}
  pcLog(p,'Ремонт на перерыве',out.join(' · ')+` — осталось Ремонтов ${c.rep}`,'hit');pcRender();
});
