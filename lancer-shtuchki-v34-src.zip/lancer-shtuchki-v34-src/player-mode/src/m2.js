/* ---------- боковая панель и вкладки ---------- */
function pcSide(){
  const el=document.getElementById('side');const cp=curP();
  el.innerHTML=`<div class="cgrp" style="display:block">Пилоты</div>
   <div class="clist">${PS.pilots.map(p=>{const m=curM(p),f=m&&P.F[m.frame];return `
     <button class="citem ${cp&&p.id===cp.id?'on':''}" data-pa="psel" data-v="${p.id}">
       <span class="ic">◭</span><span><b>${esc(p.callsign||p.name)}</b><small>УЛ ${p.ll}${f?' · '+esc(f.name):''}${m&&m.name?' «'+esc(m.name)+'»':''}</small></span>
     </button>`}).join('')||'<div class="muted" style="font-size:12px">Пилотов пока нет</div>'}</div>
   <div class="side-btns">
     <button class="btn red" data-pa="pnew">＋ Новый пилот</button>
     ${cp?`<button class="btn" data-pa="pdup">⧉ Копия пилота</button><button class="btn" data-pa="pdel">✕ Удалить пилота</button>`:''}
     <button class="btn" data-pa="pio">⇅ Импорт / экспорт пилотов</button>
   </div>
   <p class="muted" style="font-size:12px;margin-top:14px">Лист пилота как в Comp/Con: уровень, навыки, таланты, лицензии, сборка меха. Во вкладке «Бой» — все броски с автоматическими точностью и уроном; ходы нажимать не нужно.</p>`;
}
function viewPc(){
  const p=curP();
  if(!p)return `<div class="empty">Создайте пилота кнопкой «＋ Новый пилот» слева.<br><br><button class="btn red" data-pa="pnew">＋ Новый пилот</button></div>`;
  const tabs=[['pilot','Пилот'],['mech','Мех'],['combat','Бой'],['bond','Связь']];
  const W=buildWarnings(p,curM(p));
  return `<div class="pc-top">
     <div class="pc-name"><input class="pc-big" data-pf="name" value="${esc(p.name)}" placeholder="Имя пилота">
       <input class="pc-cs" data-pf="callsign" value="${esc(p.callsign)}" placeholder="Позывной"></div>
     <div class="pc-ll"><span class="muted">Уровень лицензии</span><div class="llrow"><button class="pm" data-pa="ll" data-d="-1">−</button><b class="llnum">${p.ll}</b><button class="pm" data-pa="ll" data-d="1">+</button></div>
       <span class="muted kw" data-tt="Стойкость" data-tip="Половина УЛ (округление вверх). Добавляется к ПЗ меха, СП, Спасброску Цели и броскам атаки.">Стойкость ${sgn(grit(p))}</span></div>
   </div>
   <div class="pc-tabs">${tabs.map(([k,l])=>`<button class="tab ${PS.tab===k?'on':''}" data-pa="ptab" data-v="${k}">${l}</button>`).join('')}
     ${W.length?`<span class="badge kw" data-tt="Проверка сборки" data-tip="${esc(W.join('\n'))}">⚠ ${W.length}</span>`:'<span class="ok-badge">✓ сборка по правилам</span>'}</div>
   ${PS.tab==='pilot'?viewPilot(p):PS.tab==='mech'?viewMech(p):PS.tab==='bond'&&typeof bondView==='function'?bondView(p):viewCombat(p)}`;
}
function budgetBar(b){const over=b.used>b.max;return `<span class="bud ${over?'over':b.used===b.max?'full':''} kw" data-tt="${esc(b.label)}" data-tip="${esc(b.hint)}">${esc(b.label)}: <b>${b.used}/${b.max}</b></span>`}
function rankPips(n,max,act,id,extra){
  let h='';for(let i=1;i<=max;i++)h+=`<button class="pip ${i<=n?'on':''}" data-pa="${act}" data-v="${esc(id)}" data-r="${i===n?i-1:i}" ${extra||''} title="${i===n?'снять':'ранг '+i}">${'I'.repeat(i)}</button>`;
  return h;
}

/* ---------- лист пилота ---------- */
function viewPilot(p){
  const b=budgets(p),ps=pilotStats(p);
  const open=k=>PS.open[k]?'open':'';
  const skills=PCD.skills.map(s=>{const r=p.skills[s.id]||0;return `<div class="prow ${r?'sel':''}">
      <div class="pn"><span class="kw" data-tt="${esc(s.name)}" data-tip="${esc(String(s.text||'').replace(/\*\*/g,''))}">${esc(s.name)}</span></div>
      <div class="pp">${rankPips(r,3,'skr',s.id)}<span class="bonus">${r?'+'+r*2:''}</span>${r?`<button class="atkbtn sm" data-pa="rtrig" data-v="${s.id}">d20${sgn(r*2)}</button>`:''}</div></div>`}).join('');
  const custom=p.custom.map((c,i)=>`<div class="prow sel"><div class="pn"><input class="pin" data-pf="custom" data-i="${i}" value="${esc(c.name)}" placeholder="Свой триггер"></div>
      <div class="pp">${rankPips(c.rank,3,'ckr',i)}<span class="bonus">${c.rank?'+'+c.rank*2:''}</span>${c.rank?`<button class="atkbtn sm" data-pa="rtrigc" data-v="${i}">d20${sgn(c.rank*2)}</button>`:''}<button class="btn sm" data-pa="cdel" data-v="${i}">✕</button></div></div>`).join('');
  const hase=HASE.map(([k,l])=>`<div class="hase"><div class="hl kw" data-tt="${l}" data-tip="${esc(HASE_TIP[k])}">${l}</div>
      <div class="hv"><button class="pm" data-pa="hase" data-v="${k}" data-d="-1">−</button><b>${p.hase[k]}</b><button class="pm" data-pa="hase" data-v="${k}" data-d="1">+</button></div></div>`).join('');
  const tal=PCD.talents.map(t=>{const r=p.talents[t.id]||0;const rk=(rr,i)=>`<div class="trank ${i<r?'on':''}"><div class="trn">${'I'.repeat(i+1)} · ${esc(rr.name)}</div><div>${pfmt(rr.text)}</div></div>`;
      const rest=t.ranks.map((rr,i)=>i>=r?rk(rr,i):'').join('');
      return `<div class="talent ${r?'sel':''}"><div class="th"><b>${esc(t.name)}</b><span class="pp">${rankPips(r,3,'tr',t.id)}</span></div>
      ${t.ranks.map((rr,i)=>i<r?rk(rr,i):'').join('')}
      ${rest?`<details data-po="t-${t.id}" ${open('t-'+t.id)}><summary>${r?'следующие ранги':'показать ранги'}</summary>${rest}</details>`:''}</div>`}).join('');
  const lic=MANU_ORDER.filter(mn=>mn!=='GMS'&&mn!=='EXOTIC').map(mn=>`<div class="lman"><div class="lmh" style="border-color:${MANU_COL[mn]}">${esc(MANU_FULL[mn])} <span class="muted">· рангов ${licRanksOf(p,mn)}</span></div>
      ${PCD.frames.filter(f=>f.src===mn&&!f.variant).map(f=>{const r=p.lic[f.id]||0;return `<div class="prow ${r?'sel':''}"><div class="pn"><b>${esc(f.name)}</b> <span class="muted">${esc(f.role)}</span></div>
        <div class="pp">${rankPips(r,3,'lr',f.id)}</div></div>`}).join('')}</div>`).join('');
  const cbs=MANU_ORDER.filter(mn=>mn!=='EXOTIC'||PCD.cbs.some(c=>c.src==='EXOTIC')).map(mn=>`<div class="lman"><div class="lmh" style="border-color:${MANU_COL[mn]}">${esc(MANU_FULL[mn])}</div>
      ${PCD.cbs.filter(c=>c.src===mn).map(c=>{const on=p.cbs.includes(c.id),ok=cbOk(p,c.id);return `<label class="cbrow ${on?'sel':''} ${!on&&!ok.ok?'dis':''}">
        <input type="checkbox" class="chk" data-pa="cb" data-v="${c.id}" ${on?'checked':''}>
        <span><b>${esc(c.name)}</b>${!ok.ok?` <span class="warn">${esc(ok.why)}</span>`:''}<br><span class="cbt">${pfmt(c.text)}</span>${typeof cbHint==='function'?cbHint(p,c.id,on):''}</span></label>`}).join('')}</div>`).join('');
  const gsel=(slot,i,type,val)=>`<select data-pf="gear" data-slot="${slot}" data-i="${i}"><option value="">— нет —</option>${PCD.gear.filter(g=>g.type===type).map(g=>`<option value="${g.id}" ${g.id===val?'selected':''}>${esc(g.name)}</option>`).join('')}</select>`;
  const gdesc=id=>{const g=P.G[id];if(!g)return '';return `<div class="gdesc">${g.dmg&&g.dmg.length?`<span class="wprof"><span class="pill">${esc(rngTxt(g.rng))}</span><span class="pill">${esc(dmgTxt(g.dmg))}</span></span> `:''}${(g.tags||[]).filter(t=>!['tg_pilot_weapon','tg_gear','tg_personal_armor'].includes(t[0])).map(tagChip).join(', ')}<div>${pfmt(g.text||'')}</div>${g.flav&&PCD.gearflav?`<details class="gflav" data-po="gf-${id}" ${open('gf-'+id)}><summary>Особенности (1d6) <button class="btn sm" data-pa="gflav" data-v="${id}">🎲 бросить</button></summary><ol>${PCD.gearflav[g.flav].map(x=>`<li>${esc(x)}</li>`).join('')}</ol></details>`:''}</div>`};
  return `
  <div class="buds">${Object.values(b).map(budgetBar).join('')}</div>
  <div class="pgrid">
   <section class="pbox"><h3>Пилот</h3>
     <div class="mini-core"><span>ПЗ <b>${ps.hp}</b></span><span>Броня <b>${ps.armor}</b></span><span>Уклонение <b>${ps.evasion}</b></span><span>Э-Защита <b>${ps.edef}</b></span><span>Скорость <b>${ps.speed}</b></span><span>Стойкость <b>${sgn(ps.grit)}</b></span></div>
     ${bgHtml(p)}
     <label class="fl">Заметки<textarea class="notes" data-pf="notes">${esc(p.notes)}</textarea></label>
   </section>
   <section class="pbox"><h3>Навыки меха</h3>${haseHtml(p)}
   </section>
  </div>
  <h2>Навыки-триггеры <span class="muted" style="font-size:12px;text-transform:none">клик по рангу — +2/+4/+6</span></h2>
  <div class="plist">${skills}${custom}<button class="btn sm" data-pa="cadd" style="margin-top:6px">＋ Свой триггер</button></div>
  <h2>Таланты</h2>${talentHtml(p)}
  <h2>Лицензии <span class="muted" style="font-size:12px;text-transform:none">ДМС (Эверест и всё ДМС) доступны всегда · нажмите на раму, чтобы увидеть, что даёт каждый ранг</span></h2>${licHtml(p)}
  <h2>Бонусы Ядра</h2><div class="lgrid">${cbs}</div>
  <h2>Снаряжение пилота</h2>
  <div class="pgrid">
   <section class="pbox"><h3>Броня</h3>${gsel('armor',0,'Armor',p.gear.armor)}${gdesc(p.gear.armor)}</section>
   <section class="pbox"><h3>Оружие (до ${pcWSlots(p)})</h3>${[...Array(pcWSlots(p)).keys()].map(i=>`<div style="margin-bottom:6px">${gsel('weapons',i,'Weapon',p.gear.weapons[i])}${gdesc(p.gear.weapons[i])}</div>`).join('')}</section>
   <section class="pbox"><h3>Снаряжение (до ${pcGSlots(p)})</h3>${[...Array(pcGSlots(p)).keys()].map(i=>`<div style="margin-bottom:6px">${gsel('items',i,'Gear',p.gear.items[i])}${gdesc(p.gear.items[i])}</div>`).join('')}</section>
  </div>
  ${resHtml(p)}`;
}
