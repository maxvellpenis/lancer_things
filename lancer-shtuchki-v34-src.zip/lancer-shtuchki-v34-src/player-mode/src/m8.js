/* ---------- v16: импорт пилотов из Comp/Con (файл пилота v2 и «Save Pilot» из нового Comp/Con) ---------- */
const ccId=x=>x==null?null:typeof x==='string'?x:x.id;
const ccTxt=s=>String(s||'').replace(/<br\s*\/?>/gi,'\n').replace(/<[^>]+>/g,'').trim();
const CC_DT={kinetic:'kin',energy:'en',explosive:'exp'};
function isCC(x){return !!x&&typeof x==='object'&&(x.EXPORT_TYPE&&x.data||Array.isArray(x.mechSkills)||(x.level!==undefined&&Array.isArray(x.mechs)&&!x.hase))}
function ccConvert(raw){
  const d=raw.EXPORT_TYPE?raw.data:raw,warn=[];
  if(!d||typeof d!=='object')throw new Error('нет данных пилота');
  const p=newPilot();p.id='cc-'+(d.id||puid());
  p.name=d.name||'';p.callsign=d.callsign||'';p.ll=Math.max(0,Math.min(12,+d.level||0));
  p.notes=[ccTxt(d.notes),d.history&&'История: '+ccTxt(d.history),d.text_appearance&&'Внешность: '+ccTxt(d.text_appearance),d.player_name&&'Игрок: '+d.player_name].filter(Boolean).join('\n\n');
  const bgn=String(d.background||'').trim(),bg=PCD.backgrounds.find(b=>b.en.toLowerCase()===bgn.toLowerCase()||b.name.toLowerCase()===bgn.toLowerCase()||b.id===bgn);
  if(bg)p.bgId=bg.id;else p.bg=ccTxt(bgn);
  p.skills={};p.custom=[];
  (d.skills||[]).forEach(s=>{const r=Math.max(1,Math.min(3,+s.rank||1));if(P.SK[s.id])p.skills[s.id]=r;else p.custom.push({name:ccTxt(s.custom_desc||s.custom_detail||s.name||s.id),rank:r})});
  p.talents={};(d.talents||[]).forEach(t=>{if(P.T[t.id])p.talents[t.id]=Math.max(1,Math.min(3,+t.rank||1));else warn.push(`Талант ${t.id} не из основной книги — пропущен`)});
  const ms=d.mechSkills||[0,0,0,0];p.hase={hull:+ms[0]||0,agi:+ms[1]||0,sys:+ms[2]||0,eng:+ms[3]||0};
  p.cbs=(d.core_bonuses||[]).map(ccId).filter(id=>{if(P.CB[id])return true;warn.push(`Бонус ядра ${id} не из основной книги — пропущен`);return false});
  p.lic={};(d.licenses||[]).forEach(l=>{if(P.F[l.id])p.lic[l.id]=Math.max(1,Math.min(3,+l.rank||1));else warn.push(`Лицензия ${(l.stub&&l.stub.name)||l.id} не из основной книги — пропущена`)});
  p.reserves=(d.reserves||[]).map(r=>P.RS[r.id]&&r.id!=='custom'?{id:r.id,used:!!r.used,note:ccTxt(r.note||'')}:{id:'custom',name:ccTxt(r.resource_name||r.name||r.id||'Резерв'),note:ccTxt(r.resource_note||r.description||r.note||''),used:!!r.used});
  const lo=d.loadout||(d.loadouts||[])[d.active_index||0]||{};
  const gl=(arr,type)=>(arr||[]).map(ccId).filter(id=>{if(!id)return false;if(P.G[id]&&P.G[id].type===type)return true;warn.push(`Снаряжение пилота ${id} не найдено — пропущено`);return false});
  const ar=gl(lo.armor,'Armor');p.gear={armor:ar[0]||'',weapons:gl([...(lo.weapons||[]),...(lo.extendedWeapons||[])],'Weapon'),items:gl([...(lo.gear||[]),...(lo.extendedGear||[])],'Gear')};
  while(p.gear.weapons.length<2)p.gear.weapons.push('');while(p.gear.items.length<3)p.gear.items.push('');
  [...(lo.weapons||[]),...(lo.extendedWeapons||[])].forEach(w=>{if(w&&w.customDamageType&&CC_DT[String(w.customDamageType).toLowerCase()])p.sigDt[w.id]=CC_DT[String(w.customDamageType).toLowerCase()]});
  p.mechs=(d.mechs||[]).filter(cm=>!cm.isDeleted).map(cm=>ccMech(p,cm,warn));
  if(!p.mechs.length)p.mechs=[newMech()];
  const aid=(d.state&&d.state.active_mech_id)||d.favorite_mech;const ai=(d.mechs||[]).filter(cm=>!cm.isDeleted).findIndex(cm=>cm.id===aid);p.mech=ai>=0?ai:0;
  p.cb=null;migratePilot(p);
  return{p,warn};
}
function ccMech(p,cm,warn){
  const ok=!!P.F[cm.frame];const m=newMech(ok?cm.frame:undefined);m.name=cm.name||'';
  if(!ok)warn.push(`«${cm.name}»: рама ${cm.frame} не из основной книги — поставлен Эверест`);
  const f=P.F[m.frame],L=(cm.loadouts||[])[cm.active_loadout_index||0]||cm.loadout||{},nm=cm.name||f.name;
  (L.systems||[]).forEach(s=>{const x=P.SY[s.id];if(x&&!x.tal)m.systems.push(s.id);else if(!x&&!/^ms_(technophile|walking_armory)/.test(s.id))warn.push(`«${nm}»: система ${s.id} не найдена — пропущена`)});
  const cmM=L.mounts||[];
  if(p.cbs.includes('cb_mount_retrofitting'))cmM.forEach((mt,i)=>{if(mt&&mt.mount_type==='Main/Aux'&&f.mounts[i]&&f.mounts[i]!=='Main/Aux')m.retro=i});
  const locked=[];
  const put=(key,cmt)=>{if(!cmt)return;if(cmt.lock)locked.push(key);
    [...(cmt.slots||[]),...(cmt.extra||[])].forEach((s,si)=>{const w=s&&s.weapon;if(!w)return;
      if(!P.W[w.id]){if(!/^mw_prototype/.test(w.id))warn.push(`«${nm}»: оружие ${w.id} не найдено — пропущено`);return}
      (m.load[key]=m.load[key]||[])[si]=w.id;
      const md=ccId(w.mod);if(md){if(P.MO[md])m.mods[key+'#'+si]=md;else warn.push(`«${nm}»: мод ${md} не найден`)}
      const dt=w.customDamageType&&CC_DT[String(w.customDamageType).toLowerCase()];if(dt)m.varDt[w.id]=dt});
    (cmt.bonus_effects||[]).forEach(b=>{const id=ccId(b);if(id==='cb_auto_stabilizing_hardpoints')m.autostab=key;if(id==='cb_overpower_caliber')m.overpower=key+'#0'})};
  cmM.forEach((cmt,i)=>{if(i<f.mounts.length)put('f'+i,cmt)});
  if(p.cbs.includes('cb_improved_armament')&&f.mounts.length<3)put('cbIA',L.improved_armament);
  if(p.cbs.includes('cb_integrated_weapon'))put('cbIW',L.integratedWeapon);
  Object.entries(m.load).forEach(([k,l])=>{const w=P.W[l[0]];if(w&&w.mount==='Superheavy'){const o=locked.find(x=>x!==k)||(mechMounts(p,m).find(x=>x.key!==k&&!x.fixed&&!(m.load[x.key]||[]).some(Boolean))||{}).key;if(o)m.sh[k]=o}});
  const pr=(L.integratedMounts||[]).map(x=>x&&x.weapon).find(w=>w&&/^mw_prototype/.test(w.id));
  if(pr){const dt=pr.customDamageType&&CC_DT[String(pr.customDamageType).toLowerCase()];m.proto=Object.assign(newProto(),dt?{dt}:{})}
  return m;
}
function pcImportText(txt){
  txt=String(txt||'').replace(/^\uFEFF/,'').trim();if(txt[0]!=='{'&&txt[0]!=='['){const i=txt.search(/[\[{]/);if(i>0)txt=txt.slice(i)}
  let d;try{d=JSON.parse(txt)}catch(err){toast('Ошибка JSON: '+err.message);return 0}
  const arr=Array.isArray(d)?d:[d];let n=0,last=null;const warn=[],upd=[];
  arr.forEach(x=>{
    if(isCC(x)){try{const r=ccConvert(x);x=r.p;warn.push(...r.warn.map(w=>(r.p.callsign||r.p.name)+': '+w))}catch(e){warn.push('Не удалось прочитать пилота Comp/Con: '+e.message);return}}
    if(!x||!x.id||!x.mechs)return;migratePilot(x);if(PS.pilots.some(y=>y.id===x.id))upd.push(x.callsign||x.name);PS.pilots=PS.pilots.filter(y=>y.id!==x.id);PS.pilots.push(x);n++;last=x});
  if(!n){toast('Пилотов не найдено');return 0}
  PS.sel=last.id;PS.tab='pilot';M=null;renderModal();pcRender();
  const p=last;pcLog(p,'Импорт',`Импортировано пилотов: ${n}.${warn.length?'<div class="bd">'+warn.map(esc).join('<br>')+'</div>':' Всё перенесено.'}`,warn.length?'':'hit');
  const W=buildWarnings(p,curM(p));
  toast(`${upd.length?'Обновлён уже загруженный пилот: '+upd.join(', ')+' (тот же пилот из Comp/Con)':'Добавлено пилотов: '+n}${warn.length?' · замечаний '+warn.length+' (в журнале)':''}${W.length?' · ⚠ сборка: '+W.length:''}`);
  return n;
}
function pcPickFile(){let inp=document.getElementById('ccfile');if(!inp){inp=document.createElement('input');inp.type='file';inp.id='ccfile';inp.style.display='none';document.body.appendChild(inp);
  inp.addEventListener('change',()=>{const f=inp.files&&inp.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{pcImportText(String(r.result));inp.value=''};r.onerror=()=>toast('Не удалось прочитать файл');r.readAsText(f,'utf-8')})}
  inp.click()}
document.addEventListener('click',e=>{const el=e.target.closest('[data-pa="ccimport"]');if(!el)return;pcPickFile()});
{const o=pcSide;pcSide=function(){o();const b=document.querySelector('#side [data-pa="pio"]');if(b&&!document.querySelector('#side [data-pa="ccimport"]'))b.insertAdjacentHTML('afterend','<button class="btn" data-pa="ccimport" title="Файл пилота из Comp/Con (.json): старый формат и «Save Pilot»">⇪ Импорт из Comp/Con</button>')}}
{const o=pcIO;pcIO=function(){o();const f=document.querySelector('#mbox .mfoot');if(f)f.insertAdjacentHTML('afterbegin','<button class="btn" data-pa="ccimport">📂 Открыть файл (наш или Comp/Con)…</button>');
  const pp=document.querySelector('#mbox p.muted');if(pp)pp.insertAdjacentHTML('beforeend',' Сюда же можно вставить JSON пилота из Comp/Con — он будет переведён автоматически.')}}

/* перетаскивание файла пилота на окно */
document.addEventListener('dragover',e=>{if(S.view==='pc'&&e.dataTransfer&&[...e.dataTransfer.types].includes('Files')){e.preventDefault();document.body.classList.add('dropping')}});
document.addEventListener('dragleave',e=>{if(!e.relatedTarget)document.body.classList.remove('dropping')});
document.addEventListener('drop',e=>{document.body.classList.remove('dropping');if(S.view!=='pc'||!e.dataTransfer||!e.dataTransfer.files.length)return;e.preventDefault();
  [...e.dataTransfer.files].forEach(f=>{const r=new FileReader();r.onload=()=>pcImportText(String(r.result));r.readAsText(f,'utf-8')})});
