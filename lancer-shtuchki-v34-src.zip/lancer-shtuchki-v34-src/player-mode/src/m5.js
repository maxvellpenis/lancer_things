/* ---------- окно броска игрока ---------- */
const BASIC={
  impro:{n:'Импровизированная атака',d:[{t:'kinetic',v:'1d6'}],melee:1,note:'Полное действие: ближняя атака по соседней цели.'},
  ram:{n:'Таран',d:[],melee:1,note:'Быстрое действие: ближняя атака по соседней цели того же Размера или меньше. При попадании цель Сбита с ног, можно отбросить её на 1 пространство.'},
  grapple:{n:'Хватание',d:[],melee:1,note:'Быстрое действие: ближняя атака по соседней цели. При попадании оба Вовлечены, никто не может Ускоряться и реагировать; меньший Обездвижен и тащится за большим.'},
};
function pcTalentHints(p){return talentRanks(p).map(x=>`<span class="ntag kw" data-tt="${esc(x.t.name+' '+'I'.repeat(x.i+1)+': '+x.r.name)}" data-tip="${esc(String(x.r.text).replace(/\*\*/g,'').replace(/\[(\S+?)\]/g,'$1'))}">${esc(x.r.name)}</span>`).join(' ')}
function pcBaseMods(p,kind,o){
  o=o||{};const c=pcEnsure(p),m=curM(p),mods=[];
  if(pHas(c,'Ослаблен'))mods.push({label:'Вы Ослаблены (состояние)',diff:1,on:true,fixed:1});
  if(kind==='atk'||kind==='tech'){
    mods.push({label:'Цель в Захвате — потратить Захват',acc:1,on:false});
    if(kind==='atk')mods.push({label:'Цель Сбита с ног',acc:1,on:false});
    mods.push({label:'Цель Невидима (50% промах до броска)',invis:1,on:false});
    mods.push({label:'Усиление/бонус союзника (+1)',acc:1,on:false});
  }
  if(kind==='atk'&&o.ranged){
    if(o.seeking)mods.push({label:'Искатель: укрытие игнорируется',info:1});
    else{mods.push({label:'Цель в лёгком укрытии',diff:1,on:false,grp:'cover'});mods.push({label:'Цель в твёрдом укрытии',diff:2,on:false,grp:'cover'})}
    mods.push({label:'Вы Вовлечены (дальняя атака)',diff:1,on:pHas(c,'Вовлечён'),fixed:pHas(c,'Вовлечён')?1:0});
  }
  if(kind==='check'){
    mods.push({label:'Подкрепление (Bolster) от союзника',acc:2,on:false});
    const fr=m.frame,sk=o.skill;
    if(sk==='agi'&&(fr==='mf_drake'||fr==='mf_barbarossa'))mods.push({label:'Черта «Медленный»',diff:1,on:true,fixed:1});
    if(sk==='eng'&&fr==='mf_blackbeard')mods.push({label:'Черта «Открытый Реактор»',diff:1,on:true,fixed:1});
  }
  return mods;
}
function pcOpenWeapon(p,uid){
  const m=curM(p),st=mechStats(p,m),c=pcEnsure(p);const x=mechWeapons(p,m).find(y=>y.uid===uid);if(!x)return;
  const w=x.w,warns=[];
  if(c.destroyed[uid])warns.push('Оружие уничтожено.');
  if(c.unloaded[uid])warns.push('Оружие разряжено — Стабилизация (перезарядка) или система, перезаряжающая его.');
  const lm=limMax(p,w);if(lm!==null&&(c.uses[uid]??lm)<=0)warns.push(w.freeAtk?'Зарядов нет — атаковать можно и без них.':'Ограниченное: зарядов нет.');
  if(pHas(c,'Заклинен'))warns.push('Заклинен: оружие использовать нельзя (кроме Хватания, Тарана, Импровизированной атаки).');
  if(pHas(c,'Ошеломлен')||pHas(c,'Выключен'))warns.push('Ошеломлён/Выключен: действовать нельзя.');
  if(w.mount==='Superheavy')warns.push('Сверхтяжёлое: только как Заградительный огонь (полное действие).');
  if(tagVal(w.tags,'tg_ordnance'))warns.push('Артиллерийское: только до перемещения и других действий в этот ход (кроме протоколов).');
  if(x.mt&&x.mt.key==='cbIW')warns.push('Встроенное Оружие: 1/раунд свободным действием, когда стреляете другим оружием.');
  M={kind:'pcroll',pid:p.id,uid,title:w.name,who:pcWho(p),mode:'atk',profiles:w.profiles||null,prof:0,warns,targets:1,bonusDmg:'',target:'',acc:0,diff:0,res:null};
  pcSetProfile(p,x,0);renderModal();
}
function pcSetProfile(p,x,pi){
  const m=curM(p),st=mechStats(p,m),w=x.w,pr=w.profiles?w.profiles[pi]:null;
  const base={...w,dmg:pr&&pr.dmg&&pr.dmg.length?pr.dmg:w.dmg,rng:pr&&pr.rng&&pr.rng.length?pr.rng:w.rng,tags:pr&&pr.tags&&pr.tags.length?pr.tags:w.tags};
  const tags=[...(base.tags||[]),...(x.mod&&x.mod.addTags||[])];
  const dmg=[...(base.dmg||[]),...(x.mod&&x.mod.addDmg||[])];
  const rng=weaponRanges(st,base,x.mod);
  const melee=w.type==='Melee',seeking=!!tagVal(tags,'tg_seeking');
  const mods=pcBaseMods(p,'atk',{ranged:!melee,seeking});
  if(tagVal(tags,'tg_accurate'))mods.unshift({label:'Метка «Точное»',acc:1,on:true,fixed:1});
  if(tagVal(tags,'tg_inaccurate'))mods.unshift({label:'Метка «Неточное»',diff:1,on:true,fixed:1});
  if(m.autostab&&x.key===m.autostab)mods.unshift({label:P.CB.cb_auto_stabilizing_hardpoints.name,acc:1,on:true,fixed:1});
  if(m.overpower===x.uid)mods.push({label:P.CB.cb_overpower_caliber.name+': +1d6 (1/раунд)',addDice:'1d6',on:false});
  if(tagVal(tags,'tg_smart'))mods.push({label:'Умное: атака против Э-Защиты',info:1});
  Object.assign(M,{prof:pi,w:{name:w.name,dmg,rng,tags,id:w.id},mods,melee,bonus:st.attack,bwhy:`Стойкость ${sgn(st.attack)}`,
    tlabel:tagVal(tags,'tg_smart')?'Э-Защита цели':'Уклонение цели',dtSel:m.varDt[w.id]||'kin',area:rng.some(r=>['Blast','Burst','Line','Cone'].includes(r.t)),crit:true});
}
function pcOpenTech(p,title,o){
  o=o||{};const st=mechStats(p,curM(p)),c=pcEnsure(p),warns=[];
  if(pHas(c,'Заклинен'))warns.push('Заклинен: технические действия недоступны.');
  M={kind:'pcroll',pid:p.id,mode:'tech',title:title+' (тех. атака)',who:pcWho(p),bonus:st.tech,bwhy:`Тех. Атака ${sgn(st.tech)}`,acc:0,diff:0,target:'',tlabel:'Э-Защита цели',
     mods:pcBaseMods(p,'tech'),warns,res:null,invade:!!o.invade,uid:o.uid||'',targets:1,w:null};
  renderModal();
}
function pcOpenCheck(p,skill){
  const c=pcEnsure(p),st=mechStats(p,curM(p)),l=HASE.find(h=>h[0]===skill)[1];
  const stn=(pHas(c,'Ошеломлен')||pHas(c,'Выключен'))&&(skill==='hull'||skill==='agi');
  M={kind:'pcroll',pid:p.id,mode:'check',title:'Проверка / спасбросок: '+l,who:pcWho(p),bonus:p.hase[skill],bwhy:`${l} ${sgn(p.hase[skill])}`,acc:0,diff:0,target:'10',
     tlabel:'Сложность (проверка 10, спасбросок — Спас. Цель врага)',mods:pcBaseMods(p,'check',{skill}),warns:[],res:null,autoFail:stn?'Ошеломлён: автопровал Корпуса и Маневренности':''};
  renderModal();
}
function pcOpenTrigger(p,name,rank){
  M={kind:'pcroll',pid:p.id,mode:'check',title:'Навык: '+name,who:p.callsign||p.name,bonus:rank*2,bwhy:`триггер ${sgn(rank*2)}`,acc:0,diff:0,target:'10',
     tlabel:'Сложность (обычно 10)',mods:[{label:'Сложная задача (ГМ)',diff:1,on:false},{label:'Помощь / выгодные условия',acc:1,on:false}],warns:[],res:null};
  renderModal();
}
function pcOpenBasic(p,k){
  const st=mechStats(p,curM(p)),b=BASIC[k],c=pcEnsure(p);
  if(k==='invade'){pcOpenTech(p,'Вторжение',{invade:1});return}
  if(k==='search'){M={kind:'pcroll',pid:p.id,mode:'check',title:'Поиск (спорная проверка Систем)',who:pcWho(p),bonus:p.hase.sys,bwhy:`Системы ${sgn(p.hase.sys)}`,acc:0,diff:0,target:'',
    tlabel:'Результат Маневренности цели',mods:pcBaseMods(p,'check',{skill:'sys'}),warns:[],res:null,note:'Цель в пределах Сенсоров. При успехе она теряет статус Скрыт.'};renderModal();return}
  M={kind:'pcroll',pid:p.id,mode:'atk',title:b.n,who:pcWho(p),bonus:st.attack,bwhy:`Стойкость ${sgn(st.attack)}`,acc:0,diff:0,target:'',tlabel:'Уклонение цели',
     mods:pcBaseMods(p,'atk',{ranged:false}),warns:[],res:null,w:b.d.length?{name:b.n,dmg:b.d,rng:[{t:'Threat',v:1}],tags:[]}:null,note:b.note,melee:1,crit:true,targets:1,bonusDmg:''};
  renderModal();
}
function pcOpenPilotAtk(p,gid){
  const g=P.G[gid],ps=pilotStats(p);
  const mods=[{label:'Цель Сбита с ног',acc:1,on:false},{label:'Цель в лёгком укрытии',diff:1,on:false,grp:'cover'},{label:'Цель в твёрдом укрытии',diff:2,on:false,grp:'cover'}];
  if(tagVal(g.tags,'tg_inaccurate'))mods.unshift({label:'Метка «Неточное»',diff:1,on:true,fixed:1});
  M={kind:'pcroll',pid:p.id,mode:'atk',title:g.name+' (пилот)',who:p.callsign||p.name,bonus:ps.grit,bwhy:`Стойкость ${sgn(ps.grit)}`,acc:0,diff:0,target:'',tlabel:'Уклонение цели',
     mods,warns:tagVal(g.tags,'tg_archaic')?['Архаичное: не может повредить мехам.']:[],res:null,w:{name:g.name,dmg:g.dmg,rng:g.rng,tags:g.tags},dtSel:p.sigDt[gid]||'kin',crit:true,targets:1,bonusDmg:'',pilot:1};
  renderModal();
}
const pModAcc=()=>M.mods.reduce((a,m)=>a+(m.on?(m.acc||0):0),0);
const pModDiff=()=>M.mods.reduce((a,m)=>a+(m.on?(m.diff||0):0),0);
function pWhy(){
  const A=[],D=[];M.mods.forEach(m=>{if(!m.on)return;if(m.acc)A.push(`+${m.acc} — ${m.label}`);if(m.diff)D.push(`+${m.diff} — ${m.label}`)});
  if(M.acc)A.push(`+${M.acc} — вручную`);if(M.diff)D.push(`+${M.diff} — вручную`);
  const net=M.acc+pModAcc()-M.diff-pModDiff();
  return{A,D,tail:net===0?'чистый d20':net>0?`итог: +${net} точн. (наибольший из ${net}d6)`:`итог: +${-net} неточн. (минус наибольший из ${-net}d6)`};
}
function pDmgPreview(){
  if(!M.w||!M.w.dmg||!M.w.dmg.length)return '';
  return M.w.dmg.map(d=>`${d.v} ${PDT_RU[d.t==='variable'?M.dtSel:PDT[d.t]]||''}`).join(' + ');
}
function renderPcModal(){
  const box=document.getElementById('mbox');box.classList.remove('wide');
  const p=PS.pilots.find(x=>x.id===M.pid);const r=M.res;
  const {A,D,tail}=pWhy();
  let res='';
  if(r){
    if(r.invisMiss)res=`<div class="mres"><div class="big">—</div><div class="bd">Невидимость: d6 [${r.die}] — 1–3, атака промахивается</div><div class="vd verdict miss">ПРОМАХ</div>${r.dmgHtml||''}</div>`;
    else{
      const accTxt=r.a.dice.length?` ${r.a.val>=0?'+':'−'} ${Math.abs(r.a.val)} [${r.a.dice.join(',')}]`:'';
      let vd='';
      if(r.autoFail)vd=`<div class="vd verdict miss">АВТОПРОВАЛ — ${esc(r.autoFail)}</div>`;
      else if(M.mode==='check')vd=r.hit===null?'':`<div class="vd verdict ${r.hit?'hit':'miss'}">${r.hit?'УСПЕХ':'ПРОВАЛ'}</div>`;
      else vd=`<div class="vd ${r.hit===true?'verdict hit':r.hit===false?'verdict miss':''}">${r.hit===true?'ПОПАДАНИЕ':r.hit===false?'ПРОМАХ':'Сравните с защитой цели'}${r.crit?' · <span class="nat20">КРИТ (20+)</span>':''}</div>`;
      res=`<div class="mres"><div class="big">${r.total}</div><div class="bd">d20 [<span class="${r.d20===20?'nat20':r.d20===1?'nat1':''}">${r.d20}</span>] ${sgn(M.bonus)}${accTxt}</div>${vd}${r.dmgHtml||''}
        ${r.notes&&r.notes.length?`<div class="notes-l"><b>Не забудьте:</b>${r.notes.map(n=>`<div>• ${esc(n)}</div>`).join('')}</div>`:''}</div>`;
    }
  }
  box.innerHTML=`<h3>${esc(M.title)}</h3><div class="muted">${esc(M.who)}</div>
   ${M.w?`<div class="wprof" style="margin:6px 0">${M.w.rng&&M.w.rng.length?`<span class="pill">${rngHtml(M.w.rng)}</span>`:''}${M.w.dmg&&M.w.dmg.length?`<span class="pill dmg">${esc(pDmgPreview())}</span>`:''}<span class="tag-s">${(M.w.tags||[]).map(tagChip).join(', ')}</span></div>`:''}
   ${M.note?`<div class="info" style="font-weight:400">${esc(M.note)}</div>`:''}
   ${M.warns.map(w=>`<div class="warn">⚠ ${esc(w)}</div>`).join('')}
   ${M.profiles?`<div class="stepper"><span class="lbl">Режим</span><select id="pprof">${M.profiles.map((pr,i)=>`<option value="${i}" ${i===M.prof?'selected':''}>${esc(profRu(pr.name))}</option>`).join('')}</select></div>`:''}
   ${M.w&&M.w.dmg&&M.w.dmg.some(d=>d.t==='variable')?`<div class="stepper"><span class="lbl">Тип урона</span><select id="pdtsel">${['kin','en','exp'].map(k=>`<option value="${k}" ${M.dtSel===k?'selected':''}>${PDT_RU[k]}</option>`).join('')}</select></div>`:''}
   <div class="stepper"><span class="lbl">Бонус</span><span class="num" style="width:auto">${sgn(M.bonus)}</span><span class="muted">${esc(M.bwhy||'')}</span></div>
   <div class="stepper"><span class="lbl acc">Точность</span><button class="pm" data-pa="pm" data-k="acc" data-d="-1">−</button><span class="num acc">${M.acc}</span><button class="pm" data-pa="pm" data-k="acc" data-d="1">+</button>${pModAcc()?`<span class="acc">+${pModAcc()} авто</span>`:''}</div>
   <div class="stepper"><span class="lbl dif">Неточность</span><button class="pm" data-pa="pm" data-k="diff" data-d="-1">−</button><span class="num dif">${M.diff}</span><button class="pm" data-pa="pm" data-k="diff" data-d="1">+</button>${pModDiff()?`<span class="dif">+${pModDiff()} авто</span>`:''}</div>
   ${M.mods.length?`<div class="mods"><div class="h">Модификаторы — серые стоят сами, остальные отметьте</div>${M.mods.map((m,k)=>m.info?`<div class="muted">✓ ${esc(m.label)}</div>`:`<label class="${m.fixed?'fixed':''}"><input type="checkbox" data-pa="pmod" data-k="${k}" ${m.on?'checked':''} ${m.fixed?'disabled':''}> ${esc(m.label)} <span class="${m.acc?'acc':m.diff?'dif':'info'}">${m.acc?'+'+m.acc+' точн.':m.diff?'+'+m.diff+' неточн.':m.addDice?'+'+m.addDice+' урона':''}</span></label>`).join('')}</div>`:''}
   <div class="why"><div class="acc">Точность: ${A.length?A.map(esc).join('; '):'нет'}</div><div class="dif">Неточность: ${D.length?D.map(esc).join('; '):'нет'}</div><div class="muted">${esc(tail)}</div></div>
   ${M.w&&M.w.dmg&&M.w.dmg.length?`<div class="stepper"><span class="lbl kw" data-tt="Бонусный урон" data-tip="Например от талантов: 1d6, 2, 1d3+1. При атаке по нескольким целям бонусный урон делится пополам.">Бонусный урон</span><input class="tgt" id="pbdmg" value="${esc(M.bonusDmg)}" placeholder="напр. 1d6"></div>`:''}
   ${M.area?`<div class="stepper"><span class="lbl">Целей в зоне</span><button class="pm" data-pa="pm" data-k="targets" data-d="-1">−</button><span class="num">${M.targets}</span><button class="pm" data-pa="pm" data-k="targets" data-d="1">+</button></div>`:''}
   <div class="stepper"><span class="lbl">${esc(M.tlabel||'Цель')}</span><input class="tgt" id="ptgt" type="number" value="${esc(M.target)}" placeholder="необяз."></div>
   ${p&&(M.mode==='atk'||M.mode==='tech')?`<div class="muted" style="font-size:12px;margin-top:4px">Ваши таланты (наведите): ${pcTalentHints(p)||'нет'}</div>`:''}
   ${res}
   <div class="mfoot"><button class="btn" data-pa="mclose">Закрыть</button>${M.w&&M.w.dmg&&M.w.dmg.length?`<button class="btn" data-pa="pdmgonly">Только урон</button>`:''}<button class="btn red" data-pa="proll">⚄ ${r?'Бросить ещё':'Бросить'}</button></div>`;
}
function pcSyncInputs(){const t=document.getElementById('ptgt');if(t)M.target=t.value;const b=document.getElementById('pbdmg');if(b)M.bonusDmg=b.value}
function pcDamageRoll(crit,hit){
  // возвращает html и применяет перегрев от Избыточного Урона
  const p=PS.pilots.find(x=>x.id===M.pid),w=M.w;if(!w||!w.dmg||!w.dmg.length)return{html:'',heat:0};
  const ok=!!tagVal(w.tags,'tg_overkill'),rel=+tagVal(w.tags,'tg_reliable')||0,ap=!!tagVal(w.tags,'tg_ap');
  const parts=[];let heat=0,mainTot=0;
  const dtOf=d=>d.t==='variable'?M.dtSel:PDT[d.t]||d.t;
  if(hit===false){return{html:rel?`<div class="vd">Надёжное: <b>${rel}</b> ${PDT_RU[dtOf(w.dmg[0])]}${ap?' ББ':''}</div>`:'',heat:0}}
  w.dmg.forEach((d,i)=>{const r=pcRollExpr(d.v,{crit,overkill:ok});heat+=r.heat;let v=r.v;if(i===0){if(rel&&v<rel){v=rel}mainTot=v}
    parts.push({v,t:dtOf(d),txt:r.txt+(i===0&&rel&&r.v<rel?` → Надёжное ${rel}`:'')})});
  const extras=[M.bonusDmg,...M.mods.filter(m=>m.on&&m.addDice).map(m=>m.addDice)].filter(x=>String(x||'').trim());
  extras.forEach(e=>{const r=pcRollExpr(e,{crit,overkill:ok});heat+=r.heat;let v=r.v;const half=M.targets>1;if(half)v=Math.ceil(v/2);parts.push({v,t:dtOf(w.dmg[0]),txt:`бонус ${r.txt}${half?' ½ (несколько целей)':''}`})});
  const byT={};parts.forEach(x=>byT[x.t]=(byT[x.t]||0)+x.v);
  const html=`<div class="dmgres">${Object.entries(byT).map(([t,v])=>`<span class="dbig">${v}</span> ${esc(PDT_RU[t]||t)}`).join(' + ')}${ap?' <b>ББ</b>':''}${crit?' <span class="nat20">(крит: кубы ×2, взят больший)</span>':''}
    <div class="bd">${parts.map(x=>esc(x.txt)).join(' · ')}${heat?` · Избыточный Урон: +${heat} нагрева вам`:''}</div></div>`;
  return{html,heat,byT};
}
function pcSpend(p){
  // заряды, перезарядка, нагрев (свой) — один раз за бросок
  if(!M.uid)return[];const c=pcEnsure(p),out=[];
  if(M.mode==='atk'&&M.w){
    if(tagVal(M.w.tags,'tg_loading')){c.unloaded[M.uid]=true;out.push('оружие разряжено')}
    const x=mechWeapons(p,curM(p)).find(y=>y.uid===M.uid);
    if(x){const lm=limMax(p,x.w);if(lm!==null&&!x.w.freeAtk){c.uses[M.uid]=Math.max(0,(c.uses[M.uid]??lm)-1);out.push(`заряды ${c.uses[M.uid]}/${lm}`);if(typeof wsLimSpent==='function'){const t=wsLimSpent(p,1);if(t)out.push(t)}}}
    const hv=tagVal(M.w.tags,'tg_heat_self');if(hv){const r=pcRollExpr(String(hv),{});out.push(`Нагрев ${hv}${/d/.test(String(hv))?' ['+r.txt+']':''} (свой)`);pcHeat(p,r.v,M.w.name)}
  }
  return out;
}
function pcRoll(dmgOnly){
  pcSyncInputs();const p=PS.pilots.find(x=>x.id===M.pid);if(!p)return;const c=pcEnsure(p);
  if(dmgOnly){const d=pcDamageRoll(false,true);M.res={total:'—',d20:0,a:{dice:[],val:0},hit:null,dmgHtml:d.html,notes:[]};
    pcLog(p,M.title+' — урон',d.html,'');if(d.heat)pcHeat(p,d.heat,'Избыточный Урон');renderModal();renderMain();pcSave();return}
  const spent=M.mode==='check'?[]:pcSpend(p);
  const notes=[];
  if(M.mode!=='check'&&pHas(c,'Скрыт')){pDelCond(c,'Скрыт');notes.push('Вы больше не Скрыты (атаковали).')}
  if(M.mods.some(m=>m.on&&/Захват/.test(m.label)))notes.push('Захват цели потрачен — снимите его с цели.');
  if(M.mods.some(m=>m.on&&m.invis)){const die=rnd(6);if(die<=3){const rel=M.w?pcDamageRoll(false,false):{html:''};
      M.res={invisMiss:true,die,dmgHtml:rel.html};pcLog(p,M.title,`<div><span class="verdict miss">Промах — Невидимость</span></div><div class="bd">d6 [${die}]: 1–3${spent.length?' · '+esc(spent.join(' · ')):''}</div>${rel.html}`,'miss');renderModal();renderMain();pcSave();return}
    notes.push(`Невидимость: d6 [${die}] — атака проходит`)}
  const acc=M.acc+pModAcc(),diff=M.diff+pModDiff(),d20=rnd(20),a=accRoll(acc,diff),total=d20+M.bonus+a.val;
  let hit=M.target!==''&&!isNaN(+M.target)?total>=+M.target:null;if(M.autoFail)hit=false;
  const crit=M.mode==='atk'&&M.crit&&total>=20&&hit!==false;
  let dmgHtml='';
  if(M.mode==='atk'&&M.w&&M.w.dmg&&M.w.dmg.length){const d=pcDamageRoll(crit,hit===false?false:true);dmgHtml=(hit===null?'<div class="muted" style="font-size:12px">урон, если попали:</div>':'')+d.html;if(d.heat&&hit!==false)pcHeat(p,d.heat,'Избыточный Урон')}
  if(M.invade&&hit!==false)notes.push('Вторжение: цель получает 2 нагрева и эффект (по умолчанию Фрагментированный Сигнал: Ослаблена и Замедлена до конца своего следующего хода).');
  if(M.note&&hit!==false&&M.mode==='atk'&&!M.w)notes.push(M.note);
  if(M.mode==='tech'&&M.uid){const x=mechSystems(p,curM(p)).find(y=>y.uid===M.uid);if(x)notes.push('Эффект — см. текст системы «'+x.s.name+'».')}
  M.res={d20,a,total,hit,crit,dmgHtml,notes,autoFail:M.autoFail};
  const {A,D,tail}=pWhy();
  const accTxt=a.dice.length?` ${a.val>=0?'+':'−'}${Math.abs(a.val)}[${a.dice.join(',')}]`:'';
  const v=M.autoFail?'<span class="verdict miss">Автопровал</span>':M.mode==='check'?(hit===null?'':`<span class="verdict ${hit?'hit':'miss'}">${hit?'Успех':'Провал'}</span>`):(hit===true?'<span class="verdict hit">Попадание</span>':hit===false?'<span class="verdict miss">Промах</span>':'')+(crit?' <span class="nat20">КРИТ</span>':'');
  pcLog(p,M.title,`<div style="display:flex;gap:10px;align-items:center"><span class="tot">${total}</span><span>${v}</span></div>
    <div class="bd">d20[<span class="${d20===20?'nat20':d20===1?'nat1':''}">${d20}</span>] ${sgn(M.bonus)}${accTxt}${M.target!==''?' vs '+esc(M.target):''}${spent.length?' · '+esc(spent.join(' · ')):''}</div>
    <div class="bd">Точн.: ${A.length?esc(A.join('; ')):'нет'} · Неточн.: ${D.length?esc(D.join('; ')):'нет'} → ${esc(tail)}</div>${dmgHtml}${notes.length?`<div class="bd">${esc(notes.join(' '))}</div>`:''}`,hit===true?'hit':hit===false?'miss':'');
  renderModal();renderMain();pcSave();
}

/* ---------- импорт / экспорт ---------- */
function pcIO(){
  M={kind:'io'};const box=document.getElementById('mbox');document.getElementById('modal').classList.add('on');box.classList.add('wide');
  box.innerHTML=`<h3>Пилоты: импорт / экспорт</h3><p class="muted" style="font-size:12px">Скопируйте текст, чтобы перенести пилотов в другой браузер, или вставьте сюда сохранённый и нажмите «Импортировать» (пилоты с тем же id заменятся).</p>
   <textarea class="io" id="pio">${esc(JSON.stringify(PS.pilots.map(p=>({...p,cb:null})),null,1))}</textarea>
   <div class="mfoot"><button class="btn" data-pa="mclose">Закрыть</button><button class="btn red" data-pa="pimport">Импортировать</button></div>`;
}

/* ---------- события ---------- */
function pcRender(){renderSide();renderMain();pcSave()}
document.addEventListener('click',e=>{
  const el=e.target.closest('[data-pa]');if(!el||el.disabled)return;
  const a=el.dataset.pa,v=el.dataset.v,p=curP(),m=p&&curM(p);
  if(el.tagName==='INPUT'&&el.type==='checkbox'&&!['cb','showall','cp','react','destroy','pmod'].includes(a))return;
  switch(a){
    case 'psel':PS.sel=v;pcRender();break;
    case 'pnew':{const np=newPilot();PS.pilots.push(np);PS.sel=np.id;PS.tab='pilot';pcRender();break}
    case 'pdup':{const c=JSON.parse(JSON.stringify(p));c.id=puid();c.name+=' (копия)';c.cb=null;PS.pilots.push(c);PS.sel=c.id;pcRender();break}
    case 'pdel':if(armed(el,`Удалить пилота «${p.callsign||p.name}»?`)){PS.pilots=PS.pilots.filter(x=>x!==p);PS.sel=PS.pilots[0]?PS.pilots[0].id:null;pcRender()}break;
    case 'pio':pcIO();break;
    case 'pimport':pcImportText(document.getElementById('pio').value);break;
    case 'ptab':PS.tab=v;pcRender();document.getElementById('main').scrollTop=0;break;
    case 'll':p.ll=Math.max(0,Math.min(12,p.ll+ +el.dataset.d));pcRender();break;
    case 'skr':{const r=+el.dataset.r;if(r)p.skills[v]=r;else delete p.skills[v];pcRender();break}
    case 'ckr':p.custom[+v].rank=+el.dataset.r;pcRender();break;
    case 'cadd':p.custom.push({name:'',rank:1});pcRender();break;
    case 'cdel':p.custom.splice(+v,1);pcRender();break;
    case 'tr':{const r=+el.dataset.r;if(r)p.talents[v]=r;else delete p.talents[v];pcRender();break}
    case 'lr':{const r=+el.dataset.r;if(r)p.lic[v]=r;else delete p.lic[v];pcRender();break}
    case 'hase':p.hase[v]=Math.max(0,Math.min(6,p.hase[v]+ +el.dataset.d));pcRender();break;
    case 'cb':{const k=p.cbs.indexOf(v);if(k>=0)p.cbs.splice(k,1);else{const o=cbOk(p,v);if(!o.ok)toast('Условие не выполнено: '+o.why+' — бонус взят, сборка помечена ⚠');p.cbs.push(v)}pcRender();break}
    case 'showall':PS.showAll=el.checked;pcRender();break;
    case 'msel':p.mech=+v;pcRender();break;
    case 'madd':p.mechs.push(newMech());p.mech=p.mechs.length-1;pcRender();break;
    case 'mdel':if(armed(el,'Удалить этот мех?')){p.mechs.splice(p.mech||0,1);p.mech=0;pcRender()}break;
    case 'sysdel':{const i=+String(v).match(/^s(\d+)-/)[1];m.systems.splice(i,1);pcRender();break}
    case 'hp':{const c=pcEnsure(p),st=mechStats(p,m);c.hp=Math.max(0,Math.min(st.hp,c.hp+ +el.dataset.d));pcRender();break}
    case 'heat':{const d=+el.dataset.d;if(d>0)pcHeat(p,1,'вручную');else{const c=pcEnsure(p);c.heat=Math.max(0,c.heat-1)}pcRender();break}
    case 'struct':{const c=pcEnsure(p),r=+v;const was=c.struct;c.struct=r;if(r<was)pcStructCheck(p);pcRender();break}
    case 'stress':{const c=pcEnsure(p),r=+v;const was=c.stress;c.stress=r;if(r<was)pcStressCheck(p);pcRender();break}
    case 'cp':{const c=pcEnsure(p);c.cp=el.checked?1:0;pcRender();break}
    case 'react':{const c=pcEnsure(p);c.react=el.checked;pcRender();break}
    case 'destroy':{const c=pcEnsure(p);if(el.checked)c.destroyed[v]=1;else delete c.destroyed[v];pcRender();break}
    case 'use':{const c=pcEnsure(p);const it=[...mechWeapons(p,m).map(x=>({u:x.uid,i:x.w})),...mechSystems(p,m).map(x=>({u:x.uid,i:x.s}))].find(x=>x.u===v);const lm=limMax(p,it.i);
      const nv=Math.max(0,Math.min(lm,(c.uses[v]??lm)+ +el.dataset.d));if(+el.dataset.d<0&&(c.uses[v]??lm)<=0){alert('Зарядов не осталось');break}c.uses[v]=nv;if(+el.dataset.d<0&&typeof wsLimSpent==='function'){const t=wsLimSpent(p,1);if(t)toast(t)}
      if(+el.dataset.d<0)pcLog(p,it.i.name,`Заряд потрачен: осталось ${nv}/${lm}`);pcRender();break}
    case 'reload':{const c=pcEnsure(p);delete c.unloaded[v];pcRender();break}
    case 'sheat':{const s=mechSystems(p,m).find(x=>x.uid===v);const hv=String(tagVal(s.s.tags,'tg_heat_self')||0),r=pcRollExpr(hv,{});pcHeat(p,r.v,s.s.name+(/d/.test(hv)?' ['+r.txt+']':''));pcRender();break}
    case 'stech':{const s=mechSystems(p,m).find(x=>x.uid===v);const ac=(s.s.acts||[]).filter(a=>a.tech||/Tech|Invade/.test(a.act||''))[+el.dataset.i]||{};pcOpenTech(p,ac.name||s.s.name,{uid:v,invade:/Invade/.test(ac.act||'')});break}
    case 'ctr':{const c=pcEnsure(p);const ct=[...talentRanks(p).flatMap(x=>x.r.counters||[]),...(((P.F[(curM(p)||{}).frame]||{}).core||{}).counters||[])].find(x=>x.id===v);c.counters[v]=Math.max(ct.min,Math.min(ct.max,(c.counters[v]??ct.default_value)+ +el.dataset.d));pcRender();break}
    case 'cond':{const c=pcEnsure(p);if(pHas(c,v))pDelCond(c,v);else{pAddCond(c,v);if(v==='Выключен'){c.heat=0;pDelCond(c,'Уязвим');pcLog(p,'Выключен','Нагрев и Уязвимость сброшены; мех Ошеломлён, пока его не включат (полное действие).')}}pcRender();break}
    case 'takedmg':{const n=+document.getElementById('pdmg').value||0;pcDamage(p,n,document.getElementById('pdt').value,{ap:document.getElementById('pap').checked,half:document.getElementById('phalf').checked,area:!!(document.getElementById('parea')||{}).checked});pcRender();break}
    case 'heal':{const n=+document.getElementById('pheal').value||0,c=pcEnsure(p),st=mechStats(p,m);c.hp=Math.min(st.hp,c.hp+n);pcLog(p,'Лечение',`+${n} ПЗ → ${c.hp}/${st.hp}`,'hit');pcRender();break}
    case 'pburn':pcBurnCheck(p);pcRender();break;
    case 'pmelt':pcMeltTick(p);pcRender();break;
    case 'oc':pcOvercharge(p);pcRender();break;
    case 'stab':pcStabilize(p,document.getElementById('pstab').value,document.getElementById('pstab2').value);pcRender();break;
    case 'brace':{const c=pcEnsure(p);
      pcLog(p,'Укрепление (реакция)','Сопротивляемость ко всему урону, горению и нагреву от этой атаки (отметьте «½ Сопр.» при получении урона). До конца вашего следующего хода все другие атаки по вам — с +1 неточностью. До конца следующего хода нельзя реагировать, а в свой следующий ход — только одно быстрое действие: нельзя Перегружаться, обычно перемещаться, совершать полные и свободные действия.');document.getElementById('phalf')&&(document.getElementById('phalf').checked=true);pcSave();renderSide();break}
    case 'fullrep':pcFullRepair(p);pcRender();toast('Полный ремонт выполнен');break;
    case 'core':{const c=pcEnsure(p),f=P.F[m.frame];if(!c.cp)break;c.cp--;pcLog(p,'Ядро: '+(f.core.aname||f.core.name),`<div class="bd">Мощь Ядра потрачена${c.cp?' (осталось '+c.cp+')':''}.</div><div style="font-size:12px">${pfmt(f.core.atext)}</div>`,'hit');pcRender();break}
    case 'downout':{const d=rnd(6);const t=d===6?'6 — пилот отделался лёгким испугом: 1 ПЗ.':d>=2?'2–5 — Выведен из строя (статус) и Ошеломлён, остаётся на 0 ПЗ: без сознания или прижат; в бою Уклонение 5. Любой следующий урон — смерть. (Можно выбрать смерть вместо этого.)':'1 — удача кончилась: пилот погибает.';pcLog(p,'Ранен (0 ПЗ пилота)',`d6 [${d}]: ${t}`,d===1?'miss':'');break}
    case 'chk':pcOpenCheck(p,v);break;
    case 'basic':pcOpenBasic(p,v);break;
    case 'generic':M={kind:'pcroll',pid:p.id,mode:'check',title:'d20 с точностью',who:pcWho(p),bonus:0,bwhy:'',acc:0,diff:0,target:'',tlabel:'Цель',mods:[],warns:[],res:null};renderModal();break;
    case 'atk':pcOpenWeapon(p,v);break;
    case 'gflav':{e.preventDefault();const g=P.G[v],r=rnd(6);pcLog(p,'Особенность: '+g.name,`<div class="bd"><b>1d6 = ${r}</b>: ${esc(PCD.gearflav[g.flav][r-1])}</div>`);break;}
    case 'patk':pcOpenPilotAtk(p,v);break;
    case 'rtrig':pcOpenTrigger(p,P.SK[v].name,p.skills[v]||0);break;
    case 'rtrigc':{const c=p.custom[+v];pcOpenTrigger(p,c.name||'свой триггер',c.rank);break}
    case 'pm':{pcSyncInputs();const k=el.dataset.k;M[k]=Math.max(k==='targets'?1:0,M[k]+ +el.dataset.d);renderModal();break}
    case 'pmod':{pcSyncInputs();const md=M.mods[+el.dataset.k];md.on=el.checked;if(md.on&&md.grp)M.mods.forEach(o=>{if(o!==md&&o.grp===md.grp)o.on=false});renderModal();break}
    case 'proll':pcRoll();break;
    case 'pdmgonly':pcRoll(true);break;
    case 'mclose':M=null;renderModal();break;
    case 'zoom':el.classList.toggle('big');break;
    case 'vit':{const c=pcEnsure(p),st=mechStats(p,m),k=el.dataset.k,vv=+v;
      if(k==='oc'){
        if(vv>c.oc){let tot=0;const parts=[];while(c.oc<vv){const cost=st.oc[Math.min(c.oc,st.oc.length-1)];const r=pcRollExpr(cost,{});tot+=r.v;parts.push(`${cost}${r.txt!==cost?' ['+r.txt+']':''} = ${r.v}`);c.oc++}
          pcLog(p,'Перегрузка',`Любое быстрое действие как свободное. Нагрев: ${parts.join('; ')}. Следующая: ${st.oc[Math.min(c.oc,st.oc.length-1)]}.`);pcHeat(p,tot,'Перегрузка')}
        else{c.oc=vv;pcLog(p,'Перегрузка','Счётчик исправлен вручную: '+vv+' (нагрев не меняется)')}
        pcRender();break}
      const max=k==='struct'?st.struct:st.stress,was=max-c[k];c[k]=max-vv;
      if(vv>was){if(k==='struct')pcStructCheck(p);else pcStressCheck(p)}
      pcRender();break}
  }
});
document.addEventListener('change',e=>{
  const el=e.target,f=el.dataset.pf;
  if(M&&M.kind==='pcroll'){
    if(el.id==='pprof'){pcSyncInputs();const p=PS.pilots.find(x=>x.id===M.pid);const x=mechWeapons(p,curM(p)).find(y=>y.uid===M.uid);if(x){pcSetProfile(p,x,+el.value)}renderModal();return}
    if(el.id==='pdtsel'){pcSyncInputs();M.dtSel=el.value;renderModal();return}
  }
  if(!f)return;const p=curP();if(!p)return;const m=curM(p);
  switch(f){
    case 'name':case 'callsign':case 'bg':case 'notes':p[f]=el.value;pcSave();renderSide();return;
    case 'custom':p.custom[+el.dataset.i].name=el.value;break;
    case 'gear':{const g=p.gear[el.dataset.slot];if(Array.isArray(g))g[+el.dataset.i]=el.value;else p.gear.armor=el.value;break}
    case 'mname':m.name=el.value;break;
    case 'frame':{const nf=P.F[el.value];if(!frameOk(p,nf))toast(`Нет лицензии ${nf.name} ранга II — рама поставлена, сборка помечена ⚠`);m.frame=el.value;m.load={};m.mods={};m.sh={};p.cb=null;break}
    case 'wpn':{const k=el.dataset.k,si=+el.dataset.si;m.load[k]=m.load[k]||[];m.load[k][si]=el.value;delete m.mods[k+'#'+si];
      const w=P.W[el.value];if(si===0&&w&&w.mount==='Main'){const mt=mechMounts(p,m).find(x=>x.key===k);if(mt&&mt.type==='Flex')m.load[k][1]=''}
      if(w&&w.mount==='Superheavy'&&!m.sh[k]){const o=mechMounts(p,m).find(x=>x.key!==k&&!x.fixed);if(o)m.sh[k]=o.key}
      break}
    case 'mod':m.mods[el.dataset.k]=el.value;if(!el.value)delete m.mods[el.dataset.k];break;
    case 'sh':m.sh[el.dataset.k]=el.value;break;
    case 'retro':m.retro=+el.value;break;
    case 'autostab':m.autostab=el.value;break;
    case 'overpower':m.overpower=el.value;break;
    case 'sysadd':if(el.value){const s=P.SY[el.value];if(tagVal(s.tags,'tg_unique')&&m.systems.includes(s.id)){alert('Уникальное: уже установлено');break}m.systems.push(el.value)}break;
    case 'vdt':m.varDt[el.dataset.k]=el.value;break;
    case 'sigdt':p.sigDt[el.dataset.k]=el.value;break;
    case 'cb':{const c=pcEnsure(p);c[el.dataset.k]=Math.max(0,+el.value||0);break}
  }
  pcRender();
});
document.addEventListener('toggle',e=>{const d=e.target;if(d.tagName!=='DETAILS'||!d.dataset.po)return;PS.open[d.dataset.po]=d.open},true);
