/* ============================== v22: Battlegroup — экраны «Флот» ============================== */
const bgGM=()=>!(typeof isPlayer==='function'&&isPlayer());
const bgSrc=p=>srcTag('BG',p);
const bgPip=(on,act,v,title)=>`<button class="tpip ${on?'on':''}" data-bg="${act}" data-v="${esc(v)}" title="${esc(title||'')}">${on?'✓':'○'}</button>`;
function bgNum(act,v,val,min){return `<span class="bg-num"><button class="btn sm" data-bg="${act}" data-v="${esc(v)}" data-d="-1">−</button><b>${val}</b><button class="btn sm" data-bg="${act}" data-v="${esc(v)}" data-d="1">+</button></span>`}
function bgDet(id,sum,body){const o=PS.open&&PS.open['bg-'+id];return `<details class="bg-det" data-po="bg-${esc(id)}" ${o?'open':''}><summary>${sum}</summary><div class="bg-txt">${body}</div></details>`}

/* ---------- карточки каталога ---------- */
function bgHullCard(h,mini){const sl=Object.entries(h.sl).map(([k,n])=>k==='mod'?`${n} модульный (${(h.modk||[]).map(x=>BG_SLOT[x].toLowerCase()).join('/')})`:`${n} ${BG_SLOT[k].toLowerCase()}`).join(', ');
  return `<div class="bg-card cls-${h.cls}">${bgImg(h.id)}<div class="bg-hd"><b>${esc(h.ru)}</b><span class="muted">${esc(h.mf)} ${esc(h.en)} · ${BG_CLS[h.cls]}</span></div>
   <div class="bg-stats"><span>Очки <b>${h.pts}</b></span><span>ПЗ <b>${h.hp}</b></span><span>Защита <b>${h.df}</b></span><span>Слоты: ${esc(sl)}</span>${h.cls==='cv'?`<span>+${h.bonus||3} оч. на эскорты/крылья</span>`:''}</div>
   <div class="bg-txt muted">${esc(h.d)}</div>${h.tr.map(t=>bgAbil(t)).join('')}${mini?'':bgSrc(h.page)}</div>`}
function bgAbil(t,extra){const k=t.k==='tactic'?'Тактика':t.k==='maneuver'?'Манёвр':t.k==='system'?'Система':t.k==='charge'?'Заряд':'Черта';
  return `<div class="bg-ab k-${t.k||'trait'}"><div class="bg-abh"><b>${esc(t.n)}</b><span>${esc(t.tg||k)}${t.lim&&!t.tg?`, Ограничено ${t.lim}`:''}${t.rl&&!t.tg?`, Перезарядка ${t.rl}`:''}${t.rng?` · дальность ${bgRng(t.rng)}`:''}${t.dmg?` · урон ${esc(t.dmg)}`:''}</span>${extra||''}</div><div class="bg-txt">${bgfmt(t.t)}</div></div>`}
function bgWTags(w){const t=w.tg||{};const a=[];if(t.st)a.push('по одной цели');if(t.at)a.push('по площади');if(t.ch)a.push('Заряд '+t.ch);if(t.pl!=null)a.push('Ракета'+(t.pl?(t.pl>0?' +':' −')+Math.abs(t.pl):''));
  if(t.acc)a.push('Точное');if(t.crit)a.push('Критическое');if(t.rel)a.push('Надёжное '+t.rel);if(t.ok)a.push('Избыточное');if(t.rl)a.push('Перезарядка '+t.rl);if(t.lim)a.push('Ограничено '+t.lim);
  if(t.leg)a.push('Легионное');if(t.brd)a.push('Абордаж');if(t.ten)a.push('Упорство '+t.ten);if(t.grey)a.push('Грейвош');if(t.uniq)a.push('Уникальное');return a.join(', ')}
function bgItemCard(it,kind){const sub=(it.sub||[]).map(a=>bgAbil(a)).join('');
  const head=kind==='w'?`${BG_SLOT[it.cat]} · дальность ${bgRng(it.rng)}${it.dmg?' · урон '+esc(it.dmg):''}`:kind==='s'?'Система':kind==='e'?'Эскорт':'Крыло';
  return `<div class="bg-card">${bgImg(it.id)}<div class="bg-hd"><b>${esc(it.ru)}</b><span class="muted">${esc(it.en)}</span></div>
   <div class="bg-stats"><span>Очки <b>${it.pts}</b></span><span>${head}</span>${it.hp?`<span>ПЗ <b>${it.hp}</b></span>`:''}${it.ten?`<span>Упорство <b>${it.ten}</b></span>`:''}</div>
   ${bgWTags(it)?`<div class="bg-tags">${bgTags(bgWTags(it))}</div>`:''}<div class="bg-txt">${bgfmt(it.t)}</div>${sub}${bgSrc(it.page)}</div>`}
function bgNpcCard(x,kind){const hp=Array.isArray(x.hp)?x.hp.join('/'):x.hp;
  return `<div class="bg-card npc">${bgImg(x.id)}<div class="bg-hd"><b>${esc(x.ru)}</b><span class="muted">${esc(x.en)} · ${kind}${x.tags?' · '+esc(x.tags):''}</span></div>
   <div class="bg-stats"><span>ПЗ <b>${esc(String(hp))}</b></span>${x.df!=null?`<span>Защита <b>${x.df>0&&x.tpl?'+':''}${x.df}</b></span>`:''}${x.it?`<span>Перехват <b>${esc(x.it)}</b></span>`:''}</div>
   <div class="bg-txt muted">${esc(x.d)}</div>${bgDet('cat-'+x.id,'Тактика ГМа',bgfmt(x.tac))}${x.items.map(t=>bgAbil(t)).join('')}${bgSrc(x.page)}</div>`}
function bgCatalog(){const c=BGS.cat||'hulls';const tabs=[['hulls','Корпуса'],['weap','Оружие'],['sys','Системы'],['ew','Эскорты и крылья'],['npc','НИП: корабли'],['npce','НИП: эскорты и асы']];
  let body='';
  if(c==='hulls')body=['fr','cv','bb'].map(k=>`<h2>${BG_CLS[k]}ы <span class="muted" style="font-size:13px">(максимум ${BG_CLS_MAX[k]} в группе)</span></h2><div class="bg-grid">${BG.hulls.filter(h=>h.cls===k).map(h=>bgHullCard(h)).join('')}</div>`).join('');
  else if(c==='weap')body=['sh','pr','aux'].map(k=>`<h2>${BG_SLOT[k]}</h2><div class="bg-grid">${BG.weapons.filter(w=>w.cat===k).map(w=>bgItemCard(w,'w')).join('')}</div>`).join('');
  else if(c==='sys')body=`<div class="bg-grid">${BG.systems.map(s=>bgItemCard(s,'s')).join('')}</div>`;
  else if(c==='ew')body=`<h2>Эскорты</h2><div class="bg-grid">${BG.escorts.map(s=>bgItemCard(s,'e')).join('')}</div><h2>Крылья</h2><div class="bg-grid">${BG.wings.map(s=>bgItemCard(s,'g')).join('')}</div>
    <h2>Улучшения эскадрильи аса (выберите три)</h2><div class="bg-grid">${BG.aceUps.map(a=>`<div class="bg-card"><div class="bg-hd"><b>${esc(a.ru)}</b><span class="muted">${esc(a.en)}</span></div><div class="bg-txt">${bgfmt(a.t)}</div>${bgSrc(118)}</div>`).join('')}</div>`;
  else if(c==='npc')body=`<div class="bg-grid">${BG.npcCap.map(x=>bgNpcCard(x,'капитальный корабль')).join('')}</div>`;
  else body=`<h2>Эскорты</h2><div class="bg-grid">${BG.npcEsc.map(x=>bgNpcCard(x,'эскорт')).join('')}</div><h2>Асы</h2><div class="bg-grid">${BG.npcAce.map(x=>bgNpcCard(x,'ас (крыло)')).join('')}</div>`;
  return `<div class="pc-tabs">${tabs.filter(t=>bgGM()||!t[0].startsWith('npc')).map(t=>`<button class="btn ${c===t[0]?'red':''}" data-bg="cat" data-v="${t[0]}">${t[1]}</button>`).join('')}</div>${body}`}

/* ---------- сборка ---------- */
function bgOpts(list,cur,cost){return `<option value="">— пусто —</option>`+list.map(x=>`<option value="${esc(x.id)}" ${x.id===cur?'selected':''}>${esc(x.ru)} (${cost?cost(x):x.pts} оч.)</option>`).join('')}
function bgSlotList(s,k){if(k==='sh'||k==='pr'||k==='aux')return BG.weapons.filter(w=>w.cat===k);if(k==='sys')return BG.systems;if(k==='esc')return BG.escorts;return BG.wings}
function bgShipEd(g,s,i){const h=BH[s.hull];const n=bgSlots(s);const items=bgShipItems(s);
  const slotRows=['sh','pr','aux','sys','esc','wing'].filter(k=>n[k]).map(k=>{const a=s.eq[k]||[];let r='';
    for(let j=0;j<n[k];j++){const id=a[j]||'';const it=id&&bgItem(k,id);
      r+=`<div class="bg-slot"><span class="bg-sk">${BG_SLOT[k]}</span><select data-bgf="slot" data-v="${s.id}|${k}|${j}">${bgOpts(bgSlotList(s,k),id,x=>bgItemCost(s,k,x))}</select>
        ${it?bgDet(`eq-${s.id}-${k}-${j}`,`<span class="muted">${esc(k==='sh'||k==='pr'||k==='aux'?`${bgRng(it.rng)}${it.dmg?' · '+it.dmg:''} · `+bgWTags(it):bgWTags(it)||'подробнее')}</span>`,bgfmt(it.t)+(it.sub||[]).map(a=>bgAbil(a)).join('')):''}</div>`}
    return r}).join('');
  const mk=bgModKinds(s);const mod=s.eq.mod||{};
  const modRow=mk.length?`<div class="bg-slot"><span class="bg-sk">Модульный</span><select data-bgf="modk" data-v="${s.id}">${mk.map(k=>`<option value="${k}" ${mod.k===k?'selected':''}>${BG_SLOT[k]}</option>`).join('')}</select>
    <select data-bgf="modid" data-v="${s.id}">${bgOpts(bgSlotList(s,mod.k||mk[0]).filter(x=>s.hull!=='minokawa'||(x.tg&&x.tg.brd)),mod.id)}</select></div>`:'';
  const hasAce=items.some(x=>x.id==='ace');
  const aceRow=hasAce?`<div class="bg-slot"><span class="bg-sk">Ас: улучшения</span>${[0,1,2].map(j=>`<select data-bgf="ace" data-v="${s.id}|${j}"><option value="">—</option>${BG.aceUps.map(a=>`<option value="${a.id}" ${(s.ace||[])[j]===a.id?'selected':''}>${esc(a.ru)}</option>`).join('')}</select>`).join('')}</div>`:'';
  return `<div class="bg-ship cls-${h.cls}">${bgImg(h.id,'bg-shimg')}<div class="bg-shd">
    <button class="tpip ${s.flag?'on':''}" data-bg="flag" data-v="${s.id}" title="Флагман: +3 ПЗ, +1d6 Перехват, +1 слот системы">★</button>
    <b>${esc(h.ru)}</b><span class="muted">${BG_CLS[h.cls]} · ${esc(h.mf)} ${esc(h.en)}</span>
    <input class="bg-in" data-bgf="sname" data-v="${s.id}" value="${esc(s.name)}" placeholder="Имя корабля">
    <span class="bg-stats"><span>ПЗ <b>${bgHp(s)}</b></span><span>Защита <b>${h.df}</b></span><span>${h.pts} оч.</span></span>
    <span class="bg-sp"></span><button class="btn sm" data-bg="shipup" data-v="${s.id}" title="Выше">↑</button><button class="btn sm" data-bg="shipdel" data-v="${s.id}">✕</button></div>
    ${bgDet('hull-'+s.id,`Черты корпуса: ${h.tr.map(t=>esc(t.n)).join(', ')}`,h.tr.map(t=>bgAbil(t)).join(''))}
    <div class="bg-slots">${slotRows}${modRow}${aceRow}</div></div>`}
function bgBuild(){const g=bgGroup(BGS.cur)||BGS.groups[0];
  if(!g)return `<div class="bg-empty"><h2>Боевая группа</h2><p>Соберите свою группу на <b>20 очков</b>: минимум 2 капитальных корабля (до 3 фрегатов, 2 авианосцев и 1 линкора), один из них — флагман. Затем добавьте её в бой во вкладке «Бой».</p><button class="btn red" data-bg="gnew">＋ Создать группу</button> <label class="btn">⇧ Импорт группы (JSON)<input type="file" accept=".json,application/json" data-bgf="import" hidden></label></div>`;
  BGS.cur=g.id;const c=bgCost(g);const w=bgWarn(g);
  const hullOpts=['fr','cv','bb'].map(k=>`<optgroup label="${BG_CLS[k]}ы">${BG.hulls.filter(h=>h.cls===k).map(h=>`<option value="${h.id}">${esc(h.ru)} — ${h.pts} оч., ПЗ ${h.hp}, Защ ${h.df}</option>`).join('')}</optgroup>`).join('');
  return `<div class="bg-gtop"><input class="pc-big" data-bgf="gname" value="${esc(g.name)}" placeholder="Название группы">
    <div class="bg-row"><label>Командир <input class="bg-in" data-bgf="gcmdr" value="${esc(g.cmdr)}"></label><label class="bg-grow">Черты (2 положительные, 1 отрицательная) <input class="bg-in" data-bgf="gtraits" value="${esc(g.traits)}"></label></div></div>
   <div class="buds"><span class="bud ${c.left<0?'over':c.left===0?'full':''}">Очки: <b>${c.main}</b> / 20</span>${c.bonusMax?`<span class="bud">Бонусные очки авианосцев: ${c.bonusUsed} / ${c.bonusMax}</span>`:''}<span class="bud">Корабли: ${g.ships.length}</span>${c.left>0?`<span class="bud">Остаток → банк Точности: ${bgBanked(g)}</span>`:''}</div>
   ${w.length?`<div class="bg-warn">${w.map(x=>`<div>⚠ ${esc(x)}</div>`).join('')}</div>`:g.ships.length?'<div class="ok-badge">✓ Группа собрана по правилам</div>':''}
   ${g.ships.map((s,i)=>bgShipEd(g,s,i)).join('')}
   <div class="bg-pick"><h3>＋ Добавить корабль <span class="muted bg-small">— нажмите на корабль</span></h3>${['fr','cv','bb'].map(k=>`<div class="bg-pk-cls">${BG_CLS[k]}ы <span class="muted">(до ${BG_CLS_MAX[k]})</span></div><div class="bg-tiles">${BG.hulls.filter(h=>h.cls===k).map(h=>`<button class="bg-tile cls-${k}" data-bg="shipaddh" data-v="${h.id}" title="${esc(h.d)}">${bgImg(h.id,'bg-timg')}<b>${esc(h.ru)}</b><small>${h.pts} оч. · ПЗ ${h.hp} · Защ ${h.df}</small><small class="muted">${esc(h.d)}</small></button>`).join('')}</div>`).join('')}</div>
   <label class="bg-notes">Заметки<textarea data-bgf="gnotes" rows="3">${esc(g.notes)}</textarea></label>
   <div class="row-btns"><button class="btn" data-bg="gexport">⇩ Экспорт группы</button><label class="btn">⇧ Импорт группы<input type="file" accept=".json,application/json" data-bgf="import" hidden></label><button class="btn" data-bg="gcopy">⧉ Копия</button><button class="btn" data-bg="gdel">Удалить группу</button></div>`}

/* ---------- бой ---------- */
function bgPhaseBar(){const b=BB();
  const hint=!b.started?'Добавьте группы игроков и НИП, затем нажмите «Начать бой» — сразу пройдёт первая логистика.':[
   'Логистика: счётчики уже сняты. Используйте способности фазы логистики (системы, черты), затем — к фазе удара.',
   'Удар: оружие с Зарядом на 0 стреляет («Огонь») или держит выстрел; ракеты на 0 попадают — нажмите «Разрешить попадания». Перехват бросается один раз на группу. При переходе дальше — урон Грейвоша, Захваты снимаются.',
   'Действия: поочерёдно (первым — игрок): 1 манёвр + 1 тактика или 2 тактики. В конце своего хода группа бросает отражение абордажа.',
   'Абордаж: отряды получают команды и бросают d20 против 8. Затем — новый раунд.'][b.phase];
  return `<div class="bg-phase"><div class="bg-round">Раунд <b>${b.started?b.round:'—'}</b></div>
    ${bgPhaseNames.map((p,i)=>`<span class="bg-ph ${b.started&&b.phase===i?'on':''}">${i+1}. ${p}</span>`).join('')}
    <button class="btn red" data-bg="next">${b.started?'Следующая фаза ▶':'▶ Начать бой'}</button>${b.started&&bgGM()?'<button class="btn sm" data-bg="breset">Сбросить бой</button>':''}
    <div class="bg-hint">${esc(hint)}${b.started&&b.round>=5?' · <b>Переломный момент</b>: в начале раунда можно уйти выбросом.':''}${b.started&&b.round>=5?` Гир: ${b.round>=8?'все в упор, отступать нельзя':b.round===7?'не дальше Сближения':b.round===6?'не дальше Дальней':'пока без изменений'}.`:''}</div></div>`}
function bgSetup(){const a=BGS.add||{};
  const pc=`<div class="bg-addrow"><b>Группа игрока:</b><select data-bgf="add.g">${BGS.groups.map(g=>`<option value="${g.id}" ${a.g===g.id?'selected':''}>${esc(g.name)}</option>`).join('')||'<option value="">— сначала соберите группу —</option>'}</select>
    <select data-bgf="add.band">${[[5,'Осторожная — Предельная'],[4,'Номинальная — Дальняя'],[3,'Агрессивная — Прицельная'],[2,'Сближение'],[1,'Ближняя'],[0,'В упор']].map(([v,t])=>`<option value="${v}" ${String(a.band??4)===String(v)?'selected':''}>${t}</option>`).join('')}</select>
    <button class="btn" data-bg="addpc">＋ В бой</button></div>`;
  const npc=bgGM()?`<div class="bg-addrow"><b>НИП-группа:</b><select data-bgf="add.cap">${BG.npcCap.map(x=>`<option value="${x.id}" ${a.cap===x.id?'selected':''}>${esc(x.ru)} (ПЗ ${x.hp}, Защ ${x.df})</option>`).join('')}</select>
    ${[0,1,2].map(j=>`<select data-bgf="add.e${j}"><option value="">— эскорт ${j+1} —</option>${BG.npcEsc.map(x=>`<option value="${x.id}" ${a['e'+j]===x.id?'selected':''}>${esc(x.ru)}${x.tags?' ('+esc(x.tags)+')':''}</option>`).join('')}</select>`).join('')}
    <select data-bgf="add.ace"><option value="">— без аса —</option>${BG.npcAce.map(x=>`<option value="${x.id}" ${a.ace===x.id?'selected':''}>${esc(x.ru)}</option>`).join('')}</select>
    <input class="bg-in" data-bgf="add.name" value="${esc(a.name||'')}" placeholder="Имя группы (необязательно)"><button class="btn" data-bg="addnpc">＋ В бой</button>
    <div class="muted bg-small">1 эскорт — проще, 2 — по умолчанию, 3 — серьёзная угроза. Шаблон — только один на корабль; уникальный — один на группу.</div></div>`:'';
  return bgDet('setup','Добавить участников',pc+npc)}
function bgTargetOpts(a){const me=bgU(a.from);const side=me&&me.kind==='pc'?'npc':'pc';
  return BB().units.filter(u=>u.kind===side).map(u=>`<optgroup label="${esc(u.name)}${u.kind==='pc'?' · '+bgBand(u.band):''}">${u.ships.filter(s=>!s.dead&&!s.wing).map(s=>`<option value="${u.uid}|${s.sid}" ${a.tgt===u.uid&&a.sid===s.sid?'selected':''}>${esc(s.name)} — ПЗ ${s.hp}/${s.max}, Защ ${bgDef(u,s)}${s.lock?' · Захват':''}</option>`).join('')}</optgroup>`).join('')}
function bgUnitOpts(a){const me=bgU(a.from);const side=me&&me.kind==='pc'?'npc':'pc';return BB().units.filter(u=>u.kind===side).map(u=>`<option value="${u.uid}" ${a.tgt===u.uid?'selected':''}>${esc(u.name)}${u.kind==='pc'?' · '+bgBand(u.band):''}</option>`).join('')}
function bgAtkPanel(){const a=BGS.atk;if(!a)return'';const me=bgU(a.from);if(!me){BGS.atk=null;return''}
  const tu=bgU(a.tgt);const band=me.kind==='pc'?me.band:(tu?tu.band:3);const rngOk=bgInRng(a.rng,band);
  let body='';
  if(a.mode==='atk'){const M=bgAtkMods(a);const ts=tu&&bgShip(tu,a.sid);
    body=`<div class="bg-row"><label>Цель <select data-bgf="atk.tgt">${bgTargetOpts(a)}</select></label>${ts?`<span>Защита цели: <b>${bgDef(tu,ts)}</b></span>`:''}</div>
     <div class="bg-mods">${M.map((m,i)=>`<label><input type="checkbox" data-bgf="atk.off" data-v="${i}" ${(a.off||{})[i]?'':'checked'}> ${esc(m[0])} (${m[1]?'Точность +'+m[1]:'Сложность +'+m[2]})</label>`).join('')}
      ${ts&&ts.lock?`<label><input type="checkbox" data-bgf="atk.lock" ${a.lock?'checked':''}> Израсходовать Захват цели (Точность +1)</label>`:''}</div>
     <div class="bg-row">Точность ${bgNum('atkn','acc',+a.acc||0)} Сложность ${bgNum('atkn','dif',+a.dif||0)} Плоский бонус ${bgNum('atkn','flat',+a.flat||0)}${me.kind==='pc'&&me.acc?` <button class="btn sm" data-bg="bank" data-v="${me.uid}">Потратить банк Точности (${me.acc})</button>`:''}</div>
     <div class="bg-row"><button class="btn red" data-bg="atkroll">🎲 Бросить атаку</button>${a.res?`<span class="bg-res ${a.res.hit?'hit':'miss'}">${a.res.tot} против ${a.res.def}: ${a.res.hit?(a.res.crit?'КРИТ':'попадание'):'промах'}${a.res.dmg?' · урон '+a.res.dmg:''}</span>${a.res.dmg&&!a.res.applied?`<button class="btn" data-bg="atkapply">Применить урон к цели</button>`:''}${a.res.applied?'<span class="ok-badge">урон применён</span>':''}`:''}</div>`}
  else if(a.mode==='launch'){body=`<div class="bg-row"><label>Цель ${a.at?`<select data-bgf="atk.unit">${bgUnitOpts(a)}</select>`:`<select data-bgf="atk.tgt">${bgTargetOpts(a)}</select>`}</label>
     <span>Счётчиков полёта: <b>${band===0?'сразу (в упор)':bgFc(band,a.pl)}</b></span></div>
     <div class="bg-row"><button class="btn red" data-bg="launch">🚀 Запустить</button></div>`}
  else if(a.mode==='area'){body=`<div class="bg-row"><label>Группа-цель <select data-bgf="atk.unit">${bgUnitOpts(a)}</select></label></div><div class="bg-row"><button class="btn red" data-bg="area">💥 Ударить по площади</button></div>`}
  return `<div class="bg-atk"><div class="bg-hd"><b>${esc(a.name)}</b><span class="muted bg-grow">${esc(me.name)} · ${esc(a.tgs||'')}${a.rng?' · дальность '+bgRng(a.rng):''}${a.dmg?' · урон '+esc(a.dmg):''}</span><button class="btn sm" data-bg="atkclose" title="Закрыть">✕</button></div>
    ${!rngOk?`<div class="bg-warn">⚠ Диапазон ${bgBand(band)} вне дальности ${bgRng(a.rng)} — по правилам атака невозможна.</div>`:''}${a.extra?`<div class="bg-txt muted">${bgfmt(a.extra)}</div>`:''}${body}</div>`}
function bgPayloads(){const b=BB();if(!b.pls.length)return'';
  const by={};b.pls.forEach(p=>(by[p.tgt]=by[p.tgt]||[]).push(p));
  return `<div class="bg-box"><h3>Ракеты в полёте</h3>${Object.entries(by).map(([t,arr])=>{const tu=bgU(t);const ready=arr.filter(p=>p.fc===0).length;
    return `<div class="bg-plg"><b>→ ${esc(tu?tu.name:'?')}</b>${ready?` <button class="btn sm red" data-bg="impact" data-v="${t}">Разрешить попадания (${ready})</button>`:''}
     ${arr.map(p=>{const f=bgU(p.from);return `<div class="bg-pl"><span class="bg-fc ${p.fc?'':'zero'}">${p.fc}</span><span>${esc(p.name)} <span class="muted">от ${esc(f?f.name:'?')} · ${p.at?'по площади':esc((bgShip(tu,p.sid)||{}).name||'')} · ${esc(p.dmg)}</span></span>
       <span class="bg-sp"></span><button class="btn sm" data-bg="fc" data-v="${p.id}" data-d="-1" title="Снять счётчик">−1</button><button class="btn sm" data-bg="fc" data-v="${p.id}" data-d="1" title="Добавить счётчик">+1</button><button class="btn sm" data-bg="pldel" data-v="${p.id}" title="Подорвать / уничтожить">✕</button></div>`}).join('')}</div>`}).join('')}</div>`}
function bgBoards(){const b=BB();if(!b.brd.length)return'';
  return `<div class="bg-box"><h3>Абордаж</h3>${b.brd.map(r=>{const tu=bgU(r.tgt),f=bgU(r.from);const s=tu&&bgShip(tu,r.sid);
    const cmds=f&&f.kind==='pc'?['Саботаж управления огнём','Обрыв связи','Штурм БИЦ','Особая команда отряда','Особое действие ситрепа']:['Команда из профиля НИП','Особое действие ситрепа'];
    return `<div class="bg-pl"><span>${esc(r.name)} <span class="muted">(${esc(f?f.name:'?')}) на «${esc(s?s.name:'?')}» · Упорство ${r.ten||'—'} · успех на ${tu?bgBoardThr(tu,r.sid):8}+</span></span>
     <select data-bgf="bcmd" data-v="${r.id}"><option value="">— команда —</option>${cmds.map(c=>`<option ${r.cmd===c?'selected':''}>${esc(c)}</option>`).join('')}</select>
     <button class="btn sm red" data-bg="broll" data-v="${r.id}">🎲 d20</button>${r.last?`<span class="bg-res ${r.last==='успех'?'hit':'miss'}">${r.last}</span>`:''}
     <span class="bg-sp"></span><button class="btn sm" data-bg="brepel" data-v="${r.id}" title="Бросок отражения в конце хода защитника">Отразить</button><button class="btn sm" data-bg="brecall" data-v="${r.id}">Отозвать</button></div>`}).join('')}
    <div class="muted bg-small">Стандартные команды: Саботаж — Сложность +2 на атаки по одной цели; Обрыв связи — без тактик; Штурм БИЦ — не может двигать группы игроков (до конца следующего хода цели). Зачистка манёвром выбивает всех сразу (✕ «Отозвать»).</div></div>`}
function bgShipRow(u,s){const pct=s.max?Math.max(0,Math.min(100,s.hp/s.max*100)):0;const def=bgDef(u,s);const brd=BB().brd.filter(r=>r.tgt===u.uid&&r.sid===s.sid);const k=s.dead?bgKillTxt(s.hp):null;
  const v=u.uid+'|'+s.sid;
  const imgId=s.hull||s.arch||s.esc||'';
  return `<div class="bg-sh ${s.dead?'dead':''}">${imgId&&BGART[imgId]?bgImg(imgId,'bg-thumb'):''}<div class="bg-shn">${s.flag?'<span title="Флагман">★</span> ':''}<b>${esc(s.name)}</b>${s.hull&&s.name!==BH[s.hull].ru?`<span class="muted"> ${esc(BH[s.hull].ru)}</span>`:''}${s.esc?'<span class="muted"> эскорт</span>':''}${s.wing?'<span class="muted"> ас</span>':''}</div>
   <div class="bg-hp"><div class="bg-bar"><i style="width:${pct}%"></i></div><span><b>${s.hp}</b>/${s.max} ПЗ${s.os?` · <span class="bg-os">+${s.os} Сверхщит</span>`:''}</span></div>
   ${s.wing?'':`<span class="bg-def" title="Защита (с учётом бонусов)">Защ <b>${def}</b>${+s.dfx?` <small class="muted">(${s.dfx>0?'+':''}${s.dfx})</small>`:''} <button class="btn sm bg-tiny" data-bg="dfx" data-v="${esc(v)}" data-d="-1" title="Защита −1 (временный эффект)">−</button><button class="btn sm bg-tiny" data-bg="dfx" data-v="${esc(v)}" data-d="1" title="Защита +1 (временный эффект)">+</button></span>`}
   ${s.wing?'':`<button class="tpip ${s.lock?'on':''}" data-bg="lock" data-v="${v}" title="Захват">🎯 Захват</button><span title="Счётчики Грейвоша">☣ ${bgNum('grey',v,s.grey||0)}</span>`}
   <span class="bg-dmg"><input type="number" min="0" class="bg-n" data-bgf="dmgv" data-v="${v}" value="${esc(String(BGS.dmgv&&BGS.dmgv[v]||''))}" placeholder="0"><button class="btn sm red" data-bg="dmg" data-v="${v}">Урон</button><button class="btn sm" data-bg="dmgos" data-v="${v}" title="Урон в обход Сверхщита">Урон⇣</button><button class="btn sm" data-bg="heal" data-v="${v}">Ремонт</button><button class="btn sm" data-bg="os" data-v="${v}" title="Установить Сверхщит (наибольшее значение)">Сверхщит</button></span>
   ${k?`<div class="bg-kill">✖ ${esc(k[0])}: ${esc(k[1])}</div>`:''}
   ${brd.length?`<div class="bg-brd">На борту абордажники: ${brd.map(r=>`${esc(r.name)} (Упорство ${r.ten||'—'}) <button class="btn sm" data-bg="brepel" data-v="${r.id}">Отразить d20</button>`).join(' ')}</div>`:''}</div>`}
function bgLimPips(u,key,lim,rl){const c=u.c['a:'+key]||{used:0,rl:0};let h='';
  if(lim)for(let i=0;i<lim;i++)h+=bgPip(i<(c.used||0),'abuse',u.uid+'|'+key+'|'+lim,'Использование (Ограничено '+lim+')');
  if(rl)h+=` <button class="btn sm ${c.rl?'':'red'}" data-bg="abrl" data-v="${u.uid}|${key}|${rl}" title="Использовать: получить ${rl} счётчика перезарядки">${c.rl?'⟳ '+c.rl:'Использовать (⟳'+rl+')'}</button>`;
  return h}
function bgWeapRow(u,x){const it=x.it,tg=it.tg||{};const c=u.c['w:'+x.key]||{};const dead=x.sh&&x.sh.dead;const v=u.uid+'|'+x.key;const ok=bgInRng(it.rng,u.band);let btn='';
  if(dead)btn='<span class="muted">корабль уничтожен</span>';
  else if(it.cat==='aux')btn='<span class="muted">стреляет вместе с основным</span>';
  else if(tg.skip)btn=c.skip&&c.skip.on?(c.ch>0?`<span class="muted">заряжается: ${c.ch}</span>`:`<button class="btn sm red" data-bg="skipfire" data-v="${v}">Сработать (d20)</button>`):(c.lim?'<span class="muted">использован</span>':`<button class="btn sm" data-bg="skipstart" data-v="${v}" title="Выбрать цель в фазе логистики">Начать зарядку</button>`);
  else if(tg.pl!=null)btn=c.busy&&BB().pls.some(p=>p.id===c.busy)?'<span class="muted">в полёте</span>':`<button class="btn sm ${ok?'red':''}" data-bg="wlaunch" data-v="${v}">🚀 Запуск</button>`;
  else if(tg.ch)btn=c.ch>0?`<span class="bg-chg" title="Счётчики заряда: столько логистик до выстрела">⏳ заряд ${c.ch}</span>`:`<button class="btn sm red" data-bg="watk" data-v="${v}">⚡ Огонь</button><button class="btn sm" data-bg="whold" data-v="${v}" title="Сбросить заряд (держать — просто не стрелять)">↺</button>`;
  else if(tg.at)btn=`<button class="btn sm ${ok?'red':''}" data-bg="warea" data-v="${v}" ${c.rl?'disabled':''}>💥 По площади</button>`;
  else btn=`<button class="btn sm ${ok?'red':''}" data-bg="watk" data-v="${v}" ${c.rl||(tg.lim&&c.lim>=tg.lim)?'disabled':''}>🎯 Атака</button>`;
  return `<div class="bg-w ${dead?'dead':''} ${ok?'':'oor'}"><span class="bg-wn"><b>${esc(it.ru)}</b> <span class="muted">${BG_SLOT[it.cat]} · ${esc(x.sh?x.sh.name:'')} · ${bgRng(it.rng)}${it.dmg?' · '+esc(it.dmg):''}${c.rl?' · ⟳'+c.rl:''}</span></span>${btn}
   ${bgDet('w-'+u.uid+x.key,'описание',`<div class="bg-tags">${bgTags(bgWTags(it))}</div>${bgfmt(it.t)}`)}</div>`}
function bgPcUnit(u){const items=bgPcItems(u);const it=bgIntTxt(u);
  const weap=items.filter(x=>['sh','pr','aux'].includes(x.k));
  const ew=items.filter(x=>x.k==='esc'||x.k==='wing');
  const abil=[];u.snap.ships.forEach(s=>{const h=BH[s.hull];const sh=bgShip(u,s.id);h.tr.forEach((t,i)=>abil.push({key:`${s.id}:h${i}`,t,sh,src:h.ru}));
    bgShipItems(s).filter(x=>x.k==='sys').forEach(x=>{abil.push({key:`${s.id}:s${x.i}`,t:{n:x.it.ru,k:'system',tg:bgWTags(x.it)||'Система',t:x.it.t,lim:x.it.tg.lim,rl:x.it.tg.rl},sh,src:x.it.ru});(x.it.sub||[]).forEach((a,j)=>abil.push({key:`${s.id}:s${x.i}:${j}`,t:a,sh,src:x.it.ru}))})});
  const brdTargets=BB().units.filter(o=>o.kind==='npc').flatMap(o=>o.ships.filter(s=>!s.dead&&!s.wing&&!s.esc).map(s=>({o,s})));
  return `<div class="bg-unit pc"><div class="bg-uh"><b class="bg-un">${esc(u.name)}</b>
    <span class="bg-bands">${[5,4,3,2,1,0].map(b=>`<button class="bg-band ${u.band===b?'on':''}" data-bg="band" data-v="${u.uid}|${b}" title="${BG_BAND[b]}">${b}</button>`).join('')}<span class="muted">${BG_BAND[u.band]}</span></span>
    <button class="tpip ${u.bolst?'on':''}" data-bg="bolst" data-v="${u.uid}" title="+1d6 Перехват, +2 Защита">Укреплена</button>
    <span class="bg-int" title="${esc(bgIntParts(u).map(p=>p[0]+': '+p[1]).join(', '))}">Перехват <b>${esc(it.txt)}</b> <button class="btn sm" data-bg="int" data-v="${u.uid}">🎲</button></span>
    <span class="bg-small">Банк: Точн ${bgNum('bankacc',u.uid,u.acc||0)} Сложн ${bgNum('bankdif',u.uid,u.dif||0)}</span>
    <span class="bg-sp"></span><button class="btn sm" data-bg="eject" data-v="${u.uid}" title="Субсветовой выброс (с 5-го раунда)">Выброс</button><button class="btn sm" data-bg="surr" data-v="${u.uid}">Сдаться</button></div>
   <div class="bg-ships">${u.ships.map(s=>bgShipRow(u,s)).join('')}</div>
   <div class="bg-cols"><div><h4>Оружие</h4>${weap.map(x=>bgWeapRow(u,x)).join('')||'<div class="muted">нет</div>'}</div>
    <div><h4>Эскорты и крылья</h4>${ew.map(x=>{const c=u.c['u:'+x.key]||{};const v=u.uid+'|'+x.key;const dead=c.dead||(x.sh&&x.sh.dead);
      return `<div class="bg-w ${dead?'dead':''}"><span class="bg-wn"><b>${esc(x.it.ru)}</b> <span class="muted">${x.k==='esc'?'эскорт':'крыло'} · ${esc(x.sh?x.sh.name:'')}</span></span>
       ${c.max?`<span>ПЗ ${bgNum('uhp',v,c.hp)}${c.os?` +${c.os}`:''}</span>`:''}
       <button class="tpip ${c.used?'on':''}" data-bg="uused" data-v="${v}" title="Отдан приказ в этом раунде (сбрасывается в логистике)">приказ</button>
       ${(x.it.tg&&x.it.tg.brd||x.id==='ace'&&(x.s.ace||[]).includes('ram'))&&!dead?(c.brd?'<span class="muted">на абордаже</span>':`<select data-bgf="brdt" data-v="${v}"><option value="">цель абордажа…</option>${brdTargets.map(({o,s})=>`<option value="${o.uid}|${s.sid}">${esc(o.name)}: ${esc(s.name)}</option>`).join('')}</select>`):''}
       ${bgDet('u-'+u.uid+x.key,'описание',bgfmt(x.it.t)+(x.it.sub||[]).map(a=>bgAbil(a)).join('')+(x.id==='ace'?(x.s.ace||[]).filter(Boolean).map(a=>`<div class="bg-ab"><div class="bg-abh"><b>${esc(BAU[a].ru)}</b></div><div class="bg-txt">${bgfmt(BAU[a].t)}</div></div>`).join(''):''))}</div>`}).join('')||'<div class="muted">нет</div>'}</div></div>
   ${bgDet('ab-'+u.uid,`Черты, тактики, манёвры и системы (${abil.length})`,`<div class="bg-std">${bgStdActs(u)}</div>`+abil.map(a=>bgAbil(a.t,`<span class="bg-sp"></span>${bgLimPips(u,a.key,a.t.lim,a.t.rl)}<span class="muted">${esc(a.src)}</span>`)).join(''))}
  </div>`}
function bgStdActs(u){const uid=u.uid;const fr=u.ships.some(s=>!s.dead&&s.hull&&(BH[s.hull].cls==='fr'||BH[s.hull].scr));
  return `<b>Общие действия:</b> <button class="btn sm" data-bg="mv" data-v="${uid}|-1" title="Продвинуться на диапазон">«Полный вперёд» / вперёд</button><button class="btn sm" data-bg="retro" data-v="${uid}">«Обратная тяга»</button><button class="btn sm" data-bg="mv" data-v="${uid}|1">Отойти на диапазон</button><button class="btn sm" data-bg="ram" data-v="${uid}" title="С Ближней или в упор">«Таран»</button><button class="btn sm" data-bg="purge" data-v="${uid}">Зачистка (выбить абордаж)</button><button class="btn sm" data-bg="ungrey" data-v="${uid}">Снять Грейвош</button><button class="btn sm" data-bg="coin" title="Оборонительный заслон: перехват с вероятностью 50%">🪙 Заслон 50%</button>${bgLimPips(u,'std:em',1,0)} <span class="muted">«Экстренный манёвр»</span>${fr?' · <span class="muted">«Оборонительный заслон» доступен</span>':''}`}
function bgNpcUnit(u){const cap=BNC[u.cap];const it=bgIntTxt(u);const items=bgNpcItems(u);
  const groups={};items.forEach(x=>(groups[x.owner]=groups[x.owner]||{src:x.src,list:[]}).list.push(x));
  const wingBlocks=Object.entries(u.c).filter(([k])=>k.startsWith('wg:')).map(([k,w])=>`<div class="bg-wings"><b>Крылья (${esc(k.slice(3)==='c'?cap.ru:(BNE[u.esc[+k.slice(4)]]||{}).ru||'')})</b>: ${w.hp.map((h,i)=>`<span class="bg-wg ${h<=0?'dead':''}">${bgNum('wg',u.uid+'|'+k+'|'+i,h)}</span>`).join('')}
    ${w.ten?`<select data-bgf="nbrd" data-v="${u.uid}|${k}|${w.ten}"><option value="">абордаж (Упорство ${w.ten})…</option>${bgPcShipOpts()}</select>`:''}</div>`).join('');
  return `<div class="bg-unit npc"><div class="bg-uh"><b class="bg-un">${esc(u.name)}</b><span class="muted">НИП · ${esc(cap.ru)}${u.esc.length?' + '+u.esc.map(e=>BNE[e].ru).join(', '):''}${u.ace?' + ас '+BNA[u.ace].ru:''}</span>
    <button class="tpip ${u.bolst?'on':''}" data-bg="bolst" data-v="${u.uid}">Укреплена</button>
    <span class="bg-int">Перехват <b>${esc(it.txt)}</b> <button class="btn sm" data-bg="int" data-v="${u.uid}">🎲</button></span>
    ${(u.esc||[]).includes('unknown')?`<span>Омнипушка: <b>${u.omni||0}</b> ${bgNum('omni',u.uid,u.omni||0)}</span>`:''}
    <span class="bg-sp"></span><button class="btn sm" data-bg="purge" data-v="${u.uid}">Выбить абордаж</button><button class="btn sm" data-bg="ungrey" data-v="${u.uid}">Снять Грейвош</button><button class="btn sm" data-bg="eject" data-v="${u.uid}">Выброс</button><button class="btn sm" data-bg="surr" data-v="${u.uid}">Сдаться</button></div>
   <div class="bg-ships">${u.ships.map(s=>bgShipRow(u,s)).join('')}</div>${wingBlocks}
   ${Object.entries(groups).map(([o,g])=>`<div class="bg-own ${bgOwnerAlive(u,o)?'':'dead'}"><h4>${esc(g.src.ru)} ${g.src.tags?'<span class="muted">· '+esc(g.src.tags)+'</span>':''}</h4>${bgDet('tac-'+u.uid+o,'Тактика ГМа',bgfmt(g.src.tac))}
     ${g.list.map(x=>bgNpcItemRow(u,x)).join('')}</div>`).join('')}</div>`}
function bgPcShipOpts(){return BB().units.filter(o=>o.kind==='pc').flatMap(o=>o.ships.filter(s=>!s.dead).map(s=>`<option value="${o.uid}|${s.sid}">${esc(o.name)}: ${esc(s.name)}</option>`)).join('')}
function bgNpcItemRow(u,x){const it=x.it,t=bgNpcTg(it);const c=u.c['n:'+x.key]||{};const v=u.uid+'|'+x.key;const alive=bgOwnerAlive(u,x.owner);let btn='';
  if(!alive)btn='';
  else if(it.omni)btn=`<button class="btn sm red" data-bg="omni-fire" data-v="${u.uid}">Омнипушка: ${u.omni||0} урона</button>`;
  else if(t.pl!=null&&it.dmg)btn=c.busy&&BB().pls.some(p=>p.id===c.busy)?'<span class="muted">в полёте</span>':`<button class="btn sm red" data-bg="nlaunch" data-v="${v}" ${c.rl?'disabled':''}>🚀 Запуск</button>`;
  else if(t.ch&&it.k==='charge')btn=c.ch>0?`<span class="bg-chg" title="Счётчики заряда: столько логистик до выстрела">⏳ заряд</span> ${bgNum('nch',v,c.ch)}`:`<button class="btn sm red" data-bg="natk" data-v="${v}">⚡ Огонь</button>`;
  else if(t.at&&it.dmg)btn=`<button class="btn sm red" data-bg="narea" data-v="${v}" ${c.rl?'disabled':''}>💥 По площади</button>`;
  else if(t.st&&it.dmg)btn=`<button class="btn sm red" data-bg="natk" data-v="${v}" ${c.rl||(t.lim&&c.lim>=t.lim)?'disabled':''}>🎯 Атака</button>`;
  if(alive&&t.brd)btn+=`<select data-bgf="nbrd" data-v="${u.uid}|${'n:'+x.key}|${t.ten||0}|${esc(it.n)}"><option value="">абордаж…</option>${bgPcShipOpts()}</select>`;
  let ctr='';if(t.rl&&!(t.ch&&it.k==='charge'))ctr+=` <button class="btn sm" data-bg="nrl" data-v="${v}|${t.rl}" title="Отметить использование: ${t.rl} счётчика перезарядки">${c.rl?'⟳ '+c.rl:'⟳'+t.rl}</button>`;
  if(t.lim)for(let i=0;i<t.lim;i++)ctr+=bgPip(i<(c.lim||0),'nlim',v+'|'+t.lim,'Ограничено '+t.lim);
  return `<div class="bg-w ${alive?'':'dead'}"><span class="bg-wn"><b>${esc(it.n)}</b> <span class="muted">${esc(it.tg)}${it.rng?' · '+bgRng(it.rng):''}${it.dmg?' · '+esc(it.dmg):''}</span></span>${btn}${ctr}
   ${bgDet('n-'+u.uid+x.key,'описание',bgfmt(it.t))}</div>`}
function bgBattle(){const b=BB();const pcs=b.units.filter(u=>u.kind==='pc'),npcs=b.units.filter(u=>u.kind==='npc');
  return `${bgPhaseBar()}${bgSetup()}${bgAtkPanel()}${bgPayloads()}${bgBoards()}
   ${pcs.length?`<h2>Группы игроков</h2>${pcs.map(bgPcUnit).join('')}`:''}
   ${npcs.length?`<h2>НИП</h2>${npcs.map(bgNpcUnit).join('')}`:''}
   ${!b.units.length?'<div class="muted bg-empty">В бою пока никого. Откройте «Добавить участников».</div>':''}`}

/* ---------- экран и боковая панель ---------- */
function viewFleet(){const t=BGS.tab||'build';
  return `<div class="bg-view"><div class="gl-top"><h1>⚓ Флот · Battlegroup</h1>
    <div class="pc-tabs">${[['build','Сборка группы'],['battle','Бой'],['cat','Каталог']].map(([k,n])=>`<button class="btn ${t===k?'red':''}" data-bg="tab" data-v="${k}">${n}</button>`).join('')}
    <span class="muted bg-small">Правила — в Справочнике, раздел «Battlegroup». Таблицы — в ГМ tools.</span></div></div>
   ${t==='build'?bgBuild():t==='battle'?bgBattle():bgCatalog()}</div>`}
function fleetSide(){const t=BGS.tab||'build';
  if(t==='battle'){const b=BB();return `<div class="side-hd"><b>Бой</b></div><div class="refnav">${b.units.map(u=>`<div class="bg-sideu ${u.kind}"><b>${esc(u.name)}</b>${u.kind==='pc'?`<small>${bgBand(u.band)}</small>`:''}${u.ships.map(s=>`<small class="${s.dead?'dead':''}">${esc(s.name)}: ${s.hp}/${s.max}${s.os?' +'+s.os:''}</small>`).join('')}</div>`).join('')||'<div class="muted">пусто</div>'}</div>`}
  return `<div class="side-hd"><b>Боевые группы</b></div><div class="refnav">${BGS.groups.map(g=>{const c=bgCost(g);return `<button class="citem ${g.id===BGS.cur?'on':''}" data-bg="gsel" data-v="${g.id}"><span><b>${esc(g.name)}</b><small>${g.ships.length} кор. · ${c.main}/20 оч.</small></span></button>`}).join('')}</div>
   <div class="side-btns"><button class="btn" data-bg="gnew">＋ Новая группа</button></div>
   <p class="muted" style="font-size:12px">Группы хранятся в этом браузере. Экспорт/импорт — чтобы передать группу ГМу.</p>`}
V19.push('fleet');
{const o=renderTabs;renderTabs=function(){o();const t=document.getElementById('tabs');if(!t)return;if(t.querySelector('[data-v="fleet"]'))return;
  const html=`<button class="tab ${S.view==='fleet'?'on':''}" data-act="view" data-v="fleet">⚓ Флот</button>`;const r=t.querySelector('.tab[data-v="ref"]');
  if(r)r.insertAdjacentHTML('beforebegin',html);else t.insertAdjacentHTML('beforeend',html)}}
{const o=renderMain;renderMain=function(){if(S.view!=='fleet')return o();const m=document.getElementById('main');
  try{m.innerHTML=viewFleet();if(typeof foldApply==='function')foldApply()}catch(e){m.innerHTML=`<div class="crashbox"><b>Ошибка экрана «Флот»</b><div class="muted">${esc(e&&e.message||e)}</div><div class="row-btns"><button class="btn" data-bg="tab" data-v="build">Сборка</button><button class="btn red" data-bg="hardreset">Сбросить данные флота</button></div></div>`}}}
{const o=renderSide;renderSide=function(){if(S.view!=='fleet')return o();const s=document.getElementById('side');try{s.innerHTML=fleetSide()}catch(e){s.innerHTML='<div class="muted">Ошибка панели</div>'}}}
function bgRender(){bgSave();renderMain();renderSide()}
