/* ===== m23: у каждого дополнения свой цвет надписей (как жёлтый у The Long Rim) ===== */
const BK_RX=[['LR',/long rim|долгий обод/i],['KTB',/karrakin|карракин/i],['WF',/wallflower|тихони/i],['DG',/dustgrave|пыльная могила/i],['BG',/battlegroup|флотские сражения/i],['WS',/winter scar|зимний шрам/i]];
const bkOf=t=>{for(const [k,rx] of BK_RX)if(rx.test(t||''))return k;return ''};
function bkTag(root){try{(root||document).querySelectorAll('.dlc-hd,.side-sub,.srcmark,.lic-src,.tl-book,.cgrp,.citem small,.io-src,.lic-ban[data-book]').forEach(el=>{
  const k=el.dataset.book&&BOOKS[el.dataset.book]?el.dataset.book:bkOf(el.getAttribute('title')+' '+el.textContent);
  if(k){if(el.dataset.bk!==k)el.dataset.bk=k}else if(el.dataset.bk)delete el.dataset.bk})}catch(e){}}
{let pend=false;const run=()=>{pend=false;bkTag(document)};
 const obs=new MutationObserver(()=>{if(!pend){pend=true;(window.requestAnimationFrame||setTimeout)(run)}});
 try{obs.observe(document.body,{childList:true,subtree:true})}catch(e){}
 run()}
