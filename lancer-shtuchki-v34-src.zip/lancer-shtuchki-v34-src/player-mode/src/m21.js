/* ===== m21: шаблоны НИП в боковом списке библиотеки и отдельная страница шаблона ===== */
S.tplView=null;
const tvItem=f=>({...f,type:f.type||'tpl'});
function tplPage(tp){const t=S.tier;const strip=h=>h.replace(/<button class="atkbtn"[^>]*>[^<]*<\/button>/g,'');
  const ex=(tp.excludes||[]).map(id=>(tpl(id)||{}).name).filter(Boolean);
  const okCls=allCls().filter(c=>tplApplicable(tp,c));
  const cur=cls(S.cls);const def=cur&&tplApplicable(tp,cur)?cur.id:(okCls[0]||{}).id;
  return `<div class="npc-head tv-head">
    <div class="hex">ШАБЛОН<b>◆</b></div>
    <div><h1>${esc(tp.name)}</h1><div class="role">Шаблон НИП ${tp.book||tp.page?srcTag(tp.book||'',tp.page):''}</div></div>
    <div class="tiers">${[1,2,3].map(i=>`<button class="tierbtn ${i===t?'on':''}" data-act="tier" data-v="${i}">ГРАДАЦИЯ ${i}</button>`).join('')}</div>
  </div>
  ${tp.desc?`<p class="desc">${fmt(tp.desc,t)}</p>`:''}
  ${tp.requiresTag||ex.length?`<p class="muted">${tp.requiresTag?`Только для НИП с меткой «${esc(tp.requiresTag)}». `:''}${ex.length?`Несовместим с шаблонами: ${esc(ex.join(', '))}.`:''}</p>`:''}
  <div class="tv-apply"><b>Применить к классу:</b> <select id="tv-cls">${okCls.map(c=>`<option value="${esc(c.id)}" ${c.id===def?'selected':''}>${esc(c.name)}${c.role?' · '+esc(c.role):''}</option>`).join('')}</select>
   <button class="btn red" data-tv-apply="${esc(tp.id)}" ${okCls.length?'':'disabled'}>Открыть класс с этим шаблоном</button>
   <span class="muted">Опции шаблона отмечаются там же, внизу страницы класса.</span></div>
  ${(tp.features||[]).length?`<h2>Особенности шаблона</h2>${strip(tp.features.map(f=>sysCard(tvItem(f),t,{src:'lib'})).join(''))}`:''}
  ${tplGroups(tp).map(g=>{const mx=grpMax(g,t);return `<h2>${esc(g.label)} <span class="muted" style="font-size:13px;text-transform:none">— ${g.items.length} шт.${mx?`, можно выбрать до ${mx}`:''}</span></h2>${strip(g.items.map(x=>sysCard(tvItem(x),t,{src:'lib'})).join(''))}`}).join('')}`}
{const o=viewLib;viewLib=function(){if(S.tplView){const tp=tpl(S.tplView);if(tp)return tplPage(tp);S.tplView=null}
  let h=o();
  /* быстрый переход к шаблонам и якоря на карточках */
  h=h.replace('<h2>Шаблоны <span class="muted"','<h2 id="lib-tpl">Шаблоны <span class="muted"');
  const c=cls(S.cls);if(c){const n=allTpl().length;h=h.replace(/(<div class="role">[\s\S]*?<\/div>)/,`$1<button class="btn sm tv-jump" data-tv-jump="1">◆ Шаблоны (${n}) ↓</button>`)}
  return h}}
{const o=tplCard;tplCard=function(tp,c,ts,t){return o(tp,c,ts,t).replace('<div class="sys ',`<div id="tplc-${esc(tp.id)}" class="sys `)}}
{const o=renderSide;renderSide=function(){o();if(S.view==='pc')return;const el=document.getElementById('side');const list=el&&el.querySelector('.clist');if(!list)return;
  const f=(S.filter||'').toLowerCase();const ts=allTpl().filter(tp=>!f||(tp.name+' шаблон '+(tp.book?BOOKS[tp.book]?BOOKS[tp.book].name:'':'')).toLowerCase().includes(f));
  if(!ts.length)return;
  const empty=list.querySelector(':scope > .muted');if(empty&&/Ничего не найдено/.test(empty.textContent))empty.remove();
  list.insertAdjacentHTML('beforeend',`<div class="cgrp">Шаблоны НИП</div>`+ts.map(tp=>`<button class="citem ${S.tplView===tp.id&&S.view==='lib'?'on':''}" data-tv="${esc(tp.id)}">
    <span class="ic">◆</span><span><b>${esc(tp.name)}</b><small>Шаблон${tp.book&&BOOKS[tp.book]?' · '+esc(BOOKS[tp.book].name):''}</small></span></button>`).join(''));
  if(S.tplView){const on=list.querySelector('.citem.on[data-act="cls"]');if(on)on.classList.remove('on')}}}
/* выбор класса или вкладки закрывает страницу шаблона */
document.addEventListener('click',e=>{const b=e.target.closest('[data-act="cls"],[data-act="view"]');if(b)S.tplView=null},true);
document.addEventListener('click',e=>{
  const v=e.target.closest('[data-tv]');if(v){S.tplView=v.dataset.tv;S.view='lib';render();const m=document.getElementById('main');if(m)m.scrollTop=0;window.scrollTo(0,0);return}
  const a=e.target.closest('[data-tv-apply]');if(a&&!a.disabled){const id=a.dataset.tvApply,sel=document.getElementById('tv-cls');const cid=sel&&sel.value;const c=cls(cid);const tp=tpl(id);if(!c||!tp)return;
    S.cls=c.id;S.tplView=null;S.view='lib';const ts=getTplSel(c.id);
    if(!ts.tpls.includes(id)){const conf=tplConflict(tp,ts.tpls);if(conf){toast(`Сначала снимите шаблон «${conf}»`)}else ts.tpls.push(id)}
    if(typeof save==='function')save();render();const card=document.getElementById('tplc-'+id);if(card){card.scrollIntoView({block:'start'});card.classList.add('tv-flash');setTimeout(()=>card.classList.remove('tv-flash'),1600)}return}
  const j=e.target.closest('[data-tv-jump]');if(j){const h=document.getElementById('lib-tpl');if(h)h.scrollIntoView({behavior:'smooth',block:'start'})}});
