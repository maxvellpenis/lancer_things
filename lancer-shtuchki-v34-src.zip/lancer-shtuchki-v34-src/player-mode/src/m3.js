/* ---------- сборка меха ---------- */
function statCell(st,k,l,tip){return `<div class="sc kw" data-tt="${esc(l)}" data-tip="${esc((tip?tip+'\n':'')+(st.why[k]||''))}"><span>${esc(l)}</span><b>${k==='size'?sizeTxt(st[k]):k==='tech'||k==='attack'?sgn(st[k]):st[k]}</b></div>`}
function mechStatBlock(st){
  return `<div class="mstats">
   ${statCell(st,'hp','ПЗ')}${statCell(st,'armor','Броня','Уменьшает урон (не ББ, не горение и не нагрев). Максимум 4.')}${statCell(st,'struct','Структура')}${statCell(st,'stress','Нагрузка')}
   ${statCell(st,'evasion','Уклонение')}${statCell(st,'edef','Э-Защита')}${statCell(st,'speed','Скорость')}${statCell(st,'size','Размер')}
   ${statCell(st,'heatcap','Тепл. Макс.')}${statCell(st,'repcap','Лимит Ремонта')}${statCell(st,'sensors','Сенсоры')}${statCell(st,'save','Спас. Цель')}
   ${statCell(st,'tech','Тех. Атака')}${statCell(st,'attack','Атака','Бонус к броскам атаки = Стойкость.')}${statCell(st,'sp','СП')}${statCell(st,'limited','Доп. заряды','Добавляется к Ограниченным системам и оружию.')}
  </div>`;
}
function wHead(w){return `${esc(WSIZE_S[w.mount]||w.mount)} ${esc(WTYPE_RU[w.type]||w.type)}`}
function weaponLine(w,st,mod,dtSel,notes){
  if(w.profiles&&w.profiles.length&&!(w.dmg||[]).length)w={...w,dmg:w.profiles[0].dmg||[],rng:(w.rng&&w.rng.length?w.rng:w.profiles[0].rng)||[],tags:[...(w.tags||[]),...(w.profiles[0].tags||[])]};
  const r=st?weaponRanges(st,w,mod):w.rng;
  const dmg=[...(w.dmg||[]),...(mod&&mod.addDmg||[])];
  const tags=[...(w.tags||[]),...(mod&&mod.addTags||[])];
  return `<div class="wprof"><span class="pill">${esc(wHead(w))}</span>${r.length?`<span class="pill">${rngHtml(r)}</span>`:''}${dmg.length?`<span class="pill dmg">${esc(dmgTxt(dmg))}${dtSel?' → '+esc(PDT_RU[dtSel]):''}</span>`:''}
    ${tags.length?`<span class="tag-s">${tags.map(tagChip).join(', ')}</span>`:''}${w.sp?`<span class="pill">${w.sp} СП</span>`:''}${(notes||[]).map(n=>`<span class="pill cbn ${n.cond?'cond':''}" title="${esc(n.src)}">${esc(n.txt)}</span>`).join('')}</div>`;
}
function itemCard(x,kind,opts){
  opts=opts||{};const key=kind+'-'+x.id+(opts.k||'');const open=PS.open[key]?'open':'';
  return `<details class="pitem ${kind}" data-po="${esc(key)}" ${open}><summary><span class="pin-n">${esc(opts.label||x.name)}</span>
     <span class="tag-s">${kind==='sys'?esc(/СП/.test(x.rutags||'')?x.rutags:(x.sp?x.sp+' СП · ':'')+(x.rutags||'')):kind==='mod'?esc(x.sp+' СП · Мод'):''}</span>${opts.right||''}</summary>
     ${kind==='w'?weaponLine(x,opts.st,opts.mod,opts.dt,opts.notes):''}
     <div class="ptxt">${pfmt(x.text||'')}</div>
     <div class="muted" style="font-size:11px">${esc(x.en)} · ${esc(licLabel(x))}${x.page?' · стр. '+x.page:''}</div></details>`;
}
function frameOptions(p,cur){
  return MANU_ORDER.filter(mn=>PCD.frames.some(f=>f.src===mn)).map(mn=>`<optgroup label="${esc(MANU_FULL[mn])}">${PCD.frames.filter(f=>f.src===mn).map(f=>`<option value="${f.id}" ${f.id===cur?'selected':''}>${esc(f.name)}${f.variant&&P.F[f.variant]?' — вариант '+esc(P.F[f.variant].name):''}${frameOk(p,f)?'':' (нет лицензии)'}</option>`).join('')}</optgroup>`).join('');
}
function weaponOptions(p,sizes,cur){
  const list=PCD.weapons.filter(w=>!w.tal&&sizes.includes(w.mount)&&!/_integrated$/.test(w.id)&&(PS.showAll||itemOk(p,w)||w.id===cur));
  return `<option value="">— пусто —</option>`+MANU_ORDER.map(mn=>{const ws=list.filter(w=>w.src===mn);return ws.length?`<optgroup label="${esc(MANU[mn])}">${ws.map(w=>`<option value="${w.id}" ${w.id===cur?'selected':''}>${esc(w.name)} · ${esc(wHead(w))}${itemOk(p,w)?'':' ⚠'}</option>`).join('')}</optgroup>`:''}).join('');
}
function modOptions(p,w,cur){
  const list=PCD.mods.filter(md=>(md.types||[]).includes(w.type)&&!(md.sizes||[]).includes(w.mount)&&(PS.showAll||itemOk(p,md)||md.id===cur));
  if(!list.length)return '';
  return `<select data-pf="mod" data-k="${esc(cur===undefined?'':'')}" class="msel"><option value="">мод: нет</option>${list.map(md=>`<option value="${md.id}" ${md.id===cur?'selected':''}>${esc(md.name)} (${md.sp} СП)${itemOk(p,md)?'':' ⚠'}</option>`).join('')}</select>`;
}
function viewMech(p){
  const m=curM(p),f=P.F[m.frame],st=mechStats(p,m),used=spUsed(p,m),ms=mechMounts(p,m);
  const mechTabs=p.mechs.map((x,i)=>`<button class="tab ${i===(p.mech||0)?'on':''}" data-pa="msel" data-v="${i}">${esc(x.name||P.F[x.frame].name)}</button>`).join('');
  const mounts=ms.map(mt=>{
    if(mt.fixed){const w=mt.w||P.W[mt.fixed];return `<div class="mount fixed"><div class="mh">${esc(MOUNT_RU.Integrated)} <span class="muted">${esc(mt.note||'')}</span></div>${mt.ui||''}${itemCard(w,'w',{st,k:mt.key,notes:wCbNotes(p,m,{w,key:mt.key,uid:mt.key+'#0'})})}</div>`}
    const sh=shUsedBy(m,mt.key);
    if(sh)return `<div class="mount used"><div class="mh">${esc(MOUNT_RU[mt.type])} <span class="muted">— занят сверхтяжёлым оружием (${esc(P.W[m.load[sh[0]][0]].name)})</span></div></div>`;
    const slots=(SLOTS[mt.type]||[]).map((_,si)=>{
      const al=slotAllowed(m,mt,si),cur=(m.load[mt.key]||[])[si]||'',w=P.W[cur];
      if(!al.length)return `<div class="slot muted" style="font-size:12px">второй слот недоступен: в Гибком слоте стоит основное оружие</div>`;
      const mk=mt.key+'#'+si,mod=m.mods[mk]||'';
      const others=ms.filter(o=>o.key!==mt.key&&!o.fixed);
      return `<div class="slot"><select data-pf="wpn" data-k="${mt.key}" data-si="${si}">${weaponOptions(p,al,cur)}</select>
         ${w&&!mt.noMod&&!w.no_mods?modOptions(p,w,mod).replace('data-k=""',`data-k="${mk}"`):''}
         ${w?wCbBtns(p,m,mt,mk):''}
         ${w&&w.mount==='Superheavy'?`<select data-pf="sh" data-k="${mt.key}"><option value="">второй слот для сверхтяжёлого…</option>${others.map(o=>`<option value="${o.key}" ${m.sh[mt.key]===o.key?'selected':''}>${esc(MOUNT_RU[o.type])} (слот ${ms.indexOf(o)+1})</option>`).join('')}</select>`:''}
         ${w?itemCard(w,'w',{st,mod:P.MO[mod],k:mk,notes:wCbNotes(p,m,{w,key:mt.key,uid:mk})}):''}${P.MO[mod]?itemCard(P.MO[mod],'mod',{k:mk}):''}</div>`;
    }).join('');
    return `<div class="mount"><div class="mh">${ms.indexOf(mt)+1}. ${esc(MOUNT_RU[mt.type])} слот <span class="muted">${esc(mt.note||'')}</span></div>${slots}</div>`;
  }).join('');
  const sysl=mechSystems(p,m);
  const sysAvail=PCD.systems.filter(s=>!s.tal&&(PS.showAll||itemOk(p,s)));
  const cbOpts=[];
  if(p.cbs.includes('cb_mount_retrofitting'))cbOpts.push(`<label class="fl">${esc(P.CB.cb_mount_retrofitting.name)}: заменить слот <select data-pf="retro">${f.mounts.map((t,i)=>`<option value="${i}" ${+m.retro===i?'selected':''}>${i+1}. ${esc(MOUNT_RU[t])}</option>`).join('')}</select></label>`);
  if(p.cbs.includes('cb_auto_stabilizing_hardpoints'))cbOpts.push(`<label class="fl">${esc(P.CB.cb_auto_stabilizing_hardpoints.name)} (+1 точн.): слот <select data-pf="autostab"><option value="">—</option>${ms.filter(x=>!x.fixed).map(x=>`<option value="${x.key}" ${m.autostab===x.key?'selected':''}>${esc(MOUNT_RU[x.type])} (слот ${ms.indexOf(x)+1})</option>`).join('')}</select></label>`);
  if(p.cbs.includes('cb_overpower_caliber'))cbOpts.push(`<label class="fl">${esc(P.CB.cb_overpower_caliber.name)} (+1d6, 1/раунд): оружие <select data-pf="overpower"><option value="">—</option>${mechWeapons(p,m).map(x=>`<option value="${x.uid}" ${m.overpower===x.uid?'selected':''}>${esc(x.w.name)}</option>`).join('')}</select></label>`);
  return `
  <div class="pc-tabs">${mechTabs}<button class="btn sm" data-pa="madd">＋ мех</button>${p.mechs.length>1?`<button class="btn sm" data-pa="mdel">✕ удалить этот мех</button>`:''}</div>
  <div class="pgrid">
   <section class="pbox">
     <label class="fl">Имя меха<input data-pf="mname" value="${esc(m.name)}" placeholder="напр. Гордость Карины"></label>
     <label class="fl">Рама<select data-pf="frame">${frameOptions(p,m.frame)}</select></label>
     <label class="fl" style="flex-direction:row;align-items:center;gap:6px"><input type="checkbox" class="chk" data-pa="showall" ${PS.showAll?'checked':''}> показывать всё, даже без лицензии (⚠)</label>
     ${cbOpts.join('')}
   </section>
   <section class="pbox"><h3 style="display:flex;gap:8px;align-items:center">${esc(f.name)} <span class="role">${esc(MANU[f.src])} · ${esc(f.role)}</span></h3>
     ${mechStatBlock(st)}
     <div class="spbar ${used>st.sp?'over':''}">Системные очки: <b>${used} / ${st.sp}</b><div class="meter"><i style="width:${Math.min(100,used/Math.max(1,st.sp)*100)}%;background:${used>st.sp?'var(--bad)':'var(--gold)'}"></i></div></div>
   </section>
  </div>
  <h2>Черты рамы</h2>${f.traits.map(t=>`<div class="trait"><b>${esc(t.name)}</b><div>${pfmt(t.text)}</div></div>`).join('')}
  <h2>Система ядра — ${esc(f.core.name)}</h2>${coreHtml(f)}
  <h2>Слоты и оружие</h2><div class="mounts">${mounts}</div>
  <h2>Системы <span class="muted" style="font-size:12px;text-transform:none">${used}/${st.sp} СП</span></h2>
  <div class="syslist">${sysl.map(x=>itemCard(x.s,'sys',{k:x.uid,right:x.fixed?'<span class="ntag">талант</span>':`<button class="btn sm" data-pa="sysdel" data-v="${esc(x.uid)}">✕</button>`})).join('')||'<div class="muted">Систем нет</div>'}</div>
  <div class="slot"><select data-pf="sysadd"><option value="">＋ добавить систему…</option>${MANU_ORDER.map(mn=>{const ss=sysAvail.filter(s=>s.src===mn);return ss.length?`<optgroup label="${esc(MANU[mn])}">${ss.map(s=>`<option value="${s.id}">${esc(s.name)} · ${s.sp} СП${itemOk(p,s)?'':' ⚠'}</option>`).join('')}</optgroup>`:''}).join('')}</select></div>`;
}
function coreHtml(f){
  const c=f.core;
  return `<div class="core-c">${c.pname&&c.ptext?`<div class="trait"><b>${esc(c.pname)}</b> <span class="muted">(пассивно)</span><div>${pfmt(c.ptext)}</div></div>`:''}
   ${c.aname?pfmt('⟦A⟧'+c.aname+'⟦T⟧'+(c.atags||'Активное (1 МЯ)')+'⟦E⟧'+c.atext):''}</div>`;
}
