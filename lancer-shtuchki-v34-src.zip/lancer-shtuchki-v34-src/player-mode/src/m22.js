/* ===== m22: бонусы ядра — видимость на оружии, выбор слота/оружия, подсказки «что делает программа» ===== */
const CB_AUTO={
 cb_auto_stabilizing_hardpoints:'+1 точн. к атакам оружием выбранного слота (на карточке оружия — «+1 точн.»). Слот — кнопкой «◎ Автостаб.» у оружия во вкладке «Мех»; если не выбран, берётся слот первого оружия.',
 cb_overpower_caliber:'на карточке выбранного оружия — «+1d6 урона», в окне атаки — галочка «+1d6» (1/раунд). Оружие — кнопкой «◎ Калибр» у оружия во вкладке «Мех»; если не выбрано, берётся первое оружие.',
 cb_improved_armament:'Дополнительный Гибкий слот, если слотов меньше трёх.',
 cb_integrated_weapon:'Новый встроенный Вспомогательный слот (без модов).',
 cb_mount_retrofitting:'Выбранный слот становится Осн./Вспом. (выбор — во вкладке «Мех»).',
 cb_briareos_frame:'Сопротивляемость ко всему урону при Структуре 1 и меньше — учитывается в «Нанести урон».',
 cb_fomorian_frame:'Размер +1.',
 cb_gyges_frame:'+1 точн. к проверкам и спасброскам Корпуса; +1 Угроза ближнему оружию (на карточке — «+1» цветом).',
 cb_reinforced_frame:'+5 ПЗ.',
 cb_sloped_plating:'+1 Броня.',
 cb_full_subjectivity_sync:'+2 Уклонение.',
 cb_kai_bioplating:'+1 точн. к проверкам и спасброскам Маневренности.',
 cb_neurolink_targeting:'+3 Дальности оружию дальнего боя (на карточке — «+3» цветом).',
 cb_the_lesson_of_disbelief:'+1 точн. к проверкам и спасброскам Систем, +2 Э-Защита.',
 cb_the_lesson_of_the_open_door:'Спас. Цель +2.',
 cb_the_lesson_of_thinking_tomorrows_thought:'в окне ближней атаки — галочка «+1 точн. (тех. атака попала)».',
 cb_the_lesson_of_shaping:'+1 к числу ИИ.',
 cb_armory_sculpted_chassis:'+1 точн. к проверкам и спасброскам Инженерии.',
 cb_heatfall_coolant_system:'Нагрев от Перегрузки не выше 1d6.',
 cb_integrated_ammo_feeds:'+2 заряда всем Ограниченным системам и оружию.',
 cb_stasis_shielding:'При нагрузочном уроне — запись в журнале с напоминанием о Сопротивляемости.',
 cb_superior_by_design:'Невосприимчивость к Ослаблению, +2 Тепловой Максимум.',
 cb_superheavy_mounting:'Дополнительный сверхтяжёлый слот, если слотов меньше трёх.',
 cb_universal_compatibility:'',cb_titanomachy_mesh:'',cb_all_theater_movement_suite:'',cb_ghostweave:'',cb_integrated_nerveweave:'',
 cb_the_lesson_of_the_held_image:'',cb_the_lesson_of_transubstantiation:'',cb_adaptive_reactor:''
};
function cbHint(p,id,on){const a=CB_AUTO[id];if(a===undefined)return '';
  let cur='';const m=on&&p.mechs&&p.mechs.length?curM(p):null;
  if(m&&id==='cb_auto_stabilizing_hardpoints'){cbAutoAssign(p,m);const ms=mechMounts(p,m),mt=ms.find(x=>x.key===m.autostab);cur=mt?` Сейчас: слот ${ms.indexOf(mt)+1} (${MOUNT_RU[mt.type]}) у меха «${m.name||P.F[m.frame].name}».`:' Сейчас: слот не выбран (у меха нет оружия).'}
  if(m&&id==='cb_overpower_caliber'){cbAutoAssign(p,m);const x=mechWeapons(p,m).find(y=>y.uid===m.overpower);cur=x?` Сейчас: ${x.w.name} у меха «${m.name||P.F[m.frame].name}».`:' Сейчас: оружие не выбрано (у меха нет оружия).'}
  return a?`<span class="cbauto">⚙ Программа: ${esc(a)}${esc(cur)}</span>`:''}
/* выбор по умолчанию: слот/оружие первого (не встроенного) оружия, если выбор пуст или устарел */
function cbAutoAssign(p,m){if(!p||!m)return;const ws=mechWeapons(p,m).filter(x=>!x.fixed);
  if(p.cbs.includes('cb_auto_stabilizing_hardpoints')){const ms=mechMounts(p,m).filter(x=>!x.fixed);if(!ms.some(x=>x.key===m.autostab)){const w=ws[0];m.autostab=w?w.key:''}}
  if(p.cbs.includes('cb_overpower_caliber')){const all=mechWeapons(p,m);if(!all.some(x=>x.uid===m.overpower)){const w=ws[0]||all[0];m.overpower=w?w.uid:''}}}
function wCbNotes(p,m,x){const out=[];if(!p||!m||!x||!x.w)return out;
  if(p.cbs.includes('cb_auto_stabilizing_hardpoints')&&m.autostab&&x.key===m.autostab)out.push({txt:'+1 точн.',src:P.CB.cb_auto_stabilizing_hardpoints.name});
  if(p.cbs.includes('cb_overpower_caliber')&&m.overpower&&x.uid===m.overpower)out.push({txt:'+1d6 урона (1/раунд)',src:P.CB.cb_overpower_caliber.name});
  if(p.cbs.includes('cb_the_lesson_of_thinking_tomorrows_thought')&&x.w.type==='Melee')out.push({txt:'+1 точн. после попавшей тех. атаки',src:P.CB.cb_the_lesson_of_thinking_tomorrows_thought.name,cond:1});
  return out}
function wCbBtns(p,m,mt,uid){let h='';
  if(p.cbs.includes('cb_auto_stabilizing_hardpoints')){const on=m.autostab===mt.key;h+=`<button class="btn sm cbsel ${on?'on':''}" data-pcb="autostab" data-v="${esc(mt.key)}" title="${esc(P.CB.cb_auto_stabilizing_hardpoints.name)}">${on?'◉':'◎'} Автостаб. +1 точн.</button>`}
  if(p.cbs.includes('cb_overpower_caliber')){const on=m.overpower===uid;h+=`<button class="btn sm cbsel ${on?'on':''}" data-pcb="overpower" data-v="${esc(uid)}" title="${esc(P.CB.cb_overpower_caliber.name)}">${on?'◉':'◎'} Калибр +1d6</button>`}
  return h}
{const o=viewMech;viewMech=function(p){cbAutoAssign(p,curM(p));return o(p)}}
{const o=viewCombat;viewCombat=function(p){cbAutoAssign(p,curM(p));return o(p)}}
/* окно атаки: бонусы ядра отдельными пилюлями */
{const o=pcSetProfile;pcSetProfile=function(p,x,pi){cbAutoAssign(p,curM(p));o(p,x,pi);
  const n=wCbNotes(p,curM(p),x).filter(y=>!y.cond&&y.txt!=='+1d6 урона (1/раунд)');if(M&&M.w)M.w.cbNotes=n;
  /* если слот выбран только что — у атаки должна быть точность */
  const m=curM(p);if(M&&m.autostab&&x.key===m.autostab&&!M.mods.some(z=>z.label===P.CB.cb_auto_stabilizing_hardpoints.name))M.mods.unshift({label:P.CB.cb_auto_stabilizing_hardpoints.name,acc:1,on:true,fixed:1});
  if(M&&m.overpower===x.uid&&!M.mods.some(z=>z.label.indexOf(P.CB.cb_overpower_caliber.name)===0))M.mods.push({label:P.CB.cb_overpower_caliber.name+': +1d6 (1/раунд)',addDice:'1d6',on:false})}}
{const o=renderPcModal;renderPcModal=function(){o();try{if(M&&M.kind==='pcroll'&&M.w&&M.w.cbNotes&&M.w.cbNotes.length){const box=document.querySelector('#mbox .wprof');
  if(box&&!box.querySelector('.cbn'))box.insertAdjacentHTML('beforeend',M.w.cbNotes.map(n=>`<span class="pill cbn" title="${esc(n.src)}">${esc(n.txt)}</span>`).join(''))}}catch(e){}}}
document.addEventListener('click',e=>{const b=e.target.closest('[data-pcb]');if(!b)return;const p=curP();if(!p)return;const m=curM(p);
  if(b.dataset.pcb==='autostab')m.autostab=b.dataset.v;
  if(b.dataset.pcb==='overpower')m.overpower=b.dataset.v;
  pcRender()});
