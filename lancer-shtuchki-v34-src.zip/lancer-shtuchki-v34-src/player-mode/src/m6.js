/* ---------- без ходов: отдельные кнопки НИП (v13) ---------- */
function npcBurn(i){
  const st=stOf(i);if(!(i.burn>0&&i.struct>0))return;
  const diff=hasCond(i,'Ослаблен')?1:0,a=accRoll(0,diff),d=rnd(20),tot=d+st.eng+a.val,ok=tot>=10;let txt;
  if(ok){i.burn=0;txt='Потушено — горение снято'}else{const o=takeHp(i,i.burn);txt=`Горит: −${i.burn} ПЗ${o?` (щит −${o})`:''} → ПЗ ${i.hp}`}
  addLog(ok?'hit':'miss',logHead(i.label+' — горение')+`<div style="display:flex;gap:10px;align-items:center"><span class="tot">${tot}</span><span class="verdict ${ok?'hit':'miss'}">${txt}</span></div><div class="bd">d20[${d}] ${sgn(st.eng)} Инж.${a.dice.length?` −${-a.val}[${a.dice}]`:''} vs 10</div><div class="bd">Неточн.: ${diff?'+1 — НИП Ослаблен (состояние)':'нет'} · Точн.: нет</div>`);
  if(!ok)checkHp(i);render();
}
function npcRegen(i){
  const st=stOf(i);if(i.struct<=0)return;
  if(i.enRound===S.round)addLog('miss',logHead(i.label+' — Регенератор')+`<div class="bd">Не сработал: в этом раунде получен энергетический урон.</div>`);
  else{const h=Math.ceil(st.hp/4),b=i.hp;i.hp=Math.min(st.hp,i.hp+h);if(i.hp>=st.hp)i.hideLost=false;
    addLog('hit',logHead(i.label+' — Регенератор')+`<div class="tot">+${i.hp-b}</div><div class="bd">¼ от ${st.hp} = ${h} → ПЗ ${i.hp}</div>`)}
  render();
}
function npcRecharge(i){
  const spent=instSystems(i).filter(s=>s.rc&&i.spent[s.id]);if(!spent.length)return;
  const r=rnd(6),ok=spent.filter(s=>r>=s.rc),no=spent.filter(s=>r<s.rc);ok.forEach(s=>i.spent[s.id]=false);
  addLog(ok.length?'hit':'miss',logHead(i.label+' — перезарядка')+`<div style="display:flex;gap:10px;align-items:center"><span class="tot">${r}</span><span>${ok.length?'<span class="verdict hit">Готово:</span> '+esc(ok.map(s=>s.name+' ('+s.rc+'+)').join(', ')):''}${no.length?' <span class="verdict miss">Нет:</span> '+esc(no.map(s=>s.name+' ('+s.rc+'+)').join(', ')):''}</span></div><div class="bd">Один d6 на все системы НИП (правило книги)</div>`);
  render();
}
function npcMeltdown(i){
  if(!i.meltdown)return;i.meltdown--;
  if(i.meltdown<=0){i.meltdown=0;const dmg=[rnd(6),rnd(6),rnd(6),rnd(6)];destroyNpc(i,'плавление реактора');addLog('miss',logHead(i.label+' — плавление реактора')+`<div class="bd">Взрыв 2: спасбросок Маневренности или ${dmg.reduce((a,b)=>a+b,0)} взр. (4d6 [${dmg.join(',')}]), половина при успехе</div>`)}
  else addLog('miss',logHead(i.label)+`<div class="bd">До плавления реактора: ${i.meltdown} ход(а)</div>`);
  render();
}
function npcTurnBtns(i){
  const sysl=instSystems(i),b=[];
  if(i.burn>0)b.push(`<button class="btn sm red" data-pa="nburn" data-uid="${i.uid}" data-tt="Проверка горения" data-tip="Проверка Инженерии 10+: успех — горение снято, провал — урон, равный горению (без Брони).">🔥 Горение ${i.burn}: проверка</button>`);
  if(sysl.some(s=>s.rc&&i.spent[s.id]))b.push(`<button class="btn sm" data-pa="nrech" data-uid="${i.uid}" data-tt="Перезарядка" data-tip="Один бросок d6 на все потраченные системы с Перезарядкой N+.">⟳ Перезарядка d6</button>`);
  if(sysl.some(s=>s.regen))b.push(`<button class="btn sm" data-pa="nregen" data-uid="${i.uid}" data-tt="Регенератор" data-tip="Лечит ¼ ПЗ, если в этом раунде не было энергетического урона.">✚ Регенерация</button>`);
  if(i.meltdown)b.push(`<button class="btn sm red" data-pa="nmelt" data-uid="${i.uid}">☢ Плавление: −1 ход (${i.meltdown})</button>`);
  return b.join('');
}
document.addEventListener('click',e=>{
  const el=e.target.closest('[data-pa]');if(!el)return;const a=el.dataset.pa;if(!['nburn','nrech','nregen','nmelt','nturn'].includes(a))return;
  const i=inst(el.dataset.uid);if(!i)return;
  if(a==='nturn'){const v=+el.dataset.v;i.turns=(i.turns||0)>=v?v-1:v;render();return}
  if(a==='nburn')npcBurn(i);else if(a==='nrech')npcRecharge(i);else if(a==='nregen')npcRegen(i);else npcMeltdown(i);
});
