/* ============================== v20: защита данных ==============================
   Всё, что приходит извне (импорт пилотов, Comp/Con, библиотеки НИП) и что лежит в
   хранилище браузера, пересобирается по белому списку полей: идентификаторы — только
   безопасные символы и только существующие в справочниках, числа — числа в допустимых
   пределах, текст — обрезается по длине. Плюс ограничения размера и «предохранитель»
   отрисовки, чтобы одна битая запись не ломала программу.                           */
const LIM={file:8e6,pilots:60,mechs:20,text:20000,name:200,arr:400,depth:12};
const safeId=v=>String(v??'').replace(/[^\w\-~#.:]/g,'').slice(0,120);
const num=(v,lo,hi,d)=>{const n=Number(v);return Number.isFinite(n)?Math.min(hi,Math.max(lo,Math.round(n))):d};
const str=(v,max)=>typeof v==='string'?v.slice(0,max||LIM.text):(typeof v==='number'?String(v):'');
const pick=(o,ok,f)=>{const r={};if(o&&typeof o==='object'&&!Array.isArray(o))Object.keys(o).slice(0,LIM.arr).forEach(k=>{const kk=safeId(k);if(kk&&ok(kk)){const v=f(o[k],kk);if(v!==undefined)r[kk]=v}});return r};
const DTS=['kin','en','exp','burn','heat'];
function cleanMech(raw){
  const m=newMech();if(!raw||typeof raw!=='object')return m;
  m.id=safeId(raw.id)||m.id;m.name=str(raw.name,LIM.name);m.frame=P.F[raw.frame]?raw.frame:m.frame;
  m.load=pick(raw.load,()=>true,v=>Array.isArray(v)?v.slice(0,4).map(x=>x&&P.W[x]?x:''):undefined);
  m.mods=pick(raw.mods,()=>true,v=>P.MO[v]?v:undefined);
  m.sh=pick(raw.sh,()=>true,v=>safeId(v)||undefined);
  m.systems=(Array.isArray(raw.systems)?raw.systems:[]).filter(x=>P.SY[x]).slice(0,40);
  m.retro=num(raw.retro,0,10,0);m.autostab=safeId(raw.autostab);m.overpower=safeId(raw.overpower);
  m.sigDt=pick(raw.sigDt,()=>true,v=>DTS.includes(v)?v:undefined);m.varDt=pick(raw.varDt,()=>true,v=>DTS.includes(v)?v:undefined);
  const pr=raw.proto||{};m.proto=newProto();
  if(PROTO_TYPES.includes(pr.type))m.proto.type=pr.type;if(DTS.includes(pr.dt))m.proto.dt=pr.dt;
  m.proto.lim=pr.lim==null?null:num(pr.lim,0,30,null);m.proto.rev=(Array.isArray(pr.rev)?pr.rev:[]).filter(x=>['optics','comp','reactor'].includes(x)).slice(0,3);
  return m}
function cleanAny(v,depth){ // для боевого состояния и прочего: только безопасные ключи/значения
  if(depth>LIM.depth)return undefined;
  if(v===null||typeof v==='boolean')return v;if(typeof v==='number')return Number.isFinite(v)?v:0;
  if(typeof v==='string')return safeId(v);
  if(Array.isArray(v))return v.slice(0,LIM.arr).map(x=>cleanAny(x,depth+1)).filter(x=>x!==undefined);
  if(typeof v==='object'){const r={};Object.keys(v).slice(0,LIM.arr).forEach(k=>{const kk=safeId(k);if(!kk||kk==='__proto__'||kk==='constructor'||kk==='prototype')return;const x=cleanAny(v[k],depth+1);if(x!==undefined)r[kk]=x});return r}
  return undefined}
function cleanCb(cb){if(!cb||typeof cb!=='object')return null;const c=cleanAny(cb,0);
  c.conds=(Array.isArray(cb.conds)?cb.conds:[]).filter(x=>CONDS.includes(x));
  ['hp','over','heat','struct','stress','rep','burn','cp','oc','phit','meltdown'].forEach(k=>{if(k in c)c[k]=num(c[k],-999,9999,0)});return c}
function cleanPilot(raw,keepCb){
  const p=newPilot();if(!raw||typeof raw!=='object')return p;
  p.id=safeId(raw.id)||p.id;p.name=str(raw.name,LIM.name)||p.name;p.callsign=str(raw.callsign,LIM.name);p.bg=str(raw.bg,LIM.text);p.notes=str(raw.notes,LIM.text);
  p.ll=num(raw.ll,0,12,0);
  p.skills=pick(raw.skills,k=>P.SK[k],v=>num(v,0,3,0)||undefined);
  p.custom=(Array.isArray(raw.custom)?raw.custom:[]).slice(0,30).map(c=>({name:str(c&&c.name,LIM.name),rank:num(c&&c.rank,0,3,0)}));
  p.talents=pick(raw.talents,k=>P.T[k],v=>num(v,0,3,0)||undefined);
  p.hase=Object.fromEntries(['hull','agi','sys','eng'].map(k=>[k,num(raw.hase&&raw.hase[k],0,6,0)]));
  p.lic=pick(raw.lic,k=>P.F[k],v=>num(v,0,3,0)||undefined);
  p.cbs=[...new Set((Array.isArray(raw.cbs)?raw.cbs:[]).filter(x=>P.CB[x]))];
  const g=raw.gear||{},gid=x=>x&&P.G[x]?x:'';
  p.gear={armor:gid(g.armor),weapons:(Array.isArray(g.weapons)?g.weapons:[]).slice(0,4).map(gid),items:(Array.isArray(g.items)?g.items:[]).slice(0,6).map(gid)};
  while(p.gear.weapons.length<2)p.gear.weapons.push('');while(p.gear.items.length<3)p.gear.items.push('');
  p.sigDt=pick(raw.sigDt,k=>P.G[k],v=>DTS.includes(v)?v:undefined);
  p.mechs=(Array.isArray(raw.mechs)&&raw.mechs.length?raw.mechs:[null]).slice(0,LIM.mechs).map(cleanMech);
  p.mech=num(raw.mech,0,p.mechs.length-1,0);
  p.bgId=(PCD.backgrounds||[]).some(b=>b.id===raw.bgId)?raw.bgId:'';
  p.reserves=(Array.isArray(raw.reserves)?raw.reserves:[]).slice(0,60).map(r=>r&&typeof r==='object'?{id:r.id==='custom'||P.RS[r.id]?r.id:'custom',name:str(r.name,LIM.name),note:str(r.note,2000),used:!!r.used,item:safeId(r.item),n:num(r.n,0,10,1),skill:safeId(r.skill)}:null).filter(Boolean);
  p.cb=keepCb?cleanCb(raw.cb):null;
  return p}
/* импорт пилотов: размер, количество, очистка; битый пилот отбрасывается, а не ломает лист */
function pilotRenders(p){const keep={sel:PS.sel,pilots:PS.pilots,tab:PS.tab};try{PS.pilots=[...keep.pilots,p];PS.sel=p.id;['pilot','mech','combat'].forEach(t=>{PS.tab=t;viewPc()});return true}catch(e){return e.message}finally{PS.sel=keep.sel;PS.pilots=keep.pilots;PS.tab=keep.tab}}
{const om=migratePilot;migratePilot=function(x){om(x);const c=cleanPilot(x,false);Object.keys(x).forEach(k=>delete x[k]);Object.assign(x,c)}}
{const o=pcImportText;pcImportText=function(txt){
  txt=String(txt||'');if(txt.length>LIM.file){toast(`Файл слишком большой (${Math.round(txt.length/1e6)} МБ). Пилоты весят килобайты — это не файл пилота.`);return 0}
  let d;try{d=JSON.parse(txt.replace(/^﻿/,'').trim().replace(/^[^\[{]*/,''))}catch(err){toast('Ошибка JSON: '+err.message);return 0}
  if(Array.isArray(d)&&d.length>LIM.pilots){toast(`В файле ${d.length} записей — больше ${LIM.pilots} за раз не импортирую.`);return 0}
  const keepP=PS.pilots.slice(),keepSel=PS.sel;let n;
  try{n=o(JSON.stringify(d))}catch(e){PS.pilots=keepP;PS.sel=keepSel;toast('Файл не удалось прочитать: '+e.message);pcRender();return 0}
  const bad=[];PS.pilots=PS.pilots.filter(p=>{if(keepP.includes(p))return true;const r=pilotRenders(p);if(r===true)return true;bad.push((p.callsign||p.name)+': '+r);return false});
  if(bad.length){if(!PS.pilots.some(p=>p.id===PS.sel))PS.sel=keepSel;toast('Пропущено повреждённых пилотов: '+bad.length);addLog('miss',logHead('Импорт: пропущено')+`<div class="bd">${bad.map(esc).join('<br>')}</div>`);pcRender()}
  return n-bad.length}}
/* что уже лежит в браузере — тоже через очистку (боевое состояние сохраняется) */
const PS_RAW=JSON.stringify((Array.isArray(PS.pilots)?PS.pilots:[]).slice(0,200)); // исходник: окончательная очистка — в m29, когда все модули добавят свои поля
PS.pilots=JSON.parse(PS_RAW).map(p=>cleanPilot(p,true));
if(!PS.pilots.some(p=>p.id===PS.sel))PS.sel=PS.pilots[0]?PS.pilots[0].id:null;
if(!['pilot','mech','combat','bond'].includes(PS.tab))PS.tab='pilot';
if(!['lib','enc','pc','ref','gm','fleet','tok'].includes(S.view))S.view='lib';

/* библиотека НИП: идентификаторы, размер, глубина; класс, который не рисуется, не добавляется */
function cleanNpcTree(v,depth,key){
  if(depth>LIM.depth)return undefined;
  if(v===null||typeof v==='boolean')return v;if(typeof v==='number')return Number.isFinite(v)?v:0;
  if(typeof v==='string')return ['id','uid','w','kind','type','dt','cls'].includes(key)?safeId(v):v.slice(0,LIM.text);
  if(Array.isArray(v))return v.slice(0,LIM.arr).map(x=>cleanNpcTree(x,depth+1,'')).filter(x=>x!==undefined);
  if(typeof v==='object'){const r={};Object.keys(v).slice(0,LIM.arr).forEach(k=>{const kk=safeId(k);if(!kk||kk==='__proto__'||kk==='constructor'||kk==='prototype')return;const x=cleanNpcTree(v[k],depth+1,kk);if(x!==undefined)r[kk]=x});return r}
  return undefined}
{const o=doImport;doImport=function(){const el=document.getElementById('io');if(!el)return o();
  if(el.value.length>LIM.file){toast('Слишком большой текст для библиотеки НИП');return}
  let d;try{d=JSON.parse(el.value)}catch(err){toast('Ошибка JSON: '+err.message);return}
  const arr=(Array.isArray(d)?d:[d]).slice(0,200).map(x=>cleanNpcTree(x,0,''));
  const keepC=S.custom.slice(),keepT=S.customTpl.slice(),keepCls=S.cls;el.value=JSON.stringify(arr);o();
  const bad=[];S.custom=S.custom.filter(c=>{if(keepC.includes(c))return true;try{const k=S.cls;S.cls=c.id;viewLib();S.cls=k;return true}catch(e){bad.push(c.name+': '+e.message);return false}});
  if(bad.length){if(!S.custom.some(c=>c.id===S.cls)&&!BUILTIN.some(c=>c.id===S.cls)){const nw=S.custom.filter(c=>!keepC.includes(c));S.cls=nw.length?nw[nw.length-1].id:keepCls}toast('Пропущено повреждённых классов: '+bad.length);render()}}}
S.custom=(Array.isArray(S.custom)?S.custom:[]).map(c=>cleanNpcTree(c,0,'')).filter(c=>c&&c.id&&Array.isArray(c.tiers));
S.customTpl=(Array.isArray(S.customTpl)?S.customTpl:[]).map(c=>cleanNpcTree(c,0,'')).filter(c=>c&&c.id);

/* предохранитель: ошибка отрисовки не оставляет пустой экран */
{const o=renderMain;renderMain=function(){try{o()}catch(e){const m=document.getElementById('main');
  m.innerHTML=`<div class="crashbox"><h2>Этот раздел не отрисовался</h2><p>Скорее всего, повреждены данные${S.view==='pc'?' текущего пилота':S.view==='lib'?' выбранного класса':''}. Остальное в порядке.</p><pre>${esc(String(e&&e.message||e))}</pre>
   <div class="row-btns"><button class="btn" data-act="view" data-v="ref">Открыть Справочник</button>${S.view==='pc'&&curP()?'<button class="btn red" data-crash="delpilot">Удалить этого пилота</button>':''}${S.view==='lib'&&S.custom.some(c=>c.id===S.cls)?'<button class="btn red" data-crash="delcls">Удалить этот класс</button>':''}</div></div>`;
  console.error(e)}}}
{const o=renderSide;renderSide=function(){try{o()}catch(e){document.getElementById('side').innerHTML='<div class="crashbox">Список не отрисовался: '+esc(String(e&&e.message||e))+'</div>';console.error(e)}}}
document.addEventListener('click',e=>{const b=e.target.closest('[data-crash]');if(!b)return;if(!armed(b,'Удалить'))return;
  if(b.dataset.crash==='delpilot'){PS.pilots=PS.pilots.filter(p=>p.id!==PS.sel);PS.sel=PS.pilots[0]?PS.pilots[0].id:null;pcSave()}
  else{S.custom=S.custom.filter(c=>c.id!==S.cls);S.cls=BUILTIN[0].id}
  render()});
