/* ---------- v17: выбор роли при входе — «Я игрок» (только раздел игроков) / «Я ГМ» (всё) ---------- */
let ROLE=null;
const isPlayer=()=>ROLE==='player';
function roleGate(){
  let o=document.getElementById('rolegate');if(o)return;
  o=document.createElement('div');o.id='rolegate';
  o.innerHTML=`<div class="rg-box"><div class="rg-logo">ЛАНСЕРОВСКИЕ<span>//</span>ШТУЧКИ <span class="rg-ver">${esc(APP_VERSION)}</span></div>
    <div class="rg-q">Кто вы?</div>
    <div class="rg-btns"><button class="rg-btn" data-role="player"><b>Я игрок</b><small>лист пилота, сборка меха, броски и бой своего меха, справочник правил</small></button>
    <button class="rg-btn gm" data-role="gm"><b>Я ГМ</b><small>всё: библиотека НИП, бой с НИП, игроки, справочник и случайные таблицы</small></button></div>
    <div class="rg-note">Сменить роль можно кнопкой в шапке. Данные пилотов и НИП сохраняются в этом браузере.</div>
    <div class="rg-legal">Неофициальный некоммерческий фанатский инструмент: распространяется бесплатно, не продаётся и не связан с Massif Press.<br>
    «Лансеровские штучки» is not an official Lancer product; it is a third party work, and is not affiliated with Massif Press.
    «Лансеровские штучки» is published via the Lancer Third Party License. Lancer is copyright Massif Press.<br>
    Спасибо Massif Press за систему и вселенную Lancer. Названия, правила, тексты и иллюстрации книг Lancer и дополнений принадлежат Massif Press и их авторам.</div></div>`;
  document.body.appendChild(o);
}
function setRole(r){ROLE=r;const o=document.getElementById('rolegate');if(o)o.remove();
  document.body.classList.toggle('role-player',r==='player');if(r==='player')S.view='pc';render()}
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-role]');if(b){setRole(b.dataset.role);return}
  if(e.target.closest('[data-act="rolechange"]')){ROLE=null;document.body.classList.remove('role-player');roleGate();return}
  if(isPlayer()){const v=e.target.closest('[data-act="view"]');if(v&&!['pc','ref','fleet','tok'].includes(v.dataset.v)){e.stopImmediatePropagation();e.preventDefault()}}
},true);
{const o=renderTabs;renderTabs=function(){if(isPlayer()&&S.view!=='pc')S.view='pc';o();
  const t=document.getElementById('tabs');if(!t)return;
  if(isPlayer())t.querySelectorAll('[data-act="view"]:not([data-v="pc"]):not([data-v="ref"])').forEach(x=>x.remove());
  if(ROLE)t.insertAdjacentHTML('beforeend',`<button class="tab rolechip" data-act="rolechange" title="Сменить роль">${isPlayer()?'🎮 Игрок':'🎲 ГМ'} ⇄</button>`)}}
{const o=renderMain;renderMain=function(){if(isPlayer()&&S.view!=='pc')S.view='pc';o()}}
{const o=renderSide;renderSide=function(){if(isPlayer()&&S.view!=='pc')S.view='pc';o()}}
roleGate();
