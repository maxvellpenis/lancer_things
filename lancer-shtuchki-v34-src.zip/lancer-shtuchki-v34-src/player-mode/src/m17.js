/* ============================== v22: Battlegroup — обработчики ============================== */
function bgPcAtk(u,key,mode){const x=bgPcItems(u).find(y=>y.key===key);if(!x)return;const it=x.it;
  const a={mode,from:u.uid,ckey:'w:'+key,name:it.ru,it:{id:it.id,en:it.en},tg:it.tg||{},cat:it.cat,dmg:it.dmg,rng:it.rng,tgs:bgWTags(it),pl:it.tg.pl,at:!!it.tg.at,ok:!!it.tg.ok,dark:it.id==='darkstar',acc:0,dif:0,flat:0,lock:true,off:{},res:null,extra:''};
  const ng=BB().units.find(o=>o.kind==='npc');if(ng){a.tgt=ng.uid;const s=ng.ships.find(s=>!s.dead&&!s.wing);a.sid=s?s.sid:''}
  if(it.id==='pjk')a.extra='Попадание или промах: в фазе удара ещё 5 урона **другому** капитальному кораблю или эскорту группы цели (нанесите вручную).';
  if(it.id==='mat')a.extra='Можно также нанести 3 урона вражескому эскорту (не цели) или до двух вражеских крыльев.';
  if(it.id==='block')a.extra='Счётчики залпа: +6 урона и Надёжное +2 за каждый (добавьте плоским бонусом урона вручную).';
  if(it.id==='lamprey')a.extra='При уроне по капитальному кораблю — эффект успешного абордажа (Саботаж / Обрыв связи / Штурм БИЦ) на выбор.';
  BGS.atk=a}
function bgNpcAtk(u,key,mode){const x=bgNpcItems(u).find(y=>y.key===key);if(!x)return;const it=x.it,t=bgNpcTg(it);
  const a={mode,from:u.uid,ckey:'n:'+key,owner:x.owner,name:it.n,it:{en:it.en},tg:{acc:t.acc,inacc:t.inacc,crit:t.crit,rel:t.rel,ok:t.ok,ch:t.ch,sh:t.sh,rl:t.rl,lim:t.lim},cat:t.sh?'sh':'pr',dmg:it.dmg,rng:it.rng,tgs:it.tg,pl:t.pl,at:t.at,ok:t.ok,acc:0,dif:0,flat:0,lock:true,off:{},res:null,extra:it.t};
  const pg=BB().units.find(o=>o.kind==='pc');if(pg){a.tgt=pg.uid;const s=pg.ships.find(s=>!s.dead);a.sid=s?s.sid:''}
  BGS.atk=a}
function bgArea(){const a=BGS.atk;if(!a)return;const att=bgU(a.from),tu=bgU(a.tgt);if(!att||!tu){toast('Выберите цель');return}
  const r=bgRoll(a.dmg,{ok:a.ok});const band=att.kind==='pc'?att.band:tu.band;let d=bgAreaBand(band,r.tot);let cut=0;
  if(band!==0){cut=bgIntRoll(tu,a.name)}const left=Math.max(0,d-cut);let hit=[];if(left>0)hit=bgApplyArea(tu,left);
  bgLog('hit',`${a.name} → ${tu.name} (по площади)`,`${esc(r.txt)} = ${r.tot}${d!==r.tot?` → ${d} (диапазон)`:''}, Перехват −${cut} → <b>${left}</b>${hit.length?'<br>'+esc(hit.join(', ')):''}`);
  const c=att.c[a.ckey];if(c&&a.tg&&a.tg.rl)c.rl=a.tg.rl;BGS.atk=null}
function bgFromV(v){const [uid,...rest]=String(v).split('|');return{u:bgU(uid),rest}}
document.addEventListener('click',e=>{const b=e.target.closest('[data-bg]');if(!b)return;const k=b.dataset.bg,v=b.dataset.v||'',d=+(b.dataset.d||0);
  const g=bgGroup(BGS.cur);const sp=v.split('|');const u=bgU(sp[0]);
  switch(k){
  case 'tab':BGS.tab=v;BGS.atk=null;break;
  case 'cat':BGS.cat=v;break;
  case 'gnew':bgNewGroup();BGS.tab='build';break;
  case 'gsel':BGS.cur=v;BGS.tab='build';break;
  case 'gdel':if(!g||!armed(b,'Удалить группу «'+g.name+'»'))return;BGS.groups=BGS.groups.filter(x=>x!==g);BGS.cur=(BGS.groups[0]||{}).id||null;break;
  case 'gcopy':if(!g)return;{const c=bgClean(JSON.parse(JSON.stringify(g)));c.name=g.name+' (копия)';BGS.groups.push(c);BGS.cur=c.id}break;
  case 'gexport':if(!g)return;{const data=JSON.stringify({format:'ulan-battlegroup',v:1,group:g},null,1);const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:'application/json'}));a.download=(g.name||'group').replace(/[^\wа-яё\- ]/gi,'_')+'.bg.json';document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)}return;
  case 'shipadd':if(!g)return;{const sel=document.querySelector('[data-bgf="addhull"]');if(sel&&BH[sel.value])bgNewShip(g,sel.value)}break;
  case 'shipaddh':if(!g||!BH[v])return;bgNewShip(g,v);toast('Добавлен: '+BH[v].ru);break;
  case 'shipdel':if(!g)return;g.ships=g.ships.filter(s=>s.id!==v);if(g.ships.length&&!g.ships.some(s=>s.flag))g.ships[0].flag=true;break;
  case 'shipup':if(!g)return;{const i=g.ships.findIndex(s=>s.id===v);if(i>0)[g.ships[i-1],g.ships[i]]=[g.ships[i],g.ships[i-1]]}break;
  case 'flag':if(!g)return;g.ships.forEach(s=>s.flag=s.id===v);break;
  /* бой */
  case 'next':bgNextPhase();break;
  case 'breset':if(!armed(b,'Сбросить бой (участники удаляются)'))return;BGS.battle={round:1,phase:0,ticked:0,started:false,units:[],pls:[],brd:[]};BGS.atk=null;break;
  case 'addpc':{const gg=bgGroup((BGS.add||{}).g)||BGS.groups[0];if(!gg){toast('Сначала соберите группу');return}if(!gg.ships.length){toast('В группе нет кораблей');return}BB().units.push(bgUnitPc(gg,(BGS.add||{}).band??4));bgLog('',`В бой вступает ${gg.name}`,'')}break;
  case 'addnpc':{const a=BGS.add||{};const capId=a.cap||BG.npcCap[0].id;const es=[a.e0,a.e1,a.e2].filter(Boolean);
    if(es.filter(id=>BNE[id].tpl).length>1){toast('Шаблон — только один на корабль');return}
    if(es.filter(id=>BNE[id].uniq).some((id,i,arr)=>arr.indexOf(id)!==i)){toast('Уникальный эскорт — один на группу');return}
    const nu=bgUnitNpc(capId,es,a.ace,a.name);if(nu){BB().units.push(nu);bgLog('',`В бой вступает НИП: ${nu.name}`,'')}}break;
  case 'band':if(u){const nb=+sp[1];if(BB().round>=6&&BB().started){const lim=BB().round>=8?0:BB().round===7?2:4;if(nb>lim){toast('Гир сжался: дальше '+BG_BAND[lim]+' нельзя');return}}u.band=nb}break;
  case 'mv':if(u){const nb=Math.max(0,Math.min(5,u.band+(+sp[1])));u.band=nb}break;
  case 'retro':if(u){u.band=Math.min(5,u.band+1);u.bolst=true;bgLog('',`${u.name}: «Обратная тяга»`,'Отход на диапазон (или игнор следующего перемещения — тогда верните диапазон вручную), группа Укреплена до конца следующего хода.')}break;
  case 'ram':if(u){if(u.band>1){toast('«Таран» — только с Ближней или в упор');return}u.band=0;const r1=bgRoll('2d6'),r2=bgRoll('2d6');bgLog('hit',`${u.name}: «Таран»`,`Группа в упор. Ваш капитальный корабль получает ${r1.tot} (${esc(r1.txt)}), вражеский — ${r2.tot} (${esc(r2.txt)}). Урон нельзя предотвратить — нанесите кнопкой «Урон⇣».`)}break;
  case 'purge':if(u){const n=BB().brd.filter(r=>r.tgt===u.uid).length;BB().brd.filter(r=>r.tgt===u.uid).forEach(r=>bgRecall(r.id,true));bgLog('',`${u.name}: зачистка`,`Выбито абордажных отрядов: ${n}.`)}break;
  case 'ungrey':if(u){u.ships.forEach(s=>s.grey=0);bgLog('',`${u.name}: Грейвош снят`,'')}break;
  case 'bolst':if(u)u.bolst=!u.bolst;break;
  case 'int':if(u)bgIntRoll(u);break;
  case 'coin':{const r=rnd(2)===1;bgLog(r?'hit':'miss','Оборонительный заслон',r?'<b>Перехвачено</b>: атакующий отменяет действие или бьёт по фрегату заслона.':'Не перехвачено — атака идёт по прикрытому кораблю.')}break;
  case 'bankacc':if(u)u.acc=Math.max(0,(u.acc||0)+d);break;
  case 'bankdif':if(u)u.dif=Math.max(0,(u.dif||0)+d);break;
  case 'bank':if(u&&u.acc>0&&BGS.atk){u.acc--;BGS.atk.acc=(+BGS.atk.acc||0)+1}break;
  case 'eject':if(!u)return;if(BB().round<5&&BB().started&&!armed(b,'До 5-го раунда выброс невозможен. Всё равно убрать?'))return;if(BB().round>=8&&!armed(b,'С 8-го раунда отступать нельзя. Всё равно?'))return;if(u.kind==='pc'&&u.band===0&&BB().round>=6&&!armed(b,'Из «в упор» с 6-го раунда уйти нельзя. Всё равно?'))return;if(BB().round>=5&&!armed(b,'Уйти выбросом'))return;bgLeave(u.uid,'eject');break;
  case 'surr':if(!u||!armed(b,'Сдаться'))return;bgLeave(u.uid,'surr');break;
  case 'lock':{const s=bgShip(u,sp[1]);if(s)s.lock=!s.lock}break;
  case 'grey':{const s=bgShip(u,sp[1]);if(s)s.grey=Math.max(0,(s.grey||0)+d)}break;
  case 'dfx':{const s=bgShip(u,sp[1]);if(s)s.dfx=(+s.dfx||0)+d}break;
  case 'dmg':case 'dmgos':case 'heal':case 'os':{const s=bgShip(u,sp[1]);const n=+((BGS.dmgv||{})[v]||0);if(!s||!n){toast('Введите число');return}
    if(k==='heal')bgHeal(u,s,n);else if(k==='os')s.os=Math.max(s.os||0,n);else{bgDamage(u,s,n,{ios:k==='dmgos'});bgLog('',`${s.name}: −${n} ПЗ`,`${esc(u.name)} · осталось ${s.hp}/${s.max}${s.os?' +'+s.os+' Сверхщит':''}`)}
    (BGS.dmgv||{})[v]='';}break;
  case 'uhp':{const c=u&&u.c['u:'+sp.slice(1).join('|')];if(c){c.hp=Math.max(0,Math.min(c.max,c.hp+d));c.dead=c.hp<=0}}break;
  case 'uused':{const c=u&&u.c['u:'+sp.slice(1).join('|')];if(c)c.used=!c.used}break;
  case 'abuse':{const [uid,key,lim]=[sp[0],sp.slice(1,-1).join('|'),+sp[sp.length-1]];const c=u.c['a:'+key]=u.c['a:'+key]||{used:0,rl:0};c.used=c.used>=lim?0:(c.used||0)+1}break;
  case 'abrl':{const key=sp.slice(1,-1).join('|'),rl=+sp[sp.length-1];const c=u.c['a:'+key]=u.c['a:'+key]||{used:0,rl:0};c.rl=c.rl?0:rl}break;
  case 'wg':{const [uid,wk,i]=sp;const w=u&&u.c[wk];if(w){w.hp[+i]=Math.max(0,w.hp[+i]+d)}}break;
  case 'omni':if(u)u.omni=Math.max(0,Math.min(6,(u.omni||0)+d));break;
  case 'omni-fire':if(u){bgLog('hit',`${u.name}: Омнипушка «Наофорос»`,`Наносит <b>${u.omni||0}</b> урона капитальному кораблю или эскорту — автоматически, нельзя предотвратить. Нанесите кнопкой «Урон⇣» на цели.`)}break;
  case 'nch':{const c=u&&u.c['n:'+sp.slice(1).join('|')];if(c)c.ch=Math.max(0,c.ch+d)}break;
  case 'nrl':{const key=sp.slice(1,-1).join('|'),rl=+sp[sp.length-1];const c=u&&u.c['n:'+key];if(c)c.rl=c.rl?0:rl}break;
  case 'nlim':{const key=sp.slice(1,-1).join('|'),lim=+sp[sp.length-1];const c=u&&u.c['n:'+key];if(c)c.lim=c.lim>=lim?0:(c.lim||0)+1}break;
  case 'watk':if(u)bgPcAtk(u,sp.slice(1).join('|'),'atk');break;
  case 'wlaunch':if(u)bgPcAtk(u,sp.slice(1).join('|'),'launch');break;
  case 'warea':if(u)bgPcAtk(u,sp.slice(1).join('|'),'area');break;
  case 'whold':{const key=sp.slice(1).join('|');const x=bgPcItems(u).find(y=>y.key===key);const c=u.c['w:'+key];if(x&&c){c.ch=x.it.tg.ch;bgLog('',`${x.it.ru}: заряд сброшен`,'')}}break;
  case 'natk':if(u)bgNpcAtk(u,sp.slice(1).join('|'),'atk');break;
  case 'nlaunch':if(u)bgNpcAtk(u,sp.slice(1).join('|'),'launch');break;
  case 'narea':if(u)bgNpcAtk(u,sp.slice(1).join('|'),'area');break;
  case 'skipstart':{const c=u&&u.c['w:'+sp.slice(1).join('|')];if(c){c.skip={on:true};c.ch=2;bgLog('','Прыжковый дрон: зарядка начата','Выберите цель — вражеский капитальный корабль (назовите её). Должен сработать сразу, как зарядится.')}}break;
  case 'skipfire':{const c=u&&u.c['w:'+sp.slice(1).join('|')];if(c){const d20=rnd(20);const hit=d20>=10;const a=bgRoll(hit?'3d6':'1d6+1'),e2=hit?bgRoll('1d6+1'):null;c.skip={on:false};c.lim=1;
    bgLog(hit?'hit':'miss','Прыжковый дрон «Сквозная линия»',`d20 [${d20}] — ${hit?`<b>попадание</b>: ${a.tot} урона цели (${esc(a.txt)}) и ${e2.tot} урона всем эскортам её группы`:`окно упущено: ${a.tot} урона цели (${esc(a.txt)})`}. Нанесите урон на цели.`)}}break;
  case 'atkclose':BGS.atk=null;break;
  case 'atkn':if(BGS.atk)BGS.atk[v]=(+BGS.atk[v]||0)+d;break;
  case 'atkroll':bgDoAttack();break;
  case 'atkapply':bgApplyAtk();break;
  case 'launch':{const a=BGS.atk;if(!a||!a.tgt){toast('Выберите цель');return}bgLaunch({from:a.from,ckey:a.ckey,name:a.name,tgt:a.tgt,sid:a.sid,dmg:a.dmg,at:a.at,ok:a.ok,pl:a.pl,dark:a.dark});
    const att=bgU(a.from);const c=att&&att.c[a.ckey];if(c&&a.tg&&a.tg.rl)c.rl=a.tg.rl;if(c&&a.tg&&a.tg.lim)c.lim=(c.lim||0)+1;BGS.atk=null}break;
  case 'area':bgArea();break;
  case 'impact':bgResolveImpact(v);break;
  case 'fc':{const p=BB().pls.find(x=>x.id===v);if(p)p.fc=Math.max(0,p.fc+d)}break;
  case 'pldel':{const p=BB().pls.find(x=>x.id===v);if(p){const f=bgU(p.from);const c=f&&f.c[p.ckey];if(c&&c.busy===p.id)c.busy='';BB().pls=BB().pls.filter(x=>x!==p);bgLog('',`${p.name}: подорвана/уничтожена`,'')}}break;
  case 'broll':bgBoardRoll(v);break;
  case 'brepel':bgRepel(v);break;
  case 'brecall':bgRecall(v);break;
  case 'hardreset':if(!armed(b,'Сбросить все данные флота'))return;Object.assign(BGS,{tab:'build',cur:null,groups:[],battle:{round:1,phase:0,ticked:0,units:[],pls:[],brd:[]},atk:null,add:{}});break;
  default:return}
  bgRender()});
document.addEventListener('change',e=>{const el=e.target.closest('[data-bgf]');if(!el)return;const f=el.dataset.bgf,v=el.dataset.v||'';const g=bgGroup(BGS.cur);const val=el.value;
  if(f==='gname'&&g)g.name=val.slice(0,120);else if(f==='gcmdr'&&g)g.cmdr=val.slice(0,120);else if(f==='gtraits'&&g)g.traits=val.slice(0,600);else if(f==='gnotes'&&g)g.notes=val.slice(0,4000);
  else if(f==='sname'&&g){const s=g.ships.find(x=>x.id===v);if(s)s.name=val.slice(0,120)}
  else if(f==='slot'&&g){const [sid,k,j]=v.split('|');const s=g.ships.find(x=>x.id===sid);if(s){s.eq[k]=s.eq[k]||[];s.eq[k][+j]=bgItem(k,val)?val:''}}
  else if(f==='modk'&&g){const s=g.ships.find(x=>x.id===v);if(s)s.eq.mod={k:val,id:''}}
  else if(f==='modid'&&g){const s=g.ships.find(x=>x.id===v);if(s){const mk=(s.eq.mod&&s.eq.mod.k)||bgModKinds(s)[0];s.eq.mod={k:mk,id:bgItem(mk,val)?val:''}}}
  else if(f==='ace'&&g){const [sid,j]=v.split('|');const s=g.ships.find(x=>x.id===sid);if(s){s.ace=s.ace||[];s.ace[+j]=BAU[val]?val:''}}
  else if(f==='addhull')return;
  else if(f==='import'){const file=el.files&&el.files[0];if(!file)return;if(file.size>2e6){toast('Файл слишком большой');return}
    file.text().then(t=>{let raw;try{raw=JSON.parse(t)}catch(x){toast('Не JSON');return}const src=raw&&raw.group?raw.group:raw;const ng=bgClean(src);if(!ng||!ng.ships.length){toast('Не похоже на группу Battlegroup');return}
      BGS.groups.push(ng);BGS.cur=ng.id;BGS.tab='build';toast('Группа импортирована');bgRender()});return}
  else if(f.startsWith('add.')){BGS.add=BGS.add||{};BGS.add[f.slice(4)]=val}
  else if(f==='dmgv'){BGS.dmgv=BGS.dmgv||{};BGS.dmgv[v]=val;bgSave();return}
  else if(f==='atk.tgt'&&BGS.atk){const [uid,sid]=val.split('|');BGS.atk.tgt=uid;BGS.atk.sid=sid;BGS.atk.res=null;BGS.atk.off={}}
  else if(f==='atk.unit'&&BGS.atk){BGS.atk.tgt=val;BGS.atk.sid=''}
  else if(f==='atk.off'&&BGS.atk){BGS.atk.off=BGS.atk.off||{};BGS.atk.off[v]=!el.checked}
  else if(f==='atk.lock'&&BGS.atk)BGS.atk.lock=el.checked;
  else if(f==='bcmd'){const r=BB().brd.find(x=>x.id===v);if(r)r.cmd=val}
  else if(f==='brdt'){const [uid,...key]=v.split('|');const u=bgU(uid);const [tuid,sid]=val.split('|');const x=u&&bgPcItems(u).find(y=>y.key===key.join('|'));if(x&&tuid){
      let ten=x.it.ten||0;if(x.id==='ace')ten=13;if(x.s.hull==='tawa')ten+=2;bgBoard({from:uid,ckey:'u:'+x.key,name:x.it.ru,ten,tgt:tuid,sid})}}
  else if(f==='nbrd'){const p=v.split('|');const uid=p[0],ck=p[1],ten=+p[2],nm=p[3]||'Абордажники НИП';const [tuid,sid]=val.split('|');if(tuid)bgBoard({from:uid,ckey:'',name:nm,ten,tgt:tuid,sid})}
  else return;
  bgRender()});
document.addEventListener('input',e=>{const el=e.target.closest('[data-bgf="dmgv"]');if(el){BGS.dmgv=BGS.dmgv||{};BGS.dmgv[el.dataset.v]=el.value}});
