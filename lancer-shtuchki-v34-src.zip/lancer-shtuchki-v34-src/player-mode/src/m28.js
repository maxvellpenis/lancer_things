/* ============================== v32: «Operation Solstice Rain» ==============================
   Снаряжение игроков (рама Чомолунгма, таланты Подрывник и Сисоп, экзотика, резервы) — в pcdata.
   Здесь: таблица резервов, корабль «Эбро» для «Флота», автоматика, раздел Справочника. Сюжетное (бои, персонажи, база) не включено. */
BOOKS.SR={name:'Operation Solstice Rain',ru:'Операция «Дождь Солнцестояния»',full:'Модуль «Lancer: Operation Solstice Rain» (Kai Tave, Massif Press)'};
BK_RX.push(['SR',/solstice rain|солнцестояни/i]);
const SRGMT=/*@@SRGMT@@*/null||[];
const SR_CHO='mf_chomolungma',SR_ADJ='ms_adjutant_class_compcon';

/* ---------- таблица ГМа ---------- */
{const bi=GMT.findIndex(t=>t.book==='BG');GMT.splice(bi<0?GMT.length:bi,0,...SRGMT.filter(t=>!GMT.some(x=>x.id===t.id)))}

/* ---------- «Флот»: лёгкий авианосец «Эбро» ---------- */
const SR_EBRO={id:'ebro',cls:'cv',mf:'GMS',en:'Ebro-class Light Carrier',ru:'Эбро',pts:3,hp:14,df:15,sl:{wing:2},page:46,book:'SR',scr:1,
 d:'Лёгкий авианосец сопровождения времён Второй Экспансии: быстрый и гибкий, несёт крылья ударных аппаратов и годится и для флота, и для патрулей.',
 tr:[{n:'Строй Сопровождения',en:'Escort Formation',t:'Этот корабль можно назначить в **Оборонительный заслон**, как если бы он был **фрегатом**.',k:'trait'}]};
try{if(!BG.hulls.some(h=>h.id===SR_EBRO.id)){BG.hulls.push(SR_EBRO);BH[SR_EBRO.id]=SR_EBRO}}catch(e){}
{const o=bgHullCard;bgHullCard=function(h,mini){const r=o(h,mini);return h&&h.book==='SR'?r.replace(/<span class="srcmark"[^>]*>[^<]*<\/span>/,srcTag('SR',h.page)):r}}

/* ---------- АДЪЮТАНТ: ранг таланта, пока вы в этом мехе ---------- */
const srAdjId=(p,m)=>{try{if(!m||!(m.systems||[]).includes(SR_ADJ)||!m.adjT||!P.T[m.adjT])return '';
  const c=p.cb&&p.cb.mechId===m.id?p.cb:null,i=m.systems.indexOf(SR_ADJ);if(c&&c.destroyed&&c.destroyed['s'+i+'-'+SR_ADJ])return '';
  return (p.talents[m.adjT]||0)<3?m.adjT:''}catch(e){return ''}};
let srAdjDepth=0,srAdjCur=null;
const srAdjUndo=c=>{if(c.had)c.p.talents[c.id]=c.old;else delete c.p.talents[c.id]};
function srWithAdj(p,m,fn){const id=srAdjDepth?'':srAdjId(p,m);if(!id)return fn();
  const c={p,id,had:Object.prototype.hasOwnProperty.call(p.talents,id),old:p.talents[id]};p.talents[id]=(c.old||0)+1;srAdjDepth++;srAdjCur=c;
  try{return fn()}finally{srAdjDepth--;srAdjCur=null;srAdjUndo(c)}}
{const o=mechStats;mechStats=function(p,m){return srWithAdj(p,m,()=>o(p,m))}}
{const o=pcBaseMods;pcBaseMods=function(p,k,opt){return srWithAdj(p,curM(p),()=>o(p,k,opt))}}
{const o=weaponTalentMods;weaponTalentMods=function(p,w,t){return srWithAdj(p,curM(p),()=>o(p,w,t))}}
{const o=viewCombat;viewCombat=function(p){return srWithAdj(p,curM(p),()=>o(p))}}
{const o=pcOpenWeapon;pcOpenWeapon=function(p,uid){return srWithAdj(p,curM(p),()=>o(p,uid))}}
{const o=pcOpenCheck;pcOpenCheck=function(p,s){return srWithAdj(p,curM(p),()=>o(p,s))}}
{const o=budgets;budgets=function(p){const c=srAdjCur;if(!c||c.p!==p)return o(p);srAdjUndo(c);try{return o(p)}finally{c.p.talents[c.id]=(c.old||0)+1}}} // бюджет талантов — без загруженного ранга
{const o=cleanMech;cleanMech=function(raw){const m=o(raw);try{m.adjT=raw&&P.T[raw.adjT]?raw.adjT:''}catch(e){m.adjT=''}return m}}
{const o=viewMech;viewMech=function(p){let h=o(p);try{const m=curM(p);if((m.systems||[]).includes(SR_ADJ)){
  const opts=PCD.talents.filter(t=>(p.talents[t.id]||0)<3).map(t=>{const r=p.talents[t.id]||0;return `<option value="${t.id}" ${m.adjT===t.id?'selected':''}>${esc(t.name)} ${'I'.repeat(r+1)}: ${esc(t.ranks[r].name)}</option>`}).join('');
  const box=`<div class="info sr-adj" style="margin:8px 0"><b>${esc(P.SY[SR_ADJ].name)}</b>: ранг таланта в онтологическом мосте (меняется при Полном Ремонте) <select data-sradj="1"><option value="">— не загружен —</option>${opts}</select>
   <div class="muted" style="font-size:12px">Пока вы в этом мехе, программа считает этот ранг взятым: бонусы, модификаторы бросков, кнопки боя. В листе пилота и в бюджете талантов он не учитывается. Система уничтожена — ранг не действует.</div></div>`;
  h=h.replace('<h2>Системы ',box+'<h2>Системы ')}}catch(e){}return h}}
document.addEventListener('change',e=>{const s=e.target.closest('[data-sradj]');if(!s)return;const p=curP();if(!p)return;const m=curM(p);m.adjT=P.T[s.value]?s.value:'';pcRender()});

/* ---------- модификаторы и подсказки ---------- */
const srRes=(p,id)=>{try{return resAll(p,id).length>0}catch(e){return false}};
{const o=mechStats;mechStats=function(p,m){const st=o(p,m);try{if(srRes(p,'reserve_up_armoring')&&st.armor<4){st.armor+=1;st.why.armor=(st.why.armor?st.why.armor+' · ':'')+'+1 резерв «'+P.RS.reserve_up_armoring.name+'» (не больше 4)'}}catch(e){}return st}}
{const o=pcBaseMods;pcBaseMods=function(p,kind,opt){const mods=o(p,kind,opt);try{const m=curM(p);
  if(kind==='check'&&srRes(p,'reserve_personal_touch'))mods.push(optM('Резерв «'+P.RS.reserve_personal_touch.name+'»: бой, выбранный для бонуса',1));
  if(kind==='tech'&&m.frame===SR_CHO)mods.push({label:'Черта «Перекачка Данных»: можно заодно автоматически Сканировать цель',info:1});
  if(kind==='tech'&&srRes(p,'reserve_sniper_team'))mods.push({label:'Резерв «'+P.RS.reserve_sniper_team.name+'» (если вызвана): Захват наносит цели 2 кин. ББ',info:1})}catch(e){}return mods}}
{const o=weaponTalentMods;weaponTalentMods=function(p,w,tags){const out=o(p,w,tags);try{
  if(w.id==='mw_xc_br_battle_rifle')out.push({label:'XC-BR: по цели в Захвате — Дальн. 15; при крите цель получает Захват',info:1});
  if(srRes(p,'reserve_hot_load_ammunition'))out.push({label:'Резерв «'+P.RS.reserve_hot_load_ammunition.name+'» (если потрачен): урон нельзя уменьшить, цель — спасбросок Корпуса или Сбита с ног',info:1});
  if(srRes(p,'reserve_lookingglass'))out.push({label:'Резерв «'+P.RS.reserve_lookingglass.name+'» (если включён): цель в пределах 3 — лёгкое укрытие и Невидимость не действуют',info:1})}catch(e){}return out}}
/* Звено «Хищник»: Невидимость цели не действует */
{const o=pcOpenWeapon;pcOpenWeapon=function(p,uid){const r=o(p,uid);try{if(M&&M.w&&M.w.id==='mw_xc_dpm_predator_nexus'){M.mods=M.mods.filter(x=>!x.invis);M.mods.push({label:'«Хищник»: атака игнорирует Невидимость',info:1});renderModal()}}catch(e){}return r}}
{const o=wCbNotes;wCbNotes=function(p,m,x){const out=o(p,m,x);try{if(x&&x.w&&x.w.id==='mw_xc_br_battle_rifle')out.push({txt:'Дальн. 15 по цели в Захвате',src:x.w.name,cond:1})}catch(e){}return out}}
/* Чомолунгма: варианты Вторжения */
{const o=pcOpenTech;pcOpenTech=function(p,title,opt){const r=srWithAdj(p,curM(p),()=>o(p,title,opt));try{if(M&&M.invade&&curM(p).frame===SR_CHO){
  M.mods.push({label:'Пакет Вторжения: можно выбрать «Блокировку Баланса» (оттолкнуть на 2 и сбить с ног / Обездвижить, 1/сцена на цель) или «Сокрушитель Систем» (4 нагрева, при превышении Предела — ещё 4 горения, 1/сцена на цель)',info:1});renderModal()}}catch(e){}return r}}

/* ---------- Справочник ---------- */
const SRR=(t,b,page)=>({t,b,src:['SR',page]});
const SR_REF={id:'sr',t:'Дополнение · Operation Solstice Rain',dlc:'SR',items:[
 SRR('О книге','**Operation Solstice Rain** — вводная серия из двух миссий для пилотов **УЛ0→УЛ2**. Из неё в программе только то, что пригодится в любой игре:\n• рама **Чомолунгма** (GMS, доступна всем с УЛ0, вместе с Эверестом) — хакер и поддержка;\n• таланты **Подрывник** (гранаты и мины) и **Сисоп** (усиленное Подкрепление);\n• экзотика: **Боевая Винтовка XC-BR**, **Звено «Хищник» XC-DPM**, **Паттерн-В Продвинутые Заряды**, **Комп/Кон класса «АДЪЮТАНТ»**, **Миниатюрная Пушка Когерентного Луча «ЛинУск»**;\n• 10 **резервов** (в листе пилота и таблица d20 в ГМ tools);\n• лёгкий авианосец **«Эбро»** для «Флота».',13),
 SRR('Чомолунгма','Вариант Эвереста, но его **не нужно открывать**: доступна с УЛ0 наравне с Эверестом. Размер 1, слоты Основной/Вспомогательный и Гибкий, Сенсоры 15, Тех. атака +1.\n• **Гениальность** — 1/сцена быстрая технология свободным действием, затем бесплатно Подкрепление или Захват.\n• **Перекачка Данных** — каждая тех. атака по врагу может заодно Сканировать его.\n• **Заменяемые Детали** — на перерыве 1 Ремонт за 1 Структуру (в программе — кнопка «1 Ремонт: +1 Структура»).\n• Ядро: два новых варианта **Вторжения** (в окне Вторжения — подсказка) и **Импульс Кода по Площади** — Вторжение по всем врагам в Сенсорах.\nВ книге нет отдельного арта Чомолунгмы.',45),
 SRR('Экзотика','Не повышает УЛ и не считается рангом лицензии; одновременно не больше **двух** предметов, ставятся и снимаются при **Полном Ремонте**. Экзотикой можно выдать и обычное снаряжение без лицензии (например, Шоковые Ножи Металмарка) — но щедрая раздача быстро поднимает силу группы.\nВ программе: **«АДЪЮТАНТ»** — во вкладке «Мех» выберите ранг таланта, он работает, пока вы в этом мехе; **«Хищник»** — окно атаки само убирает Невидимость цели; **XC-BR** — пометка «Дальн. 15 по цели в Захвате»; **«ЛинУск»** — 1/миссия, после выстрела вы Ошеломлены.',27),
 SRR('Резервы Solstice Rain','Таблица d20 на стр. 31 — замена или дополнение резервов основной книги за действия в даунтайме. Часть действует всю следующую миссию, часть тратится.\nВ программе: **Дополнительная Броня** даёт +1 Броню (не больше 4), пока резерв не отмечен использованным; **Личный Подход** — галочка +1 точность в проверках и спасбросках; **Форсированные Боеприпасы**, **ЗАЗЕРКАЛЬЕ**, **Снайперская Группа** — подсказки в окнах атаки и технологий. Сверхщит 5 от Дополнительной Брони отмечайте сами.',31),
 SRR('Сканирование: что говорить игрокам','Чомолунгма сканирует часто, поэтому держите статы НИП под рукой. При повторном Сканировании той же цели достаточно сказать, что изменилось (ПЗ, нагрев, урон Структуре и Нагрузке).\nДве вещи игроки знают **всегда**, без Сканирования: **класс НИП** и **его шаблоны** (Lancer, стр. 284). Перед мощной одноразовой атакой игрок вправе узнать, не Салага ли цель.',13),
 SRR('Корабль «Эбро» (Battlegroup)','Лёгкий авианосец GMS: **3 очка**, ПЗ 14, Защита 15, **2 крыла**, +3 очка на эскорты и крылья как у всех авианосцев. Черта **Строй Сопровождения** — можно назначить в Оборонительный заслон как фрегат (в бою программа учитывает).',46),
]};
{const bi=REF.findIndex(s=>s.dlc==='BG');REF.splice(bi<0?REF.length:bi,0,SR_REF)}
{const o=viewRef;viewRef=function(){return o().replace('<h2 id="ref-sr">',`<div class="dlc-hd"><b>Дополнение · Operation Solstice Rain</b><span>Операция «Дождь Солнцестояния»</span></div><h2 id="ref-sr">`)}}
