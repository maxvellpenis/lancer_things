/* ---------- бой игрока: состояние ---------- */
function pcEnsure(p){const m=curM(p);if(!p.cb||p.cb.mechId!==m.id)pcFullRepair(p,true);return p.cb}
function pcFullRepair(p,silent){
  const m=curM(p),st=mechStats(p,m),ps=pilotStats(p);
  p.cb={mechId:m.id,hp:st.hp,over:0,heat:0,struct:st.struct,stress:st.stress,rep:st.repcap,burn:0,cp:1,oc:0,conds:[],uses:{},unloaded:{},destroyed:{},
    react:false,phit:ps.hp,meltdown:0,counters:{},dead:false,round:1};
  if(!silent)pcLog(p,'Полный ремонт',`ПЗ ${st.hp}, Структура ${st.struct}, Нагрузка ${st.stress}, Ремонты ${st.repcap}, Мощь Ядра восстановлена, заряды Ограниченного восполнены, счётчик Перегрузки сброшен.`,'hit');
}
const pcWho=p=>{const m=curM(p);return (p.callsign||p.name)+(m.name?' «'+m.name+'»':'')};
function pcLog(p,title,body,c){addLog(c||'',logHead(pcWho(p)+' — '+title)+(String(body).startsWith('<')?body:`<div class="bd">${esc(body)}</div>`))}
const pHas=(c,x)=>c.conds.includes(x);
function pAddCond(c,x){if(!c.conds.includes(x))c.conds.push(x)}
function pDelCond(c,x){c.conds=c.conds.filter(y=>y!==x)}
function limMax(p,x){const v=tagVal(x.tags,'tg_limited');if(v===null)return null;return (+v||0)+mechStats(p,curM(p)).limited}
function lowestOf(n){const r=Array.from({length:Math.max(1,n)},()=>rnd(6));const ones=r.filter(x=>x===1).length;return{r,low:Math.min(...r),multi1:ones>=2}}
function pcStructCheck(p){
  const c=p.cb,st=mechStats(p,curM(p)),dmg=st.struct-c.struct,{r,low,multi1}=lowestOf(dmg);
  let res;
  if(c.struct<=0){c.dead=true;res='Структура 0 — мех уничтожен.'}
  else if(multi1){c.dead=true;res='Несколько единиц — СОКРУШИТЕЛЬНЫЙ УДАР: мех уничтожен (выйти из него можно как обычно).'}
  else if(low>=5){pAddCond(c,'Ослаблен');res='5–6 Скользящий удар: мех Ослаблен до конца вашего следующего хода.'}
  let direct=!res&&low===1;
  if(!res&&low>=2&&low<=4){const d=rnd(6);const m=curM(p),ok=(u,x)=>!(c.destroyed||{})[u]&&!(limMax(p,x)!==null&&c.uses[u]!=null&&c.uses[u]<=0);
    const ws=mechWeapons(p,m).filter(x=>!x.fixed&&ok(x.uid,x.w)).map(x=>x.w.name),ss=mechSystems(p,m).filter(x=>!x.fixed&&ok(x.uid,x.s)).map(x=>x.s.name);
    const want=d<=3?'w':'s',has={w:ws.length>0,s:ss.length>0};const got=has[want]?want:has[want==='w'?'s':'w']?(want==='w'?'s':'w'):null;
    if(!got){direct=true;res=`2–4 Системная травма: d6 [${d}], но целых оружия и систем не осталось → результат становится Прямым попаданием. `}
    else res=`2–4 Системная травма: d6 [${d}] → ${got==='w'?'уничтожено всё оружие на одном слоте по вашему выбору ('+ws.join(', ')+')':'уничтожена одна система по вашему выбору ('+ss.join(', ')+')'}${got!==want?' — выпавшего варианта нет, результат меняется':''}. Отметьте «уничтожено» ниже.`}
  if(direct){const pre=res||'';

    if(c.struct>=3){pAddCond(c,'Ошеломлен');res=pre+'1 Прямое попадание (3+ Структуры): мех Ошеломлён до конца вашего следующего хода.'}
    else if(c.struct===2){const d=rnd(20),tot=d+p.hase.hull,ok=tot>=10;if(ok)pAddCond(c,'Ошеломлен');else c.dead=true;
      res=pre+`1 Прямое попадание (2 Структуры): проверка Корпуса d20[${d}]+${p.hase.hull} = ${tot} против 10 → ${ok?'успех: мех Ошеломлён до конца следующего хода':'ПРОВАЛ: мех уничтожен'}.`}
    else{c.dead=true;res=pre+'1 Прямое попадание (1 Структура): мех уничтожен.'}
  }
  pcLog(p,'Структурный урон',`<div style="display:flex;gap:10px;align-items:center"><span class="tot">${low}</span><span class="verdict ${low>=5?'hit':'miss'}">Структура ${c.struct}/${st.struct}</span></div><div class="bd">${dmg}d6 [${r.join(',')}] — берётся наименьший</div><div>${esc(res)}</div>`,'miss');
}
function pcStressCheck(p){
  const c=p.cb,st=mechStats(p,curM(p)),dmg=st.stress-c.stress,{r,low,multi1}=lowestOf(dmg);
  let res;
  if(c.stress<=0){c.meltdown=1;res='Нагрузка 0: плавление реактора в конце вашего следующего хода!'}
  else if(multi1){c.meltdown=1;res='Несколько единиц — НЕОБРАТИМОЕ ПЛАВЛЕНИЕ: реактор взорвётся в конце вашего следующего хода.'}
  else if(low>=5){pAddCond(c,'Ослаблен');res='5–6 Аварийный шунт: мех Ослаблен до конца вашего следующего хода.'}
  else if(low>=2){pAddCond(c,'Уязвим');res='2–4 Дестабилизация энергоустановки: мех Уязвим (двойной кин./взр./энерг. урон), пока статус не снят (Стабилизация — охлаждение).'}
  else{
    if(c.stress>=3){pAddCond(c,'Уязвим');res='1 Плавление (3+ Нагрузки): мех Уязвим.'}
    else if(c.stress===2){const d=rnd(20),tot=d+p.hase.eng,ok=tot>=10;if(ok)pAddCond(c,'Уязвим');else c.meltdown=1+rnd(6);
      res=`1 Плавление (2 Нагрузки): проверка Инженерии d20[${d}]+${p.hase.eng} = ${tot} против 10 → ${ok?'успех: мех Уязвим':'ПРОВАЛ: плавление реактора через '+(c.meltdown-1)+' ваш(их) ход(а) (1d6 бросает ГМ; предотвратить — повторить проверку Инженерии свободным действием)'}.`}
    else{c.meltdown=1;res='1 Плавление (1 Нагрузка): плавление реактора в конце вашего следующего хода.'}
  }
  pcLog(p,'Перегрев',`<div style="display:flex;gap:10px;align-items:center"><span class="tot">${low}</span><span class="verdict ${low>=5?'hit':'miss'}">Нагрузка ${c.stress}/${st.stress}</span></div><div class="bd">${dmg}d6 [${r.join(',')}] — берётся наименьший</div><div>${esc(res)}</div>`,'miss');
}
function pcHeat(p,n,why){
  const c=pcEnsure(p),st=mechStats(p,curM(p));if(!n)return;
  c.heat=Math.max(0,c.heat+n);
  const parts=[`${n>0?'+':''}${n} нагрева${why?' ('+why+')':''} → ${c.heat}/${st.heatcap}`];
  pcLog(p,'Нагрев',parts.join(''));
  while(c.heat>st.heatcap&&!c.dead){c.heat-=st.heatcap;c.stress--;pcLog(p,'Превышен Тепловой Максимум',`−1 Нагрузка (осталось ${c.stress}); остаток нагрева ${c.heat} переносится.`,'miss');pcStressCheck(p);if(c.stress<=0)break}
}
function pcDamage(p,n,dt,o){
  o=o||{};const c=pcEnsure(p),st=mechStats(p,curM(p));if(!n||n<0)return;
  const rw=o.why?' ('+o.why+')':'';
  if(dt==='heat'){if(o.half){const h=Math.ceil(n/2);pcLog(p,'Получен нагрев',`${n} нагрева, ½ Сопротивляемость${rw} → ${h}`);n=h}pcHeat(p,n,'урон нагревом');return}
  let d=n;const parts=[`${n} ${PDT_RU[dt]||''}`];
  if(pHas(c,'Уязвим')&&['kin','exp','en'].includes(dt)){d*=2;parts.push('×2 Уязвим')}
  if(!o.ap&&dt!=='burn'&&st.armor){const a=Math.min(st.armor,d);d-=a;parts.push(`−${a} Броня`)}
  else if(o.ap)parts.push('ББ: броня не действует');
  if(o.half){d=Math.ceil(d/2);parts.push('½ Сопротивляемость'+rw)}
  if(dt==='burn'){c.burn+=d;parts.push(`горение теперь ${c.burn}`)}
  if(c.over>0){const s=Math.min(c.over,d);c.over-=s;d-=s;if(s)parts.push(`щит −${s}`)}
  c.hp-=d;parts.push(`итого −${d}`);
  pcLog(p,'Получен урон',`<div class="tot">−${d}</div><div class="bd">${esc(parts.join(', '))} → ПЗ ${Math.max(0,c.hp)}/${st.hp}</div>`,'miss');
  while(c.hp<=0&&!c.dead){const over=-c.hp;c.struct--;c.hp=st.hp-over;
    pcLog(p,'ПЗ на нуле',`−1 Структура (осталось ${c.struct}). ПЗ восстановлены, избыточный урон ${over} переносится → ПЗ ${Math.max(0,c.hp)}.`,'miss');
    pcStructCheck(p);if(c.struct<=0)break}
}
function pcBurnCheck(p){
  const c=pcEnsure(p),st=mechStats(p,curM(p));if(!(c.burn>0))return;
  const d=rnd(20),a=accRoll(0,pHas(c,'Ослаблен')?1:0),tot=d+p.hase.eng+a.val,ok=tot>=10;
  if(ok){pcLog(p,'Горение',`<div style="display:flex;gap:10px;align-items:center"><span class="tot">${tot}</span><span class="verdict hit">Потушено</span></div><div class="bd">Проверка Инженерии d20[${d}]${sgn(p.hase.eng)}${a.dice.length?' −'+(-a.val):''} против 10 — горение снято</div>`,'hit');c.burn=0;return}
  pcLog(p,'Горение',`<div style="display:flex;gap:10px;align-items:center"><span class="tot">${tot}</span><span class="verdict miss">Горит</span></div><div class="bd">Проверка Инженерии d20[${d}]${sgn(p.hase.eng)}${a.dice.length?' −'+(-a.val):''} против 10 провалена</div>`,'miss');
  const b=c.burn;c.hp-=b;pcLog(p,'Урон горением',`−${b} ПЗ (броня не действует) → ${Math.max(0,c.hp)}/${st.hp}`,'miss');
  while(c.hp<=0&&!c.dead){const over=-c.hp;c.struct--;c.hp=st.hp-over;pcStructCheck(p);if(c.struct<=0)break}
}
function pcMeltTick(p){
  const c=pcEnsure(p),st=mechStats(p,curM(p));if(!c.meltdown)return;
  if(c.meltdown>1){c.meltdown--;pcLog(p,'Плавление реактора',c.meltdown===1?'Взрыв в конце этого хода — нажмите ещё раз, когда ход закончится.':`Осталось ходов: ${c.meltdown-1}`,'miss');return}
  c.dead=true;c.meltdown=0;const dd=[rnd(6),rnd(6),rnd(6),rnd(6)];
  pcLog(p,'ПЛАВЛЕНИЕ РЕАКТОРА',`Мех испаряется, пилот внутри погибает. Разрыв 2: спасбросок Маневренности против ${st.save}, иначе ${dd.reduce((a,b)=>a+b,0)} взр. (4d6 [${dd.join(',')}]), при успехе половина.`,'miss');
}
function pcStabilize(p,mode,extra){
  const c=pcEnsure(p),st=mechStats(p,curM(p)),out=[];
  if(mode==='cool'){c.heat=0;pDelCond(c,'Уязвим');out.push('охлаждение: нагрев сброшен, Уязвимость снята')}
  else{if(c.rep<1){alert('Ремонтов не осталось');return}c.rep--;c.hp=st.hp;out.push(`1 Ремонт: ПЗ восстановлены (${st.hp}); Ремонтов ${c.rep}`)}
  if(extra==='reload'){c.unloaded={};out.push('всё Заряжаемое оружие перезаряжено')}
  if(extra==='burn'){c.burn=0;out.push('горение снято')}
  if(extra&&extra.startsWith('cond:')){pDelCond(c,extra.slice(5));out.push('снято: '+extra.slice(5))}
  if(extra==='ally')out.push('снято состояние у соседнего союзника');
  pcLog(p,'Стабилизация (полное действие)',out.join(' · '),'hit');
}
function pcOvercharge(p){
  const c=pcEnsure(p),st=mechStats(p,curM(p));
  const cost=st.oc[Math.min(c.oc,st.oc.length-1)];const r=pcRollExpr(cost,{});c.oc++;
  pcLog(p,'Перегрузка',`Любое быстрое действие как свободное. Цена: ${cost}${r.txt!==cost?' ['+r.txt+']':''} = ${r.v} нагрева${st.ocSrc?' ('+st.ocSrc+')':''}. Следующая: ${st.oc[Math.min(c.oc,st.oc.length-1)]}.`);
  pcHeat(p,r.v,'Перегрузка');
}
/* кубики урона */
function pcRollExpr(expr,o){
  o=o||{};const s=String(expr).replace(/\s+/g,'').toLowerCase();
  const terms=s.match(/[+-]?[^+-]+/g)||[];let v=0,heat=0;const txt=[];
  for(const t of terms){
    const sign=t[0]==='-'?-1:1,b=t.replace(/^[+-]/,''),m=b.match(/^(\d*)d(\d+)$/);
    if(!m){v+=sign*(+b||0);txt.push((sign<0?'−':txt.length?'+':'')+b);continue}
    const n=+(m[1]||1),f=+m[2];
    const once=()=>{let sum=0,h=0;const show=[];for(let k=0;k<n;k++){let r=rnd(f);const ch=[r];while(o.overkill&&r===1){h++;r=rnd(f);ch.push(r)}sum+=r;show.push(ch.join('→'))}return{sum,h,show}};
    let a=once();
    if(o.crit){const b2=once();heat+=a.h+b2.h;txt.push(`${n}d${f}[${a.show}|${b2.show}]→${Math.max(a.sum,b2.sum)}`);if(b2.sum>a.sum)a=b2}
    else{heat+=a.h;txt.push(`${txt.length?'+':''}${n}d${f}[${a.show}]`)}
    v+=sign*a.sum;
  }
  return{v:Math.max(0,v),txt:txt.join(''),heat};
}

/* ---------- бой: экран ---------- */
function vcol(title,cur,labels,kind,tip){
  // labels: снизу вверх; последний — ⚠
  const cells=labels.map((l,i)=>{const filled=i<=cur,now=i===cur;
    const cls=now&&cur===0&&kind!=='oc'?'ok':filled?kind:'';
    return `<button class="vc ${cls} ${now?'now':''}" data-pa="vit" data-k="${kind}" data-v="${i}" title="${esc(i===labels.length-1?'критично':String(l))}">${l==='⚠'?'<span class="warnico">⚠</span>':esc(l)}</button>`}).reverse().join('');
  return `<div class="vcol kw" data-tt="${esc(title)}" data-tip="${esc(tip)}"><div class="vlab">${esc(title)}</div><div class="vcells">${cells}</div></div>`;
}
function vitals(p,st,c){
  const sd=Math.max(0,st.struct-c.struct),xd=Math.max(0,st.stress-c.stress);
  const sl=[...Array(st.struct).keys()].map(String).concat('⚠'),xl=[...Array(st.stress).keys()].map(String).concat('⚠');
  const ol=['0',...st.oc.slice(0,3),'⚠'];
  return `<div class="vitals">${vcol('Структурный урон',Math.min(sd,st.struct),sl,'struct','Сколько Структуры потеряно. ⚠ — мех уничтожен. Клик по клетке задаёт значение; при росте урона предложит бросок по таблице.')}
    ${vcol('Нагрузка ядра',Math.min(xd,st.stress),xl,'stress','Сколько Нагрузки потеряно. ⚠ — плавление реактора. Клик по клетке задаёт значение.')}
    ${vcol('Перегрузка',Math.min(c.oc,4),ol,'oc','Клик по следующей клетке = Перегрузка: нагрев (цифра в клетке) бросается и прибавляется сам. Клик по клетке ниже — исправить счётчик без нагрева. ⚠ — каждая следующая стоит '+(st.oc[3]||'1d6+4')+'. Сбрасывается Полным Ремонтом.')}</div>`;
}
function pBar(label,cur,max,col,act,extra){return `<div class="bar"><div class="t"><span>${label}</span><span>${extra||''}</span></div>
  <div class="v"><button class="pm" data-pa="${act}" data-d="-1">−</button><span>${cur}</span><span class="muted" style="font-size:13px">/ ${max}</span><button class="pm" data-pa="${act}" data-d="1">+</button></div>
  <div class="meter"><i style="width:${Math.max(0,Math.min(100,cur/Math.max(1,max)*100))}%;background:${col}"></i></div></div>`}
function pips(n,max,act){let h='';for(let i=1;i<=max;i++)h+=`<button class="spip ${i<=n?'on':''}" data-pa="${act}" data-v="${i===n?i-1:i}"></button>`;return h}
function viewCombat(p){
  const m=curM(p),f=P.F[m.frame],st=mechStats(p,m),c=pcEnsure(p),ps=pilotStats(p);
  const dz=c.heat*2>=st.heatcap;
  const ws=mechWeapons(p,m),ss=mechSystems(p,m);
  const wRow=x=>{const w=x.w,u=x.uid,lm=limMax(p,w),left=lm===null?null:(c.uses[u]??lm),load=tagVal(w.tags,'tg_loading'),dead=c.destroyed[u];
    return `<div class="isys ${dead?'spent':''}"><div class="row"><span class="nm">${esc(w.name)}</span>${weaponLine(w,st,x.mod,m.varDt[w.id],wCbNotes(p,m,x))}</div>
      <div class="row">${w.no_attack?'':`<button class="atkbtn" data-pa="atk" data-v="${esc(u)}" ${dead?'disabled':''}>⚄ Атака</button>`}
      ${load?(c.unloaded[u]?`<span class="badge">разряжено</span><button class="btn sm" data-pa="reload" data-v="${esc(u)}">Зарядить</button>`:'<span class="ntag">заряжено</span>'):''}
      ${left!==null?`<span class="ntag">заряды ${left}/${lm}</span><button class="pm" data-pa="use" data-v="${esc(u)}" data-d="-1">−</button><button class="pm" data-pa="use" data-v="${esc(u)}" data-d="1">+</button>`:''}
      ${x.fixed?'':`<label class="ntag"><input type="checkbox" data-pa="destroy" data-v="${esc(u)}" ${dead?'checked':''}> уничтожено</label>`}
      ${w.dmg.some(d=>d.t==='variable')?`<select data-pf="vdt" data-k="${w.id}">${['kin','en','exp'].map(k=>`<option value="${k}" ${m.varDt[w.id]===k?'selected':''}>${PDT_RU[k]}</option>`).join('')}</select>`:''}</div>
      ${itemCard(w,'w',{st,mod:x.mod,k:'c'+u,label:'описание и эффекты'}).replace('<summary>','<summary class="mini-s">')}</div>`};
  const sRow=x=>{const s=x.s,u=x.uid,lm=limMax(p,s),left=lm===null?null:(c.uses[u]??lm),dead=c.destroyed[u];
    const tech=(s.acts||[]).filter(a=>a.tech||/Tech|Invade/.test(a.act||''));
    return `<div class="isys ${dead?'spent':''}"><div class="row"><span class="nm">${esc(s.name)}</span><span class="tag-s">${esc(s.rutags||'')}</span></div>
      <div class="row">${tech.map((a,i)=>`<button class="atkbtn" data-pa="stech" data-v="${esc(u)}" data-i="${i}">⚄ ${esc(a.name?'Тех: '+a.name:'Тех. атака')}</button>`).join('')}
      ${left!==null?`<span class="ntag">заряды ${left}/${lm}</span><button class="btn sm" data-pa="use" data-v="${esc(u)}" data-d="-1">Потратить</button><button class="pm" data-pa="use" data-v="${esc(u)}" data-d="1">+</button>`:''}
      ${tagVal(s.tags,'tg_heat_self')?`<button class="btn sm" data-pa="sheat" data-v="${esc(u)}">Нагрев ${tagVal(s.tags,'tg_heat_self')}</button>`:''}
      ${x.fixed?'':`<label class="ntag"><input type="checkbox" data-pa="destroy" data-v="${esc(u)}" ${dead?'checked':''}> уничтожено</label>`}</div>
      ${itemCard(s,'sys',{k:'c'+u,label:'описание'}).replace('<summary>','<summary class="mini-s">')}</div>`};
  const counters=[...talentRanks(p).filter(x=>x.r.counters).flatMap(x=>x.r.counters.map(ct=>({ct,name:x.r.name}))),...(((P.F[(curM(p)||{}).frame]||{}).core||{}).counters||[]).map(ct=>({ct,name:'Система ядра'}))];
  return `
  ${c.dead?'<div class="warn" style="font-size:16px">☠ Мех уничтожен. «Полный ремонт» восстановит его (или 4 Ремонта во время отдыха).</div>':''}
  <div class="combat-top"><div class="ctop-row"><div class="bars">
    ${pBar('ПЗ',c.hp,st.hp,'var(--good)','hp',`Броня ${st.armor}`)}
    ${pBar('Нагрев',c.heat,st.heatcap,dz?'var(--bad)':'var(--orange)','heat',dz?'<b class="dz kw" data-tt="Опасная Зона" data-tip="Нагрев не меньше половины Теплового Максимума. Некоторые системы и таланты работают только здесь.">ОПАСНАЯ ЗОНА</b>':'')}
   </div>
   ${vitals(p,st,c)}</div>
   <div class="mini">
    <label>Щит <input type="number" data-pf="cb" data-k="over" value="${c.over}"></label>
    <label>Горение <input type="number" data-pf="cb" data-k="burn" value="${c.burn}"></label>
    <label>Ремонты <input type="number" data-pf="cb" data-k="rep" value="${c.rep}"> / ${st.repcap}</label>
    <label class="${c.cp?'':'off'}"><input type="checkbox" data-pa="cp" ${c.cp?'checked':''}> Мощь Ядра</label>
    <span class="ntag kw" data-tt="Перегрузка" data-tip="1 раз за ход: любое быстрое действие как свободное. Цена растёт: ${esc(st.oc.join(' → '))}; сбрасывается Полным Ремонтом.">Перегрузок: ${c.oc} · след.: ${esc(st.oc[Math.min(c.oc,st.oc.length-1)])}</span>
    ${c.meltdown?`<span class="badge">ПЛАВЛЕНИЕ: ${c.meltdown===1?'в конце следующего хода':'через '+(c.meltdown-1)+' х.'}</span>`:''}
   </div>
   <div class="dmgrow"><b>Урон по вам:</b><input type="number" id="pdmg" min="0" placeholder="0">
     <select id="pdt">${['kin','en','exp','burn','heat'].map(k=>`<option value="${k}">${PDT_RU[k]}</option>`).join('')}</select>
     <label><input type="checkbox" id="pap"> ББ</label><label class="kw" data-tt="Сопротивляемость" data-tip="Урон делится пополам (после Брони). Например Укрепление."><input type="checkbox" id="phalf"> ½ Сопр.</label>${typeof dmgExtra==='function'?dmgExtra(p,m,c):''}
     <button class="btn red" data-pa="takedmg">Получить урон</button></div>
   <div class="dmgrow"><b>Лечение:</b><input type="number" id="pheal" min="0" placeholder="0"><button class="btn" data-pa="heal">＋ Восстановить ПЗ</button><span class="muted" style="font-size:12px">или ± у полосы ПЗ</span></div>
   <div class="enc-bar" style="margin-top:8px">
     ${c.burn>0?`<button class="btn red" data-pa="pburn" title="Проверка Инженерии 10+: успех — горение снято, провал — урон, равный горению">🔥 Горение ${c.burn}: проверка</button>`:''}
     ${c.meltdown?`<button class="btn red" data-pa="pmelt">☢ Плавление: −1 ход</button>`:''}
     <button class="btn" data-pa="oc">⚡ Перегрузка</button>
     <select id="pstab"><option value="cool">Стабилизация: охладить (нагрев и Уязвимость)</option><option value="repair">Стабилизация: 1 Ремонт → все ПЗ</option></select>
     <select id="pstab2"><option value="">+ ничего</option><option value="reload">+ перезарядить Заряжаемое</option><option value="burn">+ снять горение</option>${c.conds.map(x=>`<option value="cond:${esc(x)}">+ снять: ${esc(x)}</option>`).join('')}<option value="ally">+ состояние союзника</option></select>
     <button class="btn" data-pa="stab">Стабилизация</button>
     <button class="btn" data-pa="brace">🛡 Укрепление</button>
     <button class="btn" data-pa="fullrep">♻ Полный ремонт</button>
   </div>
   <div class="conds">${['Опасная зона',...CONDS].map(x=>x==='Опасная зона'?(dz?`<span class="cond on kw" data-tt="Опасная зона" data-tip="Нагрев ≥ половины Теплового Максимума.">Опасная зона</span>`:''):`<button class="cond ${pHas(c,x)?'on':''}" data-pa="cond" data-v="${esc(x)}"${tipAttr(tipFor(x)).replace('class="kw"','')}>${esc(x)}</button>`).join('')}</div>
   ${counters.length?`<div class="mini">${counters.map(x=>`<label class="kw" data-tt="${esc(x.name)}" data-tip="Счётчик таланта">${esc(x.ct.name.replace('Die','кубик').replace('Dice','кубики'))} <button class="pm" data-pa="ctr" data-v="${x.ct.id}" data-d="-1">−</button><b>${c.counters[x.ct.id]??x.ct.default_value}</b><button class="pm" data-pa="ctr" data-v="${x.ct.id}" data-d="1">+</button></label>`).join('')}</div>`:''}
  </div>
  <h2>Броски меха</h2>
  <div class="acts">
    <div class="sk" style="grid-template-columns:repeat(4,1fr)">${HASE.map(([k,l])=>`<button class="skbtn" data-pa="chk" data-v="${k}">${l} <i>${sgn(p.hase[k])}</i></button>`).join('')}</div>
    <div class="row-btns">
      <button class="btn" data-pa="basic" data-v="impro">Импровизированная атака (1d6 кин.)</button><button class="btn" data-pa="basic" data-v="ram">Таран</button><button class="btn" data-pa="basic" data-v="grapple">Хватание</button>
      <button class="btn" data-pa="basic" data-v="invade">Вторжение (тех)</button><button class="btn" data-pa="basic" data-v="search">Поиск (Системы)</button><button class="btn" data-pa="generic">d20 ± точн.</button>
    </div>
  </div>
  <h2>Оружие</h2>${ws.map(wRow).join('')||'<div class="muted">Оружия нет — добавьте во вкладке «Мех».</div>'}
  <h2>Системы</h2>${ss.map(sRow).join('')||'<div class="muted">Систем нет</div>'}
  <h2>Ядро — ${esc(f.core.name)}</h2>
  <div class="row-btns"><button class="btn red" data-pa="core" ${c.cp?'':'disabled'}>☢ Активировать: ${esc(f.core.aname||f.core.name)} (1 Мощь Ядра)</button></div>${coreHtml(f)}
  <h2>Черты рамы и таланты</h2>
  ${f.traits.map(t=>`<div class="trait"><b>${esc(t.name)}</b><div>${pfmt(t.text)}</div></div>`).join('')}
  ${talentRanks(p).map(x=>`<div class="trait tal"><b>${esc(x.t.name)} ${'I'.repeat(x.i+1)}: ${esc(x.r.name)}</b><div>${pfmt(x.r.text)}</div></div>`).join('')||''}
  ${p.cbs.map(id=>`<div class="trait"><b>${esc(P.CB[id].name)}</b> <span class="ntag">бонус ядра</span><div>${pfmt(P.CB[id].text)}</div></div>`).join('')}
  <h2>Пилот вне меха</h2>
  <div class="mini"><label>ПЗ пилота <input type="number" data-pf="cb" data-k="phit" value="${c.phit}"> / ${ps.hp}</label><span class="ntag">Броня ${ps.armor} · Уклонение ${ps.evasion} · Э-Защита ${ps.edef} · Скорость ${ps.speed}</span>
    <button class="btn sm" data-pa="downout">0 ПЗ пилота: бросок d6</button></div>
  ${p.gear.weapons.filter(id=>P.G[id]).map(id=>{const g=P.G[id];return `<div class="isys"><div class="row"><span class="nm">${esc(g.name)}</span><span class="wprof"><span class="pill">${esc(rngTxt(g.rng))}</span><span class="pill">${esc(dmgTxt(g.dmg))}</span></span>
     ${g.dmg.some(d=>d.t==='variable')?`<select data-pf="sigdt" data-k="${id}">${['kin','en','exp'].map(k=>`<option value="${k}" ${p.sigDt[id]===k?'selected':''}>${PDT_RU[k]}</option>`).join('')}</select>`:''}
     <button class="atkbtn" data-pa="patk" data-v="${id}">⚄ Атака</button></div></div>`}).join('')}
  <div class="plist">${Object.entries(p.skills).filter(([k,r])=>r&&P.SK[k]).map(([k,r])=>`<button class="skbtn" data-pa="rtrig" data-v="${k}">${esc(P.SK[k].name)} <i>${sgn(r*2)}</i></button>`).join('')}
    ${p.custom.filter(x=>x.rank).map((x,i)=>`<button class="skbtn" data-pa="rtrigc" data-v="${p.custom.indexOf(x)}">${esc(x.name||'свой')} <i>${sgn(x.rank*2)}</i></button>`).join('')}</div>`;
}
