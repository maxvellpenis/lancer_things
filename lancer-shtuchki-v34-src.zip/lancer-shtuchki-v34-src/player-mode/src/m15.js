/* ============================== v22: Battlegroup — трекер боя ============================== */
const BB=()=>BGS.battle;
const bgU=uid=>BB().units.find(u=>u.uid===uid);
const bgShip=(u,sid)=>u&&u.ships.find(s=>s.sid===sid);
const bgAlive=u=>u.ships.some(s=>!s.dead&&!s.wing);
const bgPhaseNames=['Логистика','Удар','Действия','Абордаж'];
function bgLog(cls,title,body){addLog(cls,logHead('⚓ '+title)+(body?`<div class="bd">${body}</div>`:''))}

/* ---------- кубики ---------- */
function bgRoll(expr,opt){opt=opt||{};const s=String(expr||'0').replace(/\s+/g,'').toLowerCase().replace(/д/g,'d');let tot=0;const parts=[];
  (s.match(/[+-]?[^+-]+/g)||[]).forEach(tm=>{const sg=tm[0]==='-'?-1:1,b=tm.replace(/^[+-]/,'');const m=b.match(/^(\d*)d(\d+)$/);
    if(m){const n=Math.min(+(m[1]||1),40),f=+m[2];const r=[];for(let i=0;i<n;i++){let v=rnd(f);if(opt.ok)while(v===1&&f>1){r.push('1↻');v=rnd(f)}r.push(v);tot+=sg*v}parts.push(`${n}d${f}[${r.join(',')}]`)}
    else if(/^\d+$/.test(b)){tot+=sg*+b;parts.push((sg<0?'−':'+')+b)}});
  return{tot,txt:parts.some(p=>p.includes('d'))?parts.join(' ').replace(/^\+/,''):''}}
const bgDiceTxt=(d,n)=>[d?d+'d6':'',n?(n>0?'+':'')+n:''].filter(Boolean).join('')||'0';

/* ---------- метки предметов НИП ---------- */
function bgNpcTg(it){const t=String(it.tg||'');const n=re=>{const m=t.match(re);return m?+m[1]:0};
  return{st:/по одной цели/i.test(t),at:/по площади/i.test(t),acc:/(^|,\s*)Точное/i.test(t),inacc:/Неточное/i.test(t),crit:/Критическое/i.test(t),
    rel:n(/Надёжное\s*(\d+)/i),ok:/Избыточное/i.test(t),ch:it.ch||n(/Заряд\s*(\d+)/i),sh:/сверхтяж/i.test(t),pl:it.pl!=null?it.pl:(/Ракета/i.test(t)?(n(/Ракета\s*[−-]\s*(\d+)/)?-n(/Ракета\s*[−-]\s*(\d+)/):0):null),
    rl:it.rl||n(/Перезарядка\s*(\d+)/i),lim:it.lim||n(/Ограничено\s*(\d+)/i),brd:/Абордаж/i.test(t),ten:n(/Упорство\s*(\d+)/i)}}

/* ---------- создание участников ---------- */
function bgUnitPc(g,band){const snap=JSON.parse(JSON.stringify(g));
  const u={uid:bgUid(),kind:'pc',gid:g.id,name:g.name,band:+band||4,bolst:false,acc:bgBanked(g),dif:0,intx:0,intd:0,snap,ships:[],c:{},screen:{}};
  snap.ships.forEach(s=>{const h=BH[s.hull];if(!h)return;const hp=bgHp(s);
    u.ships.push({sid:s.id,name:s.name||h.ru,hull:s.hull,flag:!!s.flag,hp,max:hp,os:s.hull==='louis'?5:0,dfx:0,lock:false,grey:0,dead:false});
    bgShipItems(s).forEach(({k,i,it})=>{const key=`${s.id}:${k}:${i}`;
      if(k==='sh'||k==='pr'||k==='aux')u.c['w:'+key]={ch:it.tg.ch&&!it.tg.skip?it.tg.ch:0,rl:0,lim:0,vol:0,busy:'',skip:it.tg.skip?{on:false,tgt:''}:null};
      if(k==='esc'||k==='wing'){let hp=it.hp||0;if(it.id==='ace'&&(s.ace||[]).includes('casque'))hp+=4;
        u.c['u:'+key]={hp,max:hp,os:s.hull==='eiland'&&k==='esc'?2:0,used:false,dead:false,brd:''}}})});
  return u}
function bgNpcHp(cap,escIds){let hp=cap.hp,df=cap.df;(escIds||[]).forEach(id=>{const e=BNE[id];if(e&&e.tpl){hp+=e.tpl.hp;df+=e.tpl.df}});return{hp,df}}
function bgUnitNpc(capId,escIds,aceId,name){const cap=BNC[capId];if(!cap)return null;escIds=(escIds||[]).filter(id=>BNE[id]).slice(0,3);
  const st=bgNpcHp(cap,escIds);
  const u={uid:bgUid(),kind:'npc',name:name||cap.ru,cap:capId,esc:escIds,ace:BNA[aceId]?aceId:'',bolst:false,intx:0,intd:0,ships:[],c:{},omni:0,lagoon:capId==='narcissus'};
  u.ships.push({sid:'c',name:cap.ru,arch:capId,hp:st.hp,max:st.hp,df:st.df,os:capId==='narcissus'?10:0,dfx:0,lock:false,grey:0,dead:false});
  escIds.forEach((id,i)=>{const e=BNE[id];if(e.tpl)return;(e.hp||[]).forEach((hp,j)=>u.ships.push({sid:`e${i}.${j}`,name:e.ru+(e.hp.length>1?' #'+(j+1):''),esc:id,hp,max:hp,df:e.df,os:0,dfx:0,lock:false,grey:0,dead:false}))});
  if(u.ace){const a=BNA[u.ace];u.ships.push({sid:'a',name:a.ru,ace:u.ace,wing:true,hp:a.hp[0],max:a.hp[0],os:0,dfx:0,lock:false,grey:0,dead:false})}
  const wingSrc=[['c',cap],...escIds.map((id,i)=>['e'+i,BNE[id]])];
  wingSrc.forEach(([o,x])=>{if(x&&x.wings){const n=x.id==='furies'?3*(x.hp||[]).length:x.wings.n;
    u.c['wg:'+o]={hp:Array.from({length:n},(_,j)=>x.id==='furies'&&j%3===2?6:x.wings.hp),max:x.id==='furies'?null:x.wings.hp,ten:x.wings.ten||0}}});
  bgNpcItems(u).forEach(({key,it})=>{const t=bgNpcTg(it);if(t.ch||t.rl||t.lim||t.pl!=null)u.c['n:'+key]={ch:t.ch&&!it.omni?t.ch:0,rl:0,lim:0,busy:''}});
  return u}
function bgNpcItems(u){const out=[];const cap=BNC[u.cap];if(cap)cap.items.forEach((it,i)=>out.push({key:'c:'+i,owner:'c',src:cap,it}));
  (u.esc||[]).forEach((id,j)=>{const e=BNE[id];if(e)e.items.forEach((it,i)=>out.push({key:`e${j}:${i}`,owner:'e'+j,src:e,it}))});
  if(u.ace){const a=BNA[u.ace];if(a)a.items.forEach((it,i)=>out.push({key:'a:'+i,owner:'a',src:a,it}))}
  return out}
function bgOwnerAlive(u,owner){if(owner==='c')return !bgShip(u,'c').dead;if(owner==='a'){const s=bgShip(u,'a');return s&&!s.dead}
  const j=+owner.slice(1);const e=BNE[u.esc[j]];if(e&&e.tpl)return !bgShip(u,'c').dead;return u.ships.some(s=>s.sid.startsWith(owner+'.')&&!s.dead)}

/* ---------- характеристики ---------- */
function bgPcItems(u){const out=[];u.snap.ships.forEach(s=>{const sh=bgShip(u,s.id);bgShipItems(s).forEach(x=>out.push({...x,s,sh,key:`${s.id}:${x.k}:${x.i}`}))});return out}
function bgDef(u,sh){let d;if(u.kind==='pc'){const h=BH[sh.hull];d=h?h.df:10;if(sh.hull==='louis'&&sh.os>0)d+=2}
  else{d=sh.df;if(sh.sid==='c'){if(u.cap==='breakwater'&&(u.c['wg:c']||{hp:[]}).hp.some(x=>x>0))d+=2;if(u.lagoon)d+=2}}
  if(u.bolst)d+=2;d+=+sh.dfx||0;return Math.max(6,Math.min(20,d))}
function bgIntParts(u){const P=[];const al=s=>s&&!s.dead;
  if(u.kind==='pc'){const fl=u.ships.find(s=>s.flag);if(al(fl))P.push(['Флагман','1d6',1,0]);
    if(u.ships.some(s=>s.hull==='louis'&&al(s)))P.push(['Точечная эгида','1d6',1,0]);
    const items=bgPcItems(u).filter(x=>al(x.sh));
    const ndep=items.filter(x=>x.id==='ndep').length;if(ndep&&u.band<=2)P.push(['NDEP',String(Math.min(4,ndep)),0,Math.min(4,ndep)]);
    const ftr=items.filter(x=>x.id==='fighter'&&!(u.c['u:'+x.key]||{}).dead).length;if(ftr)P.push(['Истребители',String(Math.min(4,ftr)),0,Math.min(4,ftr)]);
    if(items.some(x=>x.id==='sandstorm'))P.push(['«Песчаная буря»','2',0,2]);
    const ace=items.find(x=>x.id==='ace');if(ace&&!(u.c['u:'+ace.key]||{}).dead&&(ace.s.ace||[]).includes('goal'))P.push(['Ас: Вратарь','2',0,2])}
  else{const cap=BNC[u.cap];const c=bgShip(u,'c');if(al(c)){const m=String(cap.it).match(/(\d+)d6(?:\+(\d+))?/);if(m){P.push([cap.ru,cap.it,+m[1],+(m[2]||0)])}}
    if(u.cap==='breakwater'){const n=(u.c['wg:c']||{hp:[]}).hp.filter(x=>x>0).length;if(n&&al(c))P.push(['Крылья Волнореза',String(n),0,n])}
    if(u.lagoon&&al(c))P.push(['Щиты «Лагуна»','1d6',1,0]);
    (u.esc||[]).forEach((id,j)=>{if(id==='roughnecks'&&bgOwnerAlive(u,'e'+j))P.push(['Головорезы','2',0,2])})}
  if(u.bolst)P.push(['Укреплён','1d6',1,0]);
  if(+u.intd||+u.intx)P.push(['Вручную',bgDiceTxt(+u.intd||0,+u.intx||0),+u.intd||0,+u.intx||0]);
  return P}
function bgIntTxt(u){const P=bgIntParts(u);const d=P.reduce((a,p)=>a+p[2],0),n=P.reduce((a,p)=>a+p[3],0);return{d,n,txt:bgDiceTxt(d,n)}}
function bgIntRoll(u,why){const t=bgIntTxt(u);const r=bgRoll(t.txt);bgLog('',`Перехват: ${u.name}`,`<span class="tot">${r.tot}</span> <span class="muted">${esc(t.txt)} → ${esc(r.txt)}${why?' · '+esc(why):''}</span>`);return r.tot}

/* ---------- урон ---------- */
const bgKillTxt=hp=>hp>-5?['Выведен из боя','Экипаж успевает эвакуироваться.']:hp>-10?['Раскалывающий удар','Корпус расколот, выживших немного.']:hp>-15?['Полное уничтожение','Почти все на борту погибли.']:['Аннигиляция','Никто не выжил.'];
function bgDamage(u,sh,n,o){o=o||{};n=Math.max(0,Math.round(n));if(!sh||sh.dead&&!o.force)return 0;let rest=n;
  if(!o.ios&&sh.os>0){const a=Math.min(sh.os,rest);sh.os-=a;rest-=a;
    if(u.lagoon&&sh.sid==='c'&&sh.os<=0){u.lagoon=false;bgLog('',`${u.name}: щиты «Лагуна» отключены`,'Сверхщит исчерпан — бонусы к Защите и Перехвату потеряны.')}}
  sh.hp-=rest;
  if(sh.hp<=0&&!sh.dead){sh.dead=true;const k=bgKillTxt(sh.hp);
    bgLog('miss',`${sh.name} уничтожен`,`${esc(u.name)} · ПЗ ${sh.hp}: <b>${esc(k[0])}</b> — ${esc(k[1])}${u.kind==='npc'&&sh.sid==='c'?'<br>Эскорты: один уничтожается (выбирает атакующий), остальные переназначаются; если эскорт был один — он получает 1d6 урона. В сражениях с подкреплениями новая группа приходит в начале следующей логистики.':''}${u.kind==='pc'&&sh.flag?'<br>Флагман потерян — командир на борту (если не успел в спасательную капсулу).':''}`);
    if(u.kind==='pc')bgPcItems(u).filter(x=>x.s.id===sh.sid&&(x.k==='esc'||x.k==='wing')).forEach(x=>{const c=u.c['u:'+x.key];if(c&&x.id!=='ace')c.dead=true;if(x.id==='ace')bgLog('',`${x.it.ru}: ас уцелел`,'Переназначьте эскадрилью аса на другой корабль группы (или союзника).')});
    BB().pls=BB().pls.filter(p=>!(p.tgt===u.uid&&p.sid===sh.sid));BB().brd=BB().brd.filter(b=>!(b.tgt===u.uid&&b.sid===sh.sid))}
  return rest}
function bgHeal(u,sh,n){if(!sh)return;sh.hp=Math.min(sh.max,sh.hp+n);if(sh.hp>0)sh.dead=false}
function bgAreaTargets(u){return u.ships.filter(s=>!s.dead&&!s.wing)}
function bgPcEscUnits(u){return bgPcItems(u).filter(x=>x.k==='esc'&&!(x.sh&&x.sh.dead)).map(x=>({x,c:u.c['u:'+x.key]})).filter(o=>o.c&&o.c.max>0&&!o.c.dead)}
function bgApplyArea(u,dmg,label){const hit=[];bgAreaTargets(u).forEach(s=>{bgDamage(u,s,dmg);hit.push(s.name)});
  if(u.kind==='pc')bgPcEscUnits(u).forEach(({x,c})=>{let r=dmg;if(c.os){const a=Math.min(c.os,r);c.os-=a;r-=a}c.hp-=r;if(c.hp<=0){c.dead=true;hit.push(x.it.ru+' (уничтожен)')}else hit.push(x.it.ru)});
  return hit}
/* модификатор урона по площади от диапазона */
function bgAreaBand(b,d){return b===5?Math.floor(d/2):b===1?d+2:b===0?d+4:d}

/* ---------- фазы ---------- */
function bgStart(){const b=BB();b.round=1;b.phase=0;b.started=true;b.ticked=0;bgLogistics()}
function bgLogistics(){const b=BB();if(b.ticked===b.round)return;b.ticked=b.round;const notes=[];
  b.units.forEach(u=>{
    Object.entries(u.c).forEach(([k,c])=>{if(k.startsWith('w:')||k.startsWith('n:')){if(c.ch>0&&!(c.skip&&!c.skip.on))c.ch--;if(c.rl>0)c.rl--}
      if(k.startsWith('a:')&&c.rl>0)c.rl--;if(k.startsWith('u:'))c.used=false});
    if(u.kind==='pc'){u.ships.forEach(s=>{if(s.hull==='louis'&&!s.dead)s.os=Math.max(s.os,5)})}
    else{const c=bgShip(u,'c');if(u.cap==='highline'&&!c.dead){c.os=Math.max(c.os,5);notes.push(`${u.name}: «Занавес» — +5 Сверхщита (можно отдать союзнику)`)}
      if((u.esc||[]).includes('unknown')&&!c.dead){u.omni=Math.min(6,(u.omni||0)+1)}}
    if(u.kind==='pc'&&b.round>=6){const lim=b.round>=8?0:b.round===7?2:4;if(u.band>lim){notes.push(`${u.name}: гир сжимается — ${bgBand(u.band)} → ${bgBand(lim)}`);u.band=lim}}});
  b.pls.forEach(p=>{if(p.fc>0)p.fc--});
  const ready=b.pls.filter(p=>p.fc===0).length;
  bgLog('',`Раунд ${b.round} · Логистика`,`Счётчики заряда, полёта и перезарядки сняты; эскорты и крылья готовы.${ready?` Ракет на подлёте: <b>${ready}</b> — попадут в фазе удара.`:''}${b.round===5?'<br><b>Переломный момент</b>: с этого раунда можно уйти субсветовым выбросом (решение — до логистики).':''}${notes.length?'<br>'+notes.map(esc).join('<br>'):''}`)}
function bgEndImpact(){const b=BB();const out=[];
  b.units.forEach(u=>u.ships.forEach(s=>{if(s.grey>0&&!s.dead){const n=s.grey;bgDamage(u,s,n,{ios:1});s.grey--;out.push(`${s.name}: Грейвош ${n} урона`)}if(s.lock)s.lock=false}));
  if(out.length)bgLog('','Грейвош (конец фазы удара)',out.map(esc).join('<br>'))}
function bgNextPhase(){const b=BB();if(!b.started){bgStart();return}
  if(b.phase===1)bgEndImpact();
  if(b.phase<3)b.phase++;else{b.round++;b.phase=0;bgLogistics()}}

/* ---------- ракеты ---------- */
function bgFc(band,pl){return Math.max(1,band+(+pl||0))}
function bgLaunch(o){const b=BB();const att=bgU(o.from),tu=bgU(o.tgt);if(!att||!tu)return;
  const band=att.kind==='pc'?att.band:tu.band;
  const p={id:bgUid(),from:o.from,ckey:o.ckey||'',name:o.name,tgt:o.tgt,sid:o.at?'':o.sid,dmg:o.dmg,at:!!o.at,ok:!!o.ok,fc:0,dark:!!o.dark,round:b.round};
  if(band===0){bgImpactOne(p,true);return}
  p.fc=bgFc(band,o.pl);b.pls.push(p);const c=o.ckey&&att.c[o.ckey];if(c)c.busy=p.id;
  bgLog('',`Запуск: ${o.name}`,`${esc(att.name)} → ${esc(tu.name)}${p.sid?' / '+esc((bgShip(tu,p.sid)||{}).name||''):' (по площади)'} · счётчиков полёта: <b>${p.fc}</b>`)}
function bgImpactOne(p,instant){const att=bgU(p.from),tu=bgU(p.tgt);if(!tu)return;const r=bgRoll(p.dmg,{ok:p.ok});let d=r.tot;
  const band=att&&att.kind==='pc'?att.band:tu.band;if(p.at)d=bgAreaBand(band,d);
  let html=`${esc(p.name)}: ${esc(r.txt)} = <b>${d}</b>`;
  if(instant){html+=' · в упор: попадание сразу, без Перехвата';
    if(att){const half=Math.floor(d/2);if(p.at)bgApplyArea(att,half);else{const fs=att.ships.find(s=>!s.dead);if(fs)bgDamage(att,fs,half,{ios:0})}html+=`<br>Атакующий получает половину: ${half}`}}
  if(p.at){const hit=bgApplyArea(tu,d);html+=`<br>По площади: ${esc(hit.join(', '))}`}else{const s=bgShip(tu,p.sid);if(s){bgDamage(tu,s,d);html+=`<br>${esc(s.name)} получает ${d}`}}
  bgLog('hit',`Попадание ракеты → ${tu.name}`,html)}
function bgResolveImpact(tuid){const b=BB();const tu=bgU(tuid);if(!tu)return;const arr=b.pls.filter(p=>p.tgt===tuid&&p.fc===0);if(!arr.length)return;
  let pool=bgIntRoll(tu,'один раз против всех попаданий');const lines=[];
  arr.forEach(p=>{const att=bgU(p.from);const r=bgRoll(p.dmg,{ok:p.ok});let d=r.tot;const band=att&&att.kind==='pc'?att.band:tu.band;if(p.at)d=bgAreaBand(band,d);
    const cut=Math.min(pool,d);pool-=cut;let left=d-cut;let extra='';
    if(p.dark&&left>0){const x=bgRoll('1d6');left+=x.tot;extra=` +${x.tot} («Тёмная звезда»)`}
    const oc=att&&att.c[p.ckey];if(oc&&oc.busy===p.id)oc.busy='';
    if(left<=0){lines.push(`${esc(p.name)}: ${d} — полностью перехвачено`);return}
    if(p.at){const hit=bgApplyArea(tu,left);lines.push(`${esc(p.name)}: ${esc(r.txt)} = ${d}, −${cut} перехват${extra} → <b>${left}</b> по площади (${esc(hit.join(', '))})`)}
    else{const s=bgShip(tu,p.sid);if(s)bgDamage(tu,s,left);lines.push(`${esc(p.name)}: ${esc(r.txt)} = ${d}, −${cut} перехват${extra} → <b>${left}</b> по «${esc(s?s.name:'?')}»`)}});
  b.pls=b.pls.filter(p=>!arr.includes(p));bgLog('hit',`Фаза удара: ракеты → ${tu.name}`,lines.join('<br>'))}

/* ---------- атака по одной цели ---------- */
function bgAtkMods(a){const att=bgU(a.from),tu=bgU(a.tgt);if(!att||!tu)return[];const it=a.it,tg=a.tg||{};const M=[];
  const band=att.kind==='pc'?att.band:tu.band;const charge=!!tg.ch;
  if(band>=4){if(charge)M.push(['Дальняя/Предельная: оружие с Зарядом',1,0]);else M.push(['Дальняя/Предельная: атака по одной цели',0,1])}
  if(band<=1&&!charge)M.push(['Ближняя/в упор',1,0]);
  if(tg.acc)M.push(['Точное',1,0]);if(tg.inacc)M.push(['Неточное',0,1]);
  if(it&&it.id==='nkp'&&band<4)M.push(['Убойный пакет ближе 4: Неточное',0,1]);
  if(it&&it.id==='ckp'&&band>1)M.push(['Конические проекторы дальше 1',0,1]);
  const ts=bgShip(tu,a.sid);
  if(ts&&tu.kind==='npc'&&ts.esc&&(tg.sh||a.cat==='sh'))M.push(['Сверхтяжёлое против эскорта НИП',0,1]);
  if(ts&&tu.kind==='npc'&&tu.cap==='phantasm'&&ts.sid==='c')M.push(['Тепловой шлейф Фантазма',0,1]);
  if(att.kind==='npc'&&att.cap==='starkiller'&&a.owner==='c'&&band>=4)M.push(['Дальняя система наведения',1,0]);
  return M}
function bgDoAttack(){const a=BGS.atk;if(!a)return;const att=bgU(a.from),tu=bgU(a.tgt);const ts=tu&&bgShip(tu,a.sid);if(!att||!ts){toast('Выберите цель');return}
  const tg=a.tg||{};const M=bgAtkMods(a).filter((m,i)=>!(a.off||{})[i]);let acc=M.reduce((s,m)=>s+m[1],0)+(+a.acc||0),dif=M.reduce((s,m)=>s+m[2],0)+(+a.dif||0);
  if(a.lock&&ts.lock)acc+=a.lockBonus||1;
  const nm=n=>Math.max(0,n);let killdart=a.it&&a.it.en&&/Killdart/.test(a.it.en);if(killdart)dif=0;
  const ar=accRoll(nm(acc),nm(dif));const d20=rnd(20);const tot=d20+ar.val+(+a.flat||0);const def=bgDef(tu,ts);
  const hit=tot>=def;const solid=tu.kind==='npc'&&ts.sid==='c'&&['cornicen','hivequeen'].includes(tu.cap)||ts.esc==='battlethreads';
  const crit=hit&&tot>=20&&(tg.crit||a.critForce)&&!solid;
  let dmg=0,dtxt='';if(hit&&a.dmg){const r=bgRoll(a.dmg,{ok:tg.ok});dmg=r.tot;dtxt=r.txt;if(crit)dmg*=2}
  if(hit&&a.bonus)dmg+=+a.bonus;
  const rel=+(tg.rel||0)+(+a.rel||0);let relUsed=false;if(rel&&dmg<rel){if(!(tu.kind==='npc'&&tu.cap==='phantasm'&&ts.sid==='c'&&!hit)){dmg=rel;relUsed=true}}
  let half='';if(tu.kind==='npc'&&ts.sid==='c'&&tu.cap==='turtleback'&&att.kind==='pc'&&att.band>=3){dmg=Math.ceil(dmg/2);half='Усиленный корпус: половина урона'}
  if(tu.kind==='npc'&&ts.esc==='diluvia'){dmg=Math.ceil(dmg/2);half='Бесконечный прилив: половина урона'}
  if(a.lock&&ts.lock)ts.lock=false;
  a.res={d20,acc:ar,tot,def,hit,crit,dmg,dtxt,rel:relUsed,half,mods:M,accN:acc,difN:dif};
  bgLog(hit?'hit':'miss',`${a.name} → ${ts.name}`,`d20 [${d20}]${ar.val?` ${ar.val>0?'+':''}${ar.val} (${ar.net>0?'Точность':'Сложность'} ${ar.dice.join(',')})`:''}${+a.flat?` ${+a.flat>0?'+':''}${+a.flat}`:''} = <b>${tot}</b> против Защиты ${def}: ${hit?(crit?'<b>КРИТ!</b>':'попадание'):'промах'}${dmg?` · урон <b>${dmg}</b>${dtxt?' ('+esc(dtxt)+(crit?' ×2':'')+')':''}${relUsed?' — Надёжное':''}${half?' — '+esc(half):''}`:''}`);
  if(a.ckey){const c=att.c[a.ckey];if(c){if(tg.ch&&c.ch===0&&!tg.skip)c.ch=tg.ch;if(tg.lim)c.lim++;if(tg.rl)c.rl=tg.rl;if(a.it&&a.it.id==='block')c.vol=0}}}
function bgApplyAtk(){const a=BGS.atk;if(!a||!a.res)return;const tu=bgU(a.tgt);const ts=tu&&bgShip(tu,a.sid);if(!ts||a.res.applied)return;
  bgDamage(tu,ts,a.res.dmg);a.res.applied=true;if(a.extra)bgLog('',`${a.name}: дополнительный эффект`,bgfmt(a.extra))}

/* ---------- абордаж ---------- */
function bgBoardThr(tu,sid){const s=bgShip(tu,sid);if(tu.kind==='npc'&&s&&s.sid==='c'&&['cornicen','hivequeen'].includes(tu.cap))return 10;return 8}
function bgBoard(o){const b=BB();b.brd.push({id:bgUid(),from:o.from,ckey:o.ckey||'',name:o.name,ten:+o.ten||0,tgt:o.tgt,sid:o.sid,cmd:o.cmd||'',last:''});
  const att=bgU(o.from);const c=att&&o.ckey&&att.c[o.ckey];if(c)c.brd='1';
  bgLog('',`Абордаж: ${o.name}`,`${esc(att?att.name:'')} → ${esc((bgShip(bgU(o.tgt),o.sid)||{}).name||'')} · прибудет в фазе абордажа`)}
function bgBoardRoll(id){const b=BB();const r=b.brd.find(x=>x.id===id);if(!r)return;const tu=bgU(r.tgt);const thr=bgBoardThr(tu,r.sid);const d=rnd(20);const ok=d>=thr;
  r.last=ok?'успех':'провал';bgLog(ok?'hit':'miss',`Абордаж: ${r.name}`,`Команда: ${esc(r.cmd||'—')} · d20 [${d}] против ${thr}: <b>${ok?'успех':'без прогресса'}</b>`)}
function bgRepel(id){const b=BB();const r=b.brd.find(x=>x.id===id);if(!r)return;const d=rnd(20);const tu=bgU(r.tgt);const s=bgShip(tu,r.sid);
  const ok=r.ten?d>=r.ten:true;bgLog(ok?'hit':'miss',`Отражение абордажа: ${s?s.name:''}`,`d20 [${d}] против Упорства ${r.ten||'—'}: <b>${ok?'отряд выбит':'не удалось'}</b>`);
  if(ok)bgRecall(id,true)}
function bgRecall(id,silent){const b=BB();const r=b.brd.find(x=>x.id===id);if(!r)return;const att=bgU(r.from);const c=att&&r.ckey&&att.c[r.ckey];if(c)c.brd='';b.brd=b.brd.filter(x=>x!==r);if(!silent)bgLog('',`Отозван: ${r.name}`,'')}

/* ---------- выход из боя ---------- */
function bgLeave(uid,how){const b=BB();const u=bgU(uid);if(!u)return;
  b.pls=b.pls.filter(p=>p.from!==uid&&p.tgt!==uid);b.brd=b.brd.filter(r=>r.tgt!==uid&&r.from!==uid);b.units=b.units.filter(x=>x!==u);
  bgLog('',how==='eject'?`Субсветовой выброс: ${u.name}`:`Капитуляция: ${u.name}`,how==='eject'?'Ракеты группы и ракеты, летящие в неё, самоуничтожились; эскорты и крылья ушли вместе с ней. Можно бросить таблицу «Субсветовой выброс» в ГМ tools.':'Группа выбывает до конца боя, все её эффекты прекращаются.')}
