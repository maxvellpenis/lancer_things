import sys,json,pymupdf
sys.path.insert(0,'.')
from lines import *
for name,path in [('en',EN),('ru',RU)]:
    d=pymupdf.open(path);L={}
    for n in list(range(20,38))+list(range(56,86))+list(range(88,254)):
        L[n]=page_lines(d,n)
    json.dump(L,open(f'lines_{name}.json','w'),ensure_ascii=False)
print('ok')
