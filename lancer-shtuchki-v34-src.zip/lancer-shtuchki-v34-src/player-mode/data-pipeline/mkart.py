import json,pymupdf,io,base64,sys
from PIL import Image
d=json.load(open('pc/pcdata.json'))
U='/root/.claude/uploads/d0819c7c-129e-5c04-9991-5764081b769c/'
USER={'mf_blackbeard':'edd7a5b8','mf_drake':'c0e57c52','mf_lancaster':'31053073','mf_nelson':'3b0cb018','mf_raleigh':'69c73b3d','mf_tortuga':'8590d84e','mf_vlad':'e0ea2c7e'}
doc=pymupdf.open('/mnt/user-data/uploads/LANCER_-_Core_Rulebook.pdf')
art={};tot=0;src={}
for f in d['frames']:
    if f['id'] in USER:
        img=Image.open(U+USER[f['id']]+'-image.png').convert('RGBA');src[f['id']]='user'
    else:
        p=f['page'];best=None
        for n in (p,p+1):
            for x in doc[n-1].get_images(full=True):
                a=x[2]*x[3]
                if a>200*200 and (best is None or a>best[0]): best=(a,x[0],x[1],n)
        _,xref,smask,n=best
        pix=pymupdf.Pixmap(doc,xref)
        if smask: pix=pymupdf.Pixmap(pix,pymupdf.Pixmap(doc,smask))
        if pix.n-pix.alpha>3: pix=pymupdf.Pixmap(pymupdf.csRGB,pix)
        img=Image.open(io.BytesIO(pix.tobytes('png'))).convert('RGBA');src[f['id']]='book'
    bb=img.getchannel('A').getbbox()
    if bb: img=img.crop(bb)
    img.thumbnail((800,800),Image.LANCZOS)
    b=io.BytesIO();img.save(b,'WEBP',quality=76,method=4);s=b.getvalue();tot+=len(s)
    art[f['id']]='data:image/webp;base64,'+base64.b64encode(s).decode()
json.dump(art,open('pc/art.json','w'))
print(len(art),tot//1024,'KB',src)
