import json,pymupdf,sys
sys.path.insert(0,'.')
from lines import EN,RU
def lum(f): return 0.3*f[0]+0.59*f[1]+0.11*f[2]
for name,path in [('en',EN),('ru',RU)]:
    d=pymupdf.open(path);R={}
    for n in list(range(20,38))+list(range(48,56))+list(range(56,86))+list(range(88,254)):
        out=[]
        for g in d[n-1].get_drawings():
            f=g.get('fill');r=g['rect']
            if not f or r.width<40 or r.height<6 or r.y0<28 or r.y1>745: continue
            f=[round(c,3) for c in f[:3]]
            L=lum(f);sat=max(f)-min(f)
            kind='hdr' if (L<0.62 and (sat>0.15 or L<0.15) and r.height<=60) else 'big' if L<0.62 else 'body' if L<0.995 else 'white'
            out.append(dict(x0=r.x0,y0=r.y0,x1=r.x1,y1=r.y1,fill=f,kind=kind))
        R[n]=out
    json.dump(R,open(f'rects_{name}.json','w'))
print('ok')
