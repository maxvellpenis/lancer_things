import pymupdf,json,sys,re
EN='/mnt/user-data/uploads/LANCER_-_Core_Rulebook.pdf'
RU='/mnt/user-data/uploads/Lancer-Corebook__на_русском_.pdf'
ICON={0x01:'',0x1b:'[Линия]',0x1c:'[ТОЧН]',0x1e:'[Взрыв]',0x1f:'[Разрыв]',0x22:'[горение]',0x23:'[энерг]',0x24:'[взр]',0x25:'[нагрев]',0x26:'[кин]',0x29:'[СЛОЖН]',0x2e:'[Дальн]',0x38:'[Угроза]'}
def page_lines(doc,n):
    out=[]
    p=doc[n-1]
    for bi,b in enumerate(p.get_text('dict')['blocks']):
        for li,l in enumerate(b.get('lines',[])):
            if abs(l['dir'][0]-1)>0.01: continue
            spans=[]
            for s in l['spans']:
                t=s['text']
                if 'Icons' in s['font']:
                    o=''
                    for ci,c in enumerate(t):
                        if c==' ':
                            nx=t[ci+1] if ci+1<len(t) else ''
                            o+='' if (nx and nx not in ' \x01') else '[Конус]'
                        else: o+=ICON.get(ord(c),'{%02x}'%ord(c))
                    t=o
                f=s['font']
                kind='i' if ('Italic' in f or (s['flags']&2 and 'Consolas' in f)) else 'c' if 'Consolas' in f else 'b' if ('Bold' in f or s['flags']&16) else 'r'
                if 'Icons' in f: kind='x'
                spans.append((kind,t,round(s['size'],1),round(s['bbox'][0],1),round(s['bbox'][2],1)))
            txt=''.join(x[1] for x in spans)
            if not txt.strip(): continue
            x0,y0,x1,y1=l['bbox']
            if y0>742: continue
            cols=[s2['color'] for s2 in l['spans'] if s2['text'].strip() and 'Icons' not in s2['font']]
            cc=cols[0] if cols else 0
            r_,g_,b_=(cc>>16)&255,(cc>>8)&255,cc&255
            light=(0.3*r_+0.59*g_+0.11*b_)/255>0.8
            out.append(dict(p=n,b=bi,li=li,x=x0,y=y0,x1=x1,y1=y1,col=0 if x0<300 else 1,t=txt,spans=spans,size=max(x[2] for x in spans),light=light))
    return out
