import json,re,sys
sys.path.insert(0,'.')
from locate import ents,find,norm
LE={int(k):v for k,v in json.load(open('lines_en.json')).items()}
LR={int(k):v for k,v in json.load(open('lines_ru.json')).items()}
byid={e['id']:e for e in ents}
CBP=set([118,119,120,121,126,127,158,159,190,191,224,225])
loc={}
# frames first
for e in ents:
    if e['kind']!='frame': continue
    r=find(e)
    if r: loc[e['id']]=max(r,key=lambda x:x[3])
def pick(e,r):
    k=e['kind']
    if k in('trait','core','core_active_name','core_passive_name'):
        fp=loc.get(e['parent']);
        if not fp: return None
        r=[x for x in r if fp[0]<=x[0]<=fp[0]+(3 if k.startswith('core_') else 1)]
        if not r: return None
        if k=='core': return max(r,key=lambda x:x[3])
        if k.startswith('core_'):
            r2=[x for x in r if x[3]<14]; return (r2 or r)[0]
        return r[0]
    if k=='cb':
        r=[x for x in r if x[0] in CBP]; r=sorted(r,key=lambda x:abs(x[3]-10)); return r[0] if r else None
    if k in('talent','rank'): return max(r,key=lambda x:x[3])
    r2=[x for x in r if 11<=x[3]<14]
    return (r2 or r)[0]
for e in ents:
    if e['kind']=='frame': continue
    r=find(e)
    if r:
        x=pick(e,r)
        if x: loc[e['id']]=x
print('located',len(loc),file=sys.stderr)
# RU header for each
import re as _re
def cands(L):
    out=[]
    for i,l in enumerate(L):
        ks=[k for k,t,*_ in l['spans'] if t.strip()]
        t=l['t'].strip()
        if l['li']==0 and ks and all(k=='b' for k in ks) and 9.5<=l['size']<=14.5 and not _re.fullmatch(r'[•\d\s]*',t) and len(t)>1:
            out.append(i)
    return out
CE={p:cands(L) for p,L in LE.items()};CR={p:cands(L) for p,L in LR.items()}
def ru_header(p,i,y,col,size):
    ce=[j for j in CE.get(p,[]) if LE[p][j]['col']==col]
    cr=[j for j in CR.get(p,[]) if LR[p][j]['col']==col]
    ce.sort(key=lambda j:LE[p][j]['y']);cr.sort(key=lambda j:LR[p][j]['y'])
    if i in ce and len(ce)==len(cr): return cr[ce.index(i)]
    best=None
    for j,l in enumerate(LR.get(p,[])):
        if l['col']!=col or l['spans'][0][0]!='b': continue
        if abs(l['size']-size)>2.6: continue
        dy=abs(l['y']-y)
        if dy<=34 and (best is None or dy<best[0]): best=(dy,j)
    return best[1] if best else None
ruloc={}
for id,(p,i,k,sz,y,col) in loc.items():
    j=ru_header(p,i,y,col,sz)
    if j is not None: ruloc[id]=(p,j)
print('ru located',len(ruloc),file=sys.stderr)
# boundaries per page/col
def bounds(L,locmap,lang):
    B={}
    for id,(p,i) in locmap.items():
        l=L[p][i];B.setdefault((p,l['col']),[]).append(l['y'])
    for p,ls in L.items():
        for l in ls:
            t=l['t'].strip()
            if (l['size']>=13.5 and l['li']==0 and not any(o['col']==l['col'] and o['size']>=13.5 and 0<l['y']-o['y']<o['y1']-o['y']+6 for o in ls)) or re.match(r'^(LICENSE|ЛИЦЕНЗИЯ)\b',t) or t in('TRAITS','ЧЕРТЫ','MOUNTS','СЛОТЫ','CORE SYSTEM','СИСТЕМА ЯДРА','CORE STATS'):
                B.setdefault((p,l['col']),[]).append(l['y'])
    return B
locE={id:(v[0],v[1]) for id,v in loc.items()}
BE=bounds(LE,locE,'en');BR=bounds(LR,ruloc,'ru')
def body(L,B,p,i):
    h=L[p][i];col=h['col']
    def collect(p,col,y0):
        nb=min([y for y in B.get((p,col),[]) if y>y0+1],default=9999)
        ls=[l for l in L[p] if l['col']==col and y0+1<l['y']<nb-1]
        return ls,nb<9999
    ls,stop=collect(p,col,h['y'])
    # same-block continuation lines of header (multi-line names)
    if not stop and col==0:
        ls2,stop=collect(p,1,0);ls+=ls2
    ext=[]
    for l in sorted([l for l in ls if l['b']==h['b']],key=lambda l:l['li']):
        ks=[k for k,t,*_ in l['spans'] if t.strip()]
        if l['li']==h['li']+1+len(ext) and ks and all(k=='b' for k in ks) and abs(l['size']-h['size'])<1.5: ext.append(l)
    last=ext[-1] if ext else h
    for l in sorted(ls,key=lambda l:l['y']):
        if l in ext or l is h: continue
        ks=[k for k,t,*_ in l['spans'] if t.strip()]
        if l['col']==h['col'] and 0<l['y']-last['y']<last['y1']-last['y']+6 and ks and all(k=='b' for k in ks) and abs(l['size']-h['size'])<1.5 and l['size']>=11:
            ext.append(l);last=l
        elif l['y']>last['y1']+1: break
    ls=[l for l in ls if l not in ext]
    return ls,' '.join([h['t'].strip()]+[l['t'].strip() for l in ext])
def line_chars(l,keepi):
    out=[];px=None
    allit=all(sp[0]=='i' for sp in l['spans'] if sp[1].strip())
    for sp in l['spans']:
        k,t=sp[0],sp[1]
        if k=='i' and not keepi and allit: continue
        x0,x1=sp[3],sp[4]
        if px is not None and x0-px>1.2 and out and out[-1][0]!=' ' and t[:1]!=' ': out.append((' ',False))
        if k!='x': t=_re.sub(r'(?<=\S) {3,}(?=\S|$)',' ⟨□⟩ ',t) if len(t.strip())>0 else t
        b=(k=='b')
        for c in t: out.append((c,b and c.strip()!='' and c not in '⟨□⟩'))
        px=x1
    while out and out[0][0].isspace(): out.pop(0)
    while out and out[-1][0].isspace(): out.pop()
    return out
def chars_to_md(ch):
    s='';b=False
    for i,(c,cb) in enumerate(ch):
        if c.isspace() or c=='\n':
            # keep bold run across spaces if next non-space bold
            s+=c;continue
        if cb and not b: s+='**';b=True
        elif not cb and b:
            # close before trailing spaces
            m=len(s)-len(s.rstrip(' \n'));s=s[:len(s)-m]+'**'+s[len(s)-m:] if m else s+'**';b=False
        s+=c
    if b: s+='**'
    s=_re.sub(r'\*\*(\s*)\*\*',r'\1',s)
    return s
RECTS={k:{int(p):v for p,v in json.load(open(f'rects_{k}.json')).items()} for k in ('en','ru')}
def KIND(f):
    r,g,b=f
    if max(f)<0.12: return 'w'
    if g>0.6 and r<0.5: return 's'
    if g>0.4 and b>0.4 and r<0.15: return 'r'
    if r>0.4 and b>0.4 and g<0.3: return 't'
    if r>0.6 and g>0.3 and b<0.05: return 'o'
    if b>0.6 and r<0.3: return 'x'
    return 'c'
def boxof(l,lang):
    if not l.get('light'): return None
    rs=RECTS[lang].get(l['p'],[]);cx=(l['x']+l['x1'])/2;cy=(l['y']+l['y1'])/2;best=None
    for i,r in enumerate(rs):
        if r['kind']=='hdr' and r['x0']-2<=l['x']+1 and l['x1']<=r['x1']+30 and r['x0']-2<=cx<=r['x1']+2 and r['y0']-2<=cy<=r['y1']+2:
            a=(r['x1']-r['x0'])*(r['y1']-r['y0'])
            if best is None or a<best[0]: best=(a,i)
    return best[1] if best else None
def region(p,i,lang):
    rs=RECTS[lang].get(p,[]);r=rs[i];bottom=r['y1'];ch=True
    while ch:
        ch=False
        for rr in rs:
            if rr['kind'] in('body','white') and rr['y0']<=bottom+4 and rr['y1']>bottom+0.5 and rr['x0']<r['x1'] and rr['x1']>r['x0'] and abs(rr['x0']-r['x0'])<14:
                bottom=rr['y1'];ch=True
    return (r['x0']-3,r['y0']-2,r['x1']+3,bottom+2)
JOINS=[]
KEEPH=set(open('keeph.txt').read().split()) if __import__('os').path.exists('keeph.txt') else set()
def render(ls,keepi=False,h=None,lang='ru'):
    ls=sorted(ls,key=lambda l:(l['col'],l['y']))
    rows=[]
    for l in ls:
        if rows and rows[-1][0]['col']==l['col'] and abs(rows[-1][0]['y']-l['y'])<3.2: rows[-1].append(l)
        else: rows.append([l])
    ls=[l for r in rows for l in sorted(r,key=lambda l:l['x'])]
    # bullets drawn as separate glyphs: glue to nearest text line on the right
    BUL=('•','▪','■','●')
    glyph=[l for l in ls if l['t'].strip() in BUL]
    for g in glyph:
        cands=[o for o in ls if o is not g and o['col']==g['col'] and o['p']==g['p'] and o['x']>g['x'] and o['t'].strip() not in BUL and abs(o['y']-g['y'])<=8]
        if cands:
            o=min(cands,key=lambda o:abs(o['y']-g['y']))
            if not o.get('bul'):
                o['bul']=g['t'].strip();ls.remove(g)
    own=boxof(h,lang) if h else None
    ownset=set()
    if own is not None:
        rs=RECTS[lang][h['p']];ownset={own};ch=True
        while ch:
            ch=False
            for k,r in enumerate(rs):
                if k in ownset or r['kind']!='hdr' or KIND(r['fill'])!=KIND(rs[own]['fill']): continue
                if any(r['x0']<rs[o]['x1'] and r['x1']>rs[o]['x0'] and r['y0']<=rs[o]['y1']+4 and r['y1']>=rs[o]['y0']-4 for o in ownset): ownset.add(k);ch=True
    tag=[];blocks=[];cur={'t':'text','ch':[],'prev':None}
    blocks.append(cur);started=False;box=None
    def add(c,l,txt):
        ch=cur['ch'];prev=cur['prev']
        if prev is not None and ch:
            gap=l['y']-prev['y1'];same_row=abs(l['y']-prev['y'])<2.5
            if txt in('•','▪'): ch.extend([('\n',False),(txt,False)]);cur['prev']=l;return
            if ch[-1][0] in '•▪': ch.append((' ',False))
            elif same_row: ch.append((' ',False))
            elif gap>4 or (l['y']-prev['y'])>1.38*max(l['size'],prev['size']) or txt[:1] in '•▪' or l.get('bul') or (l['x']<prev['x']-6 and l['col']==prev['col'] and l['p']==prev['p']): ch.append(('\n',False))
            elif ch[-1][0] in '-­' and txt[:1].islower():
                lw=''.join(x for x,_ in ch[-25:]).split()[-1] if ch else '';rw=txt.split()[0] if txt.split() else ''
                if (lw+rw) in KEEPH: pass
                else: JOINS.append(lw+rw);ch.pop()
            elif ch[-1][0]=='/': pass
            else: ch.append((' ',False))
        ch.extend(c);cur['prev']=l
    for l in ls:
        kinds=[sp[0] for sp in l['spans'] if sp[1].strip()]
        if kinds and all(k=='i' for k in kinds) and not keepi: continue
        c=line_chars(l,keepi)
        if not c: continue
        if l.get('bul'): c=[(l['bul'],False),(' ',False)]+c
        txt=''.join(x for x,_ in c)
        cons=bool(kinds) and all(k in('c','x') for k in kinds)
        b=boxof(l,lang)
        if b is not None and b in ownset and l['p']==h['p']:
            if cons and not started: tag.append(txt)
            continue
        if cons and not started and b is None: tag.append(txt);continue
        if b is not None:
            rs=RECTS[lang][l['p']]
            if box is not None and box['b']!=b and box['p']==l['p']:
                ra,rb2=rs[box['b']],rs[b]
                if rb2['y0']<=ra['y1']+4 and rb2['y1']>=ra['y0']-2 and rb2['x0']<ra['x1'] and rb2['x1']>ra['x0'] and KIND(ra['fill'])==KIND(rb2['fill']):
                    reg=region(l['p'],b,lang);box['reg']=(min(box['reg'][0],reg[0]),box['reg'][1],max(box['reg'][2],reg[2]),max(box['reg'][3],reg[3]));box['b']=b
            if box is None or box['b']!=b:
                box={'t':'box','b':b,'p':l['p'],'k':KIND(rs[b]['fill']),'name':'','tags':'','reg':region(l['p'],b,lang),'ch':[],'prev':None}
                blocks.append(box);cur=box
            if cons: box['tags']+=(' ' if box['tags'] and box['tags'].rstrip().endswith(',') else (' · ' if box['tags'] else ''))+txt
            else: box['name']+=(' ' if box['name'] else '')+txt.strip()
            started=True;continue
        if box is not None:
            x0,y0,x1,y1=box['reg']
            cy=(l['y']+l['y1'])/2
            if l['p']==box['p'] and x0<=l['x']<=x1 and cy<=y1: add(c,l,txt);started=True;continue
            box=None;cur={'t':'text','ch':[],'prev':None};blocks.append(cur)
        add(c,l,txt);started=True
    out=[]
    for bl in blocks:
        t=chars_to_md(bl['ch']).strip()
        t=_re.sub(r'[ \t]{2,}',' ',t);t=_re.sub(r' +([,.;:)])',r'\1',t)
        if bl['t']=='box':
            out.append('⟦A:%s⟧%s⟦T⟧%s⟦E⟧%s⟦Z⟧'%(bl['k'],bl['name'].replace('**',''),bl['tags'],t))
        elif t: out.append(t)
    return ' '.join(tag),'\n'.join(out)
out={}
for id in loc:
    p,i=locE[id]
    ki=byid[id]['kind']=='skill'
    bl,hn=body(LE,BE,p,i);et,eb=render(bl,ki,LE[p][i],'en')
    r=dict(page=p,en_head=hn,en_tags=et,en=eb)
    if id in ruloc:
        rp,ri=ruloc[id]
        bl,hn=body(LR,BR,rp,ri);rt,rb=render(bl,ki,LR[rp][ri],'ru')
        allL=[LR[rp][ri]]+bl;bb={}
        for l in allL:
            k=(l['p'],l['col']);b=bb.get(k,[9e9,9e9,0,0]);bb[k]=[min(b[0],l['x']),min(b[1],l['y']),max(b[2],l['x1']),max(b[3],l['y1'])]
        r['ru_bbox']=[[k[0]]+v for k,v in bb.items()]
        r.update(ru_head=hn,ru_tags=rt,ru=rb)
        fl='';prev=None
        for l in sorted(bl,key=lambda l:(l['p'],l['col'],l['y'])):
            ks=[sp[0] for sp in l['spans'] if sp[1].strip()]
            if not ks or not all(k=='i' for k in ks): continue
            t=l['t'].strip()
            if prev is not None and (l['y']-prev['y']>1.6*l['size'] or l['p']!=prev['p']) and fl and fl[-1] in '.!?»"': fl+='\n'
            elif fl.endswith('-') and t[:1].islower(): fl=fl[:-1]
            elif fl: fl+=' '
            fl+=t;prev=l
        r['ru_flav']=_re.sub(r' +',' ',fl).strip()
    out[id]=r
json.dump(out,open('texts.json','w'),ensure_ascii=False,indent=0)

open('joins.txt','w').write('\n'.join(sorted(set(JOINS))))
