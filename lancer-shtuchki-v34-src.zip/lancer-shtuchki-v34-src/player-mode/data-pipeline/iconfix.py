import re,difflib
NUM=r'[+\-]?\d+(?:d\d+)?(?:[+\-]\d+(?:d\d+)?)?(?:/[+\-]?\d+)*'
ICO=r'\[[А-ЯЁа-яё]+\]'
TOK=re.compile(f'({ICO})|({NUM})')
SEP=re.compile(r'^[\s*]*$')
def toks(s):
    out=[]
    for m in TOK.finditer(s):
        out.append(('I' if m.group(1) else 'N',m.group(0),m.start(),m.end()))
    return out
def fix(en,ru):
    E=toks(en);R=toks(ru)
    en_nums=[t for t in E if t[0]=='N'];ru_nums=[t for t in R if t[0]=='N']
    sm=difflib.SequenceMatcher(None,[t[1] for t in en_nums],[t[1] for t in ru_nums],autojunk=False)
    pairs={}
    for a,b,n in sm.get_matching_blocks():
        for k in range(n): pairs[id(en_nums[a+k])]=ru_nums[b+k]
    ins=[]
    for idx,t in enumerate(E):
        if t[0]!='N' or id(t) not in pairs: continue
        r=pairs[id(t)]
        # icon after
        if idx+1<len(E) and E[idx+1][0]=='I' and SEP.match(en[t[3]:E[idx+1][2]]):
            ri=[x for x in R if x[0]=='I' and x[2]>=r[3] and SEP.match(ru[r[3]:x[2]])]
            if not ri: ins.append((r[3],' '+E[idx+1][1]))
        if idx>0 and E[idx-1][0]=='I' and SEP.match(en[E[idx-1][3]:t[2]]) and not (idx>1 and E[idx-2][0]=='N' and SEP.match(en[E[idx-2][3]:E[idx-1][2]])):
            ri=[x for x in R if x[0]=='I' and x[3]<=r[2] and SEP.match(ru[x[3]:r[2]])]
            if not ri: ins.append((r[2],E[idx-1][1]))
    for pos,txt in sorted(ins,reverse=True): ru=ru[:pos]+txt+ru[pos:]
    return ru,len(ins)
if __name__=='__main__':
    print(fix('creates a[Разрыв]1 shield, gain +1 [ТОЧН] and 1d6 [энерг].','создаст 1 щит, +1 . и 1d6 .'))

ICO2=re.compile(r'\[(?:ТОЧН|СЛОЖН|кин|энерг|взр|горение|нагрев|Дальн|Угроза|Линия|Конус|Взрыв|Разрыв)\]|⟨□⟩')
TK=re.compile(r'\[(?:ТОЧН|СЛОЖН|кин|энерг|взр|горение|нагрев|Дальн|Угроза|Линия|Конус|Взрыв|Разрыв)\]|⟨□⟩|[+\-]?\d+(?:d\d+)?(?:[+\-]\d+)?')
def fill_slots(en,ru):
    E=[m.group(0) for m in TK.finditer(re.sub(r'⟦[^⟧]*⟧',' ',en or ''))]
    R=list(TK.finditer(ru))
    if not any(m.group(0)=='⟨□⟩' for m in R): return ru,0
    n,m_=len(E),len(R)
    isI=lambda t:t.startswith('[')
    def sc(e,r):
        if r=='⟨□⟩': return 1.5 if isI(e) else -2
        return 2 if e==r else -1
    S=[[0]*(m_+1) for _ in range(n+1)]
    for a in range(1,n+1):S[a][0]=-a*0.5
    for b in range(1,m_+1):S[0][b]=-b*0.5
    for a in range(1,n+1):
        for b in range(1,m_+1):
            S[a][b]=max(S[a-1][b-1]+sc(E[a-1],R[b-1].group(0)),S[a-1][b]-0.5,S[a][b-1]-0.5)
    a,b=n,m_;fill={}
    while a>0 and b>0:
        if S[a][b]==S[a-1][b-1]+sc(E[a-1],R[b-1].group(0)):
            if R[b-1].group(0)=='⟨□⟩' and isI(E[a-1]): fill[b-1]=E[a-1]
            a-=1;b-=1
        elif S[a][b]==S[a-1][b]-0.5: a-=1
        else: b-=1
    out=[];k=0;cnt=0
    for j,mm in enumerate(R):
        if mm.group(0)!='⟨□⟩': continue
        out.append(ru[k:mm.start()]);
        if j in fill: out.append(fill[j]);cnt+=1
        k=mm.end()
    out.append(ru[k:]);s2=''.join(out)
    s2=re.sub(r' +([.,;:)])',r'\1',s2);s2=re.sub(r' {2,}',' ',s2)
    return s2,cnt
