import json,re
L=json.load(open('lines_ru.json'))
B=json.load(open('../ld/repo2/lib/backgrounds.json'))
NAMES=['Знаменитость','Колонист','Преступник','Член Группы Дальней Разведки','Хакер','Механик','Медик','Наёмник','Специалист по НЧЛ','Дворянин','Вне закона','Колонист-Уголовник','Священник','Ученый','Солдат','Косморождённый','Член Спецназа','Супер Солдат','Пилот Космофлота','Работяга']
segs=[]
for p in ['21','22','23','24']:
  for col in (0,1):
    ls=sorted([l for l in L[p] if (l['x']>290)==bool(col)],key=lambda l:l['y'])
    for l in ls:
      t=l['t'].strip()
      if l['size']>=11.5 and t in NAMES: segs.append(dict(name=t,trig=[],body=[]));continue
      if not segs: continue
      if l['size']>=9.9 and l['spans'][0][0]=='b' and (t.isupper() or t in('НЧЛы',) or t.startswith('Примечание') or t.startswith('"вестерна')): segs[-1]['stop']=1;continue
      if segs[-1].get('stop'): continue
      if t.startswith('Примеры') or (l['spans'][0][0]=='c'): segs[-1]['trig'].append(t);continue
      if t.startswith('РАЗДЕЛ') or re.match(r'^\[\d+\]$',t) or t=='ПИЛОТ': continue
      segs[-1]['body'].append(l)
print(len(segs),[s['name'] for s in segs])
def para(ls):
  out='';prev=None
  for l in ls:
    t=l['t'].strip()
    if prev is None: out=t
    elif l['y']-prev['y']>1.6*l['size'] : out+='\n'+t
    elif out.endswith('-') and re.match(r'[а-яё]',t): out=out[:-1]+t
    else: out+=' '+t
    prev=l
  return re.sub(r' +',' ',out)
res=[]
for b,s in zip(B,segs):
  tr=re.sub(r'^Примеры триггеров:\s*','',' '.join(s['trig'])).replace('- ','-').replace('что-то','что-то')
  tr=re.sub(r'(\w)- (\w)',r'\1-\2',' '.join(s['trig'])); tr=re.sub(r'^Примеры триггеров:\s*','',tr)
  res.append(dict(id=b['id'],en=b['name'],name=s['name'],trig=tr,skills=b['skills'],text=para(s['body'])))
for r in res:
  if r['id']=='pbg_spec_ops': r['trig']=r['trig'].replace('Разведчик,Сохранять','Разведчик, Сохранять Хладнокровие'); r['text']=r['text'].replace('Вы Хладнокровие могли','Вы могли')
  r['trig']=r['trig'].replace('Хладно-кровие','Хладнокровие')
json.dump(res,open('bg_ru.json','w'),ensure_ascii=False,indent=1)
for r in res: print(r['en'],'|',r['name'],'|',r['trig'],'|',len(r['text']),r['text'][:80],'…',r['text'][-60:])
