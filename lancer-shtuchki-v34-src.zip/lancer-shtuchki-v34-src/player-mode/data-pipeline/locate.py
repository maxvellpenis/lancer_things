import json,re,unicodedata
D='/tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad/ld/repo2/lib/'
LE={int(k):v for k,v in json.load(open('lines_en.json')).items()}
def norm(s): 
    s=unicodedata.normalize('NFKD',s).replace('ĳ','ij').replace('’',"'")
    return re.sub(r'[^a-z0-9]','',s.lower())
ents=[]
def add(kind,id,name,pr,parent=None): ents.append(dict(kind=kind,id=id,name=name,pr=pr,parent=parent))
J=lambda f:json.load(open(D+f+'.json'))
MECH=range(116,254)
for f in J('frames'):
    if f['id']=='missing_frame' or 'ERR' in f['name']: continue
    add('frame',f['id'],f['name'],MECH)
    for i,t in enumerate(f['traits']): add('trait',f['id']+'#t'+str(i),t['name'],MECH,f['id'])
    cs=f['core_system']
    add('core',f['id']+'#core',cs['name'],MECH,f['id'])
    for k in ('active_name','passive_name'):
        if cs.get(k): add('core_'+k,f['id']+'#'+k,cs[k],MECH,f['id'])
for k in ('weapons','systems','mods'):
    for x in J(k): add(k[:-1],x['id'],x['name'],range(90,104) if x.get('talent_item') else MECH)
for x in J('core_bonuses'): add('cb',x['id'],x['name'],MECH)
for x in J('talents'):
    add('talent',x['id'],x['name'],range(90,104))
    for i,r in enumerate(x['ranks']): add('rank',x['id']+'#'+str(i),r['name'],range(90,104),x['id'])
for x in J('pilot_gear'): add('gear',x['id'],x['name'],range(104,116))
for x in J('skills'): add('skill',x['id'],x['name'],range(26,28))
def find(e):
    n=norm(e['name']);res=[]
    for p in e['pr']:
        L=LE.get(p,[])
        for i,l in enumerate(L):
            t=norm(l['t'])
            cand=[t]
            if i+1<len(L) and L[i+1]['b']==l['b']: cand.append(t+norm(L[i+1]['t']))
            for c in cand:
                if c==n or (e['kind'] in('frame',) and c==n): 
                    res.append((p,i,l['spans'][0][0],l['size'],l['y'],l['col']));break
    return res
if __name__=='__main__':
    miss=[];multi=[];out={}
    for e in ents:
        r=find(e)
        if not r: miss.append(e)
        else:
            # prefer bold
            rb=[x for x in r if x[2]=='b'] or r
            if len(rb)>1: multi.append((e['kind'],e['name'],[x[:2]+x[3:4] for x in rb]))
            out[e['id']]=dict(e,pr=None,hits=rb)
    print('total',len(ents),'found',len(out),'miss',len(miss))
    for m in miss: print('MISS',m['kind'],m['id'],m['name'])
    print('MULTI',len(multi));[print(m) for m in multi[:60]]
    json.dump(out,open('loc_en.json','w'),ensure_ascii=False)
