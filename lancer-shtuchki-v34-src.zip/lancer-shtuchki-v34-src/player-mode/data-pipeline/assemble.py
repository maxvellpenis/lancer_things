import json,re,sys
sys.path.insert(0,'.')
from iconfix import fix,fill_slots
D='/tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad/ld/repo2/lib/'
J=lambda f:json.load(open(D+f+'.json'))
T=json.load(open('texts.json'));G=json.load(open('gloss_ru.json'))
SMALL={'под','над','при','про','у','а','но','же','и','в','во','по','от','к','с','со','для','на','из','о','об','без','до','за','или','не','—','-'}
ACR={'ИИ','НЧЛ','СШК','ОПХ','ДМС','ИПС-Н','МЯ','ПЗ','СП','РВ','ТBK','MK','IV','ЭКС','СОЛ','ХОРУС','II','III','I','М35','ОББ','ОБД','СИ/ПН','ЗФ4'}
def tc(s):
    s=re.sub(r'\s+',' ',s.strip())
    if s!=s.upper(): return s
    out=[]
    for i,w in enumerate(s.split(' ')):
        core=w.strip('«»"“”(),.!?')
        if core in ACR or re.fullmatch(r'[A-Z0-9\-/]+',core) and not re.search('[А-Я]',core): out.append(w);continue
        lw=w.lower()
        if i>0 and lw in SMALL: out.append(lw);continue
        PART={'то','либо','нибудь','ка','таки'}
        segs=lw.split('-')
        out.append('-'.join(p if (j>0 and p in PART) else p[:1].upper()+p[1:] for j,p in enumerate(segs)) if not lw.startswith(('«','"','“')) else lw[0]+lw[1:2].upper()+lw[2:])
    return ' '.join(out)
def clean(t):
    t=re.sub(r'(\d) ?d ?(\d)',r'\1d\2',t or '');t=re.sub(r'(\d)к(\d)',r'\1d\2',t)
    t=t.replace('­','')
    t=re.sub(r'\s*(\*\*Эффект)',r'\n\1',t)
    t=re.sub(r'\s*(\*\*При (Попадании|Атаке|Критическом Попадании))',r'\n\1',t)
    return t.strip()
OV={
 'mf_vlad#t1':dict(ru_body='Когда персонаж в пределах [Дальн]3 атакует Влада, атакующий сначала получает **1** [кин] **ББ** урона.'),
 'mf_pegasus#t0':dict(ru_head='¿%:?Вытес!няющий Пистолет',ru_body='Пистолет: **Пистолет**'),
 'mf_saladin#t1':dict(ru_body='Соседние союзные персонажи могут использовать Саладина как **твердое укрытие**.'),
 'mw_anti_materiel_rifle':dict(ru_head='Крупнокалиберная Снайперская Винтовка'),
 'mw_cyclone_pulse_rifle':dict(ru_head='Импульсная Винтовка «Циклон»'),
 'mw_heavy_charged_blade':dict(ru_head='Тяжёлый Заряженный Клинок'),
 'mf_drake#t1':dict(ru_head='АБРАЗИВНОЕ НАПЫЛЕНИЕ',ru_body='Дрейк имеет **Сопротивляемость** к урону, [горение] и [нагрев] от атак [Взрыв], [Разрыв], [Линия] и [Конус].'),
 'mf_saladin#t2':dict(ru_head='ИСКАЖАЮЩИЙ ЩИТ',ru_pre='**1/раунд**, Саладин в качестве **реакции** может дать '),
 't_hacker#2':dict(ru_head='ПОСЛЕДНИЙ АРГУМЕНТ КОРОЛЕЙ'),
 'ms_sekhmet_class_nhp':dict(ru_head='НЧЛ класса «Сехмет»'),
}
def ru(id,kind=None):
    r=T.get(id)
    if not r or 'ru' not in r: return None,None,None
    o=OV.get(id,{})
    name=o.get('ru_head',r['ru_head'])
    body=clean(r['ru'])
    body,_=fill_slots(r['en'],body)
    body,_=fix(r['en'],body)
    if 'ru_pre' in o: body=o['ru_pre']+body
    if 'ru_body' in o: body=o['ru_body']
    if id.startswith('mw_') and T[id]['page']==119: body=''
    if id=='ms_reinforced_cabling' and '⟦A' in body: body=body[:body.index('⟦A')].strip()
    if id=='ms_sekhmet_class_nhp': body='Ваш мех получает метку **ИИ** и **Протокол СЕХМЕТ**.\n⟦A:o⟧Протокол СЕХМЕТ⟦T⟧Протокол⟦E⟧'+body+'⟦Z⟧'
    if id=='ms_asura_class_nhp': body=body.replace('Ограниченное,','Ограниченное 1,')
    if id=='t_bonded#1' and body.endswith('вместо него'): body+='.'
    tg,_=fill_slots(r.get('en_tags',''),r.get('ru_tags',''))
    return tc(name),body,tg.replace('⟨□⟩','')
def strip_flavor(id,body):
    en=T[id]['en'];pe=[p for p in en.split('\n') if p.strip()];pr=[p for p in body.split('\n') if p.strip()]
    # EN body may contain flavor too (non-italic): count paragraphs of data effect instead
    return pr
WS_RU={'Auxiliary':'Вспомогательное','Main':'Основное','Heavy':'Тяжелое','Superheavy':'Сверхтяжелое'}
WT_RU={'Melee':'ОББ','CQB':'ОБД','Rifle':'Винтовка','Launcher':'ПУ','Cannon':'Пушка','Nexus':'Звено'}
RR={'Range':'Дальн.','Threat':'Угроза','Line':'Линия','Cone':'Конус','Blast':'Взрыв','Burst':'Разрыв'}
DR={'kinetic':'кин.','energy':'энерг.','explosive':'взр.','burn':'горения','heat':'нагрева'}
TAGRU0={'tg_burn':'Горение {VAL}','tg_heat_target':'Перегрев {VAL} (цель)','tg_accurate':'Точное','tg_arcing':'Дуговое','tg_ap':'ББ','tg_inaccurate':'Неточное','tg_knockback':'Толчок {VAL}','tg_loading':'Заряжаемое','tg_ordnance':'Артиллерийское','tg_overkill':'Избыточный Урон','tg_overshield':'Усиление Щита','tg_reliable':'Надежное {VAL}','tg_seeking':'Искатель','tg_smart':'Умное','tg_threat':'Угроза {VAL}','tg_thrown':'Бросок {VAL}','tg_turn':'{VAL}/Ход','tg_round':'{VAL}/Раунд','tg_ai':'ИИ','tg_danger_zone':'Опасная Зона','tg_deployable':'Размещаемое','tg_drone':'Дрон','tg_full_action':'Полное Действие','tg_grenade':'Граната','tg_heat_self':'Нагрев {VAL} (свой)','tg_limited':'Ограниченное {VAL}','tg_mine':'Мина','tg_mod':'Мод','tg_protocol':'Протокол','tg_quick_action':'Быстрое Действие','tg_reaction':'Реакция','tg_shield':'Щит','tg_unique':'Уникальное','tg_invade':'Вторжение','tg_quick_tech':'Быстрая Технология','tg_full_tech':'Полная Технология','tg_free_action':'Свободное Действие','tg_recharge':'Перезарядка {VAL}+','tg_unlimited':'Неограниченное','tg_resistance':'Сопротивляемость'}
ROLE={'Striker':'Нападающий','Defender':'Защитник','Support':'Поддерживающий','Controller':'Оператор','Artillery':'Артиллерист','Balanced':'Универсальный'}
MAN={'GMS':'ДМС','IPS-N':'ИПС-Н','SSC':'СШК','HORUS':'ХОРУС','HA':'ОПХ'}
out=dict(frames=[],weapons=[],systems=[],mods=[],talents=[],cbs=[],gear=[],skills=[],tags={},miss=[])
def rutag(sp,tg):
    parts=([f'{sp} СП'] if sp else [])
    for t in tg or []:
        if t['id'] not in TAGRU0: continue
        parts.append(TAGRU0[t['id']].replace('{VAL}',str(t.get('val','X'))))
    return ', '.join(parts)
def rng(a): return [{'t':x['type'],'v':x['val']} for x in (a or [])]
def dmg(a): return [{'t':x.get('type','variable').lower(),'v':x['val']} for x in (a or [])]
def tags(a): return [[x['id'],x.get('val')] for x in (a or [])]
for f in J('frames'):
    if f['id'] not in T: continue
    n,_,_=ru(f['id'])
    tr=[]
    for i,t in enumerate(f['traits']):
        tn,tb,_=ru(f['id']+'#t'+str(i))
        if tn is None: out['miss'].append(f['id']+'#t'+str(i))
        if tb and '⟦A:c⟧' in tb: tb=tb[:tb.index('⟦A:c⟧')].strip()
        if t['name'] in('Guardian','Colossus') and tb: tb=re.sub(r'^Союзн(ики|ые персонажи)','Соседние союзные персонажи',tb)
        tr.append(dict(name=tn or t['name'],en=t['name'],text=tb or t['description'],bonuses=t.get('bonuses'),use=t.get('use')))
    cs=f['core_system'];cn,cb_,_=ru(f['id']+'#core')
    an,ab,at=ru(f['id']+'#active_name')
    pn,pb,pt=ru(f['id']+'#passive_name') if cs.get('passive_name') else (None,None,None)
    core=dict(name=cn or cs['name'],en=cs['name'],aname=an or cs.get('active_name'),atext=ab or cs.get('active_effect',''),atags=at or '',
              act=cs.get('activation'),use=cs.get('use'),pname=pn or cs.get('passive_name'),ptext=pb or cs.get('passive_effect'),integrated=cs.get('integrated',[]),
              bonuses=cs.get('active_bonuses'))
    if an is None: out['miss'].append(f['id']+'#active')
    out['frames'].append(dict(id=f['id'],name=n,en=f['name'],src=f['source'],ll=f['license_level'],role='/'.join(ROLE.get(m,m) for m in f['mechtype']),
        mounts=f['mounts'],stats=f['stats'],traits=tr,core=core,page=T[f['id']]['page']))
for w in J('weapons'):
    if w['id'] not in T: continue
    n,b,tg=ru(w['id'])
    o=dict(id=w['id'],name=n,en=w['name'],src=w.get('source',''),lic=w.get('license_id',''),licn=w.get('license',''),ll=w.get('license_level',0),mount=w['mount'],type=w['type'],
           dmg=dmg(w.get('damage')),rng=rng(w.get('range')),tags=tags(w.get('tags')),sp=w.get('sp',0),rutags=tg,text=b,page=T[w['id']]['page'])
    if w.get('profiles'): o['profiles']=[dict(name=p['name'],dmg=dmg(p.get('damage')),rng=rng(p.get('range')),tags=tags(p.get('tags'))) for p in w['profiles']]
    for k in ('talent_item','no_attack','no_mods','barrage','skirmish'):
        if w.get(k): o[k]=w[k]
    if w.get('talent_item'): o['tal']=[w.get('talent_id'),w.get('talent_rank')]
    out['weapons'].append(o)
for s in J('systems'):
    if s['id'] not in T: continue
    n,b,tg=ru(s['id'])
    o=dict(id=s['id'],name=n,en=s['name'],src=s['source'],lic=s.get('license_id',''),licn=s.get('license',''),ll=s['license_level'],sp=s['sp'],type=s.get('type','System'),
           tags=tags(s.get('tags')),rutags=rutag(s.get('sp'),s.get('tags')),text=b,bonuses=s.get('bonuses'),page=T[s['id']]['page'])
    acts=[dict(name=a.get('name',''),act=a.get('activation'),tech=a.get('tech_attack',False)) for a in s.get('actions',[])]
    if acts:o['acts']=acts
    if s.get('deployables'):o['deploy']=[dict(name=d['name'],type=d.get('type'),size=d.get('size'),hp=d.get('hp'),eva=d.get('evasion'),edef=d.get('edef')) for d in s['deployables']]
    if s.get('talent_item'):o['talent_item']=1;o['tal']=[s.get('talent_id'),s.get('talent_rank')]
    out['systems'].append(o)
for m in J('mods'):
    if m['id'] not in T: continue
    n,b,tg=ru(m['id'])
    out['mods'].append(dict(id=m['id'],name=n,en=m['name'],src=m['source'],lic=m.get('license_id',''),licn=m.get('license',''),ll=m['license_level'],sp=m['sp'],types=m.get('allowed_types',[]),
        sizes=m.get('restricted_sizes'),addDmg=dmg(m.get('added_damage')),addRng=rng(m.get('added_range')),addTags=tags(m.get('added_tags')),tags=tags(m.get('tags')),rutags=rutag(m.get('sp'),[{'id':'tg_mod'}]+(m.get('tags') or [])),text=b,page=T[m['id']]['page']))
for t in J('talents'):
    if t['id'] not in T: continue
    n,_,_=ru(t['id']);rk=[]
    for i,r in enumerate(t['ranks']):
        rn,rb,rtg=ru(t['id']+'#'+str(i))
        if rtg and rb and rtg.strip(): rb='⟦A:r⟧'+tc(rn)+'⟦T⟧'+rtg.strip()+'⟦E⟧'+rb+'⟦Z⟧'
        if rn is None: out['miss'].append(t['id']+'#'+str(i))
        rk.append(dict(name=rn or r['name'],en=r['name'],text=rb or r['description'],bonuses=r.get('bonuses'),integrated=r.get('integrated',[]),counters=r.get('counters')))
    out['talents'].append(dict(id=t['id'],name=n,en=t['name'],ranks=rk,page=T[t['id']]['page']))
for c in J('core_bonuses'):
    if c['id'] not in T: continue
    n,b,_=ru(c['id'])
    if b is None: out['miss'].append(c['id']);b=c['effect']
    # strip flavor: keep last k paragraphs where k = paragraphs in data effect
    k=len([p for p in re.split(r'<br>|\n',c['effect']) if p.strip()]) + c['effect'].count('<li>')
    ps=[p for p in b.split('\n') if p.strip()]
    if len(ps)>1: 
        k=max(1,min(k,len(ps)))
        # bullets count as separate paragraphs
        b='\n'.join(ps[-k:]) if not any(p.startswith('•') for p in ps) else '\n'.join(ps[1:])
    out['cbs'].append(dict(id=c['id'],name=n,en=c['name'],src=c['source'],text=b,bonuses=c.get('bonuses'),page=T[c['id']]['page']))
for g in J('pilot_gear'):
    if g['id'] not in T: continue
    n,b,tg=ru(g['id'])
    out['gear'].append(dict(id=g['id'],name=n,en=g['name'],type=g['type'],tags=tags(g.get('tags')),rng=rng(g.get('range')),dmg=dmg(g.get('damage')),bonuses=g.get('bonuses'),text=b,rutags=tg))
for s in J('skills'):
    n,b,_=ru(s['id'])
    out['skills'].append(dict(id=s['id'],name=n,en=s['name'],text=b,family=s.get('family')))
json.dump(out,open('pcdata.json','w'),ensure_ascii=False,indent=0)
print({k:len(v) for k,v in out.items()},out['miss'])
# talent items shown inside their rank, as in the book
TT={t['id']:t for t in out['talents']}
for x in out['weapons']+out['systems']:
    if x.get('tal') and x['tal'][0] in TT:
        rk=TT[x['tal'][0]]['ranks'][x['tal'][1]-1]
        if '⟦A' in rk['text'] and x['name'][:6].lower() in rk['text'].lower(): continue
        if 'mount' in x:
            tg=f"{WS_RU.get(x['mount'],x['mount'])} {WT_RU.get(x['type'],x['type'])}"+(', '+', '.join(TAGRU0[t[0]].replace('{VAL}',str(t[1])) for t in x['tags'] if t[0] in TAGRU0) if x['tags'] else '')
            tg+=' · '+', '.join(f"{RR.get(r['t'],r['t'])} {r['v']}" for r in x['rng'])+' · '+' + '.join(f"{d['v']} {DR.get(d['t'],d['t'])}" for d in x['dmg'])
            k='w'
        else: tg=x['rutags'];k='s'
        rk['text']=rk['text'].rstrip()+'\n⟦A:%s⟧%s⟦T⟧%s⟦E⟧%s⟦Z⟧'%(k,x['name'],tg,x['text'] or '')
TAGRU={'tg_burn':'Горение {VAL}','tg_heat_target':'Перегрев {VAL} (цель)','tg_line':'Линия {VAL}','tg_cone':'Конус {VAL}','tg_blast':'Взрыв {VAL}','tg_burst':'Разрыв {VAL}',
'tg_accurate':'Точное','tg_arcing':'Дуговое','tg_ap':'Бронебойное (ББ)','tg_inaccurate':'Неточное','tg_knockback':'Толчок {VAL}','tg_loading':'Заряжаемое','tg_ordnance':'Артиллерийское',
'tg_overkill':'Избыточный Урон','tg_overshield':'Усиление Щита','tg_reliable':'Надежное {VAL}','tg_seeking':'Искатель','tg_smart':'Умное','tg_threat':'Угроза {VAL}','tg_thrown':'Бросок {VAL}',
'tg_turn':'{VAL}/Ход','tg_round':'{VAL}/Раунд','tg_ai':'ИИ','tg_danger_zone':'Опасная Зона','tg_deployable':'Размещаемое','tg_drone':'Дрон','tg_full_action':'Полное Действие',
'tg_grenade':'Граната','tg_heat_self':'Нагрев {VAL} (свой)','tg_limited':'Ограниченное {VAL}','tg_mine':'Мина','tg_mod':'Мод','tg_protocol':'Протокол','tg_quick_action':'Быстрое Действие',
'tg_reaction':'Реакция','tg_shield':'Щит','tg_unique':'Уникальное','tg_archaic':'Архаичное','tg_personal_armor':'Личная Броня','tg_pilot_weapon':'Оружие Пилота','tg_gear':'Снаряжение',
'tg_sidearm':'Личное Оружие','tg_invade':'Вторжение','tg_quick_tech':'Быстрая Технология','tg_full_tech':'Полная Технология','tg_free_action':'Свободное Действие','tg_range':'Дальность ({VAL})',
'tg_modded':'Модифицировано','tg_resistance':'Сопротивляемость','tg_exotic':'Экзотическое Снаряжение','tg_recharge':'Перезарядка {VAL}+','tg_unlimited':'Неограниченное','tg_indestructible':'Неразрушимое',
'tg_invulnerable':'Неуязвимое','tg_invisible':'Невидимое','tg_resistall':'Сопротивляемость (всё)','tg_set_max_uses':'Макс. использований','tg_set_damage_type':'Выбор типа урона','tg_set_damage_value':'Урон','tg_no_cascade':'Без каскада'}
GL={'Горение X':'tg_burn','Перегрев X (цель)':'tg_heat_target','Точное':'tg_accurate','Дуговое':'tg_arcing','Бронебойное (ББ)':'tg_ap','Неточное':'tg_inaccurate','Толчок Х':'tg_knockback',
'Заряжаемое':'tg_loading','Артиллерийское':'tg_ordnance','Избыточный Урон':'tg_overkill','Усиление Щита':'tg_overshield','Надежное X':'tg_reliable','Искатель':'tg_seeking','Умное':'tg_smart',
'Угроза X':'tg_threat','Бросок X':'tg_thrown','X/Ход':'tg_turn','X/Раунд':'tg_round','ИИ':'tg_ai','Опасная Зона':'tg_danger_zone','Размещаемое':'tg_deployable','Дрон':'tg_drone',
'Полное Действие':'tg_full_action','Граната':'tg_grenade','Нагрев X (свой)':'tg_heat_self','Вторжение':'tg_invade','Ограниченное X':'tg_limited','Мина':'tg_mine','Мод':'tg_mod','Протокол':'tg_protocol',
'Реакция':'tg_reaction','Щит':'tg_shield','Уникальное':'tg_unique','Архаичное':'tg_archaic','Личная Броня':'tg_personal_armor','Снаряжение':'tg_gear','Личное Оружие':'tg_sidearm'}
FIXD={'tg_quick_action':'Требует быстрого действия для активации.','tg_heat_self':'Сразу после использования оружия или системы пользователь получает X нагрева.',
'tg_overkill':'При броске урона все кубики, выпавшие на 1, перебрасываются, а атакующий получает 1 нагрева за каждый переброс.','tg_quick_tech':'Используется быстрой технологией.','tg_full_tech':'Используется полной технологией.',
'tg_free_action':'Используется свободным действием.','tg_pilot_weapon':'Оружие пилота.','tg_recharge':'После использования нужно перезарядить: в начале хода бросьте d6, на X+ система снова доступна.'}
for k,v in TAGRU.items():
    d=FIXD.get(k)
    if not d:
        for g,id in GL.items():
            if id==k: d=G.get(g,'')
    out['tags'][k]=dict(n=v,d=d or '')
GEARRU={'pg_archaic_melee':'Архаичное ОББ','pg_archaic_ranged':'Архаичное ОДБ','pg_light_a_c':'Лёгкое С/К','pg_medium_a_c':'Среднее С/К','pg_heavy_a_c':'Тяжёлое С/К',
'pg_light_signature':'Лёгкое Фирменное','pg_medium_signature':'Среднее Фирменное','pg_heavy_signature':'Тяжёлое Фирменное','pg_light_hardsuit':'Лёгкий Скафандр','pg_assault_hardsuit':'Штурмовой Скафандр',
'pg_heavy_hardsuit':'Тяжёлый Скафандр','pg_mobility_hardsuit':'Мобильный Скафандр','pg_stealth_hardsuit':'Стелс-Скафандр'}
GEARTX={'pg_archaic_melee':'**Архаичное ОББ**: Это Оружие Ближнего Боя было изготовлено с использованием сплавов и технологий, существовавших во времена до Союза, и может быть чем угодно — от стальных мечей индустриальной эпохи до каменных топоров. Хотя оно по-прежнему широко используется в некоторых мирах, архаичное оружие, используемое пилотами, обычно является реликвиями, ценностями или церемониальным оружием.',
'pg_archaic_ranged':'**Архаичное ОДБ**: Это Оружие Дальнего Боя — устаревшие устройства старых эпох, такие как мушкеты и луки, которые все еще используются в некоторых сообществах.',
'pg_light_a_c':'**Легкое С/К** оружие может быть ножами, штыками, пробивными кинжалами и короткими мечами.',
'pg_medium_a_c':'**Среднее** С/К оружие — это, как правило, мечи, сабли и окопные топоры.',
'pg_heavy_a_c':'**Тяжелое** С/К оружие разработано с учетом повышенной прочности защитных костюмов и включает боевые молоты, молоты, тараны, пики и тяжелые двуручные штурмовые мечи.',
'pg_light_signature':'Приобретая фирменное оружие, выберите его тип урона – взрывной [взр], энергетический [энерг] или кинетический [кин].\n**Легкое** фирменное оружие может представлять собой крупнокалиберные револьверы, скобы пистолетов и пистолеты-пулеметы.',
'pg_medium_signature':'Приобретая фирменное оружие, выберите его тип урона – взрывной [взр], энергетический [энерг] или кинетический [кин].\n**Среднее** — штурмовые винтовки, дробовики, лазеры на ранцевом питании, разрушительные пушки.',
'pg_heavy_signature':'Приобретая фирменное оружие, выберите его тип урона – взрывной [взр], энергетический [энерг] или кинетический [кин].\n**Тяжелое** — ракетные трубы, тяжелые лазеры, легкий пулемет или экзотические винтовки.',
'pg_light_hardsuit':'**+3 ПЗ**, Броня 0, Уклонение 10, Э-Защита 10, Скорость 4.\n**Легкие Скафандры**: Обычно изготавливаются из реактивного, похожего на ткань материала, с ограниченным количеством пластин и небольшим количеством силовых компонентов для обеспечения максимальной мобильности. Как и другие скафандры, они могут быть запечатаны от вакуума и защищают от приличного количества радиации и других вредных частиц.',
'pg_assault_hardsuit':'**+3 ПЗ**, Броня 1, Уклонение 8, Э-Защита 8, Скорость 4.\n**Штурмовой Скафандр**: Эти скафандры, распространенные среди военных подразделений, имеют более тяжелое покрытие, чем легкие, но более мобильны, чем тяжелые. Они питаются энергией, увеличивая силу пользователя, и часто оснащены бортовым компьютером, набором датчиков, встроенным воздухом, системой ВКД, а также системами переработки отходов.',
'pg_heavy_hardsuit':'**+3 ПЗ**, Броня 2, Уклонение 6, Э-Защита 8, Скорость 3.\n**Тяжелый Скафандр**: самые тяжелые скафандры. Они всегда снабжены источником энергии и бронированы толстой композитной броней. Тяжелые скафандры оснащены интегрированным оружием, мощными мобильными комплексами и, увеличивая силу своего пользователя, позволяют ему использовать гораздо более тяжелое оружие, чем может нести обычная пехота. Сейчас, когда популярны полуразмерные шасси, тяжелые скафандры переживают упадок, но они все еще распространены среди частных вооруженных сил и вооруженных сил диаспоры среднего уровня.',
'pg_mobility_hardsuit':'Броня 0, Уклонение 10, Э-Защита 10, Скорость 5, **Полёт**.\n**Мобильный Скафандр**: В эти скафандры интегрированы системы полёта, позволяющие пилотам **летать**, когда они двигаются или **Ускоряются**. Летающие пилоты должны завершить свой ход на земле (или другой поверхности) или начать падать.',
'pg_stealth_hardsuit':'Броня 0, Уклонение 8, Э-Защита 8, Скорость 4.\n**Стелс-Скафандр**: В качестве **быстрого действия** пилоты в стелс-скафандрах могут стать **Невидимыми**. Они перестают быть **Невидимыми**, если получают урон.'}
FL_MELEE=['Это оружие имеет древнюю конструкцию — возможно, оно было извлечено из руин, существовавших до крушения.','Это оружие богато украшено и выглядит церемониально — возможно, это знак отличия.','Это оружие хорошо известно или им владел известный воин.','Это оружие простое или массового производства, но имеет узнаваемую репутацию и историю — положительную или отрицательную.','Это оружие — семейная реликвия, которая перешла к вам по наследству.','Это оружие было выковано для вас на заказ и несет на себе ваш знак, или вы сделали его сами.']
FL_SIG=['Это оружие является устаревшим или старомодным по современным стандартам, но все еще надежным.','Это оружие хрупкое и часто клинит. Вы единственный, кто может использовать его эффективно.','Это оружие изящное, складное, его легко спрятать.','Это оружие устраивает потрясающее шоу, создавая огромное количество шума, дыма, света и так далее, когда оно стреляет.','Это оружие было изготовлено для вас на заказ энтузиастом-оружейником из омнинета и имеет несколько доп фишек — складные сошки, рукоятки, датчики дальности, детекторы движения, подключение к омнинету, чат-программы и текстовые игры.','Это оружие было вам подарено кем-то другим или отобрано у него.']
FL_ARM=['Этот скафандр был изготовлен на заказ кустарным производителем — это шедевр индивидуальной защиты, который легко идентифицировать как творение его создателя.','Этот скафандр устарел или является старой моделью, но остается невероятно прочным. Возможно, вы единственный, кто помнит, как им пользоваться. Люди очень любят эту модель, и ее репутация вполне заслужена, хотя в ней нет многих функций современных скафандров.','Этот скафандр имеет компоненты, которые можно уменьшить для его хранения: некоторые из его компонентов могут вдвигаться или выдвигаться без необходимости снятия, и он может быть активирован в мгновение ока с помощью заранее определенных мышечных подергиваний.','Этот скафандр имеет самообновляющиеся и герметизирующие компоненты, возможно, биологической природы. Он интегрируется со своим носителем для обеспечения себя энергией.','Этот скафандр был сильно изменён вами или кем-то другим, с декоративными элементами и заметными косметическими изменениями, такими как гравировки, трофеи, значки или эмблемы.','Этот скафандр имеет для вас большое культурное или личное значение и обладает фирменным или узнаваемым внешним видом. Возможно, его носят члены определенной компании наемников, это индивидуальные доспехи имперской гвардии, или он был разработан на вашей родной планете.']
out['gearflav']={'melee':FL_MELEE,'sig':FL_SIG,'armor':FL_ARM}
for g in out['gear']:
    if g['id'] in GEARRU: g['name']=GEARRU[g['id']];g['text']=GEARTX[g['id']];g['rutags']='';g['flav']='armor' if g['type']=='Armor' else 'sig' if 'signature' in g['id'] else 'melee'
def joinl(t):
    t=re.sub(r'(?<=[а-яёa-z])-\n(?=[а-яё])','',t)
    t=re.sub(r'(?<=[^.:!?\n»"⟧])\n(?=[а-яё(])',' ',t)
    t=re.sub(r'(?<=[а-яёa-z,\d\]])\n(?=\*\*[а-яёА-ЯЁ]|\[)',' ',t)
    t=re.sub(r'(?<=[а-яёА-ЯЁ,])\n(?=[А-ЯЁ][а-яё]+\*\*)',' ',t)
    return t
FIXT={'pg_sleeping_bag':[('**Невосприимчивость** к,','**Невосприимчивость** к [горение],')],
 'wm_stabilizer_mod':[('**Пусковую установку или** Пушку','**Пусковую установку** или **Пушку**')],
 'mw_stabilizer_mod':[('**Пусковую установку или** Пушку','**Пусковую установку** или **Пушку**')]}
GFIX=[('наносящим любое количество [горение], весь дополнительный урон становится.','наносящим любое количество [энерг], весь дополнительный урон становится [горение].'),
 ('вы **не можете перемещаться** до начала вашего следующего хода, но получаете **+1 [ТОЧН].** ко всем атакам','вы становитесь **Обездвиженным** до начала вашего следующего хода, но получаете **+1** [ТОЧН] ко всем атакам'),
 ('вы устраняете все **Повреждения**, **Заклинивания**','вы устраняете все **Ослабления**, **Заклинивания**'),
 ('Он должен пройти проверку **Корпуса**, или получить 2d6+2 [кин] урона и стать **Оглушенным** до конца следующего хода.','Он должен пройти спасбросок **Корпуса**, иначе получит 2d6+2 [кин] урона и станет **Ошеломлённым** до конца своего следующего хода.'),
 ('[энерг] д ополнительного урона','[энерг] дополнительного урона'),
 ('находясь в **Опасной Зоне** дает **+2**[нагрев] на попадание.','находясь в **Опасной Зоне** дает **+2**[нагрев] на попадание.\n*Если вы входите в Опасную Зону во время своего хода, талант срабатывает при вашей следующей атаке.* (примечание из английской книги; в русском переводе пропущено)'),('**• Дозатор Гранат** (1 [энерг] заряд)','**• Дозатор Гранат** (1 заряд)'),('соседние персонажи получают **1 ББ**','соседние персонажи получают **1** [энерг] **ББ**'),
 ('⟦A:c⟧Футляр для Боеприпасов⟦T⟧0 СО, Ограниченое 6','⟦A:c⟧Футляр для Боеприпасов⟦T⟧0 СП, Ограниченное 6')]
def walkfix(o):
    if isinstance(o,dict):
        for k,v in o.items():
            if k in('text','atext','ptext','desc') and isinstance(v,str):
                v=joinl(v)
                for a,b in FIXT.get(o.get('id'),[])+GFIX: v=v.replace(a,b)
                o[k]=v
            else: walkfix(v)
    elif isinstance(o,list):
        for v in o: walkfix(v)
for _c in ('weapons','systems','mods'):
    for _x in out[_c]:
        _f=T.get(_x['id'],{}).get('ru_flav','')
        if _f: _x['flav']=re.sub(r'(?<=[а-яё])-\n(?=[а-яё])','',_f)
walkfix(out)
import extra_data
_ld=[]
for _f in ('systems','weapons'): _ld+=json.load(open('../ld/repo2/lib/%s.json'%_f))
extra_data.extra(out,_ld)
json.dump(out,open('pcdata.json','w'),ensure_ascii=False,indent=0)
print('tags',len(out['tags']),[k for k,v in out['tags'].items() if not v['d']])
