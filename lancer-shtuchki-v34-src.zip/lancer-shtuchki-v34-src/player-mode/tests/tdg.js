const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:900}});pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text().slice(0,200))});
 await pg.goto('file:///home/claude/lancer-npc-v25.html');await pg.click('[data-role="gm"]');await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 const r=await pg.evaluate(()=>{const p=curP();p.ll=6;p.lic={mf_raleigh:2,mf_monarch:2};p.talents={t_iconoclast:1,t_field_analyst:2};p.cbs=['cb_superheavy_mounting'];
   const ok=['mf_störtebeker','mf_micro_monarch'].map(id=>id+':'+frameOk(p,P.F[id]));
   const m=curM(p);m.frame='mf_micro_monarch';const st=mechStats(p,m);const mts=mechMounts(p,m).map(x=>x.type);
   m.systems=['ms_cockpit_integrated_stim_pump','ms_mesmertrance_dampener','ms_armament_redundancy'];m.load={f2:['mw_reaper_assault_cannon']};
   const W=buildWarnings(p,m);
   p.gear.armor='ms_madrigal_boarding_carapace_armor';let ps=null;try{ps=pilotStats(p)}catch(e){ps='ERR '+e.message}
   return{ok,hp:st.hp,ai:st.ai,mts,W,ps:JSON.stringify(ps).slice(0,200),art:!!ART['mf_störtebeker']&&!!ART.mf_micro_monarch,cnt:talentRanks(p).filter(x=>x.r.counters).map(x=>x.r.counters.map(c=>c.name)),
     tpl:TEMPLATES.filter(t=>t.book==='DG').map(t=>t.id+':'+tplItems(t).length),lib:BUILTIN.filter(c=>c.book==='DG').map(c=>c.id),enc:WFENC.filter(e=>e.book==='DG').length,gm:GMT.filter(t=>t.book==='DG').length,ref:REF.map(s=>s.id).join(',')}});
 console.log(JSON.stringify(r));
 await pg.click('[data-pa="ptab"][data-v="mech"]');await pg.screenshot({path:'v25_mech.png'});
 await pg.click('[data-pa="ptab"][data-v="pilot"]');console.log('tl-book',await pg.$$eval('.tl-book',x=>x.map(y=>y.textContent.trim().slice(0,40))));
 console.log('variants',await pg.$$eval('.lic-var',x=>x.map(y=>y.textContent.replace(/\s+/g,' ').trim().slice(0,70))));
 const vb=await pg.$('.lic-var [data-v="mf_störtebeker"]');await vb.scrollIntoViewIfNeeded();await pg.screenshot({path:'v25_lic.png'});
 // библиотека: шаблоны
 await pg.click('[data-act="view"][data-v="lib"]');await pg.evaluate(()=>{S.cls='berserker';S.tplSel.berserker={tpls:['dg_industrial'],ch:['in-saw']};render();document.getElementById('main').scrollTop=0});await pg.screenshot({path:'v25_lib.png'});
 await pg.evaluate(()=>{S.cls='dg_virga';render()});await pg.screenshot({path:'v25_virga.png'});
 // ГМ: бои Dustgrave
 await pg.click('[data-act="view"][data-v="gm"]');
 const ids=await pg.evaluate(()=>WFENC.filter(e=>e.book==='DG').map(e=>e.id));
 for(const id of ids){await pg.evaluate(id=>{WFE.enc=id;WFE.pcs=5;render()},id);const n=await pg.$$eval('[data-wf="eadd"]',x=>x.length);for(let i=0;i<n;i++)await pg.click(`[data-wf="eadd"][data-v="${i}"]`)}
 console.log('enc',await pg.evaluate(()=>S.enc.length),await pg.evaluate(()=>S.enc.slice(0,8).map(i=>i.label+'['+i.tpls.join(',')+'|'+i.tplCh.join(',')+'|'+i.opts.join(',')+']').join('; ')));
 const bad=await pg.evaluate(()=>{for(const i of S.enc){try{stOf(i);instSystems(i)}catch(e){return i.label+': '+e.message}}return 'ok'});console.log('inst',bad);
 await pg.evaluate(id=>{WFE.enc=id;render();document.getElementById('wf-enc').scrollIntoView()},'dg_bloodsport');await pg.screenshot({path:'v25_enc.png'});
 // отношения
 await pg.click('[data-dg="start"][data-v="magenta"]');await pg.click('[data-dg="d"][data-v="magenta"][data-d="1"]');await pg.click('[data-dg="start"][data-v="lyran"]');
 console.log('rel',await pg.evaluate(()=>JSON.stringify(DGS)));
 await pg.evaluate(()=>document.getElementById('dg-rel').scrollIntoView());await pg.screenshot({path:'v25_rel.png'});
 await pg.evaluate(()=>localStorage.setItem('dg_rel',JSON.stringify({lyran:'<img src=x onerror=window.pwn=1>',magenta:999,__proto__:{x:1}})));await pg.reload();await pg.click('[data-role="gm"]');await pg.click('[data-act="view"][data-v="gm"]');
 console.log('clean',await pg.evaluate(()=>JSON.stringify(DGS)),await pg.evaluate(()=>window.pwn||0));
 // бой с ХЕПРИ — вид
 await pg.click('[data-act="view"][data-v="enc"]');await pg.waitForTimeout(200);await pg.screenshot({path:'v25_battle.png'});
 await pg.click('[data-act="view"][data-v="ref"]');await pg.evaluate(()=>document.getElementById('ref-dg').scrollIntoView());await pg.waitForTimeout(150);await pg.screenshot({path:'v25_ref.png'});
 await pg.setViewportSize({width:390,height:844});await pg.click('[data-act="view"][data-v="gm"]');await pg.evaluate(()=>document.getElementById('dg-rel').scrollIntoView());await pg.screenshot({path:'v25_mob.png'});console.log('hs',await pg.evaluate(()=>document.documentElement.scrollWidth));
 console.log('ERRS',JSON.stringify(errs));await b.close()})();
