const {JSDOM}=require('jsdom');const fs=require('fs');
const errs=[];const dom=new JSDOM(fs.readFileSync(process.argv[2],'utf8'),{runScripts:'dangerously',url:'http://localhost/',beforeParse(w){w.alert=m=>errs.push('ALERT '+m);w.confirm=()=>true;w.addEventListener('error',e=>errs.push(e.message))}});
const w=dom.window,d=w.document;
const click=sel=>{const el=d.querySelector(sel);if(!el)throw new Error('no '+sel);el.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));return el};
const change=(sel,v)=>{const el=d.querySelector(sel);if(!el)throw new Error('no '+sel);el.value=v;el.dispatchEvent(new w.Event('change',{bubbles:true}))};
const out=[];const log=()=>w.eval('S.log.slice(0,3).map(x=>x.html.replace(/<[^>]+>/g," ").replace(/\\s+/g," ").slice(0,220))');
click('[data-act="view"][data-v="pc"]');click('[data-pa="pnew"]');
// background
click('[data-pa="bgroll"]');out.push('bg: '+w.eval('curP().bgId'));
change('[data-p7="bgid"]','pbg_medic');click('[data-pa="bgsk"][data-v="sk_patch"]');out.push('skills '+JSON.stringify(w.eval('curP().skills')));
// LL 0 rank-up warnings
w.eval('curP().talents={t_ace:2};curP().skills={sk_patch:2}');out.push('W LL0: '+w.eval('buildWarnings(curP(),curM(curP())).join(" | ")'));
for(let i=0;i<6;i++)click('[data-pa="ll"][data-d="1"]');
// reserves
['reserve_skill','reserve_extra_repairs','reserve_core_battery','reserve_extended_harness','reserve_ammo','reserve_rented_gear','reserve_systems_reinforcement','reserve_boosted_servos'].forEach(id=>change('[data-p7="resadd"]',id));
click('[data-pa="resaddc"]');
out.push('budget sk max '+w.eval('budgets(curP()).sk.max')+' wslots '+w.eval('pcWSlots(curP())')+' gslots '+w.eval('pcGSlots(curP())'));
w.eval(`(()=>{const p=curP(),m=curM(p);p.talents={t_engineer:3,t_brutal:3,t_gunslinger:3,t_crack_shot:2,t_drone_commander:1,t_brawler:2};
 m.frame='mf_drake';m.systems=['ms_turret_drones','ms_pattern_a_jericho_deployable_cover','ms_pattern_a_smoke_charges'];
 const r=p.reserves;r.find(x=>x.id==='reserve_ammo').item='ms_turret_drones';r.find(x=>x.id==='reserve_ammo').n=2;
 r.find(x=>x.id==='reserve_rented_gear').item='mw_vulture_dmr';r.find(x=>x.id==='reserve_systems_reinforcement').skill='hull';
 m.proto.rev=['optics','reactor'];p.cb=null;})()`);
w.eval("PS.tab='mech';renderMain()");
out.push('proto ui: '+!!d.querySelector('.proto-ui')+' types '+d.querySelectorAll('[data-p7="ptype"] option').length);
change('[data-p7="ptype"]','Melee');change('[data-p7="pdt"]','en');click('[data-pa="plim"]');
out.push('proto: '+w.eval('JSON.stringify(mechWeapons(curP(),curM(curP())).filter(x=>x.w.proto).map(x=>[x.w.name,x.w.type,x.w.rng,x.w.dmg,x.w.tags]))'));
out.push('stats repcap '+w.eval('mechStats(curP(),curM(curP())).repcap')+' coreUses '+w.eval('mechStats(curP(),curM(curP())).coreUses'));
out.push('lim turret '+w.eval('limMax(curP(),P.SY.ms_turret_drones)')+' itemOk thermal '+w.eval('itemOk(curP(),P.W.mw_vulture_dmr)'));
w.eval("PS.tab='combat';pcFullRepair(curP());renderMain()");
out.push('cp '+w.eval('curP().cb.cp')+' counter? '+!!d.querySelector('[data-pa="cpn"]'));
click('[data-pa="core"]');out.push('cp after core '+w.eval('curP().cb.cp'));
// deployables
click('[data-pa="depadd"]');out.push('deps '+w.eval('JSON.stringify(curP().cb.deps)'));
const did=w.eval('curP().cb.deps[0].id');d.getElementById('dd-'+did).value='3';click(`[data-pa="depdmg"][data-v="${did}"]`);out.push('dep after dmg '+w.eval('curP().cb.deps[0].hp'));
// proto attack with reactor
w.eval(`(()=>{const p=curP(),m=curM(p);const x=mechWeapons(p,m).find(x=>x.w.proto);pcOpenWeapon(p,x.uid);})()`);
out.push('proto mods: '+w.eval('M.mods.map(m=>m.label+(m.on?"*":"")).join("; ")'));
w.eval('M.mods.forEach(m=>{if(m.selfHeat)m.on=true});M.target="1";pcRoll()');out.push('heat after reactor '+w.eval('curP().cb.heat'));out.push(...log());
// checks
w.eval("pcOpenCheck(curP(),'hull')");out.push('hull mods: '+w.eval('M.mods.map(m=>m.label).join("; ")'));w.eval('M=null');
w.eval("pcOpenCheck(curP(),'agi')");out.push('agi mods: '+w.eval('M.mods.map(m=>m.label).join("; ")'));w.eval('M=null');
w.eval("pcOpenTrigger(curP(),'Заплатки',1)");out.push('trig mods: '+w.eval('M.mods.map(m=>m.label).join("; ")'));w.eval('M=null');
w.eval("pcOpenBasic(curP(),'impro')");out.push('impro: '+w.eval('JSON.stringify(M.w.dmg)')+' '+w.eval('M.mods.map(m=>m.label).join("; ")'));w.eval('M=null');
// drake area resist + slowed immunity
w.eval("pcDamage(curP(),10,'exp',{area:true})");out.push(...log().slice(0,1));
w.eval("pAddCond(curP().cb,'Замедлен')");out.push('conds '+w.eval('curP().cb.conds')+' | '+log()[0]);
// brutal natural 20: force rnd
w.eval(`(()=>{const p=curP(),m=curM(p);const x=mechWeapons(p,m).find(x=>x.w.proto);pcOpenWeapon(p,x.uid);const k=rnd;let first=true;rnd=n=>{if(n===20&&first){first=false;return 20}return k(n)};M.target='5';try{pcRoll()}finally{rnd=k}})()`);out.push('brutal: '+log()[0]);
// manticore resist, lancaster burn immunity, briareos
w.eval("curM(curP()).frame='mf_manticore';curP().cb=null;pcDamage(curP(),6,'en',{})");out.push(log()[0]);
w.eval("curM(curP()).frame='mf_lancaster';curP().cb=null;pcDamage(curP(),6,'burn',{})");out.push(log()[0]);
w.eval("curM(curP()).frame='mf_hydra';curP().cb=null;PS.tab='combat';renderMain()");out.push('hydra deps: '+w.eval('depSources(curP(),curM(curP())).map(s=>s.n+" "+s.hp+"/"+s.ev).join(", ")'));
w.eval("PS.tab='pilot';renderMain()");out.push('pilot html has reserves '+!!d.querySelector('.reslist')+' bg details '+!!d.querySelector('.bgd'));
click('[data-pa="resroll"][data-t="Mech"]');out.push('reserves n '+w.eval('curP().reserves.length'));
console.log(out.join('\n'));console.log('errors',errs);
