const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const SP='/tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad/';
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:950}});pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text().slice(0,200))});
 await pg.goto('file:///home/claude/ulan-terminal-v27.html');await pg.click('[data-role="gm"]');await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 const r=await pg.evaluate(()=>{const p=curP();p.ll=12;p.cbs=['cb_auto_stabilizing_hardpoints','cb_overpower_caliber','cb_neurolink_targeting','cb_gyges_frame','cb_the_lesson_of_thinking_tomorrows_thought'];
   const m=curM(p);const ms=mechMounts(p,m);m.load={};m.load[ms[0].key]=['mw_assault_rifle'];m.load[ms[1].key]=['mw_charged_blade'];m.autostab='';m.overpower='';
   PS.tab='mech';pcRender();return {mounts:ms.map(x=>x.key+':'+x.type),autostab:m.autostab,overpower:m.overpower,
     cards:[...document.querySelectorAll('.pitem.w .wprof')].map(e=>e.innerText.replace(/\s+/g,' ')),
     cbb:[...document.querySelectorAll('.cbb')].map(e=>e.textContent+'←'+e.title),btns:[...document.querySelectorAll('[data-pcb]')].map(e=>e.dataset.pcb+':'+e.dataset.v+':'+e.textContent.trim())}});
 console.log(JSON.stringify(r,null,1));
 await pg.screenshot({path:SP+'t27_mech.png',fullPage:false});
 const w1=await pg.$('.pitem.w');if(w1)await w1.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t27_mech2.png'});
 // переключить автостаб на второй слот кнопкой
 const k2=r.mounts[1].split(':')[0];await pg.click(`[data-pcb="autostab"][data-v="${k2}"]`);
 console.log('after click',await pg.evaluate(()=>curM(curP()).autostab),await pg.$$eval('.pitem.w .wprof',x=>x.map(e=>e.innerText.replace(/\s+/g,' '))));
 // бой: атака
 await pg.evaluate(()=>{PS.tab='combat';pcRender()});
 const cmb=await pg.$$eval('.isys .wprof',x=>x.map(e=>e.innerText.replace(/\s+/g,' ')));console.log('combat',cmb);
 for(const i of [0,1]){const uid=await pg.evaluate(i=>mechWeapons(curP(),curM(curP()))[i].uid,i);await pg.click(`[data-pa="atk"][data-v="${uid}"]`);await pg.waitForTimeout(200);
  const mm=await pg.evaluate(()=>({mods:M.mods.map(z=>z.label+(z.acc?' acc'+z.acc:'')+(z.on?' ON':'')+(z.addDice?' '+z.addDice:'')),rng:document.querySelector('#mbox .wprof').innerText.replace(/\s+/g,' ')}));console.log('atk',i,JSON.stringify(mm));
  await pg.screenshot({path:SP+`t27_atk${i}.png`});
  // бросок: проверить что точность учитывается
  const rr=await pg.evaluate(()=>{const b=[...document.querySelectorAll('#mbox button')].find(x=>/Бросить/.test(x.textContent));if(b)b.click();return M.res?{acc:M.res.acc,txt:document.querySelector('#mbox .bd')&&document.querySelector('#mbox .bd').innerText}:null});console.log('roll',JSON.stringify(rr));
  await pg.keyboard.press('Escape');await pg.evaluate(()=>{M=null;renderModal()})}
 // пилот: подсказки
 await pg.evaluate(()=>{PS.tab='pilot';pcRender()});
 const h=await pg.$$eval('.cbrow.sel',x=>x.map(e=>e.innerText.replace(/\s+/g,' ').slice(0,400)));console.log('hints',h);
 const el=await pg.$('.cbrow.sel');if(el){await el.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t27_pilot.png'})}
 console.log('ERRS',JSON.stringify(errs));await b.close()})();
