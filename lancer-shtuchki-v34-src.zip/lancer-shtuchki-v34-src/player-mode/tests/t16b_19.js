const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1300,height:900}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file:///home/claude/lancer-npc-v19.html');await pg.click('[data-role="player"]');
 const [fc]=await Promise.all([pg.waitForEvent('filechooser'),pg.click('#side [data-pa="ccimport"]')]);
 await fc.setFiles('/root/.claude/uploads/d0819c7c-129e-5c04-9991-5764081b769c/6a9ddc9b-json');await pg.waitForTimeout(500);
 console.log(await pg.evaluate(()=>PS.pilots.map(p=>p.callsign+' мехов '+p.mechs.length).join()),await pg.evaluate(()=>[...document.querySelectorAll('.toast')].map(t=>t.textContent).join('|')));
 await pg.screenshot({path:'imp.png'});console.log(errs);await b.close()})();
