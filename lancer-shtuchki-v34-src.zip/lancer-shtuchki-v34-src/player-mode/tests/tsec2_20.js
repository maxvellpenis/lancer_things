const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const mk=t=>`"'><img src=x data-t="${t}">`;
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1400,height:900}});
 await pg.goto('file:///home/claude/lancer-npc-v20.html');await pg.click('[data-role="gm"]');await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 const out=await pg.evaluate(async()=>{const mk=t=>`"'><img src=x data-t="${t}">`;const p0=curP();const m0=curM(p0);m0.load={f0:['mw_assault_rifle'],f1:['mw_assault_rifle']};m0.systems=['ms_pattern_a_smoke_charges'];p0.cbs=['cb_reinforced_frame'].filter(x=>P.CB[x]);p0.gear.weapons=Object.keys(P.G).slice(0,2);p0.bgId=PCD.backgrounds[0].id;const p=JSON.parse(JSON.stringify(p0));
   const poison=(o,path)=>{if(Array.isArray(o)){o.forEach((v,i)=>{if(typeof v==='string')o[i]=v+mk(path+'['+i+']');else if(v&&typeof v==='object')poison(v,path+'['+i+']')});return}for(const k of Object.keys(o)){const v=o[k];if(typeof v==='string')o[k]=v+mk(path+'.'+k);else if(v&&typeof v==='object')poison(v,path+'.'+k)}};
   poison(p,'p');p.custom=[{name:'S'+mk('custom.name'),rank:1}];p.reserves=[{id:'custom',name:'R'+mk('res.name'),note:mk('res.note')}];
   p.skills={['sk_'+mk('skillkey')]:1};p.talents={['t_'+mk('talkey')]:1};p.lic={['mf_'+mk('lickey')]:2};p.ll='3'+mk('ll');p.id='evil'+mk('id');
   const found=new Set();
   for(const tab of ['pilot','mech','combat']){pcImportText(JSON.stringify(p));PS.tab=tab;render();document.querySelectorAll('img[src=x]').forEach(i=>found.add(tab+':'+i.dataset.t))}
   S.view='pc';render();document.querySelectorAll('img[src=x]').forEach(i=>found.add('side:'+i.dataset.t));
   const npc={id:'x'+mk('npc.id'),name:'N'+mk('npc.name'),role:'R'+mk('npc.role'),icon:mk('npc.icon'),tag:'Мех'+mk('npc.tag'),group:'G'+mk('npc.group'),desc:'D'+mk('npc.desc'),tactics:'T'+mk('npc.tactics'),tiers:[[1,2,3,4,5,6,7,8,9,10,11,12,13]],base:[{id:'s1',name:'n'+mk('sys.name'),type:'trait',tags:'t'+mk('sys.tags'),text:'**a'+mk('sys.bold')+'** '+mk('sys.text')}],optional:[]};
   S.custom.push(npc);S.view='lib';S.cls=npc.id;render();document.querySelectorAll('img[src=x]').forEach(i=>found.add('lib:'+i.dataset.t));
   return [...found]});
 console.log(out.join('\n'));await b.close()})();
