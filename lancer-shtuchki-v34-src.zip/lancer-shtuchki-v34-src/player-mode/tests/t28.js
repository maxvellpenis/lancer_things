const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const SP='/tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad/';
const F='file:///home/claude/ulan-terminal-v28.html';
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:950}});pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text().slice(0,200))});
 await pg.goto(F);await pg.click('[data-role="gm"]');
 const L=(...a)=>console.log(...a.map(x=>typeof x==='string'?x:JSON.stringify(x)));
 // ---- НИП
 L('ws npc',await pg.evaluate(()=>({cls:BUILTIN.filter(c=>c.book==='WS').map(c=>c.id+':'+c.optional.length),tpl:TEMPLATES.filter(t=>t.book==='WS').map(t=>t.id+':'+tplItems(t).length),wfenc:WFENC.length,
   side:[...document.querySelectorAll('#side .cgrp')].map(e=>e.textContent)})));
 await pg.evaluate(()=>{S.cls='ws_mbt';S.view='lib';S.sel.ws_mbt=['mbt-atg','mbt-skylight','mbt-smoke'];S.tier=2;render()});
 L('mbt',await pg.evaluate(()=>({h1:document.querySelector('#main h1').innerText,warn:[...document.querySelectorAll('#main .warn')].map(e=>e.innerText).slice(0,4),cards:document.querySelectorAll('#main .sys').length,tpls:[...document.querySelectorAll('#main [id^=tplc-]')].map(e=>e.id+(e.classList.contains('dis')?':dis':''))})));
 await pg.screenshot({path:SP+'t28_mbt.png'});
 await pg.evaluate(()=>{S.sel.ws_mbt=['mbt-atg','mbt-rail'];render()});L('mbt 2 main warn',await pg.$$eval('#main .warn',x=>x.map(e=>e.innerText)));
 await pg.evaluate(()=>{S.sel.ws_mbt=['mbt-atg','mbt-skylight'];S.tplSel.ws_mbt={tpls:['ws_marine'],ch:['mr-spike','mr-anchor']};S.addN=1;S.enc=[];addToEnc();render()});
 L('enc mbt',await pg.evaluate(()=>{const i=S.enc[0];const st=stOf(i);return {hp:st.hp,armor:st.armor,size:st.size,sys:instSystems(i).map(s=>s.name)}}));
 // ---- ГМ tools
 await pg.click('[data-act="view"][data-v="gm"]');await pg.waitForTimeout(200);
 L('gm',await pg.evaluate(()=>({enc:!!document.getElementById('wf-enc'),rel:!!document.getElementById('dg-rel'),eid:!!document.getElementById('wf-eid'),
   wf:GMT.filter(t=>t.book==='WF').map(t=>t.id),dg:GMT.filter(t=>t.book==='DG').map(t=>t.id),ws:GMT.filter(t=>t.book==='WS').map(t=>t.id),
   side:[...document.querySelectorAll('#side .side-sub,#side .citem')].map(e=>e.textContent.trim()).filter(t=>/Дополнение|Бои|Отнош|Эйдол/.test(t))})));
 L('colors',await pg.evaluate(()=>[...document.querySelectorAll('.side-sub,.dlc-hd b')].map(e=>e.textContent.slice(0,28)+' → '+(e.dataset.bk||e.parentElement.dataset.bk||'-')+' '+getComputedStyle(e).color)));
 await pg.screenshot({path:SP+'t28_gm.png'});
 const ws=await pg.$('#gm-dlc-WS');if(ws){await ws.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t28_gm_ws.png'})}
 // ---- Справочник
 await pg.click('[data-act="view"][data-v="ref"]');await pg.waitForTimeout(200);
 L('ref',await pg.evaluate(()=>({sec:REF.map(s=>s.id),ws:(REF.find(s=>s.id==='ws')||{items:[]}).items.map(x=>x.t),bad:[...document.querySelectorAll('#main')].map(e=>/Часы отношений|Даунтайм Эвергрина|Часы кампании|Работа на фракцию/.test(e.innerText))[0],
   hd:[...document.querySelectorAll('.dlc-hd')].map(e=>e.innerText.slice(0,40)+' ['+(e.dataset.bk||'')+']')})));
 const r=await pg.$('#ref-ws');if(r){await r.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t28_ref.png'})}
 // ---- Флот
 await pg.click('[data-act="view"][data-v="fleet"]');await pg.waitForTimeout(200);
 await pg.evaluate(()=>{BGS.tab='cat';BGS.cat='npc';bgRender()}).catch(e=>L('bgerr',e.message));
 L('fleet',await pg.evaluate(()=>({typ:!!BNC.typhon,cards:[...document.querySelectorAll('.bg-card.npc .bg-hd b')].map(e=>e.textContent).slice(-3),img:!!BGART.typhon})));
 const tc=await pg.$$('.bg-card.npc');if(tc.length){await tc[tc.length-1].scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t28_fleet.png'})}
 // ---- Игроки
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 L('pc',await pg.evaluate(()=>{const p=curP();p.ll=6;p.lic={mf_gilgamesh:3,mf_manticore:2};p.cbs=['cb_order_of_leander','cb_neurolink_targeting'];PS.tab='pilot';pcRender();
   return {gil:!!P.F.mf_gilgamesh,cbrows:[...document.querySelectorAll('.cbrow.sel')].map(e=>e.innerText.replace(/\s+/g,' ').slice(0,90)),
   manual:/вручную/.test(document.body.innerText.split('Бонусы Ядра')[1]||''),exoblock:[...document.querySelectorAll('.lmh')].map(e=>e.textContent).filter(t=>/Экзот/.test(t))}}));
 await pg.screenshot({path:SP+'t28_pilot.png'});
 L('gil',await pg.evaluate(()=>{const p=curP(),m=curM(p);m.frame='mf_gilgamesh';p.cb=null;const ms=mechMounts(p,m);m.load={};m.load[ms[2].key]=['mw_legionnaire_battle_rifle'];m.load[ms[0].key]=['mw_superthermal_blade'];m.systems=['ms_utility_drone','ms_emergency_repair_module'];
   const st=mechStats(p,m);PS.tab='combat';pcRender();const c=pcEnsure(p);const x=mechWeapons(p,m)[0];return {lim:st.limited,ms:ms.map(x=>x.type),uses:limMax(p,x.w),die:c.counters.gilgamesh_arsenal??'(6 по умолчанию)',W:buildWarnings(p,m)}}));
 const rif=await pg.evaluate(()=>mechWeapons(curP(),curM(curP())).find(x=>x.w.id==='mw_legionnaire_battle_rifle').uid);
 await pg.click(`[data-pa="atk"][data-v="${rif}"]`);await pg.waitForTimeout(150);
 L('atk mods',await pg.evaluate(()=>M.mods.map(z=>z.label).filter(l=>/Леандр/.test(l))));
 await pg.evaluate(()=>{const b=[...document.querySelectorAll('#mbox button')].find(x=>/Бросить/.test(x.textContent));b.click()});
 L('after atk',await pg.evaluate(()=>{const p=curP(),c=pcEnsure(p);return {uses:c.uses,die:c.counters.gilgamesh_arsenal}}));
 await pg.evaluate(()=>{M=null;renderModal()});
 // кнопка − у заряда системы
 const sysu=await pg.evaluate(()=>mechSystems(curP(),curM(curP())).find(x=>x.s.id==='ms_utility_drone').uid);
 const minus=await pg.$(`[data-pa="use"][data-v="${sysu}"][data-d="-1"]`);L('minus btn',!!minus);if(minus){await minus.click();await minus.click().catch(()=>{})}
 L('after use',await pg.evaluate(()=>{const c=pcEnsure(curP());return {uses:c.uses,die:c.counters.gilgamesh_arsenal}}));
 await pg.screenshot({path:SP+'t28_gil.png'});
 // Ликан
 L('lycan',await pg.evaluate(()=>{const p=curP(),m=curM(p);m.frame='mf_lycan';m.load={};m.systems=[];p.cb=null;const c=pcEnsure(p);const st0=mechStats(p,m);
   const r=autoResist(p,'en',{});return {armor:st0.armor,speed:st0.speed,res:r,ints:mechWeapons(p,m).map(x=>x.w.name+':'+(x.w.profiles||[]).length)}}));
 await pg.evaluate(()=>{PS.tab='combat';pcRender()});await pg.click('[data-pa="core"]');await pg.waitForTimeout(150);
 L('lycan loud',await pg.evaluate(()=>{const p=curP(),m=curM(p),c=pcEnsure(p),st=mechStats(p,m);return {cp:c.cp,loud:c.wsLoud,eff:c.wsEff,armor:st.armor,speed:st.speed,res:autoResist(p,'en',{})}}));
 await pg.screenshot({path:SP+'t28_lycan.png'});
 await pg.click('[data-pa="rest"]');await pg.waitForTimeout(150);
 L('after rest',await pg.evaluate(()=>{const p=curP(),c=pcEnsure(p),st=mechStats(p,curM(p));return {cp:c.cp,loud:c.wsLoud,armor:st.armor}}));
 // Янтарный Фантом
 L('amber',await pg.evaluate(()=>{const p=curP(),m=curM(p);m.frame='mf_amber_phantom';p.cb=null;const ms=mechMounts(p,m);m.load={};m.load[ms[1].key]=['mw_shrapnel_cannon'];PS.tab='combat';pcRender();
   const x=mechWeapons(p,m)[0];pcOpenWeapon(p,x.uid);const a=M.mods.map(z=>z.label).filter(l=>/Карта|Леандр/.test(l));M=null;pcOpenCheck(p,'agi');const s=M.mods.map(z=>z.label).filter(l=>/Сверхбдит|Леандр/.test(l));M=null;renderModal();return {a,s}}));
 // Лицензии
 await pg.evaluate(()=>{PS.tab='pilot';PS.open['lic-mf_gilgamesh']=true;pcRender()});
 const ban=await pg.$('[data-v="mf_gilgamesh"]');if(ban){await ban.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t28_lic.png'})}
 L('lic',await pg.evaluate(()=>[...document.querySelectorAll('.lic-src')].map(e=>e.textContent+'|'+(e.dataset.bk||e.closest('[data-bk]')&&e.closest('[data-bk]').dataset.bk||'')).filter(t=>/Winter|Dustgrave|Rim|Karrakin|Wallflower/.test(t)).slice(0,12)));
 L('ERRS',errs);await b.close()})();
