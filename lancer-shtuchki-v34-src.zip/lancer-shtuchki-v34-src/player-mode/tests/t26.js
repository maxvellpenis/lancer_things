const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const SP='/tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad/';
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:950}});pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file:///home/claude/ulan-terminal-v26.html');await pg.click('[data-role="gm"]');
 // 1) Бои: черты шаблонов ставятся сами
 const cases=[['dg_bloodsport',3,3],['dg_bloodsport',4,3],['dg_bloodsport',5,3],['dg_elevator',3,0],['dg_birds',5,0]];
 const wfIds=await pg.evaluate(()=>WFENC.filter(e=>!e.book).map(e=>e.id));
 for(const [id,pcs,g] of cases){
  const r=await pg.evaluate(([id,pcs,g])=>{S.enc=[];WFE.enc=id;WFE.pcs=pcs;S.view='gm';render();const txt=document.querySelectorAll('.wf-grp')[g].innerText;
    wfAddGroup(g);return {txt:txt.slice(0,700),inst:S.enc.map(i=>`${i.label||i.name}: tpl=${(i.tpls||[]).join(',')} ch=${(i.tplCh||i.ch||[]).join(',')} | ${instSystems(i).filter(s=>s._tpl).map(s=>s.name).join(', ')}`)}},[id,pcs,g]);
  console.log('###',id,pcs,'\n',r.txt,'\n',r.inst.join('\n '))}
 // WF: все бои с чертами
 const r2=await pg.evaluate(()=>{const out=[];for(const E of WFENC.filter(e=>!e.book)){WFE.enc=E.id;WFE.pcs=5;E.groups.forEach((g,gi)=>{if(!g.items.some(it=>(it.ch||[]).length||(Array.isArray(it.upg)?it.upg:[it.upg||{}]).some(u=>(u.ch||[]).length)))return;S.enc=[];wfAddGroup(gi);
   S.enc.forEach(i=>{const t=instSystems(i).filter(s=>s._tpl&&!/Особенность/.test(s.tags||'')).map(s=>s.name);if(t.length)out.push(E.id+' · '+(i.label||i.name)+': '+t.join(', '))})})}return out});
 console.log('WF:\n '+r2.join('\n '));
 // 2) Библиотека: шаблоны слева, страница шаблона
 await pg.evaluate(()=>{S.view='lib';S.cls='assault';S.tplView=null;render()});
 const side=await pg.$$eval('#side .citem[data-tv]',x=>x.map(e=>e.innerText.replace(/\s+/g,' ')));console.log('side tpls',side.length,side.slice(-4));
 await pg.click('#side .citem[data-tv="dg_horror"]');await pg.waitForTimeout(200);
 const p=await pg.evaluate(()=>({h1:document.querySelector('#main h1').innerText,h2:[...document.querySelectorAll('#main h2')].map(e=>e.innerText),cards:document.querySelectorAll('#main .sys').length,atk:document.querySelectorAll('#main .atkbtn').length,on:[...document.querySelectorAll('#side .citem.on')].map(e=>e.innerText.split('\n')[0])}));
 console.log('page',JSON.stringify(p));await pg.screenshot({path:SP+'t26_horror.png'});
 for(const id of ['dg_industrial','dg_specop','veteran','commander','ultra']){await pg.click(`#side .citem[data-tv="${id}"]`);console.log(id,await pg.evaluate(()=>document.querySelector('#main h1').innerText+' cards '+document.querySelectorAll('#main .sys').length))}
 // поиск
 await pg.fill('#search','ужас');await pg.waitForTimeout(200);console.log('search',await pg.$$eval('#side .citem',x=>x.map(e=>e.innerText.split('\n')[0])));
 await pg.fill('#search','');await pg.waitForTimeout(200);
 // применить
 await pg.click('#side .citem[data-tv="dg_specop"]');await pg.selectOption('#tv-cls','sniper');await pg.click('[data-tv-apply]');await pg.waitForTimeout(300);
 console.log('apply',await pg.evaluate(()=>({cls:S.cls,tv:S.tplView,ts:JSON.stringify(getTplSel('sniper')),h1:document.querySelector('#main h1').innerText})));
 await pg.screenshot({path:SP+'t26_apply.png'});
 // клик по классу закрывает страницу шаблона
 await pg.click('#side .citem[data-tv="dg_horror"]');await pg.click('#side .citem[data-act="cls"][data-v="assault"]');
 console.log('back',await pg.evaluate(()=>({tv:S.tplView,h1:document.querySelector('#main h1').innerText})));
 await pg.click('[data-tv-jump]');await pg.waitForTimeout(600);await pg.screenshot({path:SP+'t26_jump.png'});
 // мобильный
 await pg.setViewportSize({width:390,height:844});await pg.click('#side .citem[data-tv="dg_horror"]').catch(()=>{});await pg.evaluate(()=>{S.tplView='dg_horror';S.view='lib';render()});
 console.log('hscroll',await pg.evaluate(()=>document.documentElement.scrollWidth));await pg.screenshot({path:SP+'t26_mob.png'});
 console.log('ERRS',JSON.stringify(errs));await b.close()})();
