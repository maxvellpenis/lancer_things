const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{
 const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1500,height:1000}});
 const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('dialog',d=>d.accept());
 await pg.goto('file:///home/claude/lancer-npc-v11.html');
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 await pg.evaluate(()=>{const p=curP();p.name='Ода Ресмарк';p.callsign='Райдзин';p.ll=5;p.talents={t_gunslinger:2,t_ace:3,t_engineer:1};p.lic={mf_drake:2};const m=curM(p);m.frame='mf_drake';m.load={f0:['mw_assault_cannon']};PS.tab='pilot';render();
   [...document.querySelectorAll('h2')].find(h=>h.textContent.startsWith('Таланты')).scrollIntoView()});
 await pg.screenshot({path:'n_tal.png'});
 await pg.evaluate(()=>{PS.tab='combat';render();const p=curP();p.cb.struct=2;p.cb.stress=4;p.cb.oc=2;render();document.getElementById('main').scrollTop=0});
 await pg.screenshot({path:'n_combat.png'});
 await pg.evaluate(()=>{S.view='lib';render()});await pg.screenshot({path:'n_lib.png'});
 console.log(errs);await b.close();})();
