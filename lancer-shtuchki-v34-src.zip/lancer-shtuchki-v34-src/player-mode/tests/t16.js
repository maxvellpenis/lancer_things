const {JSDOM}=require('jsdom');const fs=require('fs');
const errs=[];const dom=new JSDOM(fs.readFileSync('/home/claude/lancer-npc-v16.html','utf8'),{runScripts:'dangerously',url:'http://localhost/',beforeParse(w){w.alert=m=>errs.push('ALERT '+m);w.addEventListener('error',e=>errs.push(e.message))}});
const w=dom.window,d=w.document;
d.querySelector('[data-act="view"][data-v="pc"]').dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
console.log('side button:',!!d.querySelector('[data-pa="ccimport"]'));
for(const f of process.argv.slice(2)){
  w.__t=fs.readFileSync(f,'utf8');
  console.log('=== ',f.split('/').pop(),w.eval('pcImportText(window.__t)'));
  console.log(w.eval(`(()=>{const p=curP();const o=[];o.push(p.name+' / '+p.callsign+' УЛ'+p.ll+' bg='+p.bgId+' hase='+JSON.stringify(p.hase));
   o.push('skills '+JSON.stringify(p.skills)+' talents '+JSON.stringify(p.talents)+' cbs '+p.cbs+' lic '+JSON.stringify(p.lic));
   o.push('gear '+JSON.stringify(p.gear));
   p.mechs.forEach((m,i)=>{p.mech=i;o.push('MECH '+m.name+' '+m.frame+' load '+JSON.stringify(m.load)+' mods '+JSON.stringify(m.mods)+' sys '+m.systems.join(',')+' autostab '+m.autostab);
     o.push('   weapons: '+mechWeapons(p,m).map(x=>x.w.name).join(', ')+' | SP '+spUsed(p,m)+'/'+mechStats(p,m).sp+' | warn: '+buildWarnings(p,m).join('; '))});
   o.push('LOG: '+S.log[0].html.replace(/<[^>]+>/g,' ').replace(/\\s+/g,' ').slice(0,600));
   PS.tab='mech';renderMain();PS.tab='combat';renderMain();PS.tab='pilot';renderMain();
   return o.join('\\n')})()`));
}
console.log('pilots',w.eval('PS.pilots.length'),'errors',errs);
