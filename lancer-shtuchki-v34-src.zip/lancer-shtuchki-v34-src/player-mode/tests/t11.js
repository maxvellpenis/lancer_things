const {JSDOM}=require('jsdom');const fs=require('fs');
const errs=[];const dom=new JSDOM(fs.readFileSync(process.argv[2],'utf8'),{runScripts:'dangerously',url:'http://localhost/',beforeParse(w){w.alert=m=>errs.push('ALERT '+m);w.confirm=()=>true;w.addEventListener('error',e=>errs.push(e.message))}});
const w=dom.window,d=w.document;
const click=sel=>{const el=d.querySelector(sel);if(!el)throw new Error('no '+sel);el.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));return el};
const change=(sel,v)=>{const el=d.querySelector(sel);if(!el)throw new Error('no '+sel);el.value=v;el.dispatchEvent(new w.Event('change',{bubbles:true}))};
click('[data-act="view"][data-v="pc"]');
click('[data-pa="pnew"]');
for(let i=0;i<12;i++)click('[data-pa="ll"][data-d="1"]');
const r=w.eval(`(()=>{const out=[];const p=curP();
 PCD.frames.forEach(f=>{if(f.ll)p.lic[f.id]=3});
 p.talents={t_ace:3,t_nuclear_cavalier:3,t_technophile:3,t_brawler:3,t_gunslinger:3};p.hase={hull:6,agi:6,sys:6,eng:6};
 p.cbs=['cb_mount_retrofitting','cb_improved_armament','cb_integrated_weapon','cb_auto_stabilizing_hardpoints','cb_fomorian_frame','cb_heatfall_coolant_system'];
 p.skills={sk_assault:3};p.gear.weapons=['pg_heavy_signature','pg_heavy_a_c'];
 const rl=renderLog;renderLog=()=>{};
 let n=0;
 for(const f of PCD.frames){
   const m=curM(p);m.frame=f.id;m.load={};m.mods={};m.sh={};m.systems=[];p.cb=null;
   const ms=mechMounts(p,m);
   // fill every slot with first allowed weapon (cycling through list)
   ms.forEach((mt,k)=>{if(mt.fixed)return;(SLOTS[mt.type]||[]).forEach((_,si)=>{const al=slotAllowed(m,mt,si);const cand=PCD.weapons.filter(w=>al.includes(w.mount)&&!w.tal&&!/_integrated$/.test(w.id));if(!cand.length)return;const w=cand[(n++)%cand.length];m.load[mt.key]=m.load[mt.key]||[];m.load[mt.key][si]=w.id;
      const md=PCD.mods.find(x=>x.types.includes(w.type));if(md)m.mods[mt.key+'#'+si]=md.id;if(w.mount==='Superheavy'){const o=ms.find(x=>x.key!==mt.key&&!x.fixed);if(o)m.sh[mt.key]=o.key}})});
   m.systems=PCD.systems.filter(s=>!s.tal).slice((n*7)%100,(n*7)%100+6).map(s=>s.id);
   try{
     PS.tab='mech';renderMain();PS.tab='combat';renderMain();PS.tab='pilot';renderMain();
     const st=mechStats(p,m);
     for(const x of mechWeapons(p,m)){pcOpenWeapon(p,x.uid);if(M.profiles)M.profiles.forEach((_,i)=>pcSetProfile(p,x,i));M.target='10';M.bonusDmg='1d6';M.mods.forEach(mm=>{if(!mm.fixed&&!mm.invis)mm.on=true});renderModal();pcRoll();pcRoll(true);M=null}
     for(const x of mechSystems(p,m)){const tech=(x.s.acts||[]).filter(a=>a.tech||/Tech|Invade/.test(a.act||''));if(tech.length){pcOpenTech(p,'t',{uid:x.uid});M.target='8';renderModal();pcRoll();M=null}}
     ['hull','agi','sys','eng'].forEach(k=>{pcOpenCheck(p,k);pcRoll();M=null});
     ['impro','ram','grapple','invade','search'].forEach(k=>{pcOpenBasic(p,k);pcRoll();M=null});
     pcOpenPilotAtk(p,'pg_heavy_signature');pcRoll();M=null;
     pcOvercharge(p);pcOvercharge(p);pcHeat(p,25,'тест');pcDamage(p,40,'kin',{});pcDamage(p,5,'burn',{ap:true});pcBurnCheck(p);pcMeltTick(p);pcStabilize(p,'cool','reload');pcStabilize(p,'repair','burn');pcFullRepair(p);
     const W=buildWarnings(p,m);
     out.push(f.en+': hp'+st.hp+' sp'+spUsed(p,m)+'/'+st.sp+' size'+st.size+' mounts '+ms.map(x=>x.type).join(',')+' W:'+W.length);
   }catch(e){out.push('ERR '+f.en+': '+e.message+' '+(e.stack||'').split('\\n').slice(1,3).join(' '))}
 }
 renderLog=rl;return out})()`);
console.log(r.join('\n'));console.log('errors',errs.slice(0,10));
console.log('log entries',w.eval('S.log.length'));
