const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:900}});pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text().slice(0,200))});
 await pg.goto('file:///home/claude/lancer-npc-v21.html');await pg.click('[data-role="gm"]');
 console.log('tabs',await pg.$$eval('#tabs .tab',x=>x.map(y=>y.textContent.trim()).join('|')));
 await pg.click('[data-act="view"][data-v="gm"]');await pg.click('[data-gm="all"]');
 console.log('gm cards',await pg.$$eval('.gm-card',x=>x.length),'rolled',await pg.$$eval('.gm-card.has',x=>x.length),'dlc',await pg.$$eval('.gm-card.dlc',x=>x.length));
 await pg.screenshot({path:'v21_gm.png'});
 await pg.evaluate(()=>document.getElementById('gm-dlc-LR').scrollIntoView());await pg.screenshot({path:'v21_gm2.png'});
 await pg.click('[data-act="view"][data-v="ref"]');await pg.evaluate(()=>document.getElementById('ref-lr').scrollIntoView());await pg.waitForTimeout(100);await pg.screenshot({path:'v21_ref.png'});
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 await pg.evaluate(()=>{const p=curP();p.ll=12;['mf_atlas','mf_caliban','mf_kobold','mf_lich','mf_sunzi','mf_zheng'].forEach(f=>p.lic[f]=3);p.talents={t_spaceborn:3,t_black_thumb:3};PS.open['lic-mf_atlas']=true;render();
   const h=[...document.querySelectorAll('.lic-ban')].find(x=>x.dataset.v==='mf_atlas');h.scrollIntoView()});
 await pg.screenshot({path:'v21_lic.png'});
 await pg.click('[data-pa="licitem"][data-v="mw_terashima_blade"]');await pg.waitForTimeout(150);await pg.screenshot({path:'v21_io.png'});await pg.click('#itemov [data-pa="iox"]');
 const R=await pg.evaluate(()=>{const p=curP(),out=[];
  for(const f of ['mf_atlas','mf_caliban','mf_kobold','mf_lich','mf_sunzi','mf_zheng']){const m=curM(p);m.frame=f;m.load={};m.systems=[];p.cb=null;
    const ms=mechMounts(p,m);const lr=PCD.weapons.filter(w=>w.book==='LR'&&w.lic===f);
    ms.forEach(mt=>{if(mt.fixed)return;const al=slotAllowed(m,mt,0);const w=lr.find(w=>al.includes(w.mount))||PCD.weapons.find(w=>al.includes(w.mount)&&!w.tal&&!/_integrated$/.test(w.id));if(w){m.load[mt.key]=[w.id]}});
    m.systems=PCD.systems.filter(s=>s.book==='LR'&&s.lic===f).map(s=>s.id);
    PS.tab='mech';renderMain();PS.tab='combat';renderMain();
    const ws=mechWeapons(p,m);for(const x of ws){pcOpenWeapon(p,x.uid);if(M.profiles)M.profiles.forEach((_,i)=>pcSetProfile(p,x,i));M.target='10';pcRoll();M=null}
    const st=mechStats(p,m);out.push(f+': hp'+st.hp+' ev'+st.evasion+' sp'+st.sp+' W:'+ws.map(x=>x.w.id).join(',')+' techbtns:'+document.querySelectorAll('[data-pa="stech"]').length)}
  return out});
 R.forEach(x=>console.log(x));
 await pg.screenshot({path:'v21_combat.png'});
 const chk=await pg.evaluate(()=>{const p=curP();curM(p).frame='mf_kobold';p.cb=null;return pcBaseMods(p,'check',{skill:'eng'}).map(m=>m.label)});console.log('kobold eng',chk);
 const fus=await pg.evaluate(()=>{const p=curP();const m=curM(p);m.frame='mf_kobold';m.load={};const ms=mechMounts(p,m);m.load[ms[0].key]=['mw_fusion_rifle'];p.cb=null;const x=mechWeapons(p,m)[0];pcOpenWeapon(p,x.uid);return M.profiles.map(p=>profRu(p.name)+':'+p.dmg[0].v).join(' ')});console.log('fusion',fus);
 console.log(errs.slice(0,6));await b.close()})();
