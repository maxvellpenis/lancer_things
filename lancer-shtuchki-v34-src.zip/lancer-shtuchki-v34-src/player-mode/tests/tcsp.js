const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const errs=[],csp=[];const pg=await b.newPage();pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(/Content Security Policy/i.test(m.text()))csp.push(m.text().slice(0,90))});
 await pg.goto('file:///home/claude/lancer-npc-v20.html');await pg.click('[data-role="gm"]');
 const r=await pg.evaluate(async()=>{document.getElementById('main').insertAdjacentHTML('beforeend','<img src=x onerror="window.__x=1"><script>window.__y=1<\/script>');const s=document.createElement('script');s.textContent='window.__z=1';document.body.appendChild(s);let f='ok';try{await fetch('https://example.com')}catch(e){f='blocked'}await new Promise(r=>setTimeout(r,300));return {x:window.__x,y:window.__y,z:window.__z,fetch:f,art:getComputedStyle(document.body).display}});
 console.log(JSON.stringify(r),csp.length,'csp violations');
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 // existing good Comp/Con file import
 const fs=require('fs');const t=fs.readFileSync('/tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad/todo/furer_v2.json','utf8');
 const n=await pg.evaluate(t=>pcImportText(t),t);console.log('cc import',n,await pg.evaluate(()=>[curP().callsign,curP().ll,Object.keys(curP().talents).length,curM(curP()).frame,curM(curP()).systems.length]));
 // export -> reimport roundtrip
 const rt=await pg.evaluate(()=>{const a=JSON.stringify(PS.pilots);const before=PS.pilots.length;pcImportText(a);return [before,PS.pilots.length,JSON.stringify(PS.pilots)===a]});console.log('roundtrip',rt);
 // crash guard
 await pg.evaluate(()=>{curP().mechs[0].frame='nope';render()});console.log('crash',await pg.evaluate(()=>!!document.querySelector('.crashbox'))||'(rendered ok)');
 console.log(errs.slice(0,3));await b.close()})();
