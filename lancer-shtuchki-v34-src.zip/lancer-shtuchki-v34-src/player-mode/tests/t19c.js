const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:900}});pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file:///home/claude/lancer-npc-v19.html');await pg.click('[data-role="gm"]');await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 await pg.evaluate(()=>{PS.tab='combat';render()});
 const R=await pg.evaluate(()=>{const p=curP(),out=[];const orig=rnd;
   const run=(seq,fn)=>{let i=0;rnd=n=>seq[i++]??1;try{fn()}finally{rnd=orig}return S.log[0].html.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').slice(0,260)};
   // structure: 1 lost, die 3 → trauma, then d6=2 (weapons) — no weapons, has no systems? new mech empty
   pcFullRepair(p,true);const c=p.cb;c.struct=3;out.push('trauma empty: '+run([3,2],()=>pcStructCheck(p))+' stunned='+c.conds.includes('Ошеломлен'));
   pcFullRepair(p,true);curM(p).systems=['ms_custom_paint_job'];p.cb.struct=3;out.push('trauma sys: '+run([3,2],()=>pcStructCheck(p)));
   pcFullRepair(p,true);p.cb.struct=2;out.push('direct 2: '+run([4,1,15],()=>pcStructCheck(p)));
   pcFullRepair(p,true);p.cb.struct=2;out.push('crush: '+run([1,1],()=>pcStructCheck(p))+' dead='+p.cb.dead);
   pcFullRepair(p,true);p.cb.stress=2;out.push('melt fail: '+run([5,1,2,4],()=>pcStressCheck(p))+' exposed='+p.cb.conds.includes('Уязвим')+' md='+p.cb.meltdown);
   pcFullRepair(p,true);p.cb.stress=2;out.push('melt ok: '+run([5,1,18],()=>pcStressCheck(p))+' exposed='+p.cb.conds.includes('Уязвим'));
   pcFullRepair(p,true);p.cb.stress=3;out.push('shunt: '+run([6],()=>pcStressCheck(p))+' imp='+p.cb.conds.includes('Ослаблен'));
   pcFullRepair(p,true);render();return out});
 R.forEach(x=>console.log(x));
 await pg.click('[data-pa="sdmg"]');await pg.click('[data-pa="hdmg"]');console.log(await pg.evaluate(()=>[curP().cb.struct,curP().cb.stress]));
 await pg.screenshot({path:'v19_btn.png',clip:{x:240,y:220,width:830,height:420}});
 console.log(errs);await b.close()})();
