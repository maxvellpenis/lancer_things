const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync(process.argv[2],'utf8'),{runScripts:'dangerously',url:'http://localhost/',beforeParse(w){w.alert=m=>console.log('ALERT',m);w.confirm=()=>false}});
const w=dom.window;
console.log(w.eval(`(()=>{const o=[];const p=newPilot();PS.pilots.push(p);PS.sel=p.id;p.ll=2;p.lic={mf_drake:2};p.hase={hull:1,agi:0,sys:0,eng:2};
 const m=curM(p);m.frame='mf_drake';p.cb=null;const st=mechStats(p,m);const c=pcEnsure(p);
 o.push('Drake hp '+st.hp+' armor '+st.armor+' heatcap '+st.heatcap+' limited+'+st.limited+' save '+st.save+' sp '+st.sp);
 pcDamage(p,20,'kin',{});o.push('after 20 kin: hp '+c.hp+' struct '+c.struct);
 pcDamage(p,10,'kin',{ap:true,half:true});o.push('after 10 AP half: hp '+c.hp+' struct '+c.struct);
 c.conds.push('Уязвим');pcDamage(p,5,'exp',{});o.push('exposed 5 exp: hp '+c.hp+' struct '+c.struct);
 pcDamage(p,3,'burn',{});o.push('burn 3: hp '+c.hp+' burn '+c.burn);
 pcHeat(p,9,'t');o.push('heat 9: heat '+c.heat+' stress '+c.stress+' conds '+c.conds);
 const costs=[];for(let i=0;i<5;i++){const h0=c.heat,s0=c.stress;pcOvercharge(p);costs.push(c.oc)}o.push('oc count '+c.oc);
 m.systems=['ms_pattern_a_smoke_charges'];const s=mechSystems(p,m)[0];o.push('smoke limited max '+limMax(p,s.s));
 for(let i=0;i<5;i++){const r=pcRollExpr('2d6+2',{crit:true,overkill:true});if(i<2)o.push('crit roll '+r.txt+' = '+r.v+' heat '+r.heat)}
 o.push(S.log.slice(0,14).map(e=>e.html.replace(/<[^>]+>/g,' ').replace(/\\s+/g,' ').trim()).reverse().join('\\n'));
 return o.join('\\n')})()`));
