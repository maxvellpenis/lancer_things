const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{
 const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1400,height:4200}});
 const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('dialog',d=>d.accept());
 await pg.goto('file:///home/claude/lancer-npc-v14.html');
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 await pg.evaluate(()=>{const p=curP();p.ll=6;p.bgId='pbg_mechanic';PS.open.bg=true;p.talents={t_engineer:2,t_drone_commander:1,t_brutal:1};p.skills={sk_hack_or_fix:2,sk_blow_something_up:1,sk_get_a_hold_of_something:1,sk_spot:1};
   p.reserves=[{id:'reserve_ammo',item:'ms_turret_drones',n:2},{id:'reserve_extended_harness'},{id:'reserve_systems_reinforcement',skill:'eng'},{id:'custom',name:'Долг контрабандистов',note:'вернуть до конца миссии'}];
   p.gear.items=['pg_corrective','pg_frag_grenades','pg_stims','pg_patch',''];PS.open['gf-pg_heavy_hardsuit']=true;p.gear.armor='pg_heavy_hardsuit';
   const m=curM(p);m.systems=['ms_turret_drones','ms_pattern_a_jericho_deployable_cover'];m.proto.rev=['optics','reactor'];PS.tab='pilot';render()});
 await pg.screenshot({path:'s14_pilot.png',fullPage:true});
 await pg.evaluate(()=>{PS.tab='mech';render()});
 await pg.screenshot({path:'s14_mech.png',fullPage:true});
 await pg.evaluate(()=>{PS.tab='combat';render()});
 await pg.click('[data-pa="depadd"]');await pg.click('[data-pa="depadd"] >> nth=1');
 await pg.screenshot({path:'s14_combat.png',fullPage:true});
 await pg.evaluate(()=>{const p=curP(),m=curM(p);const x=mechWeapons(p,m).find(x=>x.w.proto);pcOpenWeapon(p,x.uid)});
 await pg.screenshot({path:'s14_roll.png'});
 console.log(errs);await b.close();})();
