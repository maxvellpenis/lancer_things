const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const X='"\'><img src=x onerror="window.__pwn=(window.__pwn||[]).concat(1)">';
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:900}});pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file:///home/claude/lancer-npc-v20.html');await pg.click('[data-role="gm"]');await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 // build poisoned pilot from a real one: replace every string except known enum fields
 const out=await pg.evaluate(async(X)=>{const p=JSON.parse(JSON.stringify(curP()));
   const poison=(o,path)=>{for(const k of Object.keys(o)){const v=o[k];if(typeof v==='string')o[k]=v+X;else if(v&&typeof v==='object')poison(v,path+'.'+k)}};
   poison(p,'');p.id='evil'+X;p.custom=[{name:'S'+X,rank:1}];p.reserves=[{id:'custom',name:'R'+X,note:X}];p.skills={['sk_'+X]:1};p.talents={['t_'+X]:1};p.lic={['mf_'+X]:2};p.ll='3'+X;
   const res=[];
   for(const tab of ['pilot','mech','combat']){try{pcImportText(JSON.stringify(p));PS.tab=tab;render()}catch(e){res.push(tab+': '+e.message)}}
   await new Promise(r=>setTimeout(r,300));
   // NPC library import
   const npc={id:'x'+X,name:'N'+X,role:'R'+X,icon:X,tag:'Мех'+X,group:'G'+X,desc:'D'+X,tactics:'T'+X,tiers:[[1,2,3]],base:[{id:'s'+X,name:'n'+X,type:'trait',tags:'t'+X,text:'**'+X+'**'}],optional:[]};
   try{document.getElementById('io')||0;S.custom.push(npc);S.view='lib';S.cls=npc.id;render()}catch(e){res.push('npc: '+e.message)}
   await new Promise(r=>setTimeout(r,300));
   // broken & huge json
   const t0=Date.now();pcImportText('{"a":'.repeat(5000));const big='['+Array(200000).fill('{"x":1}').join(',')+']';pcImportText(big);res.push('broken+big ms '+(Date.now()-t0));
   return {pwn:window.__pwn||[],res,ll:curP()&&curP().ll}},X);
 console.log(JSON.stringify(out));console.log(errs.slice(0,5));await b.close()})();
