const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:900}});pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text().slice(0,200))});
 await pg.goto('file:///home/claude/lancer-npc-v22.html');await pg.click('[data-role="gm"]');
 console.log('tabs',await pg.$$eval('#tabs .tab',x=>x.map(y=>y.textContent.trim()).join('|')));
 await pg.click('[data-act="view"][data-v="fleet"]');
 await pg.click('[data-bg="gnew"]');
 const addHull=async h=>{await pg.click('[data-bg="shipaddh"][data-v="'+h+'"]')};
 await addHull('thoreau');await addHull('caspian');await addHull('caspian');
 // заполнить слоты
 const setSlot=async(i,k,j,id)=>{const sel=(await pg.$$(`[data-bgf="slot"]`)).filter(async x=>true);const sid=await pg.evaluate(i=>BGS.groups[0].ships[i].id,i);await pg.selectOption(`[data-bgf="slot"][data-v="${sid}|${k}|${j}"]`,id)};
 await setSlot(0,'sh',0,'block');await setSlot(0,'pr',0,'hkb');await setSlot(0,'pr',1,'razorback');await setSlot(0,'aux',0,'turrets');await setSlot(0,'aux',1,'ndep');await setSlot(0,'sys',0,'ffe');
 await setSlot(1,'pr',0,'hkb');await setSlot(1,'aux',0,'flyswatter');await setSlot(2,'pr',0,'pinaka');await setSlot(2,'aux',0,'flyswatter');
 console.log('cost',JSON.stringify(await pg.evaluate(()=>bgCost(BGS.groups[0]))),'warn',JSON.stringify(await pg.evaluate(()=>bgWarn(BGS.groups[0]))));
 await pg.screenshot({path:'v22_build.png',fullPage:false});
 // второй: авианосец с крыльями и абордажем
 await pg.click('[data-bg="gnew"]');await addHull('tawa');await addHull('minokawa');
 await pg.evaluate(()=>{const g=BGS.groups[1];g.ships[0].eq={wing:['chassis','fighter'],esc:['marines'],sys:['catapult','pos']};g.ships[1].eq={pr:['lamprey'],mod:{k:'wing',id:'tortuga'}};bgRender()});
 console.log('cost2',JSON.stringify(await pg.evaluate(()=>bgCost(BGS.groups[1]))),'warn2',JSON.stringify(await pg.evaluate(()=>bgWarn(BGS.groups[1]))));
 // бой
 await pg.click('[data-bg="tab"][data-v="battle"]');
 await pg.evaluate(()=>{BGS.add={g:BGS.groups[0].id,band:'4',cap:'manowar',e0:'wardogs',e1:'giant',ace:'valkyrie'};bgRender()});
 await pg.click('details[data-po="bg-setup"] > summary');
 await pg.click('[data-bg="addpc"]');await pg.evaluate(()=>{BGS.add.g=BGS.groups[1].id;BGS.add.band='3';bgRender()});await pg.click('[data-bg="addpc"]');
 await pg.click('[data-bg="addnpc"]');
 await pg.evaluate(()=>{BGS.add={cap:'breakwater',e0:'roughnecks',e1:'denmother'};bgRender()});await pg.click('[data-bg="addnpc"]');
 console.log('units',await pg.evaluate(()=>BB().units.map(u=>u.name+':'+u.ships.map(s=>s.name+' '+s.hp+'/'+s.max).join(',')).join(' || ')));
 await pg.click('[data-bg="next"]');// старт
 console.log('round',await pg.evaluate(()=>JSON.stringify({r:BB().round,p:BB().phase,t:BB().ticked})));
 // атака тяжёлыми батареями
 const pcu=await pg.evaluate(()=>BB().units[0].uid);
 const wkey=await pg.evaluate(()=>{const u=BB().units[0];return bgPcItems(u).find(x=>x.id==='hkb').key});
 await pg.click(`[data-bg="watk"][data-v="${pcu}|${wkey}"]`);
 await pg.click('[data-bg="atkroll"]');
 const res=await pg.evaluate(()=>BGS.atk&&BGS.atk.res);console.log('atk',JSON.stringify(res&&{tot:res.tot,def:res.def,hit:res.hit,dmg:res.dmg,mods:res.mods}));
 if(await pg.$('[data-bg="atkapply"]'))await pg.click('[data-bg="atkapply"]');
 await pg.screenshot({path:'v22_battle.png'});
 // ракета
 const rk=await pg.evaluate(()=>{const u=BB().units[0];return bgPcItems(u).find(x=>x.id==='razorback').key});
 await pg.click(`[data-bg="wlaunch"][data-v="${pcu}|${rk}"]`);await pg.click('[data-bg="launch"]');
 console.log('pls',await pg.evaluate(()=>JSON.stringify(BB().pls.map(p=>({n:p.name,fc:p.fc})))));
 // NPC атака
 const nu=await pg.evaluate(()=>BB().units[2].uid);
 await pg.click(`[data-bg="natk"][data-v="${nu}|c:1"]`);await pg.click('[data-bg="atkroll"]');
 console.log('npcatk',await pg.evaluate(()=>JSON.stringify(BGS.atk.res&&{tot:BGS.atk.res.tot,def:BGS.atk.res.def,dmg:BGS.atk.res.dmg,mods:BGS.atk.res.mods})));
 await pg.click('[data-bg="atkclose"]');
 // фазы до логистики раунда 2, 3 — ракета должна дойти
 for(let i=0;i<9;i++){await pg.click('[data-bg="next"]');}
 console.log('round',await pg.evaluate(()=>JSON.stringify({r:BB().round,p:BB().phase,pls:BB().pls.map(p=>p.fc)})));
 const imp=await pg.$('[data-bg="impact"]');if(imp){await imp.click();console.log('impact resolved')}
 // абордаж
 const brdSel=await pg.$('[data-bgf="brdt"]');if(brdSel){const opts=await brdSel.$$eval('option',o=>o.map(x=>x.value).filter(Boolean));await brdSel.selectOption(opts[0]);}
 console.log('brd',await pg.evaluate(()=>JSON.stringify(BB().brd.map(r=>[r.name,r.ten]))));
 if(await pg.$('[data-bg="broll"]')){await pg.click('[data-bg="broll"]');await pg.click('[data-bg="brepel"]')}
 // урон по площади вручную и гибель
 const v=await pg.evaluate(()=>BB().units[2].uid+'|c');
 await pg.fill(`[data-bgf="dmgv"][data-v="${v}"]`,'60');await pg.click(`[data-bg="dmg"][data-v="${v}"]`);
 console.log('dead',await pg.evaluate(()=>JSON.stringify(BB().units[2].ships[0])));
 await pg.screenshot({path:'v22_battle2.png',fullPage:true});
 // каталог
 await pg.click('[data-bg="tab"][data-v="cat"]');for(const c of ['hulls','weap','sys','ew','npc','npce']){await pg.click(`[data-bg="cat"][data-v="${c}"]`);console.log('cat',c,await pg.$$eval('.bg-card',x=>x.length))}
 await pg.screenshot({path:'v22_cat.png'});
 // Справочник
 await pg.click('[data-act="view"][data-v="ref"]');console.log('bg ref cards',await pg.$$eval('.gl-card.bgc',x=>x.length),'hd',await pg.$$eval('.bg-hd',x=>x.length));
 await pg.evaluate(()=>document.getElementById('ref-bg-base').scrollIntoView());await pg.waitForTimeout(200);await pg.screenshot({path:'v22_ref.png'});
 console.log('lancer tips in bg ref',await pg.$$eval('.gl-card.bgc .at',x=>x.length),'bg tips',await pg.$$eval('.gl-card.bgc .kw',x=>x.length));
 await pg.click('[data-act="view"][data-v="gm"]');console.log('gm BG',await pg.$$eval('.gm-card',x=>x.length));
 // игрок
 await pg.click('[data-act="rolechange"]');await pg.click('[data-role="player"]');
 console.log('player tabs',await pg.$$eval('#tabs .tab',x=>x.map(y=>y.textContent.trim()).join('|')));
 await pg.click('[data-act="view"][data-v="fleet"]');console.log('player view',await pg.evaluate(()=>S.view),await pg.$$eval('.bg-view',x=>x.length));
 // перезагрузка — сохранение
 await pg.reload();console.log('saved groups',await pg.evaluate(()=>BGS.groups.length+' units '+BB().units.length));
 console.log('ERRS',JSON.stringify(errs));await b.close()})();
