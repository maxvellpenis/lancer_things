const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:900}});pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file:///home/claude/lancer-npc-v19.html');await pg.click('[data-role="player"]');await pg.click('[data-act="view"][data-v="ref"]');await pg.waitForTimeout(100);
 console.log('cards',await pg.$$eval('#main .gl-card',x=>x.length),'titles',(await pg.$$eval('#main .gl-t',x=>x.map(y=>y.textContent))).slice(0,80).join(' | '));
 await pg.fill('#refq','реакци');console.log('search',await pg.$$eval('#main .gl-card',x=>x.filter(y=>y.style.display!=='none').map(y=>y.querySelector('.gl-t').textContent)));
 await pg.fill('#refq','');await pg.evaluate(()=>document.getElementById('ref-turn').scrollIntoView());await pg.screenshot({path:'v19_ref3.png'});
 console.log(errs);await b.close()})();
