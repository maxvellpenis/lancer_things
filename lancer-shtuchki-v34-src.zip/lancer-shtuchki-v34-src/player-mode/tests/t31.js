const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const SP='';
const F=process.argv[2]||require('path').resolve('ulan-terminal-v31.html');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:950}});pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text().slice(0,200))});
 await pg.goto('file://'+F);await pg.click('[data-role="gm"]');
 const L=(...a)=>console.log(...a.map(x=>typeof x==='string'?x:JSON.stringify(x)));
 // ГМ
 await pg.click('[data-act="view"][data-v="gm"]');await pg.waitForTimeout(200);
 L('gm',await pg.evaluate(()=>{const ts=GMT.filter(t=>t.book==='SW');const rs=[];for(let i=0;i<300;i++){gmRoll('sw_sponsor',true);rs.push(GMS.sw_sponsor)}
   return {n:ts.map(t=>t.id+':'+t.rows.length),k:[Math.min(...rs),Math.max(...rs)],order:[...new Set(GMT.map(t=>t.book||'core'))],side:[...document.querySelectorAll('#side .side-sub')].map(e=>e.textContent+':'+(e.dataset.bk||'')),
   items:[...document.querySelectorAll('#side .citem')].filter(e=>/Коллеги|курсант/.test(e.textContent)).map(e=>e.textContent.trim().slice(0,40)+':'+(e.dataset.bk||''))}}));
 await pg.click('[data-gm="roll"][data-v="sw_quirk"]');L('log',await pg.evaluate(()=>document.querySelector('#log .et')&&document.querySelector('#log .et').innerText.slice(0,200)));
 const g=await pg.$('#gm-dlc-SW');if(g){await g.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t31_gm.png'})}else L('NO gm-dlc-SW');
 // Справочник
 await pg.click('[data-act="view"][data-v="ref"]');await pg.waitForTimeout(200);
 L('ref',await pg.evaluate(()=>({sw:(REF.find(s=>s.id==='sw')||{items:[]}).items.map(x=>x.t),hd:[...document.querySelectorAll('.dlc-hd')].map(e=>e.innerText.split('\n')[0]+'['+(e.dataset.bk||'')+']'),
   marks:[...new Set([...document.querySelectorAll('#ref-sw ~ * .srcmark')].map(e=>e.textContent.split(' ·')[0]+'['+(e.dataset.bk||'')+']'))].slice(0,6)})));
 const r=await pg.$('#ref-sw');if(r){await r.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t31_ref.png'})}
 // Игроки: Тагетес
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 L('tag',await pg.evaluate(()=>{const p=curP();p.ll=2;p.lic={mf_sherman:2};const m=curM(p);m.frame='mf_sherman_alt_tagetes';const ms=mechMounts(p,m);
   const mt=ms.filter(x=>!x.fixed);m.load={};
   const pick=t=>PCD.weapons.find(w=>w.mount===t.mount&&w.type===t.type&&!w.book&&w.src==='GMS')||PCD.weapons.find(w=>w.mount===t.mount&&w.type===t.type);
   const hv=mt.find(x=>x.type==='Heavy'),mn=mt.find(x=>x.type==='Main');
   m.load[hv.key]=[pick({mount:'Heavy',type:'Cannon'}).id];m.load[mn.key]=[pick({mount:'Main',type:'Rifle'}).id];
   PS.tab='mech';pcRender();
   return {ok:frameOk(p,P.F[m.frame]),mounts:ms.map(x=>x.type),art:!!(typeof ART!=='undefined'&&ART&&ART['mf_sherman_alt_tagetes']),ws:mechWeapons(p,m).map(x=>x.w.name+'/'+x.w.type),
     btns:[...document.querySelectorAll('[data-swfus]')].map(e=>e.dataset.swfus+':'+e.textContent)}}));
 await pg.click('[data-swfus]');
 L('fus',await pg.evaluate(()=>{const p=curP(),m=curM(p);const ws=mechWeapons(p,m);const cn=ws.find(x=>x.w.swFus);
   const clean=cleanMech(JSON.parse(JSON.stringify(m)));
   pcOpenWeapon(p,cn.uid);const mods=M.mods.map(z=>z.label);const ok=tagVal(M.w?M.w.tags:cn.w.tags,'tg_overkill');M=null;renderModal();
   pcOpenCheck(p,'hull');const ck=M.mods.map(z=>z.label);M=null;renderModal();
   const notes=[...document.querySelectorAll('#main .cbn, #main .wcbn, #main [class*=cbnote]')].map(e=>e.textContent).slice(0,6);
   return {sel:m.swFus,types:ws.map(x=>x.w.name+'/'+x.w.type+(x.w.swFus?'(было '+x.w.swFus+')':'')),overkill:!!ok,clean:clean.swFus,mods:mods.filter(l=>/Захват|Темпесте|Прицел/.test(l)),ck:ck.filter(l=>/Строев/.test(l)),notes}}));
 await pg.screenshot({path:SP+'t31_mech.png'});
 await pg.evaluate(()=>{PS.tab='combat';pcRender()});await pg.screenshot({path:SP+'t31_combat.png'});
 L('combat',await pg.evaluate(()=>[...document.querySelectorAll('#main .isys .row')].map(e=>e.innerText.replace(/\s+/g,' ').slice(0,140)).slice(0,4)));
 // Гекатонхейр
 L('hec',await pg.evaluate(()=>{const p=curP();p.lic={mf_balor:2};const m=curM(p);m.frame='mf_balor_alt_hecatoncheires';m.load={};m.swFus=[];m.systems=['ms_entangled_co-consciousness_rig','ms_champions_favor'];
   const sm=PCD.weapons.find(w=>(w.tags||[]).some(t=>t[0]==='tg_smart')&&w.mount==='Main'&&!w.book);const mn=mechMounts(p,m).find(x=>x.type==='Main');m.load[mn.key]=[sm.id];
   const x=mechWeapons(p,m)[0];pcOpenWeapon(p,x.uid);const mods=M.mods.filter(z=>z.info).map(z=>z.label);M=null;renderModal();
   return {ok:frameOk(p,P.F[m.frame]),w:sm.name,mods,W:buildWarnings(p,m)}}));
 // предыстории и связь
 await pg.evaluate(()=>{PS.tab='pilot';pcRender()});
 L('bg',await pg.evaluate(()=>({groups:[...document.querySelectorAll('[data-p7="bgid"] optgroup')].map(o=>o.label+':'+o.children.length),n:document.querySelectorAll('[data-p7="bgid"] option').length})));
 await pg.selectOption('[data-p7="bgid"]','pbg_noble_heir').catch(e=>L('bgsel err',e.message.slice(0,80)));
 L('bg2',await pg.evaluate(()=>({id:curP().bgId,txt:(document.querySelector('.bgd summary')||{}).innerText})));
 await pg.click('[data-pa="ptab"][data-v="bond"]');
 L('bond',await pg.evaluate(()=>[...document.querySelectorAll('[data-pf2="bond"] optgroup')].map(o=>o.label+':'+o.children.length)));
 await pg.selectOption('[data-pf2="bond"]','sotw-bond-firebrand');await pg.waitForTimeout(150);
 L('bond2',await pg.evaluate(()=>({mark:[...document.querySelectorAll('.bd-sel .srcmark')].map(e=>e.textContent+'['+(e.dataset.bk||'')+']'),pw:document.querySelectorAll('[data-pa="bpw"]').length,q:document.querySelectorAll('[data-pf2="ansel"]').length})));
 await pg.screenshot({path:SP+'t31_bond.png'});
 // лицензии: варианты
 await pg.evaluate(()=>{PS.tab='pilot';const p=curP();p.lic={mf_lancaster:2,mf_sherman:2,mf_balor:2};PS.open['lic-mf_lancaster']=true;PS.open['lic-mf_sherman']=true;pcRender()});
 L('lic',await pg.evaluate(()=>[...document.querySelectorAll('.lic-var .lic-txt small')].map(e=>e.textContent).filter(t=>/Ланкастер|Шерман|Балор/i.test(t))));
 const vb=await pg.$('[data-v="mf_lancaster_alt_taraxacum"]');if(vb){await vb.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t31_lic.png'})}
 L('gear',await pg.evaluate(()=>PCD.gear.filter(g=>g.book==='SW').map(g=>g.name+(g.exo?'*':''))));
 await pg.setViewportSize({width:390,height:844});
 for(const v of ['ref','gm']){await pg.click(`[data-act="view"][data-v="${v}"]`);L('hs '+v,await pg.evaluate(()=>document.documentElement.scrollWidth))}
 await pg.click('[data-act="view"][data-v="pc"]');await pg.evaluate(()=>{PS.tab='bond';pcRender()});L('hs bond',await pg.evaluate(()=>document.documentElement.scrollWidth));
 await pg.evaluate(()=>{PS.tab='mech';const p=curP(),m=curM(p);m.frame='mf_sherman_alt_tagetes';pcRender()});L('hs mech',await pg.evaluate(()=>document.documentElement.scrollWidth));
 L('ERRS',errs);await b.close()})();
