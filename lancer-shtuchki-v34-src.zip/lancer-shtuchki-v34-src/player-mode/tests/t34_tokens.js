const {chromium}=require('/opt/npm-tools/node_modules/playwright');const fs=require('fs');
const F=process.argv[2]||require('path').resolve('lancer-shtuchki-v34.html');const SP='';
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1400,height:900}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text().slice(0,200))});
 await pg.goto('file://'+F);await pg.screenshot({path:SP+'t34_gate.png'});
 console.log('title',await pg.title(),'| gate',await pg.evaluate(()=>document.querySelector('.rg-logo').innerText));
 await pg.click('[data-role="gm"]');console.log('logo',await pg.evaluate(()=>document.querySelector('.logo').innerText));
 await pg.click('[data-act="view"][data-v="tok"]');await pg.waitForTimeout(300);
 const buf=fs.readFileSync('/root/.claude/uploads/d0819c7c-129e-5c04-9991-5764081b769c/7b7424b7-image.jpg');
 const png=fs.readFileSync('/root/.claude/uploads/d0819c7c-129e-5c04-9991-5764081b769c/c4a85cad-image.png');
 for(const [name,mime,bb] of [['a.jpg','image/jpeg',buf],['a.jfif','',buf],['a.jpg','application/octet-stream',buf],['noext','',png],['a.heic','image/heic',Buffer.from('not an image')],['big.jpg','image/jpeg',buf]]){
   await pg.evaluate(()=>{document.getElementById('tk_imgName').textContent='-';document.getElementById('tk_toast').textContent=''});
   await pg.setInputFiles('#tk_file',{name,mimeType:mime,buffer:bb});await pg.waitForTimeout(500);
   console.log(name,mime||'(empty)','→',await pg.evaluate(()=>[document.getElementById('tk_imgName').textContent,document.getElementById('tk_toast').textContent]))}
 console.log('accept',await pg.getAttribute('#tk_file','accept'));
 // вставка файла без типа и перетаскивание ссылки
 const r=await pg.evaluate(async b64=>{const bin=Uint8Array.from(atob(b64),c=>c.charCodeAt(0));const f=new File([bin],'x.jfif',{type:''});
   document.getElementById('tk_imgName').textContent='-';const dt=new DataTransfer();dt.items.add(f);window.dispatchEvent(new ClipboardEvent('paste',{clipboardData:dt}));
   await new Promise(r=>setTimeout(r,500));const a=document.getElementById('tk_imgName').textContent;
   const d2=new DataTransfer();d2.setData('text/uri-list','https://example.com/a.jpg');window.dispatchEvent(new DragEvent('drop',{dataTransfer:d2,cancelable:true}));
   return [a,document.getElementById('tk_toast').textContent]},buf.toString('base64'));
 console.log('paste/drop',r);
 await pg.screenshot({path:SP+'t34_tok.png'});
 await pg.setViewportSize({width:390,height:844});await pg.waitForTimeout(200);console.log('hs',await pg.evaluate(()=>document.documentElement.scrollWidth));await pg.screenshot({path:SP+'t34_mob.png'});
 await pg.evaluate(()=>{localStorage.clear()});await pg.reload();await pg.waitForTimeout(200);console.log('hs gate',await pg.evaluate(()=>document.documentElement.scrollWidth));await pg.screenshot({path:SP+'t34_gatemob.png',fullPage:true});
 console.log(errs);await b.close()})();
