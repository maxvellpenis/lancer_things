// Импорт: пилот (в т.ч. связь, Фузилёр, АДЪЮТАНТ, резервы), Comp/Con, флот, библиотека НИП — все строки отравлены.
const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const F=process.argv[2]||'/home/claude/ulan-terminal-v33.html';
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1400,height:900}});const errs=[];pg.on('pageerror',e=>errs.push(e.message.slice(0,150)));pg.on('dialog',d=>{errs.push('DIALOG');d.dismiss()});
 await pg.goto('file://'+F);await pg.click('[data-role="gm"]');await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 const out=await pg.evaluate(()=>{const mk=t=>`"'><img src=x data-t="${t}"><svg onload=alert(1)>`;const found=new Set();const scan=w=>document.querySelectorAll('img[src="x"],svg[onload],[data-t]').forEach(i=>found.add(w+':'+(i.dataset.t||i.tagName)));
   const p0=curP();p0.lic={mf_sherman:2};const m0=curM(p0);m0.frame='mf_sherman_alt_tagetes';m0.load={};m0.swFus=['f2#0'];m0.systems=['ms_adjutant_class_compcon'];m0.adjT='t_ace';
   p0.bond={id:'sotw-bond-firebrand',xp:2,stress:1,ans:['a','b'],powers:['sotw-bond-firebrand#0'],other:['ktb-bond-wolf#1'],clocks:[{n:'clock',s:6,v:2}],burdens:[{n:'Рука',s:4,f:1}],major:[0],minor:0,notes:'n'};
   p0.reserves=[{id:'custom',name:'R',note:'x'},{id:'reserve_ammo',item:'mw_assault_rifle',n:2},{id:'reserve_accuracy',skill:'hull'}];p0.bgId='pbg_noble_heir';
   const p=JSON.parse(JSON.stringify(p0));
   const poison=(o,path)=>{if(Array.isArray(o)){o.forEach((v,i)=>{if(typeof v==='string')o[i]=v+mk(path+'['+i+']');else if(v&&typeof v==='object')poison(v,path+'['+i+']')});return}for(const k of Object.keys(o)){const v=o[k];if(typeof v==='string')o[k]=v+mk(path+'.'+k);else if(v&&typeof v==='object')poison(v,path+'.'+k)}};
   poison(p,'p');p.bond.xp='9'+mk('xp');p.bond.clocks.push({n:mk('c2'),s:mk('s'),v:1e9});p.mechs[0].adjT=mk('adj');p.mechs[0].swFus=[mk('fus'),'f2#0'];
   const r1=pcImportText(JSON.stringify(p));
   for(const t of ['pilot','mech','combat','bond']){PS.tab=t;try{pcRender()}catch(e){found.add('crash:'+t+':'+e.message)}scan('pilot-'+t)}
   const q=PS.pilots[PS.pilots.length-1];const info={bondId:q.bond&&q.bond.id,clocks:q.bond&&q.bond.clocks.length,xp:q.bond&&q.bond.xp,adjT:q.mechs[0].adjT,swFus:q.mechs[0].swFus};
   // Comp/Con
   let cc=null;try{cc=ccConvert({name:'T'+mk('cc.name'),callsign:'C'+mk('cc.cs'),level:3,skills:[{id:'sk_'+mk('x'),rank:1}],talents:[{id:'t_ace',rank:1}],mechSkills:[0,0,0,0],licenses:[],mechs:[{name:'M'+mk('m'),frame:'mf_chomolungma',loadouts:[{systems:[{id:'ms_adjutant_class_compcon'}],mounts:[]}]}],bondId:'sotw-bond-knave'+mk('b'),xp:3,stress:2,bondPowers:[{name:mk('bp')}],burdens:[{title:mk('bur'),segments:4,progress:1}],clocks:[{title:mk('clk'),segments:6,progress:1}],bondAnswers:[mk('ans')]})}catch(e){found.add('cc-crash:'+e.message)}
   if(cc){PS.pilots.push(cleanPilot(cc,false));PS.sel=PS.pilots[PS.pilots.length-1].id;for(const t of ['pilot','mech','combat','bond']){PS.tab=t;try{pcRender()}catch(e){found.add('crash cc:'+t)}scan('cc-'+t)}}
   // флот
   const g=bgClean({name:'G'+mk('g'),notes:mk('n'),ships:[{hull:'ebro',name:'S'+mk('s'),eq:{wing:['chassis'+mk('w'),'fighter']},ace:[mk('a')]},{hull:mk('h')}]});BGS.groups.push(g);BGS.cur=g.id;S.view='fleet';
   for(const t of ['build','battle','cat']){BGS.tab=t;try{render()}catch(e){found.add('crash fleet')}scan('fleet-'+t)}
   return {found:[...found],info,r1:String(r1).slice(0,80)}});
 console.log(JSON.stringify(out));console.log('ERRS',errs);await b.close()})();
