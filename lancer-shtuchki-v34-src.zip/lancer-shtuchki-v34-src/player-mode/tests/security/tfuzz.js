// Отравление всех сохранённых данных браузера: XSS-строки во всех полях и мусорные типы. После перезагрузки обходим все экраны.
const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const F=process.argv[2]||'/home/claude/ulan-terminal-v32.html';
(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:1400,height:900}});const pg=await ctx.newPage();
 const errs=[];pg.on('pageerror',e=>errs.push(e.message.slice(0,160)));pg.on('dialog',d=>{errs.push('DIALOG '+d.message());d.dismiss()});
 await pg.goto('file://'+F);await pg.click('[data-role="gm"]');
 // наполнить состояние
 await pg.evaluate(()=>{S.enc=[];S.cls=BUILTIN[0].id;S.sel[S.cls]=[];addToEnc();S.custom.push({id:'cx',name:'Cx',role:'r',tiers:[[1,2,3,4,5,6,7,8,9,10,11,12,13]],base:[],optional:[]});render()});
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 await pg.evaluate(()=>{const p=curP();p.lic={mf_sherman:2};const m=curM(p);m.frame='mf_sherman_alt_tagetes';m.swFus=['f2#0'];m.systems=['ms_adjutant_class_compcon'];m.adjT='t_ace';
   p.bond={id:'sotw-bond-firebrand',xp:2,stress:1,ans:['a','b'],powers:['sotw-bond-firebrand#0'],clocks:[{n:'clock',s:6,v:2}],burdens:[{n:'Рука',s:4,f:1}],major:[0],minor:0,notes:'n'};
   p.reserves=[{id:'custom',name:'R',note:'x'},{id:'reserve_up_armoring'}];p.bgId='pbg_noble_heir';pcRender()});
 await pg.click('[data-act="view"][data-v="fleet"]');await pg.click('[data-bg="gnew"]');
 await pg.evaluate(()=>{const g=BGS.groups[0];g.name='G';g.notes='nn';bgNewShip(g,'ebro');g.ships[0].name='S';bgRender()});
 await pg.click('[data-act="view"][data-v="gm"]');await pg.evaluate(()=>{gmRoll(GMT[0].id);LS.set('fold',{x:true});LS.set('wf_eid',[{id:'e1',name:'E'}]);LS.set('wf_enc_sel',{enc:'a',pcs:3});LS.set('dg_rel',{a:1})});
 await pg.click('[data-act="view"][data-v="tok"]');await pg.waitForTimeout(300);
 await pg.evaluate(()=>localStorage.setItem('lancer-hex-tokens',JSON.stringify({size:'2',orient:'flat',frameColor:'#fff',res:280,cells:30,labelPos:'bottom',fit:'roll20'})));
 const base=await pg.evaluate(()=>{const o={};for(const k of Object.keys(localStorage))o[k]=localStorage.getItem(k);return o});
 const XS=t=>`"'><img src=x data-t="${t}"><svg onload=alert(1)>`;
 const poisonStr=raw=>{let v;try{v=JSON.parse(raw)}catch(e){return JSON.stringify(XS('raw'))}
   const walk=(o,p)=>{if(typeof o==='string')return o+XS(p);if(Array.isArray(o))return o.map((x,i)=>walk(x,p+'['+i+']'));
     if(o&&typeof o==='object'){const r={};for(const k of Object.keys(o))r[k]=walk(o[k],p+'.'+k);r['__proto__x'+XS('key')]=1;return r}return o};
   return JSON.stringify(walk(v,''))};
 const GARB=['null','"<img src=x data-t=garb>"','{"a":{"b":1}}','[1,"<img src=x data-t=arr>",null,{}]','1e308','-1','true',JSON.stringify('x'.repeat(200000)),'{"__proto__":{"polluted":1}}','not json{'];
 const views=async()=>{const out={inj:0,bad:[],t:0};const t0=Date.now();
   const go=async(fn)=>{try{await pg.evaluate(fn)}catch(e){out.bad.push(String(e.message).slice(0,120))}};
   for(const v of ['lib','enc','pc','fleet','ref','gm','tok']){await go(`(()=>{const b=document.querySelector('[data-act="view"][data-v="${v}"]');if(b)b.click()})()`);
     if(v==='pc')for(const t of ['pilot','mech','combat','bond'])await go(`(()=>{try{PS.tab='${t}';pcRender()}catch(e){throw e}})()`);
     if(v==='fleet')for(const t of ['build','battle','cat'])await go(`(()=>{BGS.tab='${t}';bgRender()})()`);
     const f=await pg.evaluate(()=>[...document.querySelectorAll('img[src="x"],svg[onload],[data-t]')].map(e=>e.tagName+':'+(e.dataset.t||'')+'@'+((e.closest('[id]')||{}).id||'')));out.inj+=f.length;(out.where=out.where||[]).push(...f.map(x=>v+'|'+x))}
   out.t=Date.now()-t0;out.polluted=await pg.evaluate(()=>({}).polluted===1);out.main=await pg.evaluate(()=>(document.getElementById('main')||{innerText:''}).innerText.length>20);return out};
 const res=[];
 const run=async(label,set)=>{await pg.evaluate(o=>{localStorage.clear();for(const [k,v] of Object.entries(o))try{localStorage.setItem(k,v)}catch(e){}},set);
   errs.length=0;await pg.reload();await pg.waitForTimeout(150);const g=await pg.$('[data-role="gm"]');if(g)await g.click().catch(()=>{});
   const r=await views();if(r.inj||r.bad.length||errs.length||r.polluted||!r.main||r.t>20000)res.push({label,...r,errs:[...new Set(errs)].slice(0,4)})};
 // 1) все ключи сразу — XSS во всех строках
 const all={};for(const [k,v] of Object.entries(base))all[k]=poisonStr(v);await run('ALL-xss',all);
 if(process.env.ONLY)return console.log(JSON.stringify(res,null,0).slice(0,6000)),b.close();
 // 2) по одному ключу — мусор
 for(const k of Object.keys(base))for(const gv of GARB){const s={...base};s[k]=gv;await run(k+' = '+gv.slice(0,20),s)}
 // 3) токены: числа вне пределов
 for(const t of [{res:1e9},{cells:1e7},{size:'<img src=x data-t=tsz>'},{frameW:-50},{res:'abc'},{calibV2:1e9},{vignette:1e9},{accentW:1e6}]){const s={...base};s['lancer-hex-tokens']=JSON.stringify({...JSON.parse(base['lancer-hex-tokens']),...t});await run('tok '+JSON.stringify(t),s)}
 console.log('cases with problems:',res.length);for(const r of res)console.log(JSON.stringify(r).slice(0,600));
 await b.close()})();
