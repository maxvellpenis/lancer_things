const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:900}});pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file:///home/claude/lancer-npc-v24.html');await pg.click('[data-role="gm"]');
 const ids=await pg.evaluate(()=>WFENC.map(e=>e.id));let tot=0;
 for(const id of ids){await pg.evaluate(id=>{WFE.enc=id;WFE.pcs=5;S.view='gm';render()},id);const n=await pg.$$eval('[data-wf="eadd"]',x=>x.length);for(let i=0;i<n;i++)await pg.click(`[data-wf="eadd"][data-v="${i}"]`)}
 console.log('enc total',await pg.evaluate(()=>S.enc.length));
 await pg.click('[data-act="view"][data-v="enc"]');await pg.waitForTimeout(300);await pg.screenshot({path:'v24_battle.png'});
 // каждый НИП: бросить первую атаку оружием, если есть кнопка
 const r=await pg.evaluate(()=>{let ok=0;for(const i of S.enc.slice(0,60)){try{const c=cls(i.cls);stOf(i);instSystems(i);ok++}catch(e){return 'ERR '+i.label+' '+e.message}}return ok});console.log('inst ok',r);
 console.log('ERRS',JSON.stringify(errs.slice(0,5)));await b.close()})();
