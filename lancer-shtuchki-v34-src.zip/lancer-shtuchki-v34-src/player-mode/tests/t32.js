const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const SP='';
const F=process.argv[2]||require('path').resolve('ulan-terminal-v32.html');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:950}});pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text().slice(0,200))});
 await pg.goto('file://'+F);await pg.click('[data-role="gm"]');
 const L=(...a)=>console.log(...a.map(x=>typeof x==='string'?x:JSON.stringify(x)));
 // ГМ
 await pg.click('[data-act="view"][data-v="gm"]');await pg.waitForTimeout(200);
 L('gm',await pg.evaluate(()=>{const t=GMT.find(t=>t.id==='sr_reserves');const ks=new Set();for(let i=0;i<400;i++){gmRoll('sr_reserves',true);ks.add(GMS.sr_reserves)}
   return {rows:t&&t.rows.length,ks:[...ks].sort((a,b)=>a-b),order:[...new Set(GMT.map(t=>t.book||'core'))],side:[...document.querySelectorAll('#side .side-sub')].map(e=>e.textContent+':'+(e.dataset.bk||'')).slice(-3)}}));
 const g=await pg.$('#gm-dlc-SR');if(g){await g.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t32_gm.png'})}else L('NO gm-dlc-SR');
 // Справочник
 await pg.click('[data-act="view"][data-v="ref"]');await pg.waitForTimeout(200);
 L('ref',await pg.evaluate(()=>({sr:(REF.find(s=>s.id==='sr')||{items:[]}).items.map(x=>x.t),hd:[...document.querySelectorAll('.dlc-hd')].map(e=>e.innerText.split('\n')[0]+'['+(e.dataset.bk||'')+']').slice(-3)})));
 const r=await pg.$('#ref-sr');if(r){await r.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t32_ref.png'})}
 // Флот
 await pg.click('[data-act="view"][data-v="fleet"]');await pg.click('[data-bg="gnew"]');
 const eb=await pg.$('[data-bg="shipaddh"][data-v="ebro"]');L('ebro btn',!!eb);if(eb)await eb.click();
 L('fleet',await pg.evaluate(()=>{const g=BGS.groups[0];g.ships[0].eq={wing:['chassis','fighter']};bgRender();
   const card=bgHullCard(BH.ebro);return {cost:bgCost(g),warn:bgWarn(g),src:(card.match(/<span class="srcmark"[^>]*>[^<]*<\/span>/)||[''])[0].replace(/<[^>]+>/g,''),img:/<img|background/.test(card),
   scr:bgStdActs({uid:'x',c:{},lim:{},ships:[{hull:'ebro',dead:false}]}).includes('Оборонительный заслон')}}));
 await pg.evaluate(()=>{BGS.tab='cat';BGS.cat='hulls';bgRender()});const ec=await pg.$('text=Эбро');if(ec){await ec.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t32_fleet.png'})}
 // Игроки: Чомолунгма
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 L('cho',await pg.evaluate(()=>{const p=curP();p.ll=0;p.lic={};const m=curM(p);m.frame='mf_chomolungma';const st=mechStats(p,m);
   PS.tab='combat';pcRender();const rest=[...document.querySelectorAll('[data-pa="rrep"][data-v="struct"]')].map(e=>e.textContent);
   pcOpenTech(p,'Вторжение',{invade:1});const inv=M.mods.filter(x=>x.info).map(x=>x.label.slice(0,60));M=null;renderModal();
   return {ok:frameOk(p,P.F[m.frame]),W:buildWarnings(p,m),st:{hp:st.hp,ev:st.evasion,ed:st.edef,sens:st.sensor_range||st.sensors,tech:st.tech,sp:st.sp},cheap:st.cheapStruct,rest,inv}}));
 await pg.screenshot({path:SP+'t32_combat.png'});
 // экзотика
 L('exo',await pg.evaluate(()=>{const p=curP();p.ll=2;p.talents={};const m=curM(p);m.frame='mf_standard_pattern_i_everest';const ms=mechMounts(p,m).filter(x=>!x.fixed);m.load={};
   const mn=ms.filter(x=>x.type==='Main'||x.type==='Flex'||x.type==='Main/Aux');m.load[mn[0].key]=['mw_xc_br_battle_rifle'];m.load[mn[1].key]=['mw_xc_dpm_predator_nexus'];
   m.systems=['ms_adjutant_class_compcon','ms_pattern_c_advanced_charges'];
   const ws=mechWeapons(p,m);const br=ws.find(x=>x.w.id==='mw_xc_br_battle_rifle'),pr=ws.find(x=>x.w.id==='mw_xc_dpm_predator_nexus');
   pcOpenWeapon(p,pr.uid);const prm=M.mods.map(x=>x.label).filter(l=>/Невид|Хищник/.test(l));M=null;
   pcOpenWeapon(p,br.uid);const brm=M.mods.filter(x=>x.info).map(x=>x.label).filter(l=>/XC/.test(l));M=null;renderModal();
   const notes=wCbNotes(p,m,br).map(n=>n.txt);
   // АДЪЮТАНТ: Ас II
   const b0=JSON.stringify(budgets(p));pcOpenCheck(p,'agi');const ag0=M.mods.map(x=>x.label).filter(l=>/Ас/.test(l));M=null;
   m.adjT='t_ace';const st1=mechStats(p,m);pcOpenCheck(p,'agi');const ag1=M.mods.map(x=>x.label).filter(l=>/Ас/.test(l));M=null;renderModal();
   const b1=JSON.stringify(budgets(p));const tal=JSON.stringify(p.talents);const cl=cleanMech(JSON.parse(JSON.stringify(m))).adjT,cl2=cleanMech({...JSON.parse(JSON.stringify(m)),adjT:'evil<x>'}).adjT;
   PS.tab='mech';pcRender();
   return {prm,brm,notes,W:buildWarnings(p,m),ag0,ag1,sameBudget:b0===b1,tal,cl,cl2,sel:document.querySelectorAll('[data-sradj] option').length}}));
 const sa=await pg.$('[data-sradj]');if(sa){await sa.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t32_mech.png'});await pg.selectOption('[data-sradj]','t_sysop');L('adjsel',await pg.evaluate(()=>curM(curP()).adjT))}
 // резервы
 L('res',await pg.evaluate(()=>{const p=curP(),m=curM(p);m.systems=[];const a0=mechStats(p,m).armor;
   p.reserves=[{id:'reserve_up_armoring'},{id:'reserve_personal_touch'},{id:'reserve_hot_load_ammunition'}];const a1=mechStats(p,m).armor;
   pcOpenCheck(p,'hull');const ck=M.mods.map(x=>x.label).filter(l=>/Личный/.test(l));M=null;
   const x=mechWeapons(p,m)[0];pcOpenWeapon(p,x.uid);const hl=M.mods.map(x=>x.label).filter(l=>/Форсир/.test(l));M=null;renderModal();
   p.reserves[0].used=true;const a2=mechStats(p,m).armor;
   const sr=PCD.reserves.filter(r=>r.book==='SR').map(r=>r.name);return {a0,a1,a2,ck,hl,sr}}));
 await pg.evaluate(()=>{PS.tab='pilot';pcRender()});
 L('tal',await pg.evaluate(()=>[...document.querySelectorAll('.tl-book')].map(e=>e.innerText.split('\n')[0]+'['+(e.dataset.bk||'')+']').slice(-2)));
 const t=[...await pg.$$('.tl-book')].pop();if(t){await t.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t32_pilot.png'})}
 L('lic',await pg.evaluate(()=>{PS.tab='pilot';pcRender();return [...document.querySelectorAll('.lic-src,.srcmark')].map(e=>e.textContent).filter(t=>/Solstice/.test(t)).slice(0,4)}));
 await pg.setViewportSize({width:390,height:844});
 for(const v of ['ref','gm','fleet']){await pg.click(`[data-act="view"][data-v="${v}"]`);L('hs '+v,await pg.evaluate(()=>document.documentElement.scrollWidth))}
 await pg.click('[data-act="view"][data-v="pc"]');await pg.evaluate(()=>{PS.tab='mech';pcRender()});L('hs mech',await pg.evaluate(()=>document.documentElement.scrollWidth));
 L('ERRS',errs);await b.close()})();
