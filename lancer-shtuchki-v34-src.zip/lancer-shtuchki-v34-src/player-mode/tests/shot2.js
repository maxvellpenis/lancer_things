const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{
 const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1500,height:1000}});
 const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('dialog',d=>d.accept());
 await pg.goto('file:///home/claude/lancer-npc-v11.html');
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 await pg.evaluate(()=>{const p=curP();p.ll=6;p.lic={mf_drake:3,mf_lancaster:1};p.cbs=['cb_mount_retrofitting'];const m=curM(p);m.frame='mf_drake';
   m.load={f0:['mw_assault_cannon','mw_pistol'],f2:['mw_leviathan_heavy_assault_cannon']};m.sh={f2:'f1'};m.mods={'f0#0':'wm_thermal_charge'};m.systems=['ms_portable_bunker','ms_aegis_shield_generator'];PS.tab='mech';render()});
 const el=await pg.$('.mounts');await el.scrollIntoViewIfNeeded();
 await pg.screenshot({path:'s_mech2.png'});
 await pg.evaluate(()=>{document.querySelector('h2:nth-of-type(2)').scrollIntoView()});await pg.screenshot({path:'s_core.png'});
 await pg.evaluate(()=>{PS.tab='combat';render();document.querySelector('#main').scrollTop=900});await pg.screenshot({path:'s_combat2.png'});
 console.log(errs);await b.close();})();
