const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const SP='/tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad/';const fs=require('fs');
(async()=>{const b=await chromium.launch();const errs=[];const ctx=await b.newContext({viewport:{width:1400,height:950},acceptDownloads:true});const pg=await ctx.newPage();
 pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text().slice(0,200))});
 await pg.goto('file:///home/claude/ulan-terminal-v30.html');await pg.click('[data-role="gm"]');
 const L=(...a)=>console.log(...a.map(x=>typeof x==='string'?x:JSON.stringify(x)));
 L('tabs',await pg.$$eval('#tabs .tab',x=>x.map(e=>e.textContent.trim())));
 await pg.click('[data-act="view"][data-v="tok"]');await pg.waitForTimeout(400);
 L('tok',await pg.evaluate(()=>({root:!!document.querySelector('#main .tkapp'),badge:document.querySelectorAll('[id*="badge"]').length,arts:document.querySelectorAll('#tk_artPick option').length,side:document.querySelectorAll('#side [data-tok]').length,
   stage:(()=>{const c=document.getElementById('tk_stage');return c.width+'x'+c.height})(),stats:document.getElementById('tk_stats').innerText.replace(/\s+/g,' ')})));
 await pg.screenshot({path:SP+'t30_tok.png'});
 const save=async(btn)=>{const [d]=await Promise.all([pg.waitForEvent('download',{timeout:8000}),pg.click(btn)]);const p=SP+'dl_'+d.suggestedFilename();await d.saveAs(p);return p};
 const dims=p=>{const b=fs.readFileSync(p);return b.readUInt32BE(16)+'x'+b.readUInt32BE(20)};
 // размеры 1 и ½: Roll20 == Foundry
 const res={};
 for(const sz of ['half','1','2']){for(const fit of ['roll20','tight']){
   await pg.click(`#tk_sizeSeg button[data-v="${sz}"]`);await pg.selectOption('#tk_fit',fit);await pg.waitForTimeout(100);
   const p=await save('#tk_btnPng');res[sz+'/'+fit]=dims(p)+' '+p.split('dl_')[1]}}
 L('dims',res);
 // арт из программы
 await pg.click('#side [data-tok^="f:"]');await pg.waitForTimeout(500);
 L('after art',await pg.evaluate(()=>({name:document.getElementById('tk_imgName').textContent,label:document.getElementById('tk_label').value,size:[...document.querySelectorAll('#tk_sizeSeg button.on')].map(b=>b.dataset.v)})));
 await pg.screenshot({path:SP+'t30_art.png'});
 const zp=await save('#tk_btnZip');L('zip',zp.split('dl_')[1],fs.statSync(zp).size);
 // NPC кнопка
 await pg.click('[data-act="view"][data-v="lib"]');await pg.evaluate(()=>{S.cls='ss_tempest';S.tier=3;render()});await pg.click('[data-tokgo="npc"]');await pg.waitForTimeout(300);
 L('npc→tok',await pg.evaluate(()=>({view:S.view,label:document.getElementById('tk_label').value,size:[...document.querySelectorAll('#tk_sizeSeg button.on')].map(b=>b.dataset.v),preset:[...document.querySelectorAll('#tk_presets .on')].map(b=>b.textContent)})));
 // мех
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');await pg.evaluate(()=>{const p=curP();p.callsign='Пила';curM(p).frame='mf_kutuzov';PS.tab='mech';pcRender()});
 await pg.click('[data-tokgo="mech"]');await pg.waitForTimeout(500);
 L('mech→tok',await pg.evaluate(()=>({view:S.view,label:document.getElementById('tk_label').value,name:document.getElementById('tk_imgName').textContent,size:[...document.querySelectorAll('#tk_sizeSeg button.on')].map(b=>b.dataset.v)})));
 await pg.screenshot({path:SP+'t30_mech.png'});
 // перерисовка при смене вкладок туда-обратно сохраняет состояние
 await pg.click('[data-act="view"][data-v="ref"]');await pg.click('[data-act="view"][data-v="tok"]');await pg.waitForTimeout(300);
 L('back',await pg.evaluate(()=>({label:document.getElementById('tk_label').value,stage:document.getElementById('tk_stage').width})));
 // игрок
 await pg.evaluate(()=>{localStorage.clear()});await pg.reload();await pg.click('[data-role="player"]').catch(()=>{});await pg.waitForTimeout(200);
 L('player tabs',await pg.$$eval('#tabs .tab',x=>x.map(e=>e.textContent.trim())));
 await pg.click('[data-act="view"][data-v="tok"]');await pg.waitForTimeout(300);L('player tok',await pg.evaluate(()=>({view:S.view,root:!!document.querySelector('#main .tkapp')})));
 await pg.setViewportSize({width:390,height:844});await pg.waitForTimeout(300);L('hs',await pg.evaluate(()=>document.documentElement.scrollWidth));await pg.screenshot({path:SP+'t30_mob.png',fullPage:false});
 L('ERRS',errs);await b.close()})();
