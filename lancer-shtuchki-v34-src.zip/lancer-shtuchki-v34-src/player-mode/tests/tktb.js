const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:900}});pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text().slice(0,200))});
 await pg.goto('file:///home/claude/lancer-npc-v23.html');await pg.click('[data-role="gm"]');await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 const r=await pg.evaluate(()=>{const p=curP();p.ll=6;p.lic={mf_black_witch:2,mf_minotaur:1,mf_emperor:2};
   const ok=['mf_black_witch_alt_orchidea','mf_minotaur_alt_wraith','mf_emperor','mf_white_witch'].map(id=>id+':'+frameOk(p,P.F[id]));
   const m=curM(p);m.frame='mf_emperor';const st=mechStats(p,m);const hp=st.hp,why=st.why.hp;m.frame='mf_standard_pattern_i_everest';const ev=mechStats(p,m).hp;m.frame='mf_emperor';
   p.cb=p.cb||null;pcRender();return{ok,hp,why,ev,bonds:PCD.bonds.bonds.length,ref:REF.map(s=>s.id).join(','),gm:GMT.filter(t=>t.book==='KTB').length,lr:licRanksOf?1:0}});
 console.log(JSON.stringify(r));
 // таланты
 await pg.click('[data-pa="ptab"][data-v="pilot"]');console.log('tl-book',await pg.$$eval('.tl-book',x=>x.map(y=>y.textContent.trim())));
 const tal=await pg.$('.tl-book.dlc');if(tal){await tal.scrollIntoViewIfNeeded();await pg.screenshot({path:'v23_tal.png'})}
 // лицензии: вариант
 await pg.click('[data-pa="licopen"][data-v="mf_black_witch"]');await pg.waitForTimeout(100);await pg.screenshot({path:'v23_lic.png'});
 console.log('lic variant btn',await pg.$$eval('#main *',x=>x.filter(e=>e.children.length===0&&/Вариант рамы/.test(e.textContent)).map(e=>e.textContent.trim()).slice(0,4)));
 // мех: фрейм опции
 await pg.click('[data-pa="ptab"][data-v="mech"]');console.log('frame opts',await pg.$$eval('option',x=>x.filter(o=>/вариант|Император|Ведьма/.test(o.textContent)).map(o=>o.textContent.trim())));
 await pg.screenshot({path:'v23_mech.png'});
 // связь
 await pg.click('[data-pa="ptab"][data-v="bond"]');await pg.screenshot({path:'v23_bond0.png'});
 await pg.selectOption('[data-pf2="bond"]','ktb-bond-titan');
 await pg.click('[data-pa="bpw"][data-v="ktb-bond-titan#0"]');await pg.click('[data-pa="bpw"][data-v="ktb-bond-titan#1"]');
 console.log('vet unlocked',await pg.$eval('[data-pa="bpw"][data-v="ktb-bond-titan#vet"]',e=>!e.disabled),'master locked',await pg.$eval('[data-pa="bpw"][data-v="ktb-bond-titan#master"]',e=>e.disabled));
 await pg.fill('[data-pf2="burn"][data-i="0"]','Сломанная рука');await pg.press('[data-pf2="burn"][data-i="0"]','Tab');
 for(const v of ['4','4','2'])await pg.click(`[data-pa="bstr"][data-v="${v}"]`);
 console.log('after break',await pg.evaluate(()=>JSON.stringify({s:curP().bond.stress,max:bondMax(curP())})));
 await pg.check('[data-pf2="maj"][data-i="0"]');await pg.selectOption('[data-pf2="minor"]','1');await pg.check('[data-pf2="mind"]');await pg.check('[data-pf2="inv"]');
 await pg.click('[data-pa="bsess"]');console.log('xp',await pg.evaluate(()=>curP().bond.xp));
 await pg.click('[data-pa="bheal"][data-v="0"]');console.log('burden',await pg.evaluate(()=>JSON.stringify(curP().bond.burdens[0])));
 await pg.click('[data-pa="bcnew"]');await pg.fill('[data-pf2="cn"][data-i="0"]','Переговоры с домом');await pg.press('[data-pf2="cn"][data-i="0"]','Tab');await pg.click('[data-pa="bcadd"][data-v="0"][data-d="2"]');
 console.log('clock',await pg.evaluate(()=>JSON.stringify(curP().bond.clocks)));
 await pg.screenshot({path:'v23_bond.png',fullPage:true});
 // санитайзер
 const s=await pg.evaluate(()=>{const raw=JSON.parse(JSON.stringify(curP()));raw.bond={id:'<img src=x>',xp:999,stress:'a',pw:['x#1','ktb-bond-titan#0','__proto__'],uses:{'__proto__':5,'ktb-bond-titan#0':99},ans:['<img src=x onerror=alert(1)>'.repeat(100)],burdens:[{n:'<b>x</b>',f:999}],clocks:[{n:'c',s:7,f:99}],evil:1};const c=cleanPilot(raw);return JSON.stringify({id:c.bond.id,xp:c.bond.xp,st:c.bond.stress,pw:c.bond.pw,u:c.bond.uses,al:c.bond.ans[0].length,b:c.bond.burdens[0],cl:c.bond.clocks,evil:c.bond.evil})});console.log('clean',s);
 await pg.evaluate(()=>{const p=curP();p.bond.burdens[1].n='<img src=x onerror="window.pwn=1">';p.bond.clocks[0].n='"><img src=x onerror="window.pwn=2">';pcRender()});console.log('pwn',await pg.evaluate(()=>window.pwn||0),await pg.$$eval('#main img[src=x]',x=>x.length));
 // comp/con
 const cc=await pg.evaluate(()=>{const r=ccConvert({name:'T',callsign:'C',level:3,skills:[],talents:[],mechSkills:[0,0,0,0],licenses:[],mechs:[],bondId:'ktb-bond-wolf',xp:3,stress:2,bondPowers:[{name:'Hunter'},{name:PCD.bonds.bonds.find(b=>b.id==='ktb-bond-wolf').powers[2].en}],burdens:[{title:'Shot',segments:4,progress:1}],clocks:[{title:'Run',segments:6,progress:2}],minorIdeal:''});return JSON.stringify({b:r.p.bond&&{id:r.p.bond.id,xp:r.p.bond.xp,pw:r.p.bond.pw,bur:r.p.bond.burdens[0],cl:r.p.bond.clocks},w:r.warn.slice(-2)})});console.log('cc',cc);
 // ремонт Императора
 await pg.evaluate(()=>{const p=curP();if(!p.cb)p.cb={};pcFullRepair(p,true);window._ov=p.cb&&p.cb.over});console.log('over',await pg.evaluate(()=>window._ov));
 // справочник
 await pg.click('[data-act="view"][data-v="ref"]');console.log('ref ktb',await pg.$$eval('#ref-ktb ~ *',x=>x.length),await pg.$$eval('.dlc-hd',x=>x.map(y=>y.textContent.slice(0,40))));
 await pg.evaluate(()=>document.getElementById('ref-ktb').scrollIntoView());await pg.waitForTimeout(150);await pg.screenshot({path:'v23_ref.png'});
 await pg.click('[data-act="view"][data-v="gm"]');console.log('gm hd',await pg.$$eval('.dlc-hd',x=>x.map(y=>y.textContent.slice(0,50))));
 const el=await pg.$('#gm-dlc-KTB');if(el){await el.scrollIntoViewIfNeeded();await pg.screenshot({path:'v23_gm.png'})}
 const mf=await pg.$$eval('.gm-card',x=>x.filter(c=>/Кузница/.test(c.textContent)).length);console.log('mapforge cards',mf);
 // мобильный
 await pg.setViewportSize({width:390,height:844});await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="ptab"][data-v="bond"]');await pg.screenshot({path:'v23_mob.png'});
 console.log('hscroll',await pg.evaluate(()=>document.documentElement.scrollWidth));
 console.log('ERRS',JSON.stringify(errs));await b.close()})();
