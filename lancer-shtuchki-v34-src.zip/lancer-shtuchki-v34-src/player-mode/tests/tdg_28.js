const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:900}});pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text().slice(0,200))});
 await pg.goto('file:///home/claude/lancer-npc-v28.html');await pg.click('[data-role="gm"]');await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 const r=await pg.evaluate(()=>{const p=curP();p.ll=6;p.lic={mf_raleigh:2,mf_monarch:2};p.talents={t_iconoclast:1,t_field_analyst:2};p.cbs=['cb_superheavy_mounting'];
   const ok=['mf_störtebeker','mf_micro_monarch'].map(id=>id+':'+frameOk(p,P.F[id]));
   const m=curM(p);m.frame='mf_micro_monarch';const st=mechStats(p,m);const mts=mechMounts(p,m).map(x=>x.type);
   m.systems=['ms_cockpit_integrated_stim_pump','ms_mesmertrance_dampener','ms_armament_redundancy'];m.load={f2:['mw_reaper_assault_cannon']};
   const W=buildWarnings(p,m);
   p.gear.armor='ms_madrigal_boarding_carapace_armor';let ps=null;try{ps=pilotStats(p)}catch(e){ps='ERR '+e.message}
   return{ok,hp:st.hp,ai:st.ai,mts,W,ps:JSON.stringify(ps).slice(0,200),art:!!ART['mf_störtebeker']&&!!ART.mf_micro_monarch,cnt:talentRanks(p).filter(x=>x.r.counters).map(x=>x.r.counters.map(c=>c.name)),
     tpl:TEMPLATES.filter(t=>t.book==='DG').map(t=>t.id+':'+tplItems(t).length),lib:BUILTIN.filter(c=>c.book==='DG').map(c=>c.id),enc:WFENC.filter(e=>e.book==='DG').length,gm:GMT.filter(t=>t.book==='DG').length,ref:REF.map(s=>s.id).join(',')}});
 console.log(JSON.stringify(r));
 await pg.click('[data-pa="ptab"][data-v="mech"]');await pg.screenshot({path:'v25_mech.png'});
 await pg.click('[data-pa="ptab"][data-v="pilot"]');console.log('tl-book',await pg.$$eval('.tl-book',x=>x.map(y=>y.textContent.trim().slice(0,40))));
 console.log('variants',await pg.$$eval('.lic-var',x=>x.map(y=>y.textContent.replace(/\s+/g,' ').trim().slice(0,70))));
 const vb=await pg.$('.lic-var [data-v="mf_störtebeker"]');await vb.scrollIntoViewIfNeeded();await pg.screenshot({path:'v25_lic.png'});
 // библиотека: шаблоны
 await pg.click('[data-act="view"][data-v="lib"]');await pg.evaluate(()=>{S.cls='berserker';S.tplSel.berserker={tpls:['dg_industrial'],ch:['in-saw']};render();document.getElementById('main').scrollTop=0});await pg.screenshot({path:'v25_lib.png'});
 await pg.evaluate(()=>{S.cls='dg_virga';render()});await pg.screenshot({path:'v25_virga.png'});
 // ГМ: бои Dustgrave
 await pg.click('[data-act="view"][data-v="gm"]');
// v28: бои и отношения убраны —  const ids=await pg.evaluate(()=>WFENC.filter(e=>e.book==='D
// v28: бои и отношения убраны —  for(const id of ids){await pg.evaluate(id=>{WFE.enc=id;WFE.
// v28: бои и отношения убраны —  console.log('enc',await pg.evaluate(()=>S.enc.length),await
// v28: бои и отношения убраны —  const bad=await pg.evaluate(()=>{for(const i of S.enc){try{
// v28: бои и отношения убраны —  await pg.evaluate(id=>{WFE.enc=id;render();document.getElem
// v28: бои и отношения убраны —  // отношения
// v28: бои и отношения убраны —  await pg.click('[data-dg="start"][data-v="magenta"]');await
// v28: бои и отношения убраны —  console.log('rel',await pg.evaluate(()=>JSON.stringify(DGS)
// v28: бои и отношения убраны —  await pg.evaluate(()=>document.getElementById('dg-rel').scr
// v28: бои и отношения убраны —  await pg.evaluate(()=>localStorage.setItem('dg_rel',JSON.st
// v28: бои и отношения убраны —  console.log('clean',await pg.evaluate(()=>JSON.stringify(DG
// v28: бои и отношения убраны —  // бой с ХЕПРИ — вид
// v28: бои и отношения убраны —  await pg.click('[data-act="view"][data-v="enc"]');await pg.
// v28: бои и отношения убраны —  await pg.click('[data-act="view"][data-v="ref"]');await pg.
// v28: бои и отношения убраны —  await pg.setViewportSize({width:390,height:844});await pg.c
 console.log('ERRS',JSON.stringify(errs));await b.close()})();
