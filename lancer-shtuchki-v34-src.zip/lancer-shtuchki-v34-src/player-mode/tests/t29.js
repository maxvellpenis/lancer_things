const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const SP='/tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad/';
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:950}});pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text().slice(0,200))});
 await pg.goto('file:///home/claude/ulan-terminal-v29.html');await pg.click('[data-role="gm"]');
 const L=(...a)=>console.log(...a.map(x=>typeof x==='string'?x:JSON.stringify(x)));
 L('npc',await pg.evaluate(()=>{const out={cls:BUILTIN.filter(c=>c.book==='SS').map(c=>c.id+':'+c.base.length+'+'+c.optional.length)};
   S.cls='ss_tempest';S.view='lib';S.tier=1;render();out.tplDis=[...document.querySelectorAll('#main [id^=tplc-]')].filter(e=>e.classList.contains('dis')).length+'/'+document.querySelectorAll('#main [id^=tplc-]').length;
   out.reason=tplBlockReason(tpl('elite'),cls('ss_tempest'));
   S.enc=[];S.addN=1;S.sel.ss_tempest=['tp-lightning','tp-manip','tp-homing'];S.tier=1;addToEnc();S.tier=3;addToEnc();
   out.inst=S.enc.map(i=>({tier:i.tier,acts:activationsOf(i),size:stOf(i).size,hp:stOf(i).hp,sys:instSystems(i).length}));
   S.cls='ss_leech';S.tier=2;S.sel.ss_leech=['lc-mess','lc-emp'];addToEnc();const l=S.enc[2];out.leech={hp:stOf(l).hp,ev:stOf(l).evasion,size:stOf(l).size,acts:activationsOf(l)};return out}));
 await pg.evaluate(()=>{S.cls='ss_tempest';S.view='lib';S.tier=2;render()});await pg.screenshot({path:SP+'t29_tempest.png'});
 await pg.click('[data-act="view"][data-v="enc"]');await pg.waitForTimeout(200);await pg.screenshot({path:SP+'t29_enc.png'});
 // ГМ
 await pg.click('[data-act="view"][data-v="gm"]');await pg.waitForTimeout(200);
 L('gm',await pg.evaluate(()=>{const rs=[];for(let i=0;i<300;i++)rs.push(gmRoll('ss_gsec',true));const k=GMS.ss_gsec;return {min:Math.min(...rs),max:Math.max(...rs),side:[...document.querySelectorAll('#side .side-sub')].map(e=>e.textContent+':'+(e.dataset.bk||''))}}));
 await pg.click('[data-gm="roll"][data-v="ss_gsec"]');L('log',await pg.evaluate(()=>document.querySelector('#log .et')&&document.querySelector('#log .et').innerText.slice(0,200)));
 const g=await pg.$('#gm-dlc-SS');if(g){await g.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t29_gm.png'})}
 // Справочник
 await pg.click('[data-act="view"][data-v="ref"]');await pg.waitForTimeout(200);
 L('ref',await pg.evaluate(()=>({ss:(REF.find(s=>s.id==='ss')||{items:[]}).items.map(x=>x.t),hd:[...document.querySelectorAll('.dlc-hd')].map(e=>e.innerText.split('\n')[0]+'['+(e.dataset.bk||'')+']')})));
 const r=await pg.$('#ref-ss');if(r){await r.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t29_ref.png'})}
 // Игроки
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 L('pc',await pg.evaluate(()=>{const p=curP();p.ll=6;p.lic={mf_blackbeard:2};p.talents={mf_orator:3};p.reserves=(p.reserves||[]);
   const m=curM(p);m.frame='mf_Empakaai_alt_blackbeard';p.cb=null;m.systems=['ms_exo_mist_feathers','ms_exo_emi_theater'];const ms=mechMounts(p,m);m.load={};m.load[ms[0].key]=['mw_assault_rifle'];
   const st=mechStats(p,m);PS.tab='combat';pcRender();const c=pcEnsure(p);
   return {ok:frameOk(p,P.F[m.frame]),mounts:ms.map(x=>x.type+(x.fixed?'(встр)':'')),ws:mechWeapons(p,m).map(x=>x.w.name),st:{hp:st.hp,ev:st.evasion,sp:st.sp},orator:c.counters.ctr_orator,
    W:buildWarnings(p,m),ctrs:[...document.querySelectorAll('.mini label')].map(e=>e.innerText.replace(/\s+/g,' '))}}));
 await pg.screenshot({path:SP+'t29_combat.png'});
 L('claw',await pg.evaluate(()=>{const p=curP(),m=curM(p);const x=mechWeapons(p,m).find(y=>y.w.id==='mw_empakaai_alt_blackbeard_integrated');pcOpenWeapon(p,x.uid);const r={mods:M.mods.map(z=>z.label).filter(l=>/Коготь|Прицел/.test(l)),pill:document.querySelector('#mbox .wprof').innerText};M=null;renderModal();return r}));
 // резервы
 L('res',await pg.evaluate(()=>{const p=curP(),m=curM(p);const ev0=mechStats(p,m).evasion;
   const ids=PCD.reserves.filter(r=>r.book==='SS').map(r=>r.id);
   p.reserves=[{id:'reserve_oba_liquidmetal_cloak'},{id:'reserve_compulsory_scope_upgrade'}];const ev1=mechStats(p,m).evasion;
   const x=mechWeapons(p,m).find(y=>y.w.id==='mw_assault_rifle');pcOpenWeapon(p,x.uid);const sc=M.mods.map(z=>z.label).filter(l=>/Прицел/.test(l));M=null;renderModal();
   p.reserves[0].used=true;const ev2=mechStats(p,m).evasion;return {ids,ev0,ev1,ev2,sc}}));
 await pg.evaluate(()=>{PS.tab='pilot';pcRender()});
 L('pilot',await pg.evaluate(()=>({talentGroups:[...document.querySelectorAll('.tl-book')].map(e=>e.innerText.split('\n')[0]+'['+(e.dataset.bk||'')+']'),gear:PCD.gear.filter(g=>g.book==='SS').map(g=>g.name)})));
 const t=[...await pg.$$('.tl-book')].pop();if(t){await t.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t29_pilot.png'})}
 await pg.evaluate(()=>{PS.tab='pilot';curP().lic={mf_blackbeard:2};PS.open['lic-mf_blackbeard']=true;pcRender()});
 const vb=await pg.$('[data-v="mf_Empakaai_alt_blackbeard"]');if(vb){await vb.scrollIntoViewIfNeeded();await pg.screenshot({path:SP+'t29_lic.png'})}
 await pg.setViewportSize({width:390,height:844});
 for(const v of ['ref','gm']){await pg.click(`[data-act="view"][data-v="${v}"]`);L('hs '+v,await pg.evaluate(()=>document.documentElement.scrollWidth))}
 await pg.evaluate(()=>{S.cls='ss_tempest';S.view='lib';render()});L('hs lib',await pg.evaluate(()=>document.documentElement.scrollWidth));
 L('ERRS',errs);await b.close()})();
