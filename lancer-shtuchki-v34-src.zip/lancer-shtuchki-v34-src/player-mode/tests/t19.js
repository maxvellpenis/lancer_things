const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const F='file:///home/claude/lancer-npc-v19.html';
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:900}});pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('console:'+m.text())});
 await pg.goto(F);const logo=await pg.textContent('.rg-logo');console.log('gate',logo);
 await pg.click('[data-role="gm"]');
 const tabs=await pg.$$eval('#tabs .tab',x=>x.map(y=>y.textContent.trim()));console.log('tabs',tabs);
 // ref
 await pg.click('[data-act="view"][data-v="ref"]');
 const nref=await pg.$$eval('#main .gl-card',x=>x.length);const nat=await pg.$$eval('#main .kw',x=>x.length);console.log('ref cards',nref,'tips',nat);
 await pg.screenshot({path:'v19_ref.png'});
 await pg.fill('#refq','перегрузк');const vis=await pg.$$eval('#main .gl-card',x=>x.filter(y=>y.style.display!=='none').length);console.log('search vis',vis);
 await pg.fill('#refq','');
 // fold
 await pg.click('#main h2 >> nth=1');const hid=await pg.$$eval('#main .fold-h',x=>x.length);console.log('folded hidden',hid);
 await pg.reload();await pg.click('[data-role="gm"]');const hid2=await pg.$$eval('#main .fold-h',x=>x.length);console.log('after reload hidden',hid2,await pg.evaluate(()=>S.view));
 await pg.click('#main h2.folded');
 // gm
 await pg.click('[data-act="view"][data-v="gm"]');await pg.click('[data-gm="all"]');
 const res=await pg.$$eval('#main .gm-card.has',x=>x.length);console.log('gm rolled',res,await pg.$$eval('#side .gm-sum>div',x=>x.length));
 await pg.screenshot({path:'v19_gm.png'});
 // pc combat
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 await pg.evaluate(()=>{PS.tab='combat';render()});
 const heat0=await pg.evaluate(()=>curP().cb.heat);
 await pg.click('.turnbox [data-pa="oc"]');
 const st1=await pg.evaluate(()=>({heat:curP().cb.heat,oc:curP().cb.oc,turn:curP().cb.turn}));
 await pg.click('.turnbox [data-pa="oc"]');
 const st2=await pg.evaluate(()=>({heat:curP().cb.heat,oc:curP().cb.oc,toast:document.getElementById('toasts')?.textContent}));
 console.log('oc',heat0,JSON.stringify(st1),JSON.stringify(st2));
 await pg.click('[data-pa="turn"][data-v="q1"]');await pg.click('[data-pa="turn"][data-v="reset"]');
 await pg.click('.turnbox [data-pa="oc"]');console.log('after reset oc',await pg.evaluate(()=>curP().cb.oc));
 // overheat via repeated
 await pg.evaluate(()=>{const c=curP().cb;c.heat=curP()&&mechStats(curP(),curM(curP())).heatcap;c.turn.oc=0;render()});
 await pg.click('.turnbox [data-pa="oc"]');console.log('stress after overheat',await pg.evaluate(()=>[curP().cb.stress,curP().cb.heat]));
 await pg.click('[data-pa="brace"]');await pg.click('[data-pa="turn"][data-v="reset"]');console.log('brace next',await pg.evaluate(()=>JSON.stringify(curP().cb.turn)));
 await pg.click('[data-pa="stab"]');console.log('stab full',await pg.evaluate(()=>curP().cb.turn.full));
 await pg.evaluate(()=>{pAddCond(curP().cb,'Ошеломлен');curP().cb.turn.oc=0;curP().cb.turn.lim=0;render()});await pg.click('.turnbox [data-pa="oc"]');console.log('stunned oc blocked',await pg.evaluate(()=>curP().cb.turn.oc));
 await pg.screenshot({path:'v19_combat.png'});
 // tooltips in systems: add a system with tags
 await pg.evaluate(()=>{const m=curM(curP());m.sys=['ms_pattern_a_smoke_charges'].filter(x=>P.SY[x]);m.load={f0:['mw_assault_rifle']};render()});
 await pg.waitForTimeout(120);const tagtips=await pg.$$eval('#main .tag-s .kw.at',x=>x.map(y=>y.textContent));console.log('tag-s tips',tagtips.slice(0,8));
 // itemov tip z
 await pg.evaluate(()=>{PS.tab='pilot';curP().lic={mf_deaths_head:2};PS.open['lic-mf_deaths_head']=true;render()});
 console.log('logos',await pg.$$eval('#main .mlogo',x=>x.length));
 await pg.screenshot({path:'v19_lic.png'});
 await pg.evaluate(()=>itemOverlay('s',Object.keys(P.SY).find(k=>/Невидим|Ошелом/.test(P.SY[k].text||''))));
 await pg.waitForTimeout(120);const kws=await pg.$$('#itemov .kw.at');console.log('itemov kws',kws.length);
 if(kws.length){await kws[0].hover();await pg.waitForTimeout(100);const tv=await pg.evaluate(()=>{const t=document.getElementById('tip');const r=t.getBoundingClientRect();const el=document.elementFromPoint(r.x+5,r.y+5);return [t.style.display,getComputedStyle(t).zIndex,el===t||t.contains(el)]});console.log('tip visible',tv)}
 await pg.screenshot({path:'v19_tip.png'});
 // player
 await pg.evaluate(()=>{const o=document.getElementById('itemov');o.classList.remove('on')});
 await pg.click('[data-act="rolechange"]');await pg.click('[data-role="player"]');
 console.log('player tabs',await pg.$$eval('#tabs .tab',x=>x.map(y=>y.textContent.trim())));
 await pg.click('[data-act="view"][data-v="ref"]');console.log('player view',await pg.evaluate(()=>S.view));
 await pg.evaluate(()=>{S.view='gm';render()});console.log('player gm forced',await pg.evaluate(()=>S.view));
 console.log('errs',errs);await b.close()})();
