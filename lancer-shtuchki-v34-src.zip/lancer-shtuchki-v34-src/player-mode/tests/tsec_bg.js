const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage();pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file:///home/claude/lancer-npc-v22.html');await pg.click('[data-role="gm"]');await pg.click('[data-act="view"][data-v="fleet"]');
 const out=await pg.evaluate(()=>{const mk=t=>`"'><img src=x data-t="${t}">`;
  const raw={name:'G'+mk('gname'),cmdr:mk('cmdr'),traits:mk('tr'),notes:mk('notes'),ships:[{hull:'murie',name:mk('sname'),flag:true,eq:{sh:['tachyon',mk('bad')],pr:[mk('x')],sys:['ffe'],mod:{k:'esc',id:mk('m')}},ace:[mk('a')]},{hull:mk('hull')},{hull:'caspian',eq:{pr:['hkb']}}],extra:{__proto__:{polluted:1}}};
  const g=bgClean(raw);BGS.groups.push(g);BGS.cur=g.id;BGS.tab='build';bgRender();const f=new Set();document.querySelectorAll('img[src=x]').forEach(i=>f.add('build:'+i.dataset.t));
  BB().units.push(bgUnitPc(g,4));BB().units.push(bgUnitNpc('manowar',['wardogs'],'',mk('npcname')));BGS.tab='battle';bgRender();document.querySelectorAll('img[src=x]').forEach(i=>f.add('battle:'+i.dataset.t));
  return {found:[...f],ships:g.ships.length,eq:JSON.stringify(g.ships[0].eq),polluted:({}).polluted}});
 console.log(JSON.stringify(out),JSON.stringify(errs));await b.close()})();
