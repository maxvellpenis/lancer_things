const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage();pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file:///home/claude/lancer-npc-v20.html');await pg.click('[data-role="gm"]');
 const r=await pg.evaluate(()=>{const ta=document.createElement('textarea');ta.id='io';document.body.appendChild(ta);
  const good=JSON.parse(JSON.stringify(BUILTIN[0]));good.id='mygood';good.name='Мой <b>класс</b>';
  const bad={id:'broken',name:'Сломанный',tiers:[1,2,3],base:'oops'};
  ta.value=JSON.stringify([good,bad]);doImport();
  return {custom:S.custom.map(c=>c.id),crash:!!document.querySelector('.crashbox'),view:S.view,cls:S.cls}});
 console.log(JSON.stringify(r),errs);
 // export/import library roundtrip of builtin-derived
 await b.close()})();
