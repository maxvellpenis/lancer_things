const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const errs=[];
 for(const vp of [{width:1300,height:800},{width:390,height:800}]){
 const pg=await b.newPage({viewport:vp});pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file:///home/claude/lancer-npc-v18.html');await pg.screenshot({path:`gate${vp.width}.png`});
 await pg.click('[data-role="player"]');
 const tabs=await pg.evaluate(()=>[...document.querySelectorAll('#tabs .tab')].map(t=>t.textContent.trim()));
 await pg.evaluate(()=>{S.view='lib';render()});const v1=await pg.evaluate(()=>S.view);
 await pg.click('[data-act="rolechange"]');await pg.click('[data-role="gm"]');
 const tabs2=await pg.evaluate(()=>[...document.querySelectorAll('#tabs .tab')].map(t=>t.textContent.trim()));
 await pg.click('[data-act="view"][data-v="lib"]');const v2=await pg.evaluate(()=>S.view);
 await pg.screenshot({path:`gm${vp.width}.png`});
 console.log(vp.width,'player tabs',tabs,'forced view',v1,'| gm tabs',tabs2,'view',v2);await pg.close()}
 console.log(errs);await b.close()})();
