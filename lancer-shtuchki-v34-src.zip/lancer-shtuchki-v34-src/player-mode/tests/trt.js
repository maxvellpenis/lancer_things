const {chromium}=require('/opt/npm-tools/node_modules/playwright');const fs=require('fs');
const t=fs.readFileSync('/tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad/todo/furer_v2.json','utf8');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();await pg.goto('file:///home/claude/lancer-npc-v20.html');await pg.click('[data-role="gm"]');
 const r=await pg.evaluate(t=>{pcImportText(t);const p=curP();p.reserves=[{id:'custom',name:'Рез',note:'н',used:false}];p.custom=[{name:'Мой',rank:2}];p.bgId=PCD.backgrounds[3].id;curM(p).proto.lim=5;
   const strip=x=>{const c=JSON.parse(JSON.stringify(x));c.forEach(p=>p.cb=null);return c};const a=strip(PS.pilots);pcImportText(JSON.stringify(a));const b2=strip(PS.pilots);
   const out=[];const diff=(a,b,path)=>{if(JSON.stringify(a)===JSON.stringify(b))return;if(a&&b&&typeof a==='object'&&typeof b==='object'){for(const k of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[k],b[k],path+'.'+k)}else out.push(path+' '+JSON.stringify(a)+' → '+JSON.stringify(b))};diff(a,b2,'');return out},t);
 console.log(r.slice(0,20));await b.close()})();
