const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1400,height:900}});pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text().slice(0,200))});
 await pg.goto('file:///home/claude/lancer-npc-v24.html');await pg.click('[data-role="gm"]');await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 const r=await pg.evaluate(()=>{const p=curP();p.ll=4;p.lic={mf_kidd:2,mf_tokugawa:2};
   const ok=['mf_kidd','mf_sagarmatha','mf_tokugawa_alt_enkidu','mf_genghis_alt_worldkiller_genghis_mk_i','mf_swallowtail_alt_swallowtail_ranger_variant'].map(id=>id+':'+frameOk(p,P.F[id]));
   const m=curM(p);m.frame='mf_kidd';const st=mechStats(p,m);
   m.systems=['ms_exo_cynosure','ms_exo_opportunity','ms_exo_carapace_cladding','ms_pebcac'];const W=buildWarnings(p,m);
   return{ok,hp:st.hp,ev:st.evasion,sp:st.sp,W:W.filter(x=>/Экзот|лиценз/.test(x)),art:!!ART.mf_kidd,lbl:licLabel(P.SY.ms_exo_cynosure),
     lib:BUILTIN.filter(c=>c.book==='WF').map(c=>c.id+':'+c.base.length+'/'+c.optional.length).join(' '),ref:REF.map(s=>s.id).join(','),gm:GMT.filter(t=>t.book==='WF').length,
     acc:(BUILTIN.find(c=>c.id==='wf_accumulation').base.find(s=>s.id==='turret')||{}).name}});
 console.log(JSON.stringify(r));
 await pg.click('[data-pa="ptab"][data-v="combat"]');console.log('jolly',await pg.$$eval('[data-pa="ctr"]',x=>x.length),await pg.evaluate(()=>document.querySelector('.mini')&&document.querySelector('.mini').textContent.replace(/\s+/g,' ')));
 await pg.click('[data-pa="ctr"][data-d="1"]');await pg.click('[data-pa="ctr"][data-d="1"]');console.log('jolly val',await pg.evaluate(()=>JSON.stringify(curP().cb.counters)));
 await pg.click('[data-pa="ptab"][data-v="mech"]');console.log('exo optgroup',await pg.$$eval('optgroup',x=>x.filter(g=>/Экзот/.test(g.label)).length),'frame opts',await pg.$$eval('option',x=>x.filter(o=>/Кидд|Сагарм|Энкиду|Мк I|рейндж/.test(o.textContent)).map(o=>o.textContent.trim())));
 await pg.screenshot({path:'v24_mech.png'});
 await pg.click('[data-pa="ptab"][data-v="pilot"]');console.log('tl-book',await pg.$$eval('.tl-book',x=>x.map(y=>y.textContent.trim().slice(0,50))));
 await pg.click('[data-pa="licopen"][data-v="mf_kidd"]');await pg.waitForTimeout(100);const kb=await pg.$('[data-pa="licopen"][data-v="mf_kidd"]');await kb.scrollIntoViewIfNeeded();await pg.screenshot({path:'v24_lic.png'});
 console.log('lic kidd items',await pg.$$eval('.lic-card.open .lic-it',x=>x.map(y=>y.textContent.trim())));
 console.log('variant cards',await pg.$$eval('.lic-var',x=>x.map(y=>y.textContent.replace(/\s+/g,' ').trim().slice(0,90))));
 // библиотека
 await pg.click('[data-act="view"][data-v="lib"]');await pg.evaluate(()=>{S.cls='wf_lurker';render()});await pg.screenshot({path:'v24_lib.png'});
 console.log('lib side groups',await pg.evaluate(()=>[...document.querySelectorAll('#side *')].filter(e=>e.children.length===0&&/Wallflower/.test(e.textContent)).map(e=>e.textContent.trim())));
 // ГМ tools
 await pg.click('[data-act="view"][data-v="gm"]');console.log('panels',await pg.$$eval('.wf-panel',x=>x.length));
 await pg.selectOption('[data-wff="enc"]','roadblock');await pg.selectOption('[data-wff="epcs"]','5');
 await pg.click('[data-wf="eadd"][data-v="0"]');await pg.click('[data-wf="eadd"][data-v="1"]');
 console.log('enc',await pg.evaluate(()=>S.enc.map(i=>i.label+'['+i.tpls.join(',')+'|'+i.opts.join(',')+']').join('; ')),'view',await pg.evaluate(()=>S.view));
 await pg.evaluate(()=>document.getElementById('wf-enc').scrollIntoView());await pg.screenshot({path:'v24_enc.png'});
 // эйдолон
 await pg.selectOption('[data-wff="preset"]','beggar');await pg.selectOption('[data-wff="cls"]','2');
 console.log('eid layers',await pg.evaluate(()=>JSON.stringify({l:EIDS.layers,h:EIDS.hpb})));
 await pg.click('[data-wf="estart"]');console.log('L1',await pg.evaluate(()=>JSON.stringify({i:EIDS.idx,hp:EIDS.hp,ar:EIDS.armor,sh:EIDS.shards})));
 await pg.fill('#eidn','12');await pg.click('[data-wf="edmg"]');console.log('after dmg',await pg.evaluate(()=>JSON.stringify({hp:EIDS.hp,ar:EIDS.armor})));
 await pg.evaluate(()=>document.getElementById('wf-eid').scrollIntoView());await pg.screenshot({path:'v24_eid.png'});
 for(let k=0;k<4;k++)await pg.click('[data-wf="enext"]');console.log('core',await pg.evaluate(()=>JSON.stringify({i:EIDS.idx,hp:EIDS.hp,sh:EIDS.shards,cur:!!eidCur().core})));
 await pg.fill('#eidn','3');await pg.click('[data-wf="edmg"]');console.log('log',await pg.evaluate(()=>document.querySelector('#log .et b')&&document.querySelector('#log .et b').textContent));
 // санитайзер
 await pg.evaluate(()=>{localStorage.setItem('wf_eid',JSON.stringify({cls:'<img src=x onerror=window.pwn=1>',layers:['__proto__',99,-5],idx:999,preset:'<b>',hp:'x'}));localStorage.setItem('wf_enc_sel',JSON.stringify({enc:'<img src=x onerror=window.pwn=2>',pcs:99}))});
 await pg.reload();await pg.click('[data-role="gm"]').catch(()=>{});await pg.click('[data-act="view"][data-v="gm"]');console.log('clean',await pg.evaluate(()=>JSON.stringify({e:EIDS,w:WFE,pwn:window.pwn||0})));
 // справочник
 await pg.click('[data-act="view"][data-v="ref"]');console.log('ref wf cards',await pg.$$eval('#ref-wf + .gl-grid .gl-card',x=>x.length),await pg.$$eval('#ref-wf-eid + .gl-grid .gl-card',x=>x.length));
 await pg.evaluate(()=>document.getElementById('ref-wf-eid').scrollIntoView());await pg.waitForTimeout(150);await pg.screenshot({path:'v24_ref.png'});
 await pg.setViewportSize({width:390,height:844});await pg.click('[data-act="view"][data-v="gm"]');await pg.evaluate(()=>document.getElementById('wf-eid').scrollIntoView());await pg.screenshot({path:'v24_mob.png'});console.log('hs',await pg.evaluate(()=>document.documentElement.scrollWidth));
 console.log('ERRS',JSON.stringify(errs));await b.close()})();
