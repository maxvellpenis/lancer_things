const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{
 const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1400,height:1300}});
 const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('dialog',d=>d.accept());
 await pg.goto('file:///home/claude/lancer-npc-v14.html');
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 await pg.evaluate(()=>{const p=curP();p.ll=6;p.bgId='pbg_mechanic';p.talents={t_engineer:2,t_drone_commander:1,t_brutal:1};p.skills={sk_hack_or_fix:2,sk_blow_something_up:1,sk_get_a_hold_of_something:1,sk_spot:1};
   p.reserves=[{id:'reserve_ammo',item:'ms_turret_drones',n:2},{id:'reserve_extended_harness'},{id:'reserve_systems_reinforcement',skill:'eng'},{id:'custom',name:'Долг контрабандистов',note:'вернуть до конца миссии'},{id:'reserve_talent'}];
   p.gear.items=['pg_corrective','pg_frag_grenades','pg_stims','pg_patch',''];PS.open['gf-pg_heavy_hardsuit']=true;p.gear.armor='pg_heavy_hardsuit';p.gear.weapons=['pg_heavy_a_c','pg_light_signature',''];
   const m=curM(p);m.systems=['ms_turret_drones','ms_pattern_a_jericho_deployable_cover'];m.proto.rev=['optics','reactor'];PS.tab='pilot';render()});
 const shot=async(sel,name)=>{await pg.evaluate(s=>{const h=[...document.querySelectorAll('#main h2')].find(x=>x.textContent.includes(s));h.scrollIntoView()},sel);await pg.screenshot({path:name,clip:{x:240,y:0,width:830,height:1300}})};
 await shot('Снаряжение пилота','s14_gear.png');
 await pg.evaluate(()=>{PS.tab='mech';render()});await shot('Слоты','s14_mounts.png');
 await pg.evaluate(()=>{PS.tab='combat';render()});
 await pg.click('[data-pa="depadd"]');await pg.click('[data-pa="depadd"] >> nth=1');
 await shot('Размещаемые','s14_deps.png');
 console.log(errs);await b.close();})();
