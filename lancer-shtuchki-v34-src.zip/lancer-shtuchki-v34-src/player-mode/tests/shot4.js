const {chromium}=require('/opt/npm-tools/node_modules/playwright');
(async()=>{
 const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1500,height:1000}});
 const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('dialog',d=>d.accept());
 await pg.goto('file:///home/claude/lancer-npc-v13.html');
 await pg.click('[data-act="view"][data-v="pc"]');await pg.click('[data-pa="pnew"]');
 await pg.evaluate(()=>{PS.tab='combat';render()});
 await pg.click('[data-pa="vit"][data-k="oc"][data-v="2"]');
 console.log('heat after 2 oc', await pg.evaluate(()=>curP().cb.heat+' oc '+curP().cb.oc));
 await pg.evaluate(()=>{curP().cb.burn=3;render()});
 await pg.screenshot({path:'v13_pc.png'});
 await pg.evaluate(()=>{S.view='lib';S.cls='cataphract';render()});await pg.click('[data-act="add"]');
 await pg.evaluate(()=>{S.enc[0].burn=2;S.enc[0].spent[instSystems(S.enc[0]).find(s=>s.rc).id]=true;render()});
 await pg.screenshot({path:'v13_npc.png'});
 console.log(errs);await b.close();})();
