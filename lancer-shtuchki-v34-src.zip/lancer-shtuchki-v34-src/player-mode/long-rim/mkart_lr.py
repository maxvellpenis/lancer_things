# Арт рам Long Rim: страница рендерится с прозрачным фоном в границах картинок (слои арта собираются как в книге).
import json,pymupdf,io,base64,sys,os
from PIL import Image
H=os.path.dirname(os.path.abspath(__file__))
PDF=sys.argv[1];ART=sys.argv[2]
doc=pymupdf.open(PDF)
PAGES={'mf_atlas':42,'mf_caliban':46,'mf_kobold':50,'mf_lich':54,'mf_sunzi':60,'mf_zheng':64}
art=json.load(open(ART)) if os.path.exists(ART) else {}
for fid,pn in PAGES.items():
    p=doc[pn-1];r=None
    for x in p.get_images(full=True):
        for rr in p.get_image_rects(x[0]):
            if rr.width*rr.height<80*80: continue
            r=rr if r is None else r|rr
    # не захватывать рамку «CORE SYSTEM» снизу
    for b in p.get_text('blocks'):
        if 'CORE SYSTEM' in b[4] and b[1]<r.y1: r.y1=b[1]-4
    # не захватывать вертикальную подпись «HORUS LICH» и красную «2» справа сверху
    for b in p.get_text('blocks'):
        if b[1]<140 and b[0]>r.x0+r.width*0.6 and b[0]<r.x1 and len(b[4].strip())>3: r.x1=min(r.x1,b[0]-6)
    pix=p.get_pixmap(dpi=200,clip=r,alpha=True)
    img=Image.open(io.BytesIO(pix.tobytes('png'))).convert('RGBA')
    bb=img.getchannel('A').point(lambda v:255 if v>8 else 0).getbbox()
    if bb: img=img.crop(bb)
    img.thumbnail((800,800),Image.LANCZOS)
    img.save(os.path.join(H,'pages',fid+'.png'))
    b=io.BytesIO();img.save(b,'WEBP',quality=80,method=4)
    art[fid]='data:image/webp;base64,'+base64.b64encode(b.getvalue()).decode()
    print(fid,img.size,len(b.getvalue())//1024,'KB')
json.dump(art,open(ART,'w'))
