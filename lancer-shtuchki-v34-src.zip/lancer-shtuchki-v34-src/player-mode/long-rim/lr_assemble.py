# Добавляет в pcdata.json содержимое «The Long Rim»: числа из long-rim-data 1.2.2, тексты из lr_ru.json.
# Повторный запуск безопасен: прежние записи LR удаляются и добавляются заново.
import json,os,sys
H=os.path.dirname(os.path.abspath(__file__))
LR=os.environ.get('LRDATA',os.path.join(H,'..','lrdata','lib'))
PCD=sys.argv[1] if len(sys.argv)>1 else os.path.join(H,'..','pc','pcdata.json')
J=lambda f:json.load(open(os.path.join(LR,f+'.json')))
RU=json.load(open(os.path.join(H,'lr_ru.json')))
d=json.load(open(PCD))
for k in ('frames','weapons','systems','mods','talents'):d[k]=[x for x in d[k] if x.get('book')!='LR']
ROLE={'Striker':'Нападающий','Defender':'Защитник','Support':'Поддерживающий','Controller':'Оператор','Artillery':'Артиллерист','Balanced':'Универсальный'}
WS={'Auxiliary':'Вспомогательное','Main':'Основное','Heavy':'Тяжелое','Superheavy':'Сверхтяжелое'}
WT={'Melee':'ОББ','CQB':'ОБД','Rifle':'Винтовка','Launcher':'ПУ','Cannon':'Пушка','Nexus':'Звено'}
TAGRU={k:v['n'] for k,v in d['tags'].items()}
LICFIX={'ms_jäger_kunst_i':('mf_atlas','Atlas'),'mw_warp_rifle':('mf_sunzi','Sunzi')}
rng=lambda a:[{'t':x['type'],'v':x['val']} for x in (a or [])]
dmg=lambda a:[{'t':x.get('type','variable').lower(),'v':x['val']} for x in (a or [])]
tags=lambda a:[[x['id'],x.get('val')] for x in (a or [])]
tagtxt=lambda tg:[TAGRU.get(t[0],t[0]).replace('{VAL}',str(t[1] if t[1] is not None else 'X')) for t in tg if t[0] in TAGRU]
def lic(x):
    if x['id'] in LICFIX: return LICFIX[x['id']]
    return x.get('license_id') or '',x.get('license') or ''
for f in J('frames'):
    r=RU['frames'][f['id']];cs=f['core_system'];rc=r['core']
    tr=[dict(name=n,en=t['name'],text=b,bonuses=t.get('bonuses'),use=t.get('use')) for (n,b),t in zip(r['traits'],f['traits'])]
    core=dict(name=rc['name'],en=cs['name'],aname=rc.get('aname'),atext=rc.get('atext',''),atags=rc.get('atags',''),act=cs.get('activation'),use=cs.get('use'),
              pname=rc.get('pname'),ptext=rc.get('ptext'),integrated=cs.get('integrated') or [],bonuses=cs.get('active_bonuses'))
    d['frames'].append(dict(id=f['id'],name=r['name'],en=f['name'],src=f['source'],ll=f['license_level'],role='/'.join(ROLE.get(m,m) for m in f['mechtype']),
        mounts=f['mounts'],stats=f['stats'],traits=tr,core=core,page=r['page'],book='LR'))
for w in J('weapons'):
    r=RU['items'][w['id']];l,ln=lic(w)
    o=dict(id=w['id'],name=r['name'],en=w['name'],src=w.get('source') or '',lic=l,licn=ln,ll=w.get('license_level') or 0,mount=w['mount'],type=w['type'],
           dmg=dmg(w.get('damage')),rng=rng(w.get('range')),tags=tags(w.get('tags')),sp=w.get('sp') or 0,text=r['text'],page=r['page'],book='LR')
    if w.get('profiles'):
        o['profiles']=[dict(name=p['name'],dmg=dmg(p.get('damage')),rng=rng(p.get('range')),tags=tags(p.get('tags'))) for p in w['profiles']]
        PN={'No Stance':'Без стойки','Troll Stance':'Стойка Тролля','Storm Stance':'Стойка Бури',"Lord's Stance":'Стойка Лорда','Wind Stance':'Стойка Ветра',
            'Single Barrel':'Один ствол','Both Barrels':'Оба ствола','Uncharged':'Без заряда','Charged':'Заряженный','Standard':'Обычный','Autochoke Equipped':'С автодросселем'}
        for p in o['profiles']:p['name']=PN.get(p['name'],p['name'])
        if w['id']=='mw_d_d_288':o['profiles'][0]['skirmish']=True;o['profiles'][1]['skirmish']=False
        if w['id']=='mw_terashima_blade':o['tags']=o['tags'] or [['tg_unique',None]]
    if w['id']=='mw_fusion_rifle':
        o['dmg']=[];o['profiles']=[dict(name=f'Цель в {i} простр.',dmg=[{'t':'energy','v':str(i)}],rng=o['rng'],tags=[]) for i in range(1,7)]
    o['rutags']=', '.join([f"{WS.get(w['mount'],w['mount'])} {WT.get(w['type'],w['type'])}"]+tagtxt(o['tags'])+([f"{o['sp']} СП"] if o['sp'] else []))
    for k in ('no_attack','no_mods','barrage','skirmish'):
        if w.get(k):o[k]=w[k]
    if w['id']=='mw_slag_cannon':o['deps']=[dict(n='Насыпь шлака',hp=10,ev=5,ed=None,ar=0,size=1,inst=1,type='Deployable')]
    d['weapons'].append(o)
for s in J('systems'):
    r=RU['items'][s['id']];l,ln=lic(s);tg=tags(s.get('tags'))
    o=dict(id=s['id'],name=r['name'],en=s['name'],src=s.get('source') or '',lic=l,licn=ln,ll=s.get('license_level') or 0,sp=s.get('sp') or 0,type=s.get('type','System'),
           tags=tg,rutags=', '.join(([f"{s['sp']} СП"] if s.get('sp') else [])+tagtxt(tg)),text=r['text'],bonuses=s.get('bonuses'),page=r['page'],book='LR')
    acts=[dict(name=a.get('name') or '',act=a.get('activation'),tech=bool(a.get('tech_attack'))) for a in s.get('actions',[])]
    if acts:o['acts']=acts
    if s.get('talent_item'):o['talent_item']=1;o['tal']=[s.get('talent_id'),s.get('talent_rank')];o['licn']='GMS'
    d['systems'].append(o)
for m in J('mods'):
    r=RU['items'][m['id']];l,ln=lic(m);tg=tags(m.get('tags'))
    d['mods'].append(dict(id=m['id'],name=r['name'],en=m['name'],src=m['source'],lic=l,licn=ln,ll=m['license_level'],sp=m['sp'],types=m.get('allowed_types',[]),
        sizes=m.get('restricted_sizes'),addDmg=dmg(m.get('added_damage')),addRng=rng(m.get('added_range')),addTags=tags(m.get('added_tags')),tags=tg,
        rutags=', '.join([f"{m['sp']} СП",'Мод']+tagtxt(tg)),text=r['text'],page=r['page'],book='LR'))
for t in J('talents'):
    r=RU['talents'][t['id']]
    rk=[dict(name=n,en=x['name'],text=b,bonuses=x.get('bonuses'),integrated=x.get('integrated') or [],counters=x.get('counters')) for (n,b),x in zip(r['ranks'],t['ranks'])]
    d['talents'].append(dict(id=t['id'],name=r['name'],en=t['name'],ranks=rk,page=r['page'],book='LR'))
json.dump(d,open(PCD,'w'),ensure_ascii=False,indent=0)
print('LR:',{k:sum(1 for x in d[k] if x.get('book')=='LR') for k in ('frames','weapons','systems','mods','talents')})
