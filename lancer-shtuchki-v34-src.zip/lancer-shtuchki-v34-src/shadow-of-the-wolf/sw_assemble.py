# Добавляет в pcdata.json снаряжение игроков из «Shadow of the Wolf»: числа из @massif/sotw-data 1.0.2, тексты из sw_ru.json.
# Повторный запуск безопасен: прежние записи SW удаляются.
import json,os,sys
H=os.path.dirname(os.path.abspath(__file__))
DD=os.environ.get('SWDATA',os.path.join(H,'..','swdata','package','lib'))
PCD=sys.argv[1] if len(sys.argv)>1 else os.path.join(H,'..','pc','pcdata.json')
J=lambda f:json.load(open(os.path.join(DD,f+'.json')))
RU=json.load(open(os.path.join(H,'sw_ru.json')))
d=json.load(open(PCD))
for k in ('frames','weapons','systems','mods','talents','gear','reserves','cbs','backgrounds'):d[k]=[x for x in d[k] if x.get('book')!='SW']
d['bonds']['bonds']=[b for b in d['bonds']['bonds'] if b.get('book')!='SW']
ROLE={'Striker':'Нападающий','Defender':'Защитник','Support':'Поддерживающий','Controller':'Оператор','Artillery':'Артиллерист','Balanced':'Универсальный'}
TAGRU={k:v['n'] for k,v in d['tags'].items()}
VARIANT={'Lancaster':'mf_lancaster','Balor':'mf_balor','Sherman':'mf_sherman'}
SKN={s['id']:s['name'] for s in d['skills']}
rng=lambda a:[{'t':x['type'],'v':x['val']} for x in (a or [])]
dmg=lambda a:[{'t':x.get('type','variable').lower(),'v':x['val']} for x in (a or [])]
tags=lambda a:[[x['id'],x.get('val')] for x in (a or [])]
tagtxt=lambda tg:[TAGRU.get(t[0],t[0]).replace('{VAL}',str(t[1] if t[1] is not None else 'X')) for t in tg if t[0] in TAGRU]
for f in J('frames'):
    r=RU['frames'][f['id']];cs=f['core_system'];rc=r['core']
    tr=[dict(name=n,en=t['name'],text=b,bonuses=t.get('bonuses'),use=t.get('use')) for (n,b),t in zip(r['traits'],f['traits'])]
    core=dict(name=rc['name'],en=cs['name'],aname=rc.get('aname'),atext=rc.get('atext',''),atags=rc.get('atags',''),act=cs.get('activation') or 'Quick',use=cs.get('use'),
              pname=rc.get('pname'),ptext=rc.get('ptext'),integrated=cs.get('integrated') or [],bonuses=None,eff=1)
    o=dict(id=f['id'],name=r['name'],en=f['name'],src=f['source'],ll=f['license_level'],role='/'.join(ROLE.get(m,m) for m in f['mechtype']),
        mounts=f['mounts'],stats=f['stats'],traits=tr,core=core,page=r['page'],book='SW',variant=VARIANT[f['variant']])
    if r.get('rkf'):o['rkf']=1
    d['frames'].append(o)
for s in J('systems'):
    r=RU['items'][s['id']];tg=tags(s.get('tags'))
    o=dict(id=s['id'],name=r['name'],en=s['name'],src='EXOTIC',lic='',licn='Экзотика',ll=0,sp=s.get('sp') or 0,type=s.get('type','System'),
           tags=tg,rutags=', '.join(([f"{s['sp']} СП"] if s.get('sp') else [])+tagtxt(tg)),text=r['text'],bonuses=s.get('bonuses'),page=r['page'],book='SW',exo=1)
    d['systems'].append(o)
for g in J('pilot_gear'):
    r=RU['gear'][g['id']];tg=tags(g.get('tags'))
    o=dict(id=g['id'],name=r['name'],en=g['name'],type=g['type'],tags=tg,rng=rng(g.get('range')),dmg=dmg(g.get('damage')),bonuses=g.get('bonuses'),
           text=r['text'],rutags=', '.join(tagtxt(tg)),page=r['page'],book='SW')
    if r.get('exo'):o['exo']=1
    if g['type']=='Armor':o['flav']='armor'
    d['gear'].append(o)
for b in J('backgrounds'):
    n,trig,tx=RU['bg'][b['id']]
    d['backgrounds'].append(dict(id=b['id'],en=b['name'],name=n,trig=', '.join(SKN.get(s,s) for s in b['skills']),skills=b['skills'],text=tx,book='SW',page=96))
for b in RU['bonds']:
    b=dict(b);b['book']='SW';b['q']=[[q,o] for q,o in b['q']];b['vet']=list(b['vet'])
    d['bonds']['bonds'].append(b)
json.dump(d,open(PCD,'w'),ensure_ascii=False,indent=0)
print('SW:',{k:sum(1 for x in d[k] if x.get('book')=='SW') for k in ('frames','systems','gear','backgrounds')},'bonds',sum(1 for b in d['bonds']['bonds'] if b.get('book')=='SW'))
