# Добавляет в pcdata.json снаряжение игроков из «Operation Winter Scar»: числа из @massif/ows-data 1.0.1, тексты из ws_ru.json.
# Повторный запуск безопасен: прежние записи WS удаляются.
import json,os,sys
H=os.path.dirname(os.path.abspath(__file__))
DD=os.environ.get('WSDATA',os.path.join(H,'..','wsdata','package','lib'))
PCD=sys.argv[1] if len(sys.argv)>1 else os.path.join(H,'..','pc','pcdata.json')
J=lambda f:json.load(open(os.path.join(DD,f+'.json')))
RU=json.load(open(os.path.join(H,'ws_ru.json')))
d=json.load(open(PCD))
for k in ('frames','weapons','systems','mods','talents','gear','reserves','cbs'):d[k]=[x for x in d[k] if x.get('book')!='WS']
ROLE={'Striker':'Нападающий','Defender':'Защитник','Support':'Поддерживающий','Controller':'Оператор','Artillery':'Артиллерист','Balanced':'Универсальный'}
WS={'Auxiliary':'Вспомогательное','Main':'Основное','Heavy':'Тяжелое','Superheavy':'Сверхтяжелое'}
WT={'Melee':'ОББ','CQB':'ОБД','Rifle':'Винтовка','Launcher':'ПУ','Cannon':'Пушка','Nexus':'Звено'}
TAGRU={k:v['n'] for k,v in d['tags'].items()}
VARIANT={'Metalmark':'mf_metalmark','Manticore':'mf_manticore','Napoleon':'mf_napoleon'}
FREE_ATK={'mw_legionnaire_battle_rifle','mw_superthermal_blade','mw_legion_nexus'}   # «можно атаковать без зарядов»
rng=lambda a:[{'t':x['type'],'v':(int(x['val']) if str(x['val']).isdigit() else x['val'])} for x in (a or [])]
dmg=lambda a:[{'t':x.get('type','variable').lower(),'v':x['val']} for x in (a or [])]
tags=lambda a:[[x['id'],x.get('val')] for x in (a or [])]
tagtxt=lambda tg:[TAGRU.get(t[0],t[0]).replace('{VAL}',str(t[1] if t[1] is not None else 'X')) for t in tg if t[0] in TAGRU]
def lic(x):
    if x.get('source')=='EXOTIC':return 'EXOTIC','','Экзотика',0
    if x.get('license')=='Gilgamesh':return 'HA','mf_gilgamesh','Gilgamesh',x.get('license_level') or 0
    return x.get('source') or '','','',0
for f in J('frames'):
    r=RU['frames'][f['id']];cs=f['core_system'];rc=r['core']
    tr=[dict(name=n,en=t['name'],text=b,bonuses=t.get('bonuses'),use=t.get('use')) for (n,b),t in zip(r['traits'],f['traits'])]
    core=dict(name=rc['name'],en=cs['name'],aname=rc.get('aname'),atext=rc.get('atext',''),atags=rc.get('atags',''),act=cs.get('activation'),use=cs.get('use'),
              pname=rc.get('pname'),ptext=rc.get('ptext'),integrated=cs.get('integrated') or [],bonuses=cs.get('active_bonuses'))
    if 'Экономное' in rc.get('atags',''):core['eff']=1
    if f['id']=='mf_gilgamesh':core['counters']=[dict(id='gilgamesh_arsenal',name='Куб Снаряжения',min=1,max=6,default_value=6)]
    o=dict(id=f['id'],name=r['name'],en=f['name'],src=f['source'],ll=f['license_level'],role='/'.join(ROLE.get(m,m) for m in f['mechtype']),
        mounts=f['mounts'],stats=f['stats'],traits=tr,core=core,page=r['page'],book='WS')
    if f.get('variant'):o['variant']=VARIANT[f['variant']]
    d['frames'].append(o)
for w in J('weapons'):
    r=RU['items'][w['id']];src,l,ln,ll=lic(w)
    o=dict(id=w['id'],name=r['name'],en=w['name'],src=src,lic=l,licn=ln,ll=ll,mount=w['mount'],type=w['type'],
           dmg=dmg(w.get('damage')),rng=rng(w.get('range')),tags=tags(w.get('tags')),sp=w.get('sp') or 0,text=r['text'],page=r['page'],book='WS')
    if w.get('profiles'):
        o['profiles']=[dict(name=RU['prof'].get(p['name'],p['name']),dmg=dmg(p.get('damage')),rng=rng(p.get('range')),tags=tags(p.get('tags'))) for p in w['profiles']]
        o['dmg']=o['dmg'] or o['profiles'][0]['dmg'];o['rng']=o['rng'] or o['profiles'][0]['rng'];o['tags']=o['tags'] or o['profiles'][0]['tags']
    if w['id']=='mw_integrated_shock_claws':o['src']='';o['integ']=1
    if w['id'] in FREE_ATK:o['freeAtk']=1
    if src=='EXOTIC':o['exo']=1
    o['rutags']=', '.join([f"{WS.get(w['mount'],w['mount'])} {WT.get(w['type'],w['type'])}"]+tagtxt(o['tags'])+([f"{o['sp']} СП"] if o['sp'] else []))
    d['weapons'].append(o)
DEPS={'ms_utility_drone':[dict(n='Вспомогательный Дрон',hp=5,ev=10,ed=10,ar=0,size=0.5,inst=2,type='Drone')]}
for s in J('systems'):
    r=RU['items'][s['id']];src,l,ln,ll=lic(s);tg=tags(s.get('tags'))
    o=dict(id=s['id'],name=r['name'],en=s['name'],src=src,lic=l,licn=ln,ll=ll,sp=s.get('sp') or 0,type=s.get('type','System'),
           tags=tg,rutags=', '.join(([f"{s['sp']} СП"] if s.get('sp') else [])+tagtxt(tg)),text=r['text'],bonuses=s.get('bonuses'),page=r['page'],book='WS')
    acts=[dict(name=a.get('name') or r['name'],act=a.get('activation'),tech=bool(a.get('tech_attack'))) for a in s.get('actions',[])]
    if acts:o['acts']=acts
    if s['id'] in DEPS:o['deps']=DEPS[s['id']]
    if src=='EXOTIC':o['exo']=1
    d['systems'].append(o)
for m in J('mods'):
    r=RU['items'][m['id']];src,l,ln,ll=lic(m);tg=tags(m.get('tags'))
    o=dict(id=m['id'],name=r['name'],en=m['name'],src=src,lic=l,licn=ln,ll=ll,sp=m.get('sp') or 0,types=m.get('allowed_types'),sizes=m.get('restricted_sizes'),
           addDmg=[],addRng=[],addTags=[],tags=tg,rutags=', '.join([f"{m.get('sp') or 0} СП",'Мод']+tagtxt(tg)),text=r['text'],page=r['page'],book='WS')
    if src=='EXOTIC':o['exo']=1
    d['mods'].append(o)
for c in J('core_bonuses'):
    r=RU['cb'][c['id']]
    d['cbs'].append(dict(id=c['id'],name=r['name'],en=c['name'],src='EXOTIC',text=r['text'],bonuses=None,page=r['page'],book='WS',exo=1))
json.dump(d,open(PCD,'w'),ensure_ascii=False,indent=0)
print('WS:',{k:sum(1 for x in d[k] if x.get('book')=='WS') for k in ('frames','weapons','systems','mods','cbs')})
