import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()

def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        raise SystemExit(f'expected {count}, found {n}: {old[:90]!r}')
    s = s.replace(old, new)

rep("<title>НПС Терминал v4</title>", "<title>НПС Терминал v5</title>")
rep("const APP_VERSION='v4';", "const APP_VERSION='v5';")

# ---------------- Squad class ----------------
SQUAD = r"""},
{
 id:'squad',name:'Отряд',role:'Биологический',icon:'⁂',tag:'Биологический',group:'Пехота',
 baseLabel:'Черты и главное оружие',optLabel:'Дополнительные модули',excludeTpl:['grunt','veteran','ultra'],structCap:1,soldiers:10,immune:['Ошеломлен'],
 desc:'Хотя отдельные пилоты и другие немеханизированные солдаты не представляют особой угрозы для большинства мехов, отряд пехотинцев с соответствующим снаряжением и подготовкой может быть опасен сам по себе. Отряды — это именно то, на что они похожи: небольшие группы от пяти до десяти вооруженных и бронированных солдат, представленных одним персонажем на поле боя.',
 tiers:[T(2,2,2,2,10,0,8,8,4,'4 (½ каждый)',null,10,5),T(4,4,4,4,15,0,8,8,4,'4 (½ каждый)',null,12,5),T(6,6,6,6,20,0,8,8,4,'4 (½ каждый)',null,14,5)],
 base:[
  {id:'soldiers',name:'Солдаты',type:'trait',tags:'Черта',text:'Отряд действует как один персонаж, но представляет собой группу солдат, действующих вместе. Когда отряд получает определенное количество урона, это приводит к смерти одного или нескольких из этих солдат в повествовании. В конце концов, это уменьшает количество атак, которые отряд может совершать за ход, как указано в соответствующих профилях оружия. **По умолчанию** отряд состоит из **10** участников, у каждого по **1 ПЗ**.'},
  {id:'rank-file',name:'Рядовой Состав',type:'trait',tags:'Черта',text:'Отряд не может взять шаблоны **Салага**, **Ветеран** или **Ультра**, и никогда не сможет получить **Структуру**. В программе эти шаблоны заблокированы, Структура не поднимается выше 1.'},
  {id:'numbers',name:'Сила в Числе',type:'trait',tags:'Черта',areaResist:1,text:'Отряд имеет **Сопротивляемость** ко всему урону от атак, которые не являются Линией, Конусом, Взрывом или Вспышкой, и **Невосприимчивость** к **Хватанию**, **Тарану**, **Толчку** и **Ошеломлению**. В программе: если у урона не отмечено «по области», он делится пополам сам; Ошеломление не ставится.'},
  {id:'spread',name:'Распространение',type:'trait',tags:'Черта',text:'Предполагается, что вместо отслеживания положения отдельных солдат члены отряда свободно перемещаются в пределах занимаемого им пространства. Другие персонажи могут свободно перемещаться и заканчивать свой ход в местах, занятых Отрядом, и пока Отряд занимает как минимум **2 свободных пространства**, он может закончить свой ход, перекрывая препятствия, укрытия или других персонажей. Поскольку его размер не отражает его массы, Отряд невозможно **Хватать** или **Таранить**.'},
  {id:'small',name:'Меньший Размер',type:'trait',tags:'Черта',text:'Отдельные солдаты могут легко спрятаться за укрытием, но мощь оружия масштаба мехов ограничивает эффективность их защиты. Отряд всегда имеет **мягкое укрытие**, даже на открытой местности, но не может воспользоваться **твердым укрытием**.'},
  {id:'sq-rifle',name:'Главное Оружие (винтовки)',type:'weapon',tags:'Основная Винтовка, вариант — выберите одно Главное Оружие',
   w:{atk:[2,4,6],rng:'Дальн. 5',dmg:[2,3,4],dt:'kin',dtAlt:['kin','en','exp'],multi:2,multiHalf:1},
   effect:'Это оружие может совершать две атаки одновременно; если Отряд теряет более **половины** своих ПЗ, он может совершать только **одну** атаку за раз. Тип урона — на выбор.'},
  {id:'sq-cannon',name:'Главное Оружие (пушка)',type:'weapon',tags:'Основная Пушка, ББ, вариант — выберите одно Главное Оружие',
   w:{atk:[1,2,3],rng:'Дальн. 10',dmg:[5,6,7],dt:'kin',dtAlt:['kin','en','exp'],ap:1},
   effect:'Тип урона — кинетический, энергетический или взрывной, на выбор.'}
 ],
 optional:[
  {id:'armored',name:'Бронированный',type:'trait',tags:'Черта',statMod:{armor:1},text:'Отряд получает **+1 Брони**. В программе Броня увеличивается сама.'},
  {id:'ambush',name:'Сидящие в Засаде',type:'trait',tags:'Черта',text:'Отряд получает **+2 точность** ко всем атакам, спасброскам и проверкам во время первого раунда боя. В программе ставится само в раунде 1.',
   mod:{label:'Первый раунд боя (Сидящие в Засаде)',acc:2,scope:'all',round1:1}},
  {id:'duck',name:'Пригнуться и Прикрыться',type:'reaction',tags:'Реакция, Черта',trigger:'Отряд поражен атакой.',effect:'Отряд получает **Сопротивляемость** к урону, но становится **Обездвиженным** до конца своего следующего хода. Кнопка «Применить» в бою: следующий урон делится пополам, Обездвиженность ставится сама.',
   apply:{cond:'Обездвижен',nextHalf:1}},
  {id:'insert',name:'Быстрое Введение',type:'trait',tags:'Черта',text:'Отряд может **летать** всякий раз, когда он движется или **Ускоряется**.'},
  {id:'discipl',name:'Дисциплинированный',type:'trait',tags:'Черта',noMultiLoss:1,text:'Потеря **ПЗ** не влияет на количество атак, которые отряд может совершать каждый ход. В программе учитывается само.'}
 ]
}
];

const MONSTER_TABLE=["""
rep("}\n];\n\nconst MONSTER_TABLE=[", SQUAD[0:0] + SQUAD)

# ---------------- template applicability vs class ----------------
rep("const tplApplicable=(t,c)=>!t.requiresTag||c.tag===t.requiresTag;",
    "function tplBlockReason(t,c){if(t.requiresTag&&c.tag!==t.requiresTag)return `Не подходит: у этого НИП нет метки «${t.requiresTag}».`;if((c.excludeTpl||[]).includes(t.id)||(t.excludes||[]).includes(c.id))return `${c.name} не может взять этот шаблон (Рядовой состав).`;return ''}\nconst tplApplicable=(t,c)=>!tplBlockReason(t,c);")
rep("   <div class=\"sys-b\">${!ok?`<p class=\"warn\">${conf?`Несовместим с шаблоном «${esc(conf)}».`:`Не подходит: у этого НИП нет метки «${esc(tp.requiresTag)}».`}</p>`:''}",
    "   <div class=\"sys-b\">${!ok?`<p class=\"warn\">${conf?`Несовместим с шаблоном «${esc(conf)}».`:esc(tplBlockReason(tp,c))}</p>`:''}")
rep("<div class=\"tg\">Шаблон${tp.requiresTag?` · только для метки «${esc(tp.requiresTag)}»`:''}</div>",
    "<div class=\"tg\">Шаблон${tp.requiresTag?` · только для метки «${esc(tp.requiresTag)}»`:''}${!tplApplicable(tp,c)?' · недоступен':''}</div>")

# ---------------- effective stats with module stat mods ----------------
rep("function effStats(c,t,tplIds){const st={...c.tiers[t-1]};",
    "function effStats(c,t,tplIds,opts){const st={...c.tiers[t-1]};(c.optional||[]).filter(o=>(opts||[]).includes(o.id)&&o.statMod).forEach(o=>Object.entries(o.statMod).forEach(([k,v])=>{st[k]=(+st[k]||0)+v}));")
rep("function stOf(i){return effStats(cls(i.cls),i.tier,i.tpls)}", "function stOf(i){return effStats(cls(i.cls),i.tier,i.tpls,i.opts)}")
rep("st=effStats(c,t,ts.tpls),isCustom", "st=effStats(c,t,ts.tpls,sel),isCustom")
rep("const ts=getTplSel(c.id),st=effStats(c,S.tier,ts.tpls);", "const ts=getTplSel(c.id),st=effStats(c,S.tier,ts.tpls,getSel(c.id));")

# ---------------- structure cap from class; immune conditions ----------------
rep("const fl=flagsOf(I.tpls);if(f==='struct'&&fl.structCap)I.struct=Math.min(I.struct,fl.structCap);",
    "const fl=flagsOf(I.tpls),cc=cls(I.cls)||{},scap=fl.structCap||cc.structCap;if(f==='struct'&&scap)I.struct=Math.min(I.struct,scap);")
rep("    case 'cond':{const v=el.dataset.v,k=I.conds.indexOf(v);\n      if(k<0){I.conds.push(v);",
    "    case 'cond':{const v=el.dataset.v,k=I.conds.indexOf(v);\n      if(k<0&&(cls(I.cls).immune||[]).includes(v)){addLog('',logHead(I.label)+`<div class=\"bd\">Невосприимчивость: «${esc(v)}» не действует на этого НИП (Сила в Числе).</div>`);break}\n      if(k<0){I.conds.push(v);")
rep("const addCond=(i,c)=>{if(!i.conds.includes(c))i.conds.push(c)};",
    "const addCond=(i,c)=>{const k=cls(i.cls);if(k&&(k.immune||[]).includes(c))return;if(!i.conds.includes(c))i.conds.push(c)};")

# ---------------- instance card: soldiers, area checkbox, apply button ----------------
rep("   <div class=\"muted\" style=\"font-size:12px\">${esc(c.name)} · ${esc(c.role||'')} · Размер ${esc(st.size)}",
    "   <div class=\"muted\" style=\"font-size:12px\">${esc(c.name)} · ${esc(c.role||'')} · Размер ${esc(st.size)}${c.soldiers&&!dead?` · <span class=\"kw\" data-tt=\"Солдаты\" data-tip=\"Примерное число живых солдат: доля оставшихся ПЗ от ${c.soldiers} участников.\">солдат ≈ ${Math.max(0,Math.ceil(i.hp/st.hp*c.soldiers))}</span>`:''}${i.nextHalf?' · <span class=\"info\">следующий урон ½</span>':''}")
rep("     ${flags.saveNoDamage?`<label",
    "     ${systems.some(s=>s.areaResist)?`<label class=\"kw\" data-tt=\"Сила в Числе\" data-tip=\"Отметьте, если урон от атаки Линией, Конусом, Взрывом или Вспышкой. Иначе урон сам делится пополам.\"><input type=\"checkbox\" id=\"area-${i.uid}\"> по области</label>`:''}\n     ${flags.saveNoDamage?`<label")
rep("        ${s.w?`<button class=\"atkbtn\" data-act=\"atk\" data-sys=\"${esc(s.id)}\" data-src=\"inst:${i.uid}\">⚄</button>`:''}\n        ${unl?",
    "        ${s.w?`<button class=\"atkbtn\" data-act=\"atk\" data-sys=\"${esc(s.id)}\" data-src=\"inst:${i.uid}\">⚄</button>`:''}\n        ${s.apply?`<button class=\"btn sm red\" data-act=\"applysys\" data-sys=\"${esc(s.id)}\" data-uid=\"${i.uid}\">Применить</button>`:''}\n        ${unl?")

# ---------------- damage: area resistance & next-half ----------------
rep("function hurt(i,n,dt,note,ap,half){", "function hurt(i,n,dt,note,ap,half,halfLabel){")
rep("  if((half||hideOn)&&!shred){d=Math.ceil(d/2);parts.push(hideOn?'½ Закалённая Шкура':'½ Сопр.')}",
    "  if(shred&&(half||hideOn))parts.push('Сопротивляемость не работает (Расщеплён)');\n  if((half||hideOn)&&!shred){d=Math.ceil(d/2);parts.push(half?(halfLabel||'½ Сопр.'):'½ Закалённая Шкура')}")
rep("  hurt(i,n,dt,'',ap,half);render();",
    """  let hl='';
  if(half)hl='½ Сопр.';
  if(!half&&i.nextHalf){half=true;hl='½ Пригнуться и Прикрыться'}
  const areaCb=document.getElementById('area-'+i.uid);
  if(!half&&instSystems(i).some(s=>s.areaResist)&&!(areaCb&&areaCb.checked)){half=true;hl='½ Сила в Числе (не по области)'}
  if(i.nextHalf)i.nextHalf=false;
  hurt(i,n,dt,'',ap,half,hl);render();""")
rep("  const ap=document.getElementById('ap-'+i.uid).checked,half=document.getElementById('half-'+i.uid).checked;\n  const fl=flagsOf",
    "  const ap=document.getElementById('ap-'+i.uid).checked;let half=document.getElementById('half-'+i.uid).checked;\n  const fl=flagsOf")

# ---------------- apply reaction button ----------------
rep("    case 'reload':delete I.unloaded[el.dataset.sys];render();break;",
    "    case 'reload':delete I.unloaded[el.dataset.sys];render();break;\n    case 'applysys':{const s=findSys(cls(I.cls),el.dataset.sys);if(!s||!s.apply)break;if(s.apply.cond)addCond(I,s.apply.cond);if(s.apply.nextHalf)I.nextHalf=true;\n      addLog('',logHead(I.label+' — '+s.name)+`<div class=\"bd\">${s.apply.nextHalf?'Следующий полученный урон делится пополам. ':''}${s.apply.cond?esc(s.apply.cond)+' до конца своего следующего хода.':''}</div>`);render();break}")

# ---------------- mods: first-round auto ----------------
rep("      if(m.scope==='all'||kind!=='check')mods.push({label:m.label,acc:m.acc||0,diff:m.diff||0,on:false});",
    "      if(m.round1){if(m.scope==='all'||kind!=='check'){const r1=S.round===1;mods.push({label:m.label+(r1?'':' — сейчас не первый раунд'),acc:m.acc||0,diff:m.diff||0,on:r1&&!!i,fixed:i?1:0})}return}\n      if(m.scope==='all'||kind!=='check')mods.push({label:m.label,acc:m.acc||0,diff:m.diff||0,on:false});")

# ---------------- weapon: damage type choice, AP, multiple attacks ----------------
rep("  M={kind:'atk',title:s.name,who:x.label,bonus:s.w.atk[x.t-1],acc:0,diff:0,target:'',w:s.w,t:x.t,src,sysId:s.id,\n     mods,warns,notes,",
    """  let multi=s.w.multi||1,multiWhy='';
  if(multi>1&&s.w.multiHalf&&x.i){const st=stOf(x.i);if(x.i.hp*2<st.hp){if(x.sys.some(o=>o.noMultiLoss))multiWhy='ПЗ меньше половины, но Дисциплинированный — атак по-прежнему 2';else{multi=1;multiWhy='Потеряно больше половины ПЗ — только одна атака'}}}
  M={kind:'atk',title:s.name,who:x.label,bonus:s.w.atk[x.t-1],acc:0,diff:0,target:'',w:s.w,t:x.t,src,sysId:s.id,dt:s.w.dt,multi,multiWhy,
     mods,warns,notes,""")
rep("  const w=M.w;if(!w||!w.dmg)return '';", "  const w=M.w;if(!w||!w.dmg)return '';const dt=M.dt||w.dt;")
rep("  if(hit===false)return w.rel?`Надёжное: ${dmgStr(w.rel[M.t-1],w.dt)}`:'';\n  return `${dmgStr(base+extra,w.dt,modAP())}${per}`;",
    "  if(hit===false)return w.rel?`Надёжное: ${dmgStr(w.rel[M.t-1],dt)}`:'';\n  return `${dmgStr(base+extra,dt,modAP()||w.ap)}${per}`;")
rep("    <div class=\"stepper\"><span class=\"lbl\">${tLabel}</span>",
    "    ${M.w&&M.w.dtAlt?`<div class=\"stepper\"><span class=\"lbl\">Тип урона</span><select id=\"mdt\">${M.w.dtAlt.map(k=>`<option value=\"${k}\" ${k===M.dt?'selected':''}>${DT[k][2]}</option>`).join('')}</select></div>`:''}\n    ${M.multi>1||M.multiWhy?`<div class=\"${M.multi>1?'info':'warn'}\">Атак за раз: ${M.multi}${M.multiWhy?' — '+esc(M.multiWhy):''}</div>`:''}\n    <div class=\"stepper\"><span class=\"lbl\">${tLabel}</span>")
rep("<button class=\"btn red\" data-act=\"mroll\">⚄ ${r?'Бросить ещё':'Бросить'}</button></div>`;",
    "${M.multi>1?`<button class=\"btn red\" data-act=\"mroll2\">⚄ ${M.multi} атаки</button>`:''}<button class=\"btn red\" data-act=\"mroll\">⚄ ${r?'Бросить ещё':'Бросить'}</button></div>`;")
rep("    case 'mroll':doRoll();break;", "    case 'mroll':doRoll();break;\n    case 'mroll2':for(let k=0;k<M.multi;k++)doRoll();break;")
rep("  if(el.id==='addTeam'){S.addTeam=el.value;return}",
    "  if(el.id==='addTeam'){S.addTeam=el.value;return}\n  if(el.id==='mdt'&&M){const tg=document.getElementById('mtgt');if(tg)M.target=tg.value;M.dt=el.value;renderModal();return}")

# ---------------- glossary ----------------
rep(" [/^салаг/,", " [/^мягк\\S* укрыт/,'Мягкое (лёгкое) укрытие','Дальние атаки по цели в мягком укрытии получают +1 неточность.'],\n [/^салаг/,")

# ---------------- help ----------------
rep("   <li><b>Причины точности</b>:",
    "   <li><b>Отряд</b> (группа «Пехота»): Сила в Числе сама делит урон пополам, если не отмечено «по области»; Ошеломление не ставится; винтовки дают 2 атаки (одну, если ПЗ меньше половины, кроме Дисциплинированного); тип урона выбирается в окне атаки; Бронированный сам даёт +1 Броню; Сидящие в Засаде сами дают +2 точность в раунде 1.</li>\n   <li><b>Причины точности</b>:")

open(p, 'w', encoding='utf-8').write(s)
print('ok')
