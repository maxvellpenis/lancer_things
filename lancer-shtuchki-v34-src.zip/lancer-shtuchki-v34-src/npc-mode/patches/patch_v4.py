import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()

def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        raise SystemExit(f'expected {count}, found {n}: {old[:90]!r}')
    s = s.replace(old, new)

# ---- version
rep("<title>НПС Терминал v3</title>", "<title>НПС Терминал v4</title>")
rep("const APP_VERSION='v3';", "const APP_VERSION='v4';")

# ---- CSS additions
rep(".badge{font-size:11px;", ".info{color:var(--gold);font-weight:800;font-size:12px}\n.why{background:var(--bg);border:1px solid var(--line);padding:6px 8px;margin:8px 0;font-size:12.5px}\n.why div{margin:1px 0}\n.mods label.fixed{opacity:.85}\n.badge{font-size:11px;")

# ---- conditions list + migration
rep("const CONDS=['Ослаблен','Обездвижен','Замедлен','Ошеломлен','Заклинен','Захват цели','Разорван','Уязвим','Сбит с ног','Скрыт','Невидим','Отключён','Вовлечён','Схвачен'];",
    "const CONDS=['Ослаблен','Обездвижен','Замедлен','Ошеломлен','Заклинен','Захват','Расщеплен','Уязвим','Сбит с ног','Скрыт','Невидим','Выключен','Вовлечён','Схвачен'];\nconst COND_RENAME={'Захват цели':'Захват','Разорван':'Расщеплен','Отключён':'Выключен'};")
rep("  i.structMax=i.structMax||Math.max(1,i.struct||1);i.hideTypes=i.hideTypes||['kin','exp'];",
    "  i.structMax=i.structMax||Math.max(1,i.struct||1);i.hideTypes=i.hideTypes||['kin','exp'];\n  i.conds=[...new Set(i.conds.map(c=>COND_RENAME[c]||c))];")

# ---- glossary: statuses & conditions from the book
rep(""" [/^ослаб/,'Ослаблен','+1 неточность ко всем атакам, спасброскам и проверкам навыков. В программе учитывается автоматически.'],
 [/^обездвиж/,'Обездвижен','Не может перемещаться сам (принудительное перемещение работает).'],
 [/^замедл/,'Замедлен','Только обычное движение: нельзя Ускоряться и перемещаться иными способами.'],
 [/^ошелом/,'Ошеломлён','Не может двигаться и действовать, даже реакциями. Уклонение 5, автопровал проверок и спасбросков Корпуса и Манёвра.'],
 [/^заклин/,'Заклинен','Нельзя использовать оружие и реакции; только базовые действия вроде движения, Хватания, Тарана и Импровизированной атаки.'],
 [/^захват цели|^захвач|^захват$/,'Захват цели','Следующий, кто атакует эту цель, может снять Захват и получить +1 точность.'],
 [/^разорван|^расщеп/,'Разорван (Расщеплён)','Не может использовать Броню и Сопротивляемость. В программе учитывается при нанесении урона.'],
 [/^уязвим/,'Уязвим','Получаемый кинетический, взрывной и энергетический урон удваивается. НИП становится Уязвимым при перегреве. Снимается Стабилизацией.'],
 [/^сбит/,'Сбит с ног','Атаки по цели получают +1 точность; цель Замедлена. Чтобы встать, тратится движение.'],
 [/^скры/,'Скрыт','Скрытого нельзя выбрать целью атаки напрямую. Снимается Поиском или когда персонаж атакует.'],
 [/^невидим/,'Невидим','Перед атакой по невидимому бросьте d6: на 1–3 атака промахивается.'],
 [/^отключ/,'Отключён','Мех выключен и не действует, пока его не запустят снова.'],
 [/^вовлеч/,'Вовлечён','Рядом с враждебным персонажем. Дальние атаки получают +1 неточность.'],""",
""" [/^ослаб/,'Ослабление (состояние)','+1 неточность ко всем атакам, спасброскам и проверкам навыков. В программе добавляется само.'],
 [/^обездвиж/,'Обездвиженность (состояние)','Не может совершать никаких произвольных движений; на непроизвольные (например, толчки) это не распространяется.'],
 [/^замедл/,'Замедление (состояние)','Только стандартное перемещение в свой ход: нельзя Ускоряться и совершать особые перемещения от талантов, систем и оружия.'],
 [/^ошелом/,'Ошеломление (состояние)','Мех не может Перегружаться, перемещаться и предпринимать какие-либо действия, включая свободные действия и реакции. Уклонение максимум 5, автопровал всех проверок и спасбросков Корпуса и Манёвренности.'],
 [/^заклин/,'Заклинивание (состояние)','Нельзя: пользоваться связью; атаковать, кроме Импровизированной атаки, Хватания и Тарана; принимать реакции; получать выгоду от технических действий.'],
 [/^захват цели|^захвач|^захват$/,'Захват (состояние)','Враги могут по выбору снять Захват и получить +1 точность к своей следующей атаке против этого персонажа. Также нужен для некоторых талантов и систем.'],
 [/^разорван|^расщеп/,'Расщепление (состояние)','Не получает преимуществ от Брони и Сопротивляемости. В программе учитывается при нанесении урона.'],
 [/^уязвим/,'Уязвимость (статус, только мехи)','Кинетический, взрывной и энергетический урон удваивается до любых уменьшений. НИП становится Уязвимым при перегреве. Снимается Стабилизацией.'],
 [/^сбит/,'Сбивание (статус)','Атаки по сбитому получают +1 точность. Сбитый Замедлен и движется как по труднопроходимой местности. Встать — потратить стандартное перемещение (если не Обездвижен); подъём не вызывает Наблюдение.'],
 [/^скры/,'Скрытность (статус)','Скрытого нельзя сделать целью вражеских атак и действий, он не вовлекается; враги знают только примерное место. Атака, спасбросок, реакция, Ускорение и потеря укрытия снимают Скрытность. Найти — Поиском.'],
 [/^невидим/,'Невидимость (статус)','Все атаки по невидимому имеют 50% шанс промахнуться до броска атаки (d6: 1–3 — промах). Невидимый всегда может спрятаться, даже без укрытия.'],
 [/^отключ|^выключ/,'Выключение (статус, только мехи)','Сбрасывается нагрев и Уязвимость; статусы и состояния от технических действий (например, Захват) прекращаются; невосприимчив ко всем техническим действиям и атакам. Ошеломлён, пока Выключен.'],
 [/^вовлеч/,'Вовлечение (статус)','Рядом с враждебным персонажем. Дальние атаки Вовлечённого получают +1 неточность. Становясь Вовлечённым с целью равного или большего Размера, персонаж прекращает перемещение.'],
 [/^опасн\\S* зон/,'Опасная зона (статус, только мехи)','Нагрев на половине Теплового Максимума или выше. Позволяет использовать некоторые атаки, таланты и эффекты. Включается сам.'],
 [/^нокаут/,'Нокаут (только пилоты)','Пилот без сознания и Ошеломлён; если получит ещё урон — умрёт.'],
 [/^салаг/,'Салага','Шаблон: 1 ПЗ, 1 Структура и 1 Нагрузка; не получает урона при успешном спасброске; уничтожается от внешнего нагрева.'],
 [/^ветеран/,'Ветеран','Шаблон (пока не добавлен в программу).'],
 [/^дополнительн\\S* урон/,'Дополнительный урон','Добавочный кин./взр./энерг. урон к атакам. Если атака направлена более чем на одного персонажа — только половина.'],
 [/^стойкост/,'Стойкость','Половина УЛ персонажа (округление вверх).'],""")
rep(" [/^сопротивл/,'Сопротивляемость','Урон уменьшается вдвое (после Брони, с округлением вверх).'],",
    " [/^сопротивл/,'Сопротивляемость','Урон этого типа уменьшается вдвое (после Брони, округление вверх). Не суммируется.'],")
rep(" [/^невосприимч/,'Невосприимчивость','Указанный урон или эффект полностью игнорируется.'],",
    " [/^невосприимч/,'Невосприимчивость','Игнорирует весь урон и эффекты, к которым есть Невосприимчивость.'],")
rep(" [/^угроз/,'Угроза','Досягаемость ближнего боя; в этой зоне срабатывает Наблюдение.'],",
    " [/^угроз/,'Угроза','Максимальная дальность ближнего боя и Наблюдения. Всё оружие имеет Угрозу 1, если не указано иное.'],")
rep(" [/^брон/,'Броня','Уменьшает каждый полученный урон на это число (кроме ББ, горения и тепла).'],",
    " [/^брон/,'Броня','Уменьшает кинетический, взрывной и энергетический урон на своё значение (максимум 4). Не действует на ББ, горение и тепло.'],")
rep(" [/^тепл/,'Тепло','Нагрев меха. Превышение Теплового Максимума — перегрев.'],",
    " [/^тепл|^нагрев/,'Нагрев','Не урон: игнорирует Броню, но на него влияет Невосприимчивость. У кого нет Тепл.Макс — эквивалентный энергетический урон.'],")
rep(" [/^элит/,'Элита','Шаблон более сильного врага (см. книгу).'],",
    " [/^элит/,'Элита','Шаблон (пока не добавлен в программу).'],")
rep(" [/^ультр/,'Ультра','Шаблон очень сильного врага (см. книгу).'],",
    " [/^ультр/,'Ультра','Шаблон (пока не добавлен в программу).'],")
rep(" [/^отряд/,'Отряд','Шаблон для группы мелких персонажей (см. книгу).'],",
    " [/^отряд/,'Отряд','Шаблон (пока не добавлен в программу).'],")

# ---- grunt template
rep("""/* Общие действия НИП */""", """TEMPLATES.push({id:'grunt',name:'Салага',hp:1,structCap:1,stressCap:1,heatKills:1,saveNoDamage:1,excludes:['veteran','squad','elite','ultra'],
 desc:'Салаги стоят на ступень выше пушечного мяса. Обычно они выходят на поле боя на серийно выпускаемых или стоковых мехах, обученных дисциплине, а не мастерству. Сами по себе Салаги могут не представлять угрозы, но в группе они становятся подавляющей массой тел и снарядов, угрожающей даже самым сильным врагам.',
 features:[
  {id:'g-chaff',name:'Отбросы',tags:'Особенность Шаблона',text:'Салага имеет **1 ПЗ** и не может получить больше. В отличие от других персонажей, они никогда не получают урона при успешном спасброске — независимо от используемого оружия или системы — но в остальном получают урон как обычно. В программе: галочка «спас пройден» у урона.'},
  {id:'g-weak',name:'Слабый',tags:'Особенность Шаблона',text:'У Салаги никогда не может быть больше **1 Структуры** и **1 Нагрузки**, и они немедленно уничтожаются, когда получают **нагрев** из любого источника, кроме их собственных систем и оружия. В программе: «Нанести» с типом «Тепло» уничтожает; кнопки ± тепла — свой нагрев.'},
  {id:'g-rank',name:'Рядовой состав',tags:'Особенность Шаблона',text:'Салага не может взять шаблоны **Ветеран**, **Отряд**, **Элита** или **Ультра**.'}
 ]});

/* Общие действия НИП */""")

# ---- template helpers: flags, effective stats, conflicts
rep("function flagsOf(tplIds){const f={};tplIds.map(tpl).filter(Boolean).forEach(t=>{if(t.noGrapple)f.noGrapple=1;if(t.noMelee)f.noMelee=1;if(t.setTag)f.tag=t.setTag});return f}",
    """function flagsOf(tplIds){const f={};tplIds.map(tpl).filter(Boolean).forEach(t=>{['noGrapple','noMelee','structCap','stressCap','heatKills','saveNoDamage'].forEach(k=>{if(t[k])f[k]=t[k]});if(t.setTag)f.tag=t.setTag});return f}
function effStats(c,t,tplIds){const st={...c.tiers[t-1]};(tplIds||[]).map(tpl).filter(Boolean).forEach(tp=>{if(tp.hp!=null)st.hp=tp.hp});return st}
function tplConflict(tp,selIds){for(const id of selIds){if(id===tp.id)continue;const o=tpl(id);if(!o)continue;if((tp.excludes||[]).includes(id)||(o.excludes||[]).includes(tp.id))return o.name}return null}""")
rep("function stOf(i){return cls(i.cls).tiers[i.tier-1]}", "function stOf(i){return effStats(cls(i.cls),i.tier,i.tpls)}")

# library uses effective stats
rep("  const t=S.tier,st=c.tiers[t-1],sel=getSel(c.id),ts=getTplSel(c.id),isCustom=S.custom.includes(c);",
    "  const t=S.tier,sel=getSel(c.id),ts=getTplSel(c.id),st=effStats(c,t,ts.tpls),isCustom=S.custom.includes(c);")
# template card: conflicts
rep("  const ok=tplApplicable(tp,c),on=ts.tpls.includes(tp.id);",
    "  const conf=tplConflict(tp,ts.tpls),ok=tplApplicable(tp,c)&&!conf,on=ts.tpls.includes(tp.id);")
rep("   <div class=\"sys-b\">${!ok?`<p class=\"warn\">Не подходит: у этого НИП нет метки «${esc(tp.requiresTag)}».</p>`:''}",
    "   <div class=\"sys-b\">${!ok?`<p class=\"warn\">${conf?`Несовместим с шаблоном «${esc(conf)}».`:`Не подходит: у этого НИП нет метки «${esc(tp.requiresTag)}».`}</p>`:''}")
rep("    case 'tpick':{const ts=getTplSel(S.cls),id=el.dataset.v,k=ts.tpls.indexOf(id);k<0?ts.tpls.push(id):ts.tpls.splice(k,1);render();break}",
    "    case 'tpick':{const ts=getTplSel(S.cls),id=el.dataset.v,k=ts.tpls.indexOf(id);if(k<0){if(tplConflict(tpl(id),ts.tpls))break;ts.tpls.push(id)}else ts.tpls.splice(k,1);render();break}")
# add to encounter: effective hp
rep("  const c=cls(S.cls);if(!c)return;const st=c.tiers[S.tier-1],ts=getTplSel(c.id);",
    "  const c=cls(S.cls);if(!c)return;const ts=getTplSel(c.id),st=effStats(c,S.tier,ts.tpls);")

# ---- instance card
rep("  const st=c.tiers[i.tier-1],t=i.tier,tm=team(i.team);", "  const st=stOf(i),t=i.tier,tm=team(i.team);")
rep("""  if(hasCond(i,'Ошеломлен'))warns.push('Ошеломлён: не действует, Уклонение 5');""",
    """  const stunned=hasCond(i,'Ошеломлен')||hasCond(i,'Выключен');
  if(hasCond(i,'Выключен'))warns.push('Выключен: Ошеломлён, невосприимчив к техническим действиям и атакам');
  else if(hasCond(i,'Ошеломлен'))warns.push('Ошеломлён: не действует, Уклонение максимум 5');
  if(hasCond(i,'Сбит с ног'))warns.push('Сбит с ног: Замедлен, встать — стандартное перемещение');
  if(hasCond(i,'Скрыт'))warns.push('Скрыт: атака, спасбросок, реакция или Ускорение снимут Скрытность');""")
rep("  if(hasCond(i,'Отключён'))warns.push('Отключён');\n", "")
rep("   ${warns.map(w=>`<div class=\"warn\">${esc(w)}</div>`).join('')}\n   <div class=\"mini\">",
    "   ${st.heat&&i.heat*2>=st.heat?`<div class=\"info kw\"${tipAttr(tipFor('Опасная зона'))}>Опасная зона (нагрев ≥ ½)</div>`:''}\n   ${warns.map(w=>`<div class=\"warn\">${esc(w)}</div>`).join('')}\n   <div class=\"mini\">")
rep("   <div class=\"mini-core\" style=\"margin-top:6px\">${CORE.filter(x=>!['hp','heat','size'].includes(x[0])).map(([k,l])=>`<span${tipAttr(tipFor(l))}>${l} <b>${fmtStat(st[k])}</b></span>`).join('')}</div>\n   <div class=\"sk\" style=\"margin-top:6px\">${SKILLS.map(([k,l])=>`<button class=\"skbtn\" data-act=\"check\" data-skill=\"${k}\" data-src=\"inst:${i.uid}\">",
    "   <div class=\"mini-core\" style=\"margin-top:6px\">${CORE.filter(x=>!['hp','heat','size'].includes(x[0])).map(([k,l])=>`<span${tipAttr(tipFor(l))}>${l} <b>${k==='evasion'&&stunned?`${Math.min(5,st[k])} <span class=\"warn\">(Ошеломлён)</span>`:fmtStat(st[k])}</b></span>`).join('')}</div>\n   <div class=\"sk\" style=\"margin-top:6px\">${SKILLS.map(([k,l])=>`<button class=\"skbtn\" data-act=\"check\" data-skill=\"${k}\" data-src=\"inst:${i.uid}\">")
rep("     <label class=\"kw\" data-tt=\"Сопротивляемость\" data-tip=\"Урон делится пополам (после Брони, округление вверх). Например, после реакции Пригнуться.\"><input type=\"checkbox\" id=\"half-${i.uid}\"> Сопр. ½</label>",
    "     <label class=\"kw\" data-tt=\"Сопротивляемость\" data-tip=\"Урон делится пополам (после Брони, округление вверх). Например, после реакции Пригнуться.\"><input type=\"checkbox\" id=\"half-${i.uid}\"> Сопр. ½</label>\n     ${flags.saveNoDamage?`<label class=\"kw\" data-tt=\"Отбросы (Салага)\" data-tip=\"Если Салага прошёл спасбросок против этого эффекта — урона нет совсем.\"><input type=\"checkbox\" id=\"save-${i.uid}\"> спас пройден</label>`:''}")

# ---- damage logic
rep("  const st=stOf(i),shred=hasCond(i,'Разорван'),parts=[`${n} ${DT[dt][0]}`];if(note)parts.push(note);",
    "  const st=stOf(i),shred=hasCond(i,'Расщеплен'),parts=[`${n} ${DT[dt][0]}`];if(note)parts.push(note);")
rep("  if(shred&&st.armor)parts.push('броня не работает (Разорван)');", "  if(shred&&st.armor)parts.push('броня не работает (Расщеплён)');")
rep("""  if(dt==='heat'){const st=stOf(i);if(st.heat)""",
    """  const fl=flagsOf(i.tpls),sv=document.getElementById('save-'+i.uid);
  if(fl.saveNoDamage&&sv&&sv.checked){addLog('hit',logHead(i.label+' — Отбросы')+`<div class="bd">Спасбросок пройден — Салага не получает урона (${n} ${DT[dt][0]} проигнорировано)</div>`);render();return}
  if(dt==='heat'&&fl.heatKills&&i.struct>0){i.struct=0;i.hp=0;addLog('miss',logHead(i.label+' — Слабый')+`<div class="verdict miss">Получил нагрев извне — УНИЧТОЖЕН</div>`);render();return}
  if(dt==='heat'){const st=stOf(i);if(st.heat)""")

# ---- change handler: caps for grunt
rep("  else{I[f]=+el.value||0;if(f==='struct')I.structMax=Math.max(I.structMax||1,I.struct);if(f==='hp')checkHp(I)}",
    "  else{I[f]=+el.value||0;const fl=flagsOf(I.tpls);if(f==='struct'&&fl.structCap)I.struct=Math.min(I.struct,fl.structCap);if(f==='stress'&&fl.stressCap)I.stress=Math.min(I.stress,fl.stressCap);if(f==='hp')I.hp=Math.min(I.hp,stOf(I).hp);if(f==='struct')I.structMax=Math.max(I.structMax||1,I.struct);if(f==='hp')checkHp(I)}")
rep("    case 'hp':I.hp+= +el.dataset.d;checkHp(I);render();break;",
    "    case 'hp':I.hp=Math.min(stOf(I).hp,I.hp+ +el.dataset.d);checkHp(I);render();break;")

# ---- condition toggle: Выключен side effects
rep("    case 'cond':{const k=I.conds.indexOf(el.dataset.v);k<0?I.conds.push(el.dataset.v):I.conds.splice(k,1);render();break}",
    """    case 'cond':{const v=el.dataset.v,k=I.conds.indexOf(v);
      if(k<0){I.conds.push(v);
        if(v==='Выключен'){I.heat=0;I.conds=I.conds.filter(c=>c!=='Уязвим'&&c!=='Захват');addLog('',logHead(I.label+' — Выключен')+`<div class="bd">Нагрев сброшен, Уязвимость и Захват сняты. Ошеломлён, пока Выключен; невосприимчив к техническим действиям.</div>`)}
      }else I.conds.splice(k,1);render();break}""")

# ---- warnings in roll windows
rep("  if(hasCond(i,'Ошеломлен'))w.push(kind==='check'&&(skill==='hull'||skill==='agi')?'Ошеломлён: проверки Корпуса и Манёвра — автопровал.':'Ошеломлён: НИП не может действовать.');",
    "  const stn=hasCond(i,'Ошеломлен')||hasCond(i,'Выключен');\n  if(stn)w.push(kind==='check'&&(skill==='hull'||skill==='agi')?'Ошеломлён: проверки и спасброски Корпуса и Манёвренности — автопровал (учтено).':'Ошеломлён: НИП не может действовать.');\n  if(hasCond(i,'Заклинен')&&kind==='act')w.push('Заклинен: доступны только Импровизированная атака, Хватание и Таран.');")

# ---- accuracy / difficulty reasons: weapon inherent values become fixed mods
rep("  M={kind:'atk',title:s.name,who:x.label,bonus:s.w.atk[x.t-1],acc:s.w.acc||0,diff:s.w.diff||0,target:'',w:s.w,t:x.t,src,sysId:s.id,\n     mods:buildMods(x,'atk',s,s.w),warns,notes,perTarget:pt?pt.perTarget[x.t-1]:0,targets:1,loading:isLoading(s),res:null};",
    "  const mods=buildMods(x,'atk',s,s.w);\n  if(s.w.acc)mods.unshift({label:`Свойство оружия «${s.name}»`,acc:s.w.acc,on:true,fixed:1});\n  if(s.w.diff)mods.unshift({label:`Свойство оружия «${s.name}»`,diff:s.w.diff,on:true,fixed:1});\n  M={kind:'atk',title:s.name,who:x.label,bonus:s.w.atk[x.t-1],acc:0,diff:0,target:'',w:s.w,t:x.t,src,sysId:s.id,\n     mods,warns,notes,perTarget:pt?pt.perTarget[x.t-1]:0,targets:1,loading:isLoading(s),res:null};")
rep("  M={kind:'check',title:'Проверка / спасбросок: '+l,who:x.label,bonus:st[skill],acc:0,diff:0,target:'',t:x.t,src,\n     mods:buildMods(x,'check'),warns:baseWarns(x,'check',skill),notes:[],res:null};",
    "  const stn=x.i&&(hasCond(x.i,'Ошеломлен')||hasCond(x.i,'Выключен'))&&(skill==='hull'||skill==='agi');\n  M={kind:'check',title:'Проверка / спасбросок: '+l,who:x.label,bonus:st[skill],acc:0,diff:0,target:'',t:x.t,src,\n     mods:buildMods(x,'check'),warns:baseWarns(x,'check',skill),notes:[],res:null,autoFail:stn?'Ошеломлён: автопровал Корпуса и Манёвренности':''};")
# buildMods: better labels + invisibility
rep("  if(hasCond(i,'Ослаблен'))mods.push({label:'НИП Ослаблен',diff:1,on:true});",
    "  if(hasCond(i,'Ослаблен'))mods.push({label:'НИП Ослаблен (состояние)',diff:1,on:true,fixed:1});")
rep("    mods.push({label:'Цель под Захватом цели',acc:1,on:false});\n    if(kind==='atk')mods.push({label:'Цель Сбита с ног',acc:1,on:false});",
    "    mods.push({label:'Цель под Захватом (снимается этой атакой)',acc:1,on:false});\n    if(kind==='atk')mods.push({label:'Цель Сбита с ног',acc:1,on:false});\n    mods.push({label:'Цель Невидима (50% промах до броска)',invis:1,on:false});")
rep("    mods.push({label:'НИП Вовлечён (дальняя атака)',diff:1,on:hasCond(i,'Вовлечён')});",
    "    mods.push({label:'НИП Вовлечён (дальняя атака)',diff:1,on:hasCond(i,'Вовлечён'),fixed:hasCond(i,'Вовлечён')?1:0});")

# reasons helper
rep("const modAcc=()=>M.mods.reduce", """function whyLists(){
  const A=[],D=[];
  M.mods.forEach(m=>{if(!m.on)return;if(m.acc)A.push(`+${m.acc} — ${m.label}`);if(m.diff)D.push(`+${m.diff} — ${m.label}`)});
  if(M.acc)A.push(`+${M.acc} — вручную`);if(M.diff)D.push(`+${M.diff} — вручную`);
  return{A,D};
}
function whyText(){
  const {A,D}=whyLists(),acc=M.acc+modAcc(),diff=M.diff+modDiff(),net=acc-diff;
  const tail=net===0?(acc?'взаимно гасятся → чистый d20':'чистый d20'):net>0?`итог: +${net} точн. (наибольший из ${net}d6)`:`итог: +${-net} неточн. (минус наибольший из ${-net}d6)`;
  return{A,D,tail};
}
function whyHtml(){
  const {A,D,tail}=whyText();
  return `<div class="why"><div class="h muted" style="font-size:11px;text-transform:uppercase">Почему такая точность</div>
    <div class="acc">Точность: ${A.length?A.map(esc).join('; '):'нет'}</div>
    <div class="dif">Неточность: ${D.length?D.map(esc).join('; '):'нет'}</div>
    <div class="muted">${esc(tail)}</div></div>`;
}
const modAcc=()=>M.mods.reduce""")
# modal: show reasons, fixed mods, invisibility result, auto fail
rep("    ${M.mods.length?`<div class=\"mods\"><div class=\"h\">Учитывается автоматически — отметьте, что подходит</div>${M.mods.map((m,k)=>m.info?`<div class=\"muted\">✓ ${esc(m.label)}</div>`:`<label><input type=\"checkbox\" data-act=\"mod\" data-k=\"${k}\" ${m.on?'checked':''}> ${esc(m.label)}",
    "    ${M.mods.length?`<div class=\"mods\"><div class=\"h\">Модификаторы — серые стоят сами, остальные отметьте</div>${M.mods.map((m,k)=>m.info?`<div class=\"muted\">✓ ${esc(m.label)}</div>`:`<label class=\"${m.fixed?'fixed':''}\"><input type=\"checkbox\" data-act=\"mod\" data-k=\"${k}\" ${m.on?'checked':''} ${m.fixed?'disabled':''}> ${esc(m.label)}")
rep("    <div class=\"muted\" style=\"font-size:12px\">Итог: ${net===0?'чистый d20':net>0?`+ наибольший из ${net}d6`:`− наибольший из ${-net}d6`}</div>\n    <div class=\"stepper\"><span class=\"lbl\">${tLabel}</span>",
    "    ${whyHtml()}\n    <div class=\"stepper\"><span class=\"lbl\">${tLabel}</span>")
rep("  let res='';\n  if(r){\n    const accTxt",
    "  let res='';\n  if(r&&r.invisMiss){\n    res=`<div class=\"mres\"><div class=\"big\">—</div><div class=\"bd\">Невидимость: d6 [${r.die}] — 1–3, атака промахивается до броска</div><div class=\"vd verdict miss\">ПРОМАХ ${M.w?dmgLine(false):''}</div></div>`;\n  }else if(r){\n    const accTxt")
rep("    }else if(r.hit!==null)vd=`<div class=\"vd verdict ${r.hit?'hit':'miss'}\">${r.hit?'УСПЕХ':'ПРОВАЛ'}</div>`;\n    const notes=[];",
    "    }else if(r.hit!==null)vd=`<div class=\"vd verdict ${r.hit?'hit':'miss'}\">${r.hit?'УСПЕХ':'ПРОВАЛ'}</div>`;\n    if(r.autoFail)vd=`<div class=\"vd verdict miss\">АВТОПРОВАЛ — ${esc(r.autoFail)}</div>`;\n    const notes=[];\n    if(r.invisOk)notes.push(`Невидимость: d6 [${r.invisOk}] — атака состоялась`);\n    if(r.unhid)notes.push('НИП больше не Скрыт (атаковал).');")

# doRoll: invisibility pre-roll, auto-fail, unhide, reasons in log
rep("""  const acc=M.acc+modAcc(),diff=M.diff+modDiff();
  const d20=rnd(20),a=accRoll(acc,diff),total=d20+M.bonus+a.val;
  const hit=M.target!==''&&!isNaN(+M.target)?total>=+M.target:null;
  M.res={d20,a,total,hit};""",
"""  const acc=M.acc+modAcc(),diff=M.diff+modDiff();
  const {A,D,tail}=whyText();
  const whyLog=`<div class="bd">Точн.: ${A.length?esc(A.join('; ')):'нет'} · Неточн.: ${D.length?esc(D.join('; ')):'нет'} → ${esc(tail)}</div>`;
  let unhid=false;
  if(M.src&&M.src.startsWith('inst:')&&(M.kind==='atk'||M.kind==='tech')){const i=inst(M.src.slice(5));if(i&&hasCond(i,'Скрыт')){i.conds=i.conds.filter(c=>c!=='Скрыт');unhid=true;renderMain();save()}}
  let invisOk=0;
  if((M.kind==='atk'||M.kind==='tech')&&M.mods.some(m=>m.on&&m.invis)){
    const die=rnd(6);
    if(die<=3){
      M.res={invisMiss:true,die,hit:false};
      addLog('miss',logHead((M.who?M.who+' — ':'')+M.title)+`<div><span class="verdict miss">Промах — Невидимость</span> ${M.w?dmgLine(false):''}</div><div class="bd">d6 [${die}]: 1–3 — атака промахивается до броска${unhid?' · Скрытность снята':''}</div>`);
      renderModal();return;
    }
    invisOk=die;
  }
  const d20=rnd(20),a=accRoll(acc,diff),total=d20+M.bonus+a.val;
  let hit=M.target!==''&&!isNaN(+M.target)?total>=+M.target:null;
  if(M.autoFail)hit=false;
  M.res={d20,a,total,hit,autoFail:M.autoFail,invisOk,unhid};""")
rep("  }else if(hit!==null)v=`<span class=\"verdict ${hit?'hit':'miss'}\">${hit?'Успех':'Провал'}</span>`;\n  addLog(",
    "  }else if(hit!==null)v=`<span class=\"verdict ${hit?'hit':'miss'}\">${hit?'Успех':'Провал'}</span>`;\n  if(M.autoFail)v=`<span class=\"verdict miss\">Автопровал</span> (${esc(M.autoFail)})`;\n  addLog(")
rep("    <div class=\"bd\">d20[<span class=\"${d20===20?'nat20':d20===1?'nat1':''}\">${d20}</span>] ${sgn(M.bonus)}${accTxt}${M.target!==''?` vs ${esc(M.target)}`:''}</div>`);\n  renderModal();\n}",
    "    <div class=\"bd\">d20[<span class=\"${d20===20?'nat20':d20===1?'nat1':''}\">${d20}</span>] ${sgn(M.bonus)}${accTxt}${M.target!==''?` vs ${esc(M.target)}`:''}${invisOk?` · Невидимость d6[${invisOk}] — попал в 50%`:''}${unhid?' · Скрытность снята':''}</div>${whyLog}`);\n  renderModal();\n}")

# dmgLine: bonus damage halved vs several targets
rep("  const base=w.dmg[M.t-1]+modDmg(),extra=M.perTarget&&M.targets>1?M.perTarget*(M.targets-1):0;\n  const per=extra?` каждой из ${M.targets} целей (+${extra} Кассетные)`:'';",
    "  const add=M.targets>1&&modDmg()?Math.ceil(modDmg()/2):modDmg();\n  const base=w.dmg[M.t-1]+add,extra=M.perTarget&&M.targets>1?M.perTarget*(M.targets-1):0;\n  const per=(extra?` каждой из ${M.targets} целей (+${extra} Кассетные)`:'')+(M.targets>1&&modDmg()?` (доп. урон ½: несколько целей)`:'');")

# burn check reason wording
rep("${a.dice.length?` −${-a.val}[${a.dice}] Ослаблен`:''} vs 10</div>`);",
    "${a.dice.length?` −${-a.val}[${a.dice}]`:''} vs 10</div><div class=\"bd\">Неточн.: ${diff?'+1 — НИП Ослаблен (состояние)':'нет'} · Точн.: нет</div>`);")

# ---- help: statuses section + template notes
rep("   <li><b>Шаблоны</b>: Транспорт меняет метку Мех на Транспорт, отключает Хватание и предупреждает про ОББ.</li>",
    "   <li><b>Шаблоны</b>: Транспорт меняет метку Мех на Транспорт, отключает Хватание и предупреждает про ОББ. Салага: 1 ПЗ, Структура и Нагрузка не больше 1, «спас пройден» обнуляет урон, внешний нагрев уничтожает; несовместим с Ветераном, Отрядом, Элитой и Ультрой.</li>\n   <li><b>Причины точности</b>: в окне броска и в журнале всегда написано, откуда взялась каждая точность и неточность.</li>")
rep("  ${ACTIONS.map(g=>`<h4>${g.grp}</h4>",
    "  <h4>Статусы и состояния</h4><ul>${['Опасная зона',...CONDS].map(n=>{const g=tipFor(n);return g?`<li><b>${esc(g[1])}</b>: ${esc(g[2])}</li>`:''}).join('')}</ul>\n  ${ACTIONS.map(g=>`<h4>${g.grp}</h4>")

open(p, 'w', encoding='utf-8').write(s)
print('ok')
