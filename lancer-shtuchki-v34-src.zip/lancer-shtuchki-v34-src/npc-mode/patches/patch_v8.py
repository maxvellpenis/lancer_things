import sys, re
p = sys.argv[1]; sd = sys.argv[2]
s = open(p, encoding='utf-8').read()
def rd(n): return open(sd + '/' + n, encoding='utf-8').read()

def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        raise SystemExit(f'expected {count}, found {n}: {old[:100]!r}')
    s = s.replace(old, new)

rep("<title>НПС Терминал v7</title>", "<title>НПС Терминал v8</title>")
rep("const APP_VERSION='v7';", "const APP_VERSION='v8';")

# ---------------- data ----------------
classes = rd('data_a.js') + rd('data_b.js') + rd('data_c.js') + rd('data_d.js') + rd('data_e.js')
rep("\nconst MONSTER_TABLE=[", "\n/* ---------- v8: остальные классы из книги (стр. 298–322) ---------- */\nBUILTIN.push(\n" + classes + "\n);\n\nconst MONSTER_TABLE=[")
rep("/* Общие действия НИП */\nconst ACTIONS=[", rd('data_tpl.js') + "\n/* Общие действия НИП */\nconst ACTIONS=[")

# book fixes
rep("Персонажи в последующем взрыве Взрыв 2 получают **2/4/6 кин.**", "Персонажи в последующем взрыве Взрыв 2 получают **2/4/6 горения**")
rep("w:{atk:[0,0,0],rng:'Дальн. 3, Угроза 3, Конус 3',dmg:[2,3,4],dt:'kin'},\n   effect:'Атаки этим оружием",
    "w:{atk:[0,0,0],rng:'Дальн. 3, Угроза 3, Конус 3',dmg:[2,3,4],dt:'kin'},\n   effect:'В книге бонус к атаке не указан — стоит +0. Атаки этим оружием")
rep("Если несколько персонажей находятся на одинаковом расстоянии, этот эффект не работает. В бою",
    "Если несколько персонажей находятся на одинаковом расстоянии, этот эффект не работает (в русском издании опечатка «работает»; тактика класса подтверждает «не работает»). В бою")
rep("  {id:'flare',name:'Сигнальный Дрон',", "  {id:'flare',name:'Сигнальный Дрон',")  # sanity
rep("{id:'siegearmor',name:'Осадная Броня',type:'trait',tags:'Черта',text:",
    "{id:'siegearmor',name:'Осадная Броня',type:'trait',tags:'Черта',resist:{types:'all',when:'far3'},text:")
rep(" id:'monster',name:'Чудовище',role:'Биологический',icon:'☠',tag:'Биологический',group:'Монстры',",
    " id:'monster',name:'Чудовище',role:'Биологический',icon:'☠',tag:'Биологический',group:'Монстры',noTech:1,")
rep(" id:'squad',name:'Отряд',role:'Биологический',icon:'⁂',tag:'Биологический',group:'Пехота',",
    " id:'squad',name:'Отряд',role:'Биологический',icon:'⁂',tag:'Биологический',group:'Пехота',noTech:1,")
rep(" humanTpl:1,structCap:1,optMax:1,optLabel:'Кастомизация',",
    " noTpl:1,noTech:1,structCap:1,optLabel:'Кастомизация',optRules:[{ids:['hm-ranged','hm-melee','hm-ap'],max:1,label:'оружие'},{ids:['hm-vet','hm-armor1','hm-armor2'],max:1,label:'Ветеран или Бронированный'}],")
# Squad: per book (p.323) only Salaga/Veteran/Ultra are forbidden — already so.

# ---------------- template & system helpers ----------------
rep("const findSys=(c,id)=>[...(c.base||[]),...(c.optional||[])].find(s=>s.id===id);",
    "function findSys(c,id){return [...(c.base||[]),...(c.optional||[]),...allTpl().flatMap(t=>[...(t.features||[]),...tplItems(t)])].find(s=>s.id===id)}\n"
    "function tplGroups(tp){return tp.groups||(tp.choices?[{label:tp.choiceLabel||'Опции',min:tp.choiceMin||0,items:tp.choices}]:[])}\n"
    "function tplItems(tp){return tplGroups(tp).flatMap(g=>g.items)}\n"
    "const grpMax=(g,t)=>g.max==='tier'?t:g.max;\n"
    "function tplSystems(tplIds,ch){const out=[];(tplIds||[]).map(tpl).filter(Boolean).forEach(tp=>{(tp.features||[]).forEach(f=>out.push({...f,type:f.type||'tpl',_tpl:tp.name}));tplItems(tp).filter(x=>(ch||[]).includes(x.id)).forEach(x=>out.push({...x,type:x.type||'tpl',_tpl:tp.name}))});return out}\n"
    "const classSystems=(c,opts)=>[...(c.base||[]),...(c.optional||[]).filter(o=>(opts||[]).includes(o.id))];\n"
    "const libSystems=c=>{const ts=getTplSel(c.id);return [...classSystems(c,getSel(c.id)),...tplSystems(ts.tpls,ts.ch)]};")
rep("const instSystems=i=>{const c=cls(i.cls);return c?[...(c.base||[]),...(c.optional||[]).filter(o=>i.opts.includes(o.id))]:[]};",
    "const instSystems=i=>{const c=cls(i.cls);return c?[...classSystems(c,i.opts),...tplSystems(i.tpls,i.tplCh)]:[]};")
rep("function tplBlockReason(t,c){if(t.requiresTag&&c.tag!==t.requiresTag)",
    "function tplBlockReason(t,c){if(c.noTpl)return `${c.name}: люди никогда не могут иметь шаблоны.`;if(t.requiresTag&&c.tag!==t.requiresTag)")
rep("function flagsOf(tplIds){const f={};tplIds.map(tpl).filter(Boolean).forEach(t=>{['noGrapple','noMelee','structCap','stressCap','heatKills','saveNoDamage'].forEach(k=>{if(t[k])f[k]=t[k]});if(t.setTag)f.tag=t.setTag});return f}",
    "function flagsOf(tplIds,ch){const f={};(tplIds||[]).map(tpl).filter(Boolean).forEach(t=>{['noGrapple','noMelee','structCap','stressCap','heatKills','saveNoDamage','legendary'].forEach(k=>{if(t[k])f[k]=t[k]});if(t.activations)f.activations=Math.max(f.activations||1,t.activations);if(t.setTag)f.tag=t.setTag});tplSystems(tplIds,ch).forEach(x=>{if(x.setTag)f.tag=x.setTag;if(x.legendary)f.legendary=1});return f}")
rep("function effStats(c,t,tplIds,opts){const st={...c.tiers[t-1]};(c.optional||[]).filter(o=>(opts||[]).includes(o.id)&&o.statMod).forEach(o=>Object.entries(o.statMod).forEach(([k,v])=>{st[k]=(+st[k]||0)+v}));(tplIds||[]).map(tpl).filter(Boolean).forEach(tp=>{if(tp.hp!=null)st.hp=tp.hp});return st}",
    """function effStats(c,t,tplIds,opts,ch){const st={...c.tiers[t-1]};
  const add=src=>src.forEach(o=>{if(o.statMod)Object.entries(o.statMod).forEach(([k,v])=>{st[k]=(+st[k]||0)+(Array.isArray(v)?v[t-1]:v)});if(o.statSet)Object.assign(st,o.statSet);if(o.hpAdd)st.hp+=o.hpAdd});
  const tps=(tplIds||[]).map(tpl).filter(Boolean),tsys=tplSystems(tplIds,ch);
  add((c.optional||[]).filter(o=>(opts||[]).includes(o.id)));
  tps.forEach(tp=>{if(tp.hpAdd)st.hp+=tp.hpAdd;if(tp.sizeSet)st.size=tp.sizeSet});
  add(tsys);
  [...(c.optional||[]).filter(o=>(opts||[]).includes(o.id)),...tsys].forEach(o=>{if(o.statCap)Object.entries(o.statCap).forEach(([k,v])=>{st[k]=Math.min(st[k],v)})});
  tps.forEach(tp=>{if(tp.hp!=null)st.hp=tp.hp});
  return st}""")
rep("const tagOf=(c,tplIds)=>flagsOf(tplIds).tag||c.tag||'';", "const tagOf=(c,tplIds,ch)=>flagsOf(tplIds,ch).tag||c.tag||'';")

# callers
rep("flagsOf(ts.tpls)", "flagsOf(ts.tpls,ts.ch)", count=s.count("flagsOf(ts.tpls)"))
rep("flagsOf(i.tpls)", "flagsOf(i.tpls,i.tplCh)", count=s.count("flagsOf(i.tpls)"))
rep("flagsOf(I.tpls)", "flagsOf(I.tpls,I.tplCh)", count=s.count("flagsOf(I.tpls)"))
rep("const tagNow=tagOf(c,ts.tpls);", "const tagNow=tagOf(c,ts.tpls,ts.ch);")
rep("tagOf(c,i.tpls)", "tagOf(c,i.tpls,i.tplCh)")
rep("st=effStats(c,t,ts.tpls,sel),isCustom", "st=effStats(c,t,ts.tpls,sel,ts.ch),isCustom")
rep("function stOf(i){return effStats(cls(i.cls),i.tier,i.tpls,i.opts)}",
    "function stOf(i){const s=effStats(cls(i.cls),i.tier,i.tpls,i.opts,i.tplCh);if(i.armorLoss)s.armor=Math.max(0,(+s.armor||0)-i.armorLoss);return s}\n"
    "function activationsOf(i){return (flagsOf(i.tpls,i.tplCh).activations||1)+(i.ultra3?1:0)}")
rep("  if(src==='lib'){const c=cls(S.cls);const ts=getTplSel(c.id);return{c,t:S.tier,label:c.name+' Г'+S.tier,flags:flagsOf(ts.tpls,ts.ch),sys:[...c.base,...c.optional.filter(o=>getSel(c.id).includes(o.id))]}}",
    "  if(src==='lib'){const c=cls(S.cls);const ts=getTplSel(c.id);return{c,t:S.tier,label:c.name+' Г'+S.tier,flags:flagsOf(ts.tpls,ts.ch),sys:libSystems(c)}}")

# migration of old saves
rep("  i.conds=[...new Set(i.conds.map(c=>COND_RENAME[c]||c))];",
    "  i.conds=[...new Set(i.conds.map(c=>COND_RENAME[c]||c))];\n  i.stressMax=i.stressMax||Math.max(1,i.stress||1);i.counters=i.counters||{};i.pickRes=i.pickRes||{};i.turns=i.turns||0;")

# ---------------- library: template card with groups, warnings ----------------
rep("""  ts.tpls.map(tpl).filter(Boolean).forEach(tp=>{if(tp.choiceMin&&ts.ch.filter(id=>(tp.choices||[]).some(x=>x.id===id)).length<tp.choiceMin)warns.push(`Шаблон «${tp.name}»: выберите ${tp.choiceLabel?tp.choiceLabel.toLowerCase().replace(/\\s*\\(.*\\)/,''):'опцию'}.`)});""",
"""  ts.tpls.map(tpl).filter(Boolean).forEach(tp=>tplGroups(tp).forEach(g=>{const n=ts.ch.filter(id=>g.items.some(x=>x.id===id)).length,mx=grpMax(g,t);
    if(g.min&&n<g.min)warns.push(`Шаблон «${tp.name}»: выберите — ${g.label.replace(/\\s*\\(.*\\)/,'')}.`);if(mx&&n>mx)warns.push(`Шаблон «${tp.name}»: слишком много — ${g.label} (максимум ${mx}).`)}));
  (c.optRules||[]).forEach(r=>{const n=sel.filter(id=>r.ids.includes(id)).length;if(n>r.max)warns.push(`Выберите только одно: ${r.label}.`)});
  const optLimit=2+ts.tpls.reduce((a,id)=>a+((tpl(id)||{}).extraOpt||0),0)+(ts.tpls.includes('ultra')?2:0);
  if(!c.optRules&&sel.length>optLimit)warns.push(`По книге обычно 0–2 доп. системы (+1 Элите, +1–2 Ультра); сейчас ${sel.length}.`);""")
rep("""     ${(tp.choices||[]).length?`<div class="agrp">${esc(tp.choiceLabel||'Опции')}</div>${tp.choices.map(ch=>`<div class="tchoice" data-act="tch" data-v="${esc(ch.id)}"><input type="checkbox" class="chk" ${ts.ch.includes(ch.id)?'checked':''} tabindex="-1" style="pointer-events:none"><div><b>${esc(ch.name)}</b> <span class="tag-s">${tagsHtml(ch.tags)}</span><div>${fmt(ch.text,t)}</div></div></div>`).join('')}`:''}`:''}""",
"""     ${tplGroups(tp).map(g=>{const n=ts.ch.filter(id=>g.items.some(x=>x.id===id)).length,mx=grpMax(g,t);return `<div class="agrp">${esc(g.label)} <span class="muted">— выбрано ${n}${mx?' из '+mx:''}</span></div>${g.items.map(ch=>{const bad=ch.onlyTag&&c.tag!==ch.onlyTag;return `<div class="tchoice" ${bad?'style="opacity:.4"':`data-act="tch" data-v="${esc(ch.id)}" data-tp="${esc(tp.id)}"`}><input type="checkbox" class="chk" ${ts.ch.includes(ch.id)?'checked':''} tabindex="-1" style="pointer-events:none"><div><b>${esc(ch.name)}</b> <span class="tag-s">${tagsHtml(ch.tags)}</span>${ch.w?weaponProfile(ch.w,t):''}<div>${fmt(ch.text||ch.effect||'',t)}</div>${ch.trigger?`<div><b>Триггер:</b> ${fmt(ch.trigger,t)}</div><div><b>Эффект:</b> ${fmt(ch.effect,t)}</div>`:''}${bad?`<div class="warn">Только для метки «${esc(ch.onlyTag)}».</div>`:''}</div></div>`}).join('')}`}).join('')}`:''}""")
rep("    case 'tch':{const ts=getTplSel(S.cls),id=el.dataset.v,k=ts.ch.indexOf(id);k<0?ts.ch.push(id):ts.ch.splice(k,1);render();break}",
    """    case 'tch':{const ts=getTplSel(S.cls),id=el.dataset.v,k=ts.ch.indexOf(id);
      if(k>=0){ts.ch.splice(k,1);render();break}
      const tp=tpl(el.dataset.tp),g=tp&&tplGroups(tp).find(g=>g.items.some(x=>x.id===id)),mx=g&&grpMax(g,S.tier);
      if(g&&mx){const inG=ts.ch.filter(x=>g.items.some(y=>y.id===x));if(inG.length>=mx){if(mx===1)ts.ch.splice(ts.ch.indexOf(inG[0]),1);else{alert(`Можно выбрать не больше ${mx}: ${g.label}`);break}}}
      ts.ch.push(id);render();break}""")
rep("  ${c.desc?`<p class=\"desc\">${fmt(c.desc)}</p>`:''}\n  ${statBlock(st,'lib')}",
    "  ${c.desc?`<p class=\"desc\">${fmt(c.desc)}</p>`:''}\n  ${c.statNote?`<p class=\"warn\">${esc(c.statNote)}</p>`:''}\n  ${c.noTech?`<p class=\"muted\">Биологический: нет Теплового Максимума, невосприимчив к техническим действиям (кроме Сканирования и Захвата), сам технические действия не выполняет.</p>`:''}\n  ${statBlock(st,'lib')}")
rep("  ${(c.base||[]).map(s=>sysCard(s,t,{src:'lib'})).join('')}\n  ${c.structTable==='monster'?monsterTableHtml():''}",
    "  ${(c.base||[]).map(s=>sysCard(s,t,{src:'lib'})).join('')}\n  ${c.structTable==='monster'?monsterTableHtml():''}\n  ${tplSystems(ts.tpls,ts.ch).filter(x=>x.w).length?`<h2>Оружие из шаблонов</h2>${tplSystems(ts.tpls,ts.ch).filter(x=>x.w).map(x=>sysCard(x,t,{src:'lib'})).join('')}`:''}")

# ---------------- add to encounter ----------------
rep("""  const c=cls(S.cls);if(!c)return;const ts=getTplSel(c.id),st=effStats(c,S.tier,ts.tpls,getSel(c.id));""",
    """  const c=cls(S.cls);if(!c)return;const ts=getTplSel(c.id),st=effStats(c,S.tier,ts.tpls,getSel(c.id),ts.ch);""")
rep("""  for(let k=0;k<n;k++)S.enc.push({uid:uidGen(),cls:c.id,tier:S.tier,opts:[...getSel(c.id)],tpls:[...tpls],tplCh:[...ts.ch],team:S.addTeam,
    label:`${c.name} #${same+k+1}`,hp:st.hp,heat:0,struct:1,structMax:1,stress:1,over:0,burn:0,conds:[],spent:{},unloaded:{},open:{},hideTypes:['kin','exp'],notes:''});""",
"""  const tps=tpls.map(tpl),tsys=tplSystems(tpls,ts.ch),fl=flagsOf(tpls,ts.ch);
  let sMax=1+tps.reduce((a,x)=>a+(x.structAdd||0),0)+tsys.reduce((a,x)=>a+(x.structAdd||0),0),stMax=1+tps.reduce((a,x)=>a+(x.stressAdd||0),0);
  const sc=fl.structCap||c.structCap;if(sc)sMax=Math.min(sMax,sc);sMax=Math.max(1,sMax);if(fl.stressCap)stMax=Math.min(stMax,fl.stressCap);
  const allSys=[...classSystems(c,getSel(c.id)),...tsys];
  const imm=[...(c.immune||[]),...allSys.flatMap(x=>x.immune||[]),...tps.flatMap(x=>x.immune||[])];
  const conds=[...new Set([...(c.startConds||[]),...tps.flatMap(x=>x.initConds||[]),...allSys.map(x=>x.initCond).filter(Boolean)])].filter(x=>!imm.includes(x));
  for(let k=0;k<n;k++)S.enc.push({uid:uidGen(),cls:c.id,tier:S.tier,opts:[...getSel(c.id)],tpls:[...tpls],tplCh:[...ts.ch],team:S.addTeam,
    label:`${c.name} #${same+k+1}`,hp:st.hp,heat:0,struct:sMax,structMax:sMax,stress:stMax,stressMax:stMax,over:0,burn:0,conds:[...conds],spent:{},unloaded:{},open:{},hideTypes:['kin','exp'],counters:{},pickRes:{},turns:0,notes:''});""")

# immunity from template level too
rep("function immuneOf(i){const k=cls(i.cls);if(!k)return [];return [...(k.immune||[]),...instSystems(i).flatMap(s=>s.immune||[])]}",
    "function immuneOf(i){const k=cls(i.cls);if(!k)return [];return [...(k.immune||[]),...instSystems(i).flatMap(s=>s.immune||[]),...(i.tpls||[]).map(tpl).filter(Boolean).flatMap(t=>t.immune||[])]}")
rep("const src=[...(cls(I.cls).immune||[]).includes(v)?['Сила в Числе']:[],...instSystems(I).filter(s=>(s.immune||[]).includes(v)).map(s=>s.name)];",
    "const src=[...(cls(I.cls).immune||[]).includes(v)?['Сила в Числе']:[],...instSystems(I).filter(s=>(s.immune||[]).includes(v)).map(s=>s.name),...I.tpls.map(tpl).filter(t=>t&&(t.immune||[]).includes(v)).map(t=>'шаблон '+t.name)];")
# Stunned → vent invisibility
rep("        if(v==='Выключен'){I.heat=0;",
    "        if(v==='Ошеломлен'&&instSystems(I).some(s=>s.ventInvis)){addCond(I,'Невидим');addLog('',logHead(I.label+' — Аварийная Вентиляция')+`<div class=\"bd\">Ошеломлён → Невидим до начала своего следующего хода</div>`)}\n        if(v==='Выключен'){I.heat=0;")

# ---------------- instance card ----------------
rep("""  const tplRows=i.tpls.map(tpl).filter(Boolean).map(tp=>{
    const feats=[...(tp.features||[]),...(tp.choices||[]).filter(ch=>i.tplCh.includes(ch.id))];""",
"""  const acts=activationsOf(i),hasUltra=i.tpls.includes('ultra');
  const whenKeys=[...new Set(systems.filter(s=>s.resist&&s.resist.when).map(s=>s.resist.when))];
  const WHEN={melee:['ближняя атака','Урон от оружия ближнего боя (Шоковая Броня).'],far3:['атака издалека (>3)','Атака пришла из-за пределов Дальн. 3 (Осадная Броня/Щит).'],main:['Основное оружие','Урон от Основного оружия (Шоковая Броня Ветерана).']};
  const pickSys=systems.filter(s=>s.resist&&s.resist.types==='pick');
  const tplRows0=i.tpls.map(tpl).filter(Boolean).map(tp=>{
    const feats=[...(tp.features||[]),...tplItems(tp).filter(ch=>i.tplCh.includes(ch.id))];""")
rep("     <button class=\"btn sm\" data-act=\"dup\" data-uid=\"${i.uid}\" data-tt=\"Дублировать\" data-tip=\"Создать копию этого НИП.\">⧉</button>",
    "     <span class=\"kw\" data-tt=\"Ходы в раунде\" data-tip=\"Кружок закрашивается кнопкой «Начало хода». Элита и Ультра ходят дважды (Ультра — трижды против 5+ врагов). Сбрасывается кнопкой «Новый раунд».\" style=\"white-space:nowrap;font-size:16px;color:var(--gold)\">${Array.from({length:acts},(_,k)=>k<(i.turns||0)?'●':'○').join('')}</span>\n     <button class=\"btn sm\" data-act=\"dup\" data-uid=\"${i.uid}\" data-tt=\"Дублировать\" data-tip=\"Создать копию этого НИП.\">⧉</button>")
rep("""     <label${tipAttr(tipFor('Структура'))}>Структура <input type="number" data-field="struct" data-uid="${i.uid}" value="${i.struct}"> / ${i.structMax}</label>
     ${st.heat?`<label${tipAttr(tipFor('Нагрузка'))}>Нагрузка <input type="number" data-field="stress" data-uid="${i.uid}" value="${i.stress}"></label>`:''}""",
"""     <label${tipAttr(tipFor('Структура'))}>Структура <input type="number" data-field="struct" data-uid="${i.uid}" value="${i.struct}"> / ${i.structMax}</label>
     ${st.heat?`<label${tipAttr(tipFor('Нагрузка'))}>Нагрузка <input type="number" data-field="stress" data-uid="${i.uid}" value="${i.stress}"> / ${i.stressMax||1}</label>`:''}
     ${hasUltra?`<label class="kw" data-tt="Шок и Трепет" data-tip="Если в начале боя против Ультра 5+ врагов — он делает третий ход."><input type="checkbox" data-act="ultra3" data-uid="${i.uid}" ${i.ultra3?'checked':''}> 3 хода</label>`:''}
     ${i.meltdown?`<span class="warn">Плавление реактора: через ${i.meltdown} ход(а)</span>`:''}
     ${i.armorLoss?`<span class="warn">Броня Аргус: −${i.armorLoss}</span>`:''}
     ${i.kinComp?`<span class="info">Кин. компенсация +${i.kinComp}</span>`:''}""")
rep("""     ${systems.some(s=>s.areaResist)?`<label""",
"""     ${whenKeys.map(k=>`<label class="kw" data-tt="${esc((WHEN[k]||[k])[0])}" data-tip="${esc((WHEN[k]||['',''])[1])}"><input type="checkbox" id="w-${k}-${i.uid}"> ${esc((WHEN[k]||[k])[0])}</label>`).join('')}
     ${systems.some(s=>s.auxCap1)?`<label class="kw" data-tt="Стальная Челюсть" data-tip="Вспомогательное оружие наносит Ветерану не больше 1 урона."><input type="checkbox" id="aux-${i.uid}"> вспомог. оружие</label>`:''}
     ${pickSys.map(s=>`<label>${esc(s.name)}: <select data-act="pickres" data-sys="${esc(s.id)}" data-uid="${i.uid}">${['kin','en','exp'].map(k=>`<option value="${k}" ${(i.pickRes[s.id]||'kin')===k?'selected':''}>${DT[k][2]}</option>`).join('')}</select></label>`).join('')}
     ${systems.some(s=>s.areaResist)?`<label""")
rep("""     <button class="btn sm" data-act="endturn" data-uid="${i.uid}" data-tt="Конец хода\"""",
    """     <button class="btn sm red" data-act="startturn" data-uid="${i.uid}" data-tt="Начало хода" data-tip="Один бросок d6 перезаряжает все системы с Перезарядкой N+ (по книге — один бросок на НИП). Плюс напоминания и эффекты «в начале хода», отметка хода.">Начало хода</button>
     <button class="btn sm" data-act="endturn" data-uid="${i.uid}" data-tt="Конец хода\"""")
rep("   ${systems.map(s=>instSys(i,s,t)).join('')}\n   ${tplRows}",
    "   ${i.tpls.length?`<div class=\"agrp\" style=\"color:#b89be0\">Шаблоны: ${i.tpls.map(id=>esc((tpl(id)||{}).name||id)).join(', ')}</div>`:''}\n   ${systems.map(s=>instSys(i,s,t)).join('')}")
# counters in system rows
rep("        ${s.apply?`<button class=\"btn sm red\" data-act=\"applysys\"",
    "        ${s.counter?`<span class=\"tag-s\">${esc(s.counter.label)}:</span><button class=\"pm\" data-act=\"cnt\" data-d=\"-1\" data-sys=\"${esc(s.id)}\" data-uid=\"${i.uid}\">−</button><b>${(i.counters||{})[s.id]||0}</b><button class=\"pm\" data-act=\"cnt\" data-d=\"1\" data-sys=\"${esc(s.id)}\" data-uid=\"${i.uid}\">+</button>`:''}\n        ${s.apply?`<button class=\"btn sm red\" data-act=\"applysys\"")
rep("    <details data-open=\"${esc(s.id)}\" data-uid=\"${i.uid}\" ${i.open[s.id]?'open':''}><summary>${esc(s.tags||ty[0])}</summary>",
    "    <details data-open=\"${esc(s.id)}\" data-uid=\"${i.uid}\" ${i.open[s.id]?'open':''}><summary>${s._tpl?esc(s._tpl)+' · ':''}${esc(s.tags||ty[0])}</summary>")
# biological: no tech actions
rep("    const blocked=a.id==='grapple'&&flags.noGrapple;",
    "    const blocked=(a.id==='grapple'&&flags.noGrapple)||((a.id==='invade'||a.id==='lock')&&flags.noTech);")
rep("<span class=\"warn\">Недоступно: Нет манипуляторов.</span>", "<span class=\"warn\">${a.id==='grapple'?'Недоступно: Нет манипуляторов.':'Биологический: технические действия недоступны.'}</span>")
rep("  ${actionsHtml('lib',null,t,flagsOf(ts.tpls,ts.ch))}", "  ${actionsHtml('lib',null,t,{...flagsOf(ts.tpls,ts.ch),noTech:tagNow==='Биологический'})}")
rep("<summary>Действия НИП</summary>${actionsHtml('inst:'+i.uid,i,t,flags)}", "<summary>Действия НИП</summary>${actionsHtml('inst:'+i.uid,i,t,{...flags,noTech:tag==='Биологический'})}")

# ---------------- mods ----------------
rep("""      if(m.skill){if(kind==='check'&&skill===m.skill)mods.push({label:m.label,acc:av(m.acc),diff:av(m.diff),on:true,fixed:1});return}
      const scopeOk=m.scope==='all'||(m.scope==='check'?kind==='check':kind!=='check');""",
"""      if(m.skill){if(kind==='check'&&skill===m.skill)mods.push({label:m.label,acc:av(m.acc),diff:av(m.diff),on:true,fixed:1});return}
      const scopeOk=m.scope==='all'||(m.scope==='check'?kind==='check':m.scope==='tech'?kind==='tech':kind!=='check');
      if(m.meleeOnly&&!(kind==='atk'&&w&&wtags(sys?sys.tags:'',w).melee))return;
      const extra={ap:m.ap,dmgAdd:m.dmgAdd,dmgMul:m.dmgMul,replaceDmg:m.replaceDmg};
      if(m.always){if(scopeOk)mods.push({label:m.label,...extra,acc:av(m.acc),diff:av(m.diff),on:true,fixed:1});return}
      if(m.ifCond){if(scopeOk){const on=hasCond(i,m.ifCond);mods.push({label:m.label+(i&&!on?` — сейчас не ${m.ifCond}`:''),...extra,acc:av(m.acc),diff:av(m.diff),on,fixed:i?1:0})}return}""")
rep("      if(scopeOk)mods.push({label:m.label,acc:av(m.acc),diff:av(m.diff),on:false});",
    "      if(scopeOk)mods.push({label:m.label,...extra,acc:av(m.acc),diff:av(m.diff),on:false});")
rep("    if(s.wmod&&sys&&s.wmod.w===sys.id)mods.push({label:s.wmod.label,dmgAdd:s.wmod.dmgAdd||0,ap:s.wmod.ap,unload:s.wmod.unload,on:false});",
    "    if(s.wmod&&sys&&s.wmod.w===sys.id)mods.push({label:s.wmod.label,dmgAdd:s.wmod.dmgAdd||0,ap:s.wmod.ap,unload:s.wmod.unload,acc:s.wmod.acc||0,multi:s.wmod.multi||0,on:false});")
rep("    melee:(/обб/i.test(t)&&!(w&&w.dual))||(!t&&!!w&&/^угроза/i.test(w.rng||'')),",
    "    melee:(/обб/i.test(t)&&!(w&&w.dual))||!!(w&&w.melee)||(!t&&!!w&&/^угроза/i.test(w.rng||'')),")

# ---------------- openAttack additions ----------------
rep("  if(x.i&&x.i.retrib)mods.unshift({label:'Возмездие (накоплено)',dmgAdd:x.i.retrib,on:true,fixed:1,retrib:1});",
    """  if(x.i&&x.i.retrib)mods.unshift({label:'Возмездие (накоплено)',dmgAdd:x.i.retrib,on:true,fixed:1,retrib:1});
  if(x.i&&x.i.kinComp)mods.unshift({label:`Кинетическая Компенсация (промахов подряд: ${x.i.kinComp})`,acc:x.i.kinComp,on:true,fixed:1});
  if(s.w.tech)x.sys.filter(o=>o.techHitNote).forEach(o=>notes.push({hit:1,text:o.techHitNote}));
  const alts=[{label:'Обычный режим'},...x.sys.filter(o=>o.walts&&o.walts.w===s.id).flatMap(o=>o.walts.alts)];""")
rep("  let multi=tvv(s.w.multi,x.t)||1,multiWhy='';",
    "  let multi=tvv(s.w.multi,x.t)||1,multiWhy='';\n  if(s.w.multiCounter&&x.i){const n=(x.i.counters||{})[s.id]||0;multi=Math.max(1,n);multiWhy=n?`по одной атаке за каждую (${s.counter?s.counter.label.toLowerCase():'шт.'}: ${n})`:'Ничего не размещено — сначала нажмите «+» у счётчика'}")
rep("     mods,warns,notes,perTarget:pt?pt.perTarget[x.t-1]:0,targets:1,loading:isLoading(s),res:null,wt,tags:s.tags||''};",
    "     mods,warns,notes,perTarget:pt?pt.perTarget[x.t-1]:0,targets:1,loading:isLoading(s),res:null,wt:s.areaLike?{...wt,area:true}:wt,tags:s.tags||'',baseW:s.w,alts,alt:0};")
rep("  if(id==='grapple'&&x.flags.noGrapple)warns.push('Транспорт: Нет манипуляторов — Хватать нельзя.');",
    "  if(id==='grapple'&&x.flags.noGrapple)warns.push('Нет манипуляторов — Хватать нельзя.');\n  if((id==='invade')&&(x.c.noTech||x.flags.tag==='Биологический'))warns.push('Биологический: технические действия недоступны.');")
rep("       mods:buildMods(x,'tech',null,null,id),warns,notes:[],onHit:p.onHit,res:null};",
    "       mods:buildMods(x,'tech',null,null,id),warns,notes:x.sys.filter(o=>o.techHitNote).map(o=>({hit:1,text:o.techHitNote})),onHit:p.onHit,res:null};")

# modal: alt select, effective multi, replaceDmg, rounding of half damage
rep("    ${M.multi>1||M.multiWhy?`<div class=\"${M.multi>1?'info':'warn'}\">Атак за раз: ${M.multi}${M.multiWhy?' — '+esc(M.multiWhy):''}</div>`:''}",
    "    ${M.alts&&M.alts.length>1?`<div class=\"stepper\"><span class=\"lbl\">Режим</span><select id=\"malt\">${M.alts.map((a,k)=>`<option value=\"${k}\" ${k===M.alt?'selected':''}>${esc(a.label)}</option>`).join('')}</select></div>`:''}\n    ${effMulti()>1||M.multiWhy?`<div class=\"${effMulti()>1?'info':'warn'}\">Атак за раз: ${effMulti()}${M.multiWhy?' — '+esc(M.multiWhy):''}</div>`:''}")
rep("${M.multi>1?`<button class=\"btn red\" data-act=\"mroll2\">⚄ ${M.multi} атаки</button>`:''}",
    "${effMulti()>1?`<button class=\"btn red\" data-act=\"mroll2\">⚄ ${effMulti()} атаки</button>`:''}")
rep("    case 'mroll2':for(let k=0;k<M.multi;k++)doRoll({label:'атака '+(k+1)});break;",
    "    case 'mroll2':{const n=effMulti();useOnce();for(let k=0;k<n;k++)doRoll({skipUse:1,label:'атака '+(k+1)});break}")
rep("const modAcc=()=>M.mods.reduce", "const effMulti=()=>Math.max(M.multi||1,...M.mods.filter(m=>m.on&&m.multi).map(m=>m.multi));\nconst modAcc=()=>M.mods.reduce")
rep("  const mul=M.mods.reduce((a,m)=>a*(m.on&&m.dmgMul?m.dmgMul:1),1);",
    "  const rd=M.mods.find(m=>m.on&&m.replaceDmg);if(rd&&hit!==false)return `<b>${esc(rd.replaceDmg)}</b>`;\n  const mul=M.mods.reduce((a,m)=>a*(m.on&&m.dmgMul?m.dmgMul:1),1);")
rep("  const rel=w.rel?w.rel[M.t-1]:0,tot=Math.max((base+extra)*mul,rel);\n  const d2=w.dmg2?' + '+dmgStr(w.dmg2.dmg[M.t-1]*mul,w.dmg2.dt):'';",
    "  const rel=w.rel?w.rel[M.t-1]:0,tot=Math.max(Math.ceil((base+extra)*mul),rel);\n  const d2=w.dmg2?' + '+dmgStr(Math.ceil(w.dmg2.dmg[M.t-1]*mul),w.dmg2.dt):'';")
rep("  if(el.id==='mdt'&&M){",
    """  if(el.id==='malt'&&M){const tg=document.getElementById('mtgt');if(tg)M.target=tg.value;M.alt=+el.value;const a=M.alts[M.alt]||{};M.w={...M.baseW};['rng','dmg','dt','rel'].forEach(k=>{if(a[k]!==undefined)M.w[k]=a[k]});M.dt=M.w.dt;M.wt={...M.wt,area:/взрыв|разрыв|лини|конус/i.test(M.w.rng||'')};renderModal();return}
  if(el.id==='mdt'&&M){""")
# alt notes on hit
rep("    if(r.invisOk)notes.push(`Невидимость: d6 [${r.invisOk}] — атака состоялась`);",
    "    if(r.invisOk)notes.push(`Невидимость: d6 [${r.invisOk}] — атака состоялась`);\n    const al=M.alts&&M.alts[M.alt];if(al&&al.note&&r.hit!==false){const sv=(()=>{const x=srcCtx(M.src);return x?x.c.tiers[x.t-1].save:''})();notes.push((r.hit===null?'При попадании: ':'')+al.note.replace('{save}',sv))}")

# kinetic compensation & useOnce
rep("  M.res={d20,a,total,hit,autoFail:M.autoFail,invisOk,unhid};",
    """  M.res={d20,a,total,hit,autoFail:M.autoFail,invisOk,unhid};
  if(M.src&&M.src.startsWith('inst:')&&M.sysId){const ii=inst(M.src.slice(5));if(ii&&instSystems(ii).some(o=>o.missAcc===M.sysId)){if(hit===false){ii.kinComp=(ii.kinComp||0)+1;addLog('',logHead(ii.label+' — Кинетическая Компенсация')+`<div class="bd">Промах → +1 точность ко всем следующим атакам (сейчас +${ii.kinComp})</div>`)}else if(hit===true&&ii.kinComp){ii.kinComp=0;addLog('',logHead(ii.label+' — Кинетическая Компенсация')+`<div class="bd">Попадание → накопленная точность сброшена</div>`)}renderMain();save()}}""")

# ---------------- damage pipeline ----------------
rep("function hurt(i,n,dt,note,ap,half,halfLabel){", "function hurt(i,n,dt,note,ap,half,halfLabel,ctx){\n  ctx=ctx||{when:{}};const st0=stOf(i),hpBefore=i.hp;\n  const immD=instSystems(i).find(s=>(s.immuneDmg||[]).includes(dt));\n  if(immD){addLog('hit',logHead(i.label)+`<div class=\"bd\">Невосприимчивость к ${esc(DT[dt][2].toLowerCase())} (${esc(immD.name)}) — урона и отметки нет</div>`);return}")
rep("  sysl.filter(s=>s.resist&&(s.resist.types==='all'||s.resist.types.includes(dt))).forEach(s=>{",
    "  sysl.filter(s=>s.resist&&(s.resist.types==='all'||(s.resist.types==='pick'?[(i.pickRes||{})[s.id]||'kin']:s.resist.types).includes(dt))&&(!s.resist.when||ctx.when[s.resist.when])).forEach(s=>{")
rep("  const o=takeHp(i,d);if(o)parts.push(`щит −${o}`);\n  if(dt==='burn')",
    "  if(ctx.aux&&sysl.some(s=>s.auxCap1)&&d>1){d=1;parts.push('максимум 1 (Стальная Челюсть)')}\n  const o=takeHp(i,d);if(o)parts.push(`щит −${o}`);\n  if(d>0){const sc=sysl.find(s=>s.startCond&&hasCond(i,s.startCond));if(sc){i.conds=i.conds.filter(c=>c!==sc.startCond);parts.push(`${sc.startCond} снят (${sc.name})`)}}\n  if(dt==='burn')")
rep("    sysl.filter(s=>s.onHurtRound).forEach(s=>{",
    "    sysl.filter(s=>s.halfHpNote).forEach(s=>{i.halfDone=i.halfDone||{};if(!i.halfDone[s.id]&&hpBefore*2>=st0.hp&&i.hp*2<st0.hp&&i.hp>0){i.halfDone[s.id]=1;addLog('miss',logHead(i.label+' — '+s.name)+`<div class=\"bd\">${esc(s.halfHpNote)}</div>`)}});\n    sysl.filter(s=>s.onHurtRound).forEach(s=>{")
rep("""  if(i.nextHalf)i.nextHalf=false;
  hurt(i,n,dt,'',ap,half,hl);render();""",
"""  if(i.nextHalf)i.nextHalf=false;
  const ctx={when:{},aux:!!(document.getElementById('aux-'+i.uid)||{}).checked};
  ['melee','far3','main'].forEach(k=>{const e=document.getElementById(`w-${k}-${i.uid}`);if(e&&e.checked)ctx.when[k]=1});
  hurt(i,n,dt,'',ap,half,hl,ctx);render();""")

# structure & overheat tables
rep("function checkHp(i){\n  const st=stOf(i),c=cls(i.cls);\n  if(i.hp<=0&&i.struct>0){\n    if(i.struct>1){\n      i.struct--;i.hp=st.hp;i.hideLost=false;\n      addLog('miss',logHead(i.label)+`<div class=\"bd\">0 ПЗ → −1 Структура (осталось ${i.struct}), ПЗ восстановлены</div>`);\n      if(c.structTable==='monster')monsterStruct(i);\n      else addLog('',logHead(i.label)+`<div class=\"bd\">Бросьте по таблице структурного урона из книги.</div>`);\n    }else{i.struct=0;i.hp=0;addLog('miss',logHead(i.label)+`<div class=\"verdict miss\">УНИЧТОЖЕН</div>`)}\n  }",
"""function isLegend(i){return !!(flagsOf(i.tpls,i.tplCh).legendary||instSystems(i).some(s=>s.legendary))}
function tableDice(i,n){const roll=()=>Array.from({length:Math.max(1,n)},()=>rnd(6));const sc=r=>r.filter(x=>x===1).length>=2?-1:Math.min(...r);
  let a=roll(),alt=null;if(isLegend(i)){const b=roll();if(sc(b)>sc(a)){alt=a;a=b}else alt=b}return{dice:a,alt,low:Math.min(...a),ones:a.filter(x=>x===1).length}}
function argusHit(i){if(instSystems(i).some(s=>s.argus)){const base=effStats(cls(i.cls),i.tier,i.tpls,i.opts,i.tplCh).armor;i.armorLoss=Math.min(base,(i.armorLoss||0)+2);addLog('miss',logHead(i.label+' — Броня Аргус')+`<div class="bd">−2 Брони (теперь ${Math.max(0,base-i.armorLoss)})</div>`)}}
function destroyNpc(i,why){
  const sysl=instSystems(i);
  if(sysl.some(s=>s.fakeDeath)&&!i.fakeUsed){i.fakeUsed=true;i.hp=1;i.struct=Math.max(1,i.struct);addLog('',logHead(i.label+' — Имитация Смерти')+`<div class="bd">Кажется уничтоженным, но на самом деле имеет 1 ПЗ. Заметить — проверка Систем рядом.</div>`);return}
  i.struct=0;i.hp=0;addLog('miss',logHead(i.label)+`<div class="verdict miss">УНИЧТОЖЕН${why?' — '+esc(why):''}</div>`);
  sysl.filter(s=>s.onDestroy).forEach(s=>addLog('miss',logHead(i.label+' — '+s.name)+`<div class="bd">${esc(tierText(s.onDestroy.replace('{save}',stOf(i).save),i.tier))}</div>`));
}
function mechStruct(i){
  const st=stOf(i),n=(i.structMax||1)-i.struct,T=tableDice(i,n);let res;
  if(T.ones>=2){destroyNpc(i,'Сокрушительный удар');res='Сокрушительный удар — мех уничтожен.'}
  else if(T.low>=5){addCond(i,'Ослаблен');res='Скользящий удар: Ослаблен до конца своего следующего хода.'}
  else if(T.low>=2){const d=rnd(6);res=`Системная травма: d6[${d}] — ${d<=3?'уничтожается всё оружие в одном слоте по выбору':'уничтожается система по выбору'} (если нечего — считается Прямым попаданием).`}
  else if(i.struct>=3){addCond(i,'Ошеломлен');res='Прямое попадание: Ошеломлён до конца своего следующего хода.'}
  else if(i.struct===2){const d=rnd(20),tot=d+st.hull;if(tot>=10){addCond(i,'Ошеломлен');res=`Прямое попадание: проверка Корпуса ${tot} (d20[${d}] ${sgn(st.hull)}) — успех, Ошеломлён до конца своего следующего хода.`}else{destroyNpc(i,'Прямое попадание');res=`Прямое попадание: проверка Корпуса ${tot} (d20[${d}] ${sgn(st.hull)}) — провал, мех уничтожен.`}}
  else{destroyNpc(i,'Прямое попадание');res='Прямое попадание — мех уничтожен.'}
  addLog('miss',logHead(i.label+' — проверка структуры')+`<div style="display:flex;gap:10px;align-items:center"><span class="tot">${T.low}</span><span>${esc(res)}</span></div><div class="bd">${T.dice.length}d6 [${T.dice.join(',')}], берётся наименьший${T.alt?` · Легендарный: второй бросок [${T.alt.join(',')}], взят лучший`:''}</div>`);
  argusHit(i);
}
function overheatCheck(i){
  const st=stOf(i),n=(i.stressMax||1)-i.stress,T=tableDice(i,n);let res;
  if(i.stress<=0){i.meltdown=1;res='Нагрузка 0 — плавление реактора в конце следующего хода.'}
  else if(T.ones>=2){i.meltdown=1;res='Необратимое плавление: реактор расплавится в конце следующего хода.'}
  else if(T.low>=5){addCond(i,'Ослаблен');res='Аварийный шунт: Ослаблен до конца своего следующего хода.'}
  else if(T.low>=2){addCond(i,'Уязвим');res='Разрушение энергоустановок: Уязвим (снимается Стабилизацией).'}
  else if(i.stress>=3){addCond(i,'Уязвим');res='Плавление: Уязвим.'}
  else if(i.stress===2){const d=rnd(20),tot=d+st.eng;if(tot>=10){addCond(i,'Уязвим');res=`Плавление: проверка Инженерии ${tot} — успех, Уязвим.`}else{const k=rnd(6);i.meltdown=k;res=`Плавление: проверка Инженерии ${tot} — провал, плавление реактора через ${k} ход(а). Отменить — повторная проверка Инженерии полным действием.`}}
  else{i.meltdown=1;res='Плавление: реактор расплавится в конце следующего хода.'}
  addLog('miss',logHead(i.label+' — проверка перегрева')+`<div style="display:flex;gap:10px;align-items:center"><span class="tot">${T.low}</span><span>${esc(res)}</span></div><div class="bd">${T.dice.length}d6 [${T.dice.join(',')}], берётся наименьший${T.alt?` · Легендарный: второй бросок [${T.alt.join(',')}], взят лучший`:''}</div>`);
  argusHit(i);
}
function checkHp(i){
  const st=stOf(i),c=cls(i.cls);
  let guard=0;
  while(i.hp<=0&&i.struct>0&&guard++<20){
    if(i.struct>1){
      const over=i.hp;i.struct--;i.hp=st.hp+over;i.hideLost=false;
      addLog('miss',logHead(i.label)+`<div class="bd">0 ПЗ → −1 Структура (осталось ${i.struct}), ПЗ восстановлены${over<0?`, лишний урон ${-over} переносится`:''} → ПЗ ${i.hp}</div>`);
      if(c.structTable==='monster')monsterStruct(i);else mechStruct(i);
    }else destroyNpc(i);
  }""")
rep("  const n=Math.max(1,(i.structMax||1)-i.struct);\n  const dice=Array.from({length:n},()=>rnd(6)),low=Math.min(...dice),ones=dice.filter(d=>d===1).length;",
    "  const n=Math.max(1,(i.structMax||1)-i.struct);\n  const TT=tableDice(i,n),dice=TT.dice,low=TT.low,ones=TT.ones;")
rep("""  if(n>0&&i.heat>st.heat){
    if(i.stress>1){i.stress--;i.heat=0;""",
"""  if(n>0&&i.heat>st.heat&&instSystems(i).some(s=>s.ventInvis)){addCond(i,'Невидим');addLog('',logHead(i.label+' — Аварийная Вентиляция')+`<div class="bd">Превышен Тепловой Максимум → Невидим до начала своего следующего хода</div>`)}
  if(n>0&&i.heat>st.heat&&(i.stressMax||1)>1){
    let g=0;while(i.heat>st.heat&&i.stress>0&&g++<10){const ex=i.heat-st.heat;i.stress--;i.heat=ex;addLog('miss',logHead(i.label)+`<div class="bd">Перегрев → −1 Нагрузка (осталось ${i.stress}), нагрев сброшен, остаток ${ex}</div>`);overheatCheck(i)}
    return;
  }
  if(n>0&&i.heat>st.heat){
    if(false){""")

# ---------------- turns ----------------
rep("function stabilize(i){\n  i.heat=0;i.conds=i.conds.filter(c=>c!=='Уязвим');i.unloaded={};",
    """function startTurn(i){
  if(i.struct<=0){addLog('',logHead(i.label)+`<div class="bd">Уничтожен — ход пропускается</div>`);return}
  const acts=activationsOf(i);i.turns=(i.turns||0)+1;
  const out=[];if(i.turns>acts)out.push(`внимание: это уже ${i.turns}-й ход при ${acts} в раунде`);else out.push(`ход ${i.turns} из ${acts}`);
  const sysl=instSystems(i);
  if(i.tpls.includes('ultra'))sysl.forEach(s=>{if(s.pr&&/реакц/i.test(s.tags||''))i.spent[s.id]=false});
  const spent=sysl.filter(s=>s.rc&&i.spent[s.id]);
  if(spent.length){const r=rnd(6),ok=spent.filter(s=>r>=s.rc),no=spent.filter(s=>r<s.rc);ok.forEach(s=>i.spent[s.id]=false);
    addLog(ok.length?'hit':'miss',logHead(i.label+' — перезарядка')+`<div style="display:flex;gap:10px;align-items:center"><span class="tot">${r}</span><span>${ok.length?'<span class="verdict hit">Готово:</span> '+esc(ok.map(s=>s.name+' ('+s.rc+'+)').join(', ')):''}${no.length?' <span class="verdict miss">Нет:</span> '+esc(no.map(s=>s.name+' ('+s.rc+'+)').join(', ')):''}</span></div><div class="bd">Один d6 на все системы НИП (правило книги)</div>`)}
  sysl.forEach(s=>{if(s.startCond&&!hasCond(i,s.startCond)){addCond(i,s.startCond);out.push(`${s.startCond} (${s.name})`)}if(s.turnCond&&!hasCond(i,s.turnCond)){addCond(i,s.turnCond);out.push(`${s.turnCond} на свой ход (${s.name})`)}});
  sysl.filter(s=>s.startNote).forEach(s=>out.push(tierText(s.startNote,i.tier)));
  if(i.meltdown)out.push(`Плавление реактора: осталось ${i.meltdown} ход(а)`);
  addLog('',logHead(i.label+' — начало хода')+out.map(x=>`<div class="bd">• ${esc(x)}</div>`).join(''));
  render();
}
function stabilize(i){
  const had=Object.keys(i.unloaded||{}).length;
  if(had&&instSystems(i).some(s=>s.reloadHeal)){const h=rnd(6),st=stOf(i);i.hp=Math.min(st.hp,i.hp+h);addLog('hit',logHead(i.label+' — Живое Оружие')+`<div class="bd">Перезарядка → +${h} ПЗ (1d6)</div>`)}
  i.heat=0;i.conds=i.conds.filter(c=>c!=='Уязвим');i.unloaded={};""")
rep("  if(!any)addLog('',logHead(i.label+' — конец хода')+`<div class=\"bd\">Ничего не происход",
    """  instSystems(i).filter(s=>s.turnCond&&hasCond(i,s.turnCond)).forEach(s=>{any=true;i.conds=i.conds.filter(c=>c!==s.turnCond);addLog('',logHead(i.label+' — '+s.name)+`<div class="bd">${esc(s.turnCond)} снят до следующего хода</div>`)});
  if(i.meltdown&&i.struct>0){any=true;i.meltdown--;if(i.meltdown<=0){i.meltdown=0;const dmg=[rnd(6),rnd(6),rnd(6),rnd(6)];destroyNpc(i,'плавление реактора');addLog('miss',logHead(i.label+' — плавление реактора')+`<div class="bd">Взрыв 2: спасбросок Маневренности или ${dmg.reduce((a,b)=>a+b,0)} взр. (4d6 [${dmg.join(',')}]), половина при успехе</div>`)}else addLog('miss',logHead(i.label)+`<div class="bd">До плавления реактора: ${i.meltdown} ход(а)</div>`)}
  if(!any)addLog('',logHead(i.label+' — конец хода')+`<div class="bd">Ничего не происход""")
rep("    case 'stab':stabilize(I);break;",
    "    case 'stab':stabilize(I);break;\n    case 'startturn':startTurn(I);break;\n    case 'ultra3':I.ultra3=el.checked;render();break;\n    case 'cnt':{I.counters=I.counters||{};const k=el.dataset.sys,sy=findSys(cls(I.cls),k),mx=sy&&sy.counter?sy.counter.max:99;I.counters[k]=Math.max(0,Math.min(mx,(I.counters[k]||0)+ +el.dataset.d));render();break}")
rep("    case 'reload':delete I.unloaded[el.dataset.sys];render();break;",
    "    case 'reload':{delete I.unloaded[el.dataset.sys];if(instSystems(I).some(s=>s.reloadHeal)){const h=rnd(6),st=stOf(I);I.hp=Math.min(st.hp,I.hp+h);addLog('hit',logHead(I.label+' — Живое Оружие')+`<div class=\"bd\">Перезарядка → +${h} ПЗ (1d6)</div>`)}render();break}")
rep("    case 'newround':S.round++;S.enc.forEach(i=>{const c=cls(i.cls);if(!c)return;[...c.base,...c.optional].forEach(s=>{if(s.pr)i.spent[s.id]=false});i.spent.act_overwatch=false});",
    "    case 'newround':S.round++;S.enc.forEach(i=>{const c=cls(i.cls);if(!c)return;instSystems(i).forEach(s=>{if(s.pr)i.spent[s.id]=false});i.spent.act_overwatch=false;i.turns=0});")
rep("      addLog('',logHead('Раунд '+S.round)+`<div class=\"bd\">Отметки «1/раунд» и Наблюдение сброшены</div>`);render();break;",
    "      addLog('',logHead('Раунд '+S.round)+`<div class=\"bd\">Отметки «1/раунд», Наблюдение и счётчики ходов сброшены. Порядок: стороны ходят по очереди; начинает сторона, которая не ходила последней в прошлом раунде.</div>`);render();break;")
rep("    case 'rechargeall':{let any=false;S.enc.forEach(i=>{const c=cls(i.cls);if(!c)return;[...c.base,...c.optional].forEach(s=>{if(s.rc&&i.spent[s.id]){rechargeRoll(i,s);any=true}})});",
    "    case 'rechargeall':{let any=false;S.enc.forEach(i=>{const c=cls(i.cls);if(!c||i.struct<=0)return;const sp=instSystems(i).filter(s=>s.rc&&i.spent[s.id]);if(!sp.length)return;any=true;const r=rnd(6),ok=sp.filter(s=>r>=s.rc);ok.forEach(s=>i.spent[s.id]=false);addLog(ok.length?'hit':'miss',logHead(i.label+' — перезарядка')+`<div style=\"display:flex;gap:10px;align-items:center\"><span class=\"tot\">${r}</span><span>${ok.length?esc('Готово: '+ok.map(s=>s.name).join(', ')):'Ничего не перезаряжено'}</span></div><div class=\"bd\">Один d6 на НИП: ${esc(sp.map(s=>s.name+' '+s.rc+'+').join(', '))}</div>`)});")
rep("    case 'recharge':rechargeRoll(I,findSys(cls(I.cls),el.dataset.sys));render();break;",
    "    case 'recharge':rechargeRoll(I,findSys(cls(I.cls),el.dataset.sys));render();break;")

# apply extensions
rep("    case 'applysys':{const s=findSys(cls(I.cls),el.dataset.sys);if(!s||!s.apply)break;if(s.apply.cond)addCond(I,s.apply.cond);if(s.apply.nextHalf)I.nextHalf=true;",
    """    case 'applysys':{const s=findSys(cls(I.cls),el.dataset.sys);if(!s||!s.apply)break;const ap=s.apply;
      if(ap.roll){const d=rnd(6),ok=d>=ap.roll;if(ok)I.nextHalf=true;addLog(ok?'hit':'miss',logHead(I.label+' — '+s.name)+`<div style="display:flex;gap:10px;align-items:center"><span class="tot">${d}</span><span class="verdict ${ok?'hit':'miss'}">${ok?'Сработало: следующий урон ½, атакующий повторяет атаку против себя':'Не сработало'}</span></div><div class="bd">d6 vs ${ap.roll}+</div>`);render();break}
      if(ap.dodge){const d=rnd(6),ok=d>=ap.dodge;addLog(ok?'hit':'miss',logHead(I.label+' — '+s.name)+`<div style="display:flex;gap:10px;align-items:center"><span class="tot">${d}</span><span class="verdict ${ok?'hit':'miss'}">${ok?'Атака автоматически промахивается':'Не увернулся'}</span></div><div class="bd">d6 vs ${ap.dodge}+</div>`);render();break}
      if(ap.vent){const h=I.heat;I.heat=0;addLog('',logHead(I.label+' — '+s.name)+`<div class="bd">Сброшено ${h} нагрева. Персонажи в области: спасбросок Маневренности против ${stOf(I).save} или ${Math.floor(h/2)} нагрева и Сбиты с ног.</div>`);render();break}
      if(ap.fullRepair){if(I.selfRepUsed){alert('Саморемонт уже использован в этой сцене');break}I.selfRepUsed=true;I.hp=stOf(I).hp;I.conds=[];addLog('hit',logHead(I.label+' — '+s.name)+`<div class="bd">Все ПЗ восстановлены, состояния сброшены (1/сцена)</div>`);render();break}
      (ap.conds||[]).forEach(c=>addCond(I,c));
      if(s.apply.cond)addCond(I,s.apply.cond);if(s.apply.nextHalf)I.nextHalf=true;""")
rep("<div class=\"bd\">${s.apply.nextHalf?'Следующий полученный урон делится пополам. ':''}${s.apply.cond?esc(s.apply.cond)+(s.apply.label?' ('+esc(s.apply.label)+')':' до конца своего следующего хода.'):''}</div>",
    "<div class=\"bd\">${s.apply.nextHalf?'Следующий полученный урон делится пополам. ':''}${s.apply.cond?esc(s.apply.cond)+(s.apply.label?' ('+esc(s.apply.label)+')':' до конца своего следующего хода.'):''}${(ap.conds||[]).length?esc(ap.conds.join(', '))+(ap.label?' ('+esc(ap.label)+')':''):''}</div>")
rep("    case 'hidet':", "    case 'pickres':break;\n    case 'hidet':")
rep("  if(el.id==='addTeam'){S.addTeam=el.value;return}",
    "  if(el.id==='addTeam'){S.addTeam=el.value;return}\n  if(el.dataset.act==='pickres'){const I=inst(el.dataset.uid);if(I){I.pickRes[el.dataset.sys]=el.value;save()}return}")

# struct/stress manual edit keeps max
rep("if(f==='struct')I.structMax=Math.max(I.structMax||1,I.struct);",
    "if(f==='struct')I.structMax=Math.max(I.structMax||1,I.struct);if(f==='stress')I.stressMax=Math.max(I.stressMax||1,I.stress);")

# glossary additions
rep(" [/^салаг/,", " [/^командир/,'Командир','Шаблон: +1 Структура и Нагрузка, Глас Авторитета, одна Черта Командира.'],\n [/^бпа$/,'БПА','Шаблон беспилотника: +5 ПЗ, всегда Ослаблен, технические действия против него +1 точность.'],\n [/^экзот/,'Экзот','Шаблон: странные технологии, до двух систем из списка Экзота.'],\n [/^наемник/,'Наёмник','Шаблон: +1 точность по цели, вовлечённой союзником; доп. системы наёмников.'],\n [/^пират/,'Пират','Шаблон: +1d6 урона при крите; доп. системы пиратов.'],\n [/^корабл/,'Корабль','Шаблон для Меха: Размер 4, +5 ПЗ, невосприимчив к Обездвиживанию, Ошеломлению, Сбиванию.'],\n [/^космонавт/,'Космонавт','Шаблон: нормально движется в невесомости; доп. системы космонавтов.'],\n [/^салаг/,")
rep(" [/^ветеран/,'Ветеран','Шаблон (пока не добавлен в программу).'],", " [/^ветеран/,'Ветеран','Шаблон: +1 Структура и Нагрузка, +1 точность к одному навыку, одна Черта Ветерана за Градацию.'],")
rep(" [/^элит/,'Элита','Шаблон (пока не добавлен в программу).'],", " [/^элит/,'Элита','Шаблон: +1 Структура и Нагрузка, два хода в раунд, +1 доп. система.'],")
rep(" [/^ультр/,'Ультра','Шаблон (пока не добавлен в программу).'],", " [/^ультр/,'Ультра','Шаблон босса: +3 Структуры и Нагрузки, +5 ПЗ, два хода (три против 5+ врагов), 1–3 системы Ультра.'],")
rep(" [/^отряд/,'Отряд','Шаблон (пока не добавлен в программу).'],", " [/^отряд/,'Отряд','Специальный класс: группа пехоты как один персонаж.'],")

# help
rep("   <li><b>Причины точности</b>:",
    "   <li><b>Ходы</b>: «Начало хода» отмечает ход (кружки в карточке), делает <b>один</b> бросок d6 на все системы с Перезарядкой (так в книге), ставит эффекты «в начале хода». Элита и Ультра ходят дважды. «Новый раунд» сбрасывает ходы и «1/раунд». Игроки всегда ходят первыми, стороны чередуются.</li>\n   <li><b>Структура и перегрев</b>: у Элиты, Ультра, Ветерана, Командира проверки структуры и перегрева бросаются по таблицам книги сами (Легендарный — дважды, берётся лучший). Лишний урон после 0 ПЗ переносится.</li>\n   <li><b>Шаблоны</b>: Командир, БПА, Элита, Экзот, Наёмник, Пират, Корабль, Космонавт, Ультра, Ветеран, Салага, Транспорт. Их черты и выбранные опции становятся системами НИП и работают так же (оружие, сопротивляемости, невосприимчивости, модификаторы).</li>\n   <li><b>Причины точности</b>:")

open(p, 'w', encoding='utf-8').write(s)
print('ok')
