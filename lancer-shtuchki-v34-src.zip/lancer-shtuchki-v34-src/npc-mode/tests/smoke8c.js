const {JSDOM}=require('jsdom');const fs=require('fs');
const errs=[];const dom=new JSDOM(fs.readFileSync(process.argv[2],'utf8'),{runScripts:'dangerously',url:'http://localhost/',beforeParse(w){w.alert=()=>{};w.confirm=()=>true;w.addEventListener('error',e=>errs.push(e.message))}});
const w=dom.window;
const t0=Date.now();
const r=w.eval(`(()=>{const out=[];const rl=renderLog;renderLog=()=>{};const ren=render;render=()=>{};
 for(const c of allCls()){for(const tp of allTpl()){
   S.cls=c.id;S.tier=3;S.sel[c.id]=(c.optional||[]).map(o=>o.id);S.tplSel[c.id]={tpls:tplApplicable(tp,c)?[tp.id]:[],ch:tplItems(tp).map(x=>x.id)};
   try{S.log=[];viewLib();S.addN=1;addToEnc();const i=S.enc[S.enc.length-1];instCard(i);
     hurt(i,7,'kin','',false,false,'',{when:{melee:1,far3:1,main:1},aux:true});addHeat(i,30);startTurn(i);endTurn(i);stabilize(i);
     for(const s of instSystems(i)){if(s.w){openAttack('inst:'+i.uid,s.id);renderModal();doRoll();M=null}}
     for(let k=0;k<6;k++)hurt(i,40,'exp','',true,false,'',{when:{}});
     S.enc=[];}catch(e){out.push(c.id+'+'+tp.id+': '+e.message+' '+(e.stack||'').split('\\n').slice(1,3).join(' '))}
 }}
 renderLog=rl;render=ren;return out})()`);
console.log('time',Date.now()-t0,'ms; combos failing',r.length);console.log(r.slice(0,10).join('\n'));console.log('window errors',errs.slice(0,5));
