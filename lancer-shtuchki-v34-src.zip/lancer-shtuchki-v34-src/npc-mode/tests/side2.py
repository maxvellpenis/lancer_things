import sys;sys.path.insert(0,'/tmp/claude-0/-home-claude/d0819c7c-129e-5c04-9991-5764081b769c/scratchpad')
from entext import page
import json,re,subprocess,sys
M={c['id']:c for c in json.load(open('mine.json'))['cls']}
pages=dict(ace=[286],aegis=[287],gunner=[288],assassin=[289],assault=[290],barricade=[291],bastion=[292],berserker=[293],bombard=[294,295],breacher=[296],cataphract=[297],wrecker=[298],engineer=[299],goliath=[300,301],hive=[302],hornet=[303],mirage=[304,305],operator=[306],priest=[307],pyro=[308],hailstorm=[309],ronin=[310],flayer=[312],scout=[313],sower=[314],sentinel=[315],sniper=[316,317],specter=[318],support=[319],witch=[320],squad=[323],monster=[324,325],human=[322])
for cid in sys.argv[1:]:
    t='\n'.join(page(p) for p in pages[cid])
    i=t.find('TACTICS');t=t[i:]
    t=re.sub(r'\n\s*\n','\n',t)
    print('#'*10,cid,'EN'); t=re.sub(r'^(HP|Armor|Evasion|E-Defense|Size|Speed|Save Target|Heat Cap|Sensors|Hull|Agility|Systems|Engineering):.*$|^(CORE STATS|MECH SKILLS|TIER [123]|NON-PLAYER CHRACTERS|SECTION 5.*|\[\d+\])$','',t,flags=re.M);t=re.sub(r'\n\s*\n','\n',t);print(t[:8000])
    print('#'*10,cid,'OURS')
    for s in M[cid]['base']+M[cid]['optional']:
        w=s.get('w')
        print('*',s['name'],'|',s.get('tags',''),'|',('W '+json.dumps(w,ensure_ascii=False)) if w else '','| T:',s.get('trigger',''),'E:',s.get('effect',''),'|',re.sub(r'\*\*','',s.get('text',''))[:500])
