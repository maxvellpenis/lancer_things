import pymupdf,sys
d=pymupdf.open('/mnt/user-data/uploads/LANCER_-_Core_Rulebook.pdf')
N={0x20:'',0x1b:'[Line]',0x1c:'[ACC]',0x1e:'[Blast]',0x1f:'[Burst]',0x22:'[burn]',0x23:'[en]',0x24:'[exp]',0x25:'[heat]',0x26:'[kin]',0x29:'[DIFF]',0x2e:'[Rng]',0x38:'[Thr]'}
def page(n):
  out=[]
  for b in d[n-1].get_text('rawdict')['blocks']:
    for l in b.get('lines',[]):
      s2=''
      for s in l['spans']:
        t=''.join(c['c'] for c in s['chars'])
        if 'Icons' in s['font']:
          t=''.join(N.get(ord(c),'{%02x}'%ord(c)) for c in t)
        s2+=t
      out.append(s2)
  return '\n'.join(out)
if __name__=='__main__':
  for a in sys.argv[1:]: print('#####',a); print(page(int(a)))
