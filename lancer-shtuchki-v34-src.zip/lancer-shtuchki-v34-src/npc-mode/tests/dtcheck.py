import sys,json,re,collections
sys.path.insert(0,'.')
from entext import page
exec(open('side.py').read().split('for cid in')[0].split('\n',2)[2])  # pages dict
M={c['id']:c for c in json.load(open('mine.json'))['cls']}
T=collections.Counter(); rows=[]
for cid,pp in pages.items():
  t=''.join(page(p) for p in pp)
  for s in M[cid]['base']+M[cid]['optional']:
    w=s.get('w')
    if not w or not w.get('dmg'): continue
    d=w['dmg']; ds='/'.join(map(str,d)) if len(set(d))>1 else str(d[0])
    ms=re.findall(r'(?<![\d/])'+re.escape(ds)+r'\{(..)\}',t)
    rows.append((cid,s['name'],ds,w.get('dt'),ms))
    for m in set(ms): T[(w.get('dt'),m)]+=1
for k,v in sorted(T.items(),key=str): print(k,v)
json.dump(rows,open('dtrows.json','w'),ensure_ascii=False)
