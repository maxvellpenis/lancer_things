const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync(process.argv[2],'utf8'),{runScripts:'dangerously',url:'http://localhost/'});
fs.writeFileSync('mine.json',dom.window.eval('JSON.stringify({cls:BUILTIN,tpl:TEMPLATES})'));
