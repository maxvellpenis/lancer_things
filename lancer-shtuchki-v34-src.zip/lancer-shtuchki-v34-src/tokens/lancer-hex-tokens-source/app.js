(() => {
"use strict";
const SQ3 = Math.sqrt(3);
const $ = id => document.getElementById(id);

/* ---------- Lancer sizes on a hex map (axial coords) ---------- */
const TRI5 = [];
for (let r = 0; r < 5; r++) for (let q = 0; q < 5 - r; q++) {
  if ((q === 0 && r === 0) || (q === 4 && r === 0) || (q === 0 && r === 4)) continue;
  TRI5.push([q, r]);
}
const SIZES = [
  { key: "half", big: "½", cells: [[0,0]], scale: 0.6, desc: "Size ½ — пилоты, дроны, мелкие цели. Занимает 1 клетку, токен рисуется уменьшенным в центре гекса." },
  { key: "1", big: "1", cells: [[0,0]], scale: 1, desc: "Size 1 — стандартный мех. 1 гекс." },
  { key: "2", big: "2", cells: [[0,0],[1,0],[0,1]], scale: 1, desc: "Size 2 — треугольник из 3 гексов. Есть два разворота." },
  { key: "3", big: "3", cells: [[0,0],[1,0],[1,-1],[0,-1],[-1,0],[-1,1],[0,1]], scale: 1, desc: "Size 3 — гексагон из 7 клеток, по 2 на сторону." },
  { key: "4", big: "4", cells: TRI5, scale: 1, desc: "Size 4 — 12 клеток: треугольник со срезанными углами, ряды 3-4-3-2. Есть два разворота." },
];
const sizeByKey = k => SIZES.find(s => s.key === k) || SIZES[1];

const PRESETS = [
  { id: "pilot", name: "Пилот", frame: "#3E8ED0", accent: "#0D1620" },
  { id: "ally", name: "Союзник", frame: "#3FAF7A", accent: "#0C1712" },
  { id: "enemy", name: "Враг", frame: "#D1453B", accent: "#170C0B" },
  { id: "elite", name: "Элита", frame: "#9A5BD6", accent: "#140C1C" },
  { id: "ultra", name: "Ультра", frame: "#E3A83A", accent: "#1A1204" },
  { id: "neutral", name: "Нейтрал", frame: "#C8CDD3", accent: "#15191E" },
  { id: "deploy", name: "Деплой", frame: "#6E8391", accent: "#0F1418" },
];

/* ---------- state ---------- */
const DEFAULTS = {
  size: "2", orient: "flat", flip: false,
  zoom: 1, ox: 0, oy: 0, rot: 0, mirror: false,
  preset: "enemy", frameColor: "#D1453B", accentColor: "#170C0B", bgColor: "#1B2027",
  frameW: 6, accentOn: true, accentW: 1.5, accentGap: 1.5, vignette: 40, cells: 30, bgOn: true,
  label: "Assault", labelPos: "bottom", badge: "1", badgeCorner: "tr",
  res: 280, calibV: 84, calibH: 84, fit: "roll20",
};
const PERSIST = ["size","orient","flip","preset","frameColor","accentColor","bgColor","frameW","accentOn","accentW","accentGap","vignette","cells","bgOn","labelPos","badgeCorner","res","calibV2","calibH2","fit"];
const st = Object.assign({}, DEFAULTS);
try {
  const saved = JSON.parse(localStorage.getItem("lancer-hex-tokens") || "null");
  if (saved) for (const k of PERSIST) if (k in saved) st[k] = saved[k];
  if (saved && saved.calibV2) st.calibV = saved.calibV2;
  if (saved && saved.calibH2) st.calibH = saved.calibH2;
} catch (e) {}
let saveTimer = 0;
function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { const o = {}; for (const k of PERSIST) o[k] = st[k]; o.calibV2 = st.calibV; o.calibH2 = st.calibH; localStorage.setItem("lancer-hex-tokens", JSON.stringify(o)); } catch (e) {}
  }, 300);
}

let img = makeSample();
let imgName = "заглушка";
let isSample = true;

/* ---------- geometry ---------- */
function axial(q, r, orient) {
  return orient === "flat" ? [1.5 * q, SQ3 * (r + q / 2)] : [SQ3 * (q + r / 2), 1.5 * r];
}
function corners(cx, cy, orient, R = 1) {
  const pts = [];
  for (let i = 0; i < 6; i++) {
    const a = ((orient === "flat" ? 0 : -30) + 60 * i) * Math.PI / 180;
    pts.push([cx + R * Math.cos(a), cy + R * Math.sin(a)]);
  }
  return pts;
}
function boundary(polys) {
  const k = p => Math.round(p[0] * 1000) + "," + Math.round(p[1] * 1000);
  const edges = new Map();
  for (const poly of polys) for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    const ka = k(a), kb = k(b);
    const key = ka < kb ? ka + "|" + kb : kb + "|" + ka;
    const e = edges.get(key);
    if (e) e.n++; else edges.set(key, { n: 1, a, b, ka, kb });
  }
  const starts = new Map();
  for (const e of edges.values()) if (e.n === 1) starts.set(e.ka, e);
  const first = starts.values().next().value;
  const out = [];
  let e = first, guard = 0;
  do { out.push(e.a); e = starts.get(e.kb); guard++; } while (e && e !== first && guard < 500);
  return out;
}
function bbox(pts) {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const [x, y] of pts) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
  return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}
function buildGeom(sizeKey, orient, flip) {
  const sz = sizeByKey(sizeKey);
  const flipOk = sizeKey === "2" || sizeKey === "4";
  const cells = sz.cells.map(([q, r]) => (flip && flipOk) ? [-q, -r] : [q, r]);
  const centers = cells.map(([q, r]) => axial(q, r, orient));
  const cellPolys = centers.map(([x, y]) => corners(x, y, orient));
  const foot = boundary(cellPolys);
  const fb = bbox(foot);
  const shift = pts => pts.map(([x, y]) => [x - fb.x, y - fb.y]);
  let outline = shift(foot);
  let tokenCells = cellPolys.map(shift);
  if (sz.scale !== 1) {
    const cx = fb.w / 2, cy = fb.h / 2, s = sz.scale;
    const sc = pts => pts.map(([x, y]) => [cx + (x - cx) * s, cy + (y - cy) * s]);
    outline = sc(outline); tokenCells = tokenCells.map(sc);
  }
  return {
    w: fb.w, h: fb.h, outline, cells: tokenCells, tb: bbox(outline),
    centers: centers.map(([x, y]) => [x - fb.x, y - fb.y]),
    origin: [-fb.x, -fb.y], // where axial (0,0) center sits inside the footprint box
    count: cells.length, half: sz.scale !== 1, orient,
  };
}

/* ---------- rendering ---------- */
const u = pct => pct / 100 * SQ3;  // % of flat-to-flat hex width -> geometry units (R=1)
function pathOf(pts, s, ox = 0, oy = 0) {
  const p = new Path2D();
  pts.forEach(([x, y], i) => i ? p.lineTo(ox + x * s, oy + y * s) : p.moveTo(ox + x * s, oy + y * s));
  p.closePath();
  return p;
}
function lum(hex) {
  const n = parseInt(hex.slice(1), 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  const f = c => { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
}
const inkOn = hex => lum(hex) > 0.4 ? "#101418" : "#FFFFFF";

function drawArt(ctx, geom, s, ox = 0, oy = 0, alpha = 1) {
  if (!img || !img.width || !img.height) return;
  const tb = geom.tb, iw = img.width, ih = img.height;
  const cover = Math.max(tb.w / iw, tb.h / ih);
  const k = cover * st.zoom * s;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(ox + (tb.x + tb.w / 2 + st.ox * tb.w) * s, oy + (tb.y + tb.h / 2 + st.oy * tb.h) * s);
  ctx.rotate(st.rot * Math.PI / 180);
  ctx.scale(st.mirror ? -1 : 1, 1);
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(img, -iw * k / 2, -ih * k / 2, iw * k, ih * k);
  ctx.restore();
}

let ringCanvas = document.createElement("canvas");
function renderToken(canvas, geom, s, frame) {
  // frame: region of footprint coords (units) that becomes the canvas; default = footprint box
  const fr = frame || { x: 0, y: 0, w: geom.w, h: geom.h };
  const W = Math.max(1, Math.round(fr.w * s)), H = Math.max(1, Math.round(fr.h * s));
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d");
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, W, H);
  ctx.translate(-fr.x * s, -fr.y * s);
  const GW = geom.w * s, GH = geom.h * s;
  const outline = pathOf(geom.outline, s);
  const fw = u(st.frameW) * s;

  ctx.save();
  ctx.clip(outline);
  if (st.bgOn) { ctx.fillStyle = st.bgColor; ctx.fillRect(0, 0, GW, GH); }
  drawArt(ctx, geom, s);

  if (st.vignette > 0) {
    const p = new Path2D();
    p.rect(-GW, -GH, GW * 3, GH * 3);
    p.addPath(outline);
    ctx.save();
    ctx.shadowColor = `rgba(0,0,0,${Math.min(1, st.vignette / 100 * 1.1)})`;
    ctx.shadowBlur = u(14) * s;
    ctx.fillStyle = "#000";
    ctx.fill(p, "evenodd");
    ctx.restore();
  }
  if (st.cells > 0 && geom.cells.length > 1) {
    ctx.save();
    ctx.globalAlpha = st.cells / 100;
    ctx.strokeStyle = st.frameColor;
    ctx.lineWidth = Math.max(1, u(1.2) * s);
    ctx.setLineDash([u(3) * s, u(2.2) * s]);
    for (const c of geom.cells) ctx.stroke(pathOf(c, s));
    ctx.restore();
  }
  if (st.label.trim()) drawLabel(ctx, geom, s, fw);
  ctx.restore();

  if (st.accentOn && st.accentW > 0) {
    ringCanvas.width = W; ringCanvas.height = H;
    const rc = ringCanvas.getContext("2d");
    rc.setTransform(1, 0, 0, 1, 0, 0);
    rc.clearRect(0, 0, W, H);
    rc.translate(-fr.x * s, -fr.y * s);
    rc.lineJoin = "miter";
    rc.strokeStyle = st.accentColor;
    rc.lineWidth = 2 * (fw + u(st.accentGap) * s + u(st.accentW) * s);
    rc.stroke(outline);
    rc.globalCompositeOperation = "destination-out";
    rc.lineWidth = 2 * (fw + u(st.accentGap) * s);
    if (rc.lineWidth > 0) rc.stroke(outline);
    rc.globalCompositeOperation = "source-over";
    ctx.save(); ctx.clip(outline); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(ringCanvas, 0, 0); ctx.restore();
  }
  if (fw > 0) {
    ctx.save();
    ctx.clip(outline);
    ctx.lineJoin = "miter";
    ctx.strokeStyle = st.frameColor;
    ctx.lineWidth = 2 * fw;
    ctx.stroke(outline);
    ctx.restore();
  }
  if (st.badge.trim()) drawBadge(ctx, geom, s, fw);
  return canvas;
}

function spanAt(poly, y) {
  let x0 = Infinity, x1 = -Infinity;
  for (let i = 0; i < poly.length; i++) {
    const [ax, ay] = poly[i], [bx, by] = poly[(i + 1) % poly.length];
    if ((ay <= y && by >= y) || (by <= y && ay >= y)) {
      const x = ay === by ? null : ax + (bx - ax) * (y - ay) / (by - ay);
      if (x === null) { x0 = Math.min(x0, ax, bx); x1 = Math.max(x1, ax, bx); }
      else { x0 = Math.min(x0, x); x1 = Math.max(x1, x); }
    }
  }
  return x1 > x0 ? [x0, x1] : null;
}
function drawLabel(ctx, geom, s, fw) {
  const tb = geom.tb, k = geom.half ? 0.6 : 1;
  const ph = u(21) * k;            // plate height, units
  const need = 1.35 * k;           // minimal usable width at the plate's inner edge
  const inset = fw / s * 0.35;
  const top = st.labelPos === "top";
  let y = top ? tb.y + inset : tb.y + tb.h - ph - inset;  // plate top, units
  for (let i = 0; i < 200; i++) {
    const inner = top ? y + ph : y;
    const sp = spanAt(geom.outline, inner), sp2 = spanAt(geom.outline, y + ph / 2);
    if (sp && sp2 && sp[1] - sp[0] >= need && sp2[1] - sp2[0] >= need * 0.9) break;
    y += top ? 0.02 : -0.02;
  }
  const mid = spanAt(geom.outline, y + ph / 2) || [tb.x, tb.x + tb.w];
  ctx.save();
  ctx.fillStyle = st.frameColor;
  ctx.globalAlpha = 0.94;
  ctx.fillRect(0, y * s, geom.w * s, ph * s);
  ctx.globalAlpha = 1;
  ctx.fillStyle = inkOn(st.frameColor);
  const fs = ph * s * 0.62;
  ctx.font = `700 ${fs}px "Chakra Petch", "Bahnschrift", "Arial Narrow", sans-serif`;
  if ("letterSpacing" in ctx) ctx.letterSpacing = (fs * 0.08).toFixed(1) + "px";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(st.label.trim().toUpperCase(), (mid[0] + mid[1]) / 2 * s, (y + ph / 2) * s + fs * 0.04, (mid[1] - mid[0]) * s * 0.78 - 2 * fw);
  ctx.restore();
}

function drawBadge(ctx, geom, s, fw) {
  const tb = geom.tb;
  const r = u(geom.half ? 24 : 15) * s;
  const cx0 = (tb.x + tb.w / 2) * s, cy0 = (tb.y + tb.h / 2) * s;
  const sx = st.badgeCorner.includes("r") ? 1 : -1, sy = st.badgeCorner.includes("b") ? 1 : -1;
  let best = null, bestV = -Infinity;
  for (const [x, y] of geom.outline) { const v = sx * x * s + sy * y * s; if (v > bestV) { bestV = v; best = [x * s, y * s]; } }
  let dx = cx0 - best[0], dy = cy0 - best[1];
  const d = Math.hypot(dx, dy) || 1; dx /= d; dy /= d;
  let bx = best[0] + dx * r * 1.25, by = best[1] + dy * r * 1.25;
  const W = geom.w * s, H = geom.h * s;
  bx = Math.min(W - r - 1, Math.max(r + 1, bx)); by = Math.min(H - r - 1, Math.max(r + 1, by));
  const hex = pathOf(corners(0, 0, geom.orient, r), 1, bx, by);
  ctx.save();
  ctx.fillStyle = st.frameColor; ctx.fill(hex);
  ctx.lineWidth = Math.max(1.5, r * 0.14); ctx.strokeStyle = st.accentColor; ctx.stroke(hex);
  ctx.fillStyle = inkOn(st.frameColor);
  const txt = st.badge.trim().toUpperCase();
  const fs = r * (txt.length > 2 ? 0.78 : txt.length > 1 ? 0.95 : 1.12);
  ctx.font = `700 ${fs}px "Chakra Petch", "Bahnschrift", "Arial Narrow", sans-serif`;
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.fillText(txt, bx, by + fs * 0.05, r * 1.55);
  ctx.restore();
}

function drawGrid(ctx, W, H, s, orient, ox, oy, color, width) {
  // ox, oy = screen position of axial (0,0) center
  ctx.save();
  ctx.strokeStyle = color; ctx.lineWidth = width;
  const span = Math.ceil(Math.max(W, H) / (s * 1.5)) + 3;
  const cq = 0, cr = 0;
  const p = new Path2D();
  for (let q = -span * 2; q <= span * 2; q++) for (let r = -span * 2; r <= span * 2; r++) {
    const [x, y] = axial(q, r, orient);
    const px = ox + x * s, py = oy + y * s;
    if (px < -s * 2 || px > W + s * 2 || py < -s * 2 || py > H + s * 2) continue;
    const c = corners(px, py, orient, s);
    p.moveTo(c[0][0], c[0][1]);
    for (let i = 1; i < 6; i++) p.lineTo(c[i][0], c[i][1]);
    p.closePath();
  }
  ctx.stroke(p);
  ctx.restore();
}

/* ---------- stage ---------- */
const stage = $("stage"), stageWrap = $("stageWrap");
const tokCanvas = document.createElement("canvas");
let view = { sd: 1, tx: 0, ty: 0, W: 0, H: 0, dpr: 1 };
let geom = buildGeom(st.size, st.orient, st.flip);
let rafId = 0;
function schedule() { if (!rafId) rafId = requestAnimationFrame(() => { rafId = 0; drawAll(); }); }

function css(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }

function drawStage() {
  const rect = stageWrap.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const W = Math.max(1, rect.width), H = Math.max(1, rect.height);
  if (stage.width !== Math.round(W * dpr) || stage.height !== Math.round(H * dpr)) {
    stage.width = Math.round(W * dpr); stage.height = Math.round(H * dpr);
  }
  const ctx = stage.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  // checkerboard
  const a = css("--check-a"), b = css("--check-b"), cs = 14;
  ctx.fillStyle = b; ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = a;
  for (let y = 0; y < H; y += cs) for (let x = ((y / cs) % 2) * cs; x < W; x += cs * 2) ctx.fillRect(x, y, cs, cs);

  const fit = 0.62;
  const fr0 = exportFrame(geom, st.res);
  const fx0 = Math.min(0, fr0.x), fy0 = Math.min(0, fr0.y);
  const fx1 = Math.max(geom.w, fr0.x + fr0.w), fy1 = Math.max(geom.h, fr0.y + fr0.h);
  const hwReq = Math.max(geom.w / 2 - fx0, fx1 - geom.w / 2), hhReq = Math.max(geom.h / 2 - fy0, fy1 - geom.h / 2);
  const sd = Math.min(W * 0.46 / hwReq, H * 0.46 / hhReq, W * fit / geom.w, H * fit / geom.h);
  const tx = (W - geom.w * sd) / 2, ty = (H - geom.h * sd) / 2;
  view = { sd, tx, ty, W, H, dpr };

  drawGrid(ctx, W, H, sd, st.orient, tx + geom.origin[0] * sd, ty + geom.origin[1] * sd, css("--grid"), 1);
  drawArt(ctx, geom, sd, tx, ty, 0.3);

  renderToken(tokCanvas, geom, sd * dpr);
  ctx.drawImage(tokCanvas, tx, ty, geom.w * sd, geom.h * sd);

  {
    const fr = exportFrame(geom, st.res);
    ctx.save(); ctx.setLineDash([5, 5]); ctx.strokeStyle = css("--muted"); ctx.lineWidth = 1;
    ctx.strokeRect(tx + fr.x * sd, ty + fr.y * sd, fr.w * sd, fr.h * sd);
    const ax = tx + (fr.x + fr.w / 2) * sd, ay = ty + (fr.y + fr.h / 2) * sd;
    ctx.setLineDash([]); ctx.strokeStyle = css("--accent"); ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(ax - 7, ay); ctx.lineTo(ax + 7, ay); ctx.moveTo(ax, ay - 7); ctx.lineTo(ax, ay + 7); ctx.stroke();
    ctx.restore();
  }
  if (geom.half) {
    const fp = corners(geom.origin[0], geom.origin[1], st.orient);
    ctx.save(); ctx.setLineDash([6, 5]); ctx.strokeStyle = css("--accent"); ctx.lineWidth = 1.5;
    ctx.stroke(pathOf(fp, sd, tx, ty)); ctx.restore();
  }
}

/* ---------- field preview (Roll20 scale) ---------- */
const field = $("field"), fieldCanvas = document.createElement("canvas");
function drawField() {
  const wrap = field.parentElement.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const W = Math.max(1, wrap.width), H = Math.max(1, wrap.height);
  field.width = Math.round(W * dpr); field.height = Math.round(H * dpr);
  const ctx = field.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = css("--field"); ctx.fillRect(0, 0, W, H);
  const calib = curCalib();
  const fr = exportFrame(geom, st.res);
  const zoom = Math.min(1, (H - 16) / (fr.h * calib / SQ3), (W - 16) / (fr.w * calib / SQ3));
  const s = calib / SQ3 * zoom;
  // grid with a hex centre in the middle of the view; the PNG centre is snapped onto it, like Roll20 does
  const gx = W / 2, gy = H / 2;
  drawGrid(ctx, W, H, s, st.orient, gx, gy, css("--field-grid"), 1);
  const cxu = fr.x + fr.w / 2, cyu = fr.y + fr.h / 2;   // PNG centre in footprint units
  renderToken(fieldCanvas, geom, s * dpr, fr);
  ctx.drawImage(fieldCanvas, gx - (cxu - fr.x) * s, gy - (cyu - fr.y) * s, fr.w * s, fr.h * s);
  ctx.save(); ctx.strokeStyle = css("--accent"); ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
  ctx.strokeRect(gx - fr.w * s / 2, gy - fr.h * s / 2, fr.w * s, fr.h * s); ctx.restore();
  $("fieldGridName").textContent = st.orient === "flat" ? "Hex (V)" : "Hex (H)";
  $("fieldZoom").textContent = zoom < 0.999 ? "масштаб " + Math.round(zoom * 100) + "%" : "масштаб 100%";
  const aligned = st.fit === "roll20" || geom.centers.some(([x, y]) => Math.hypot(x - cxu, y - cyu) < 1e-3);
  $("fieldNote").textContent = aligned ? `привязка Roll20 ставит ровно · гекс ${fmt(calib)} px` : `так Roll20 сдвинет токен при привязке — включи «Под привязку Roll20»`;
}
function snapToGrid(x, y, s, orient) {
  // pixel -> fractional axial -> round -> pixel
  let q, r;
  if (orient === "flat") { q = (2 / 3 * x) / s; r = (-1 / 3 * x + SQ3 / 3 * y) / s; }
  else { q = (SQ3 / 3 * x - 1 / 3 * y) / s; r = (2 / 3 * y) / s; }
  let xq = q, zq = r, yq = -q - r;
  let rx = Math.round(xq), rz = Math.round(zq), ry = Math.round(yq);
  const dx = Math.abs(rx - xq), dy = Math.abs(ry - yq), dz = Math.abs(rz - zq);
  if (dx > dy && dx > dz) rx = -ry - rz; else if (dy > dz) ry = -rx - rz; else rz = -rx - ry;
  const [px, py] = axial(rx, rz, orient);
  return [px * s, py * s];
}

/* ---------- UI wiring ---------- */
function curCalib() { return clampNum(st.orient === "flat" ? st.calibV : st.calibH, 30, 400, 84); }
const fmt = (n, d = 1) => Number(n).toLocaleString("ru-RU", { maximumFractionDigits: d, minimumFractionDigits: 0 });
function clampNum(v, lo, hi, dflt) { v = Number(v); return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : dflt; }

function buildSizeSeg() {
  const seg = $("sizeSeg"); seg.innerHTML = "";
  for (const sz of SIZES) {
    const b = document.createElement("button");
    b.type = "button"; b.dataset.v = sz.key;
    b.setAttribute("aria-label", "Размер " + sz.big);
    const n = sz.cells.length;
    b.innerHTML = `<span class="big">${sz.big}</span><span class="sm">${n} ${n === 1 ? "клетка" : n < 5 ? "клетки" : "клеток"}</span>`;
    b.addEventListener("click", () => { st.size = sz.key; onGeomChange(); });
    seg.appendChild(b);
  }
}
function buildPresets() {
  const box = $("presets"); box.innerHTML = "";
  for (const p of PRESETS) {
    const b = document.createElement("button");
    b.type = "button"; b.className = "preset"; b.dataset.id = p.id;
    b.innerHTML = `<i style="background:${p.frame}"></i>${p.name}`;
    b.addEventListener("click", () => {
      st.preset = p.id; st.frameColor = p.frame; st.accentColor = p.accent;
      syncControls(); changed();
    });
    box.appendChild(b);
  }
}

const sliders = {
  zoom: { get: () => Math.round(st.zoom * 100), set: v => st.zoom = v / 100, out: v => v + "%" },
  rot: { get: () => Math.round(st.rot), set: v => st.rot = v, out: v => v + "°" },
  frameW: { get: () => st.frameW, set: v => st.frameW = v, out: v => fmt(v) + "%" },
  accentW: { get: () => st.accentW, set: v => st.accentW = v, out: v => fmt(v) + "%" },
  accentGap: { get: () => st.accentGap, set: v => st.accentGap = v, out: v => fmt(v) + "%" },
  vignette: { get: () => st.vignette, set: v => st.vignette = v, out: v => v + "%" },
  cells: { get: () => st.cells, set: v => st.cells = v, out: v => v + "%" },
};
for (const [id, cfg] of Object.entries(sliders)) {
  $(id).addEventListener("input", e => { cfg.set(Number(e.target.value)); $(id + "Out").textContent = cfg.out(Number(e.target.value)); changed(); });
}
for (const id of ["frameColor", "accentColor", "bgColor"]) {
  $(id).addEventListener("input", e => { st[id] = e.target.value; if (id !== "bgColor") st.preset = ""; syncPresetUI(); changed(); });
}
for (const id of ["accentOn", "bgOn"]) $(id).addEventListener("change", e => { st[id] = e.target.checked; changed(); });
$("flip").addEventListener("change", e => { st.flip = e.target.checked; onGeomChange(); });
for (const id of ["label", "badge"]) $(id).addEventListener("input", e => { st[id] = e.target.value; changed(); });
for (const id of ["labelPos", "badgeCorner"]) $(id).addEventListener("change", e => { st[id] = e.target.value; changed(); });
$("res").addEventListener("change", e => { st.res = Number(e.target.value); changed(); });
$("fit").addEventListener("change", e => { st.fit = e.target.value; changed(); });
$("calib").addEventListener("input", e => { const v = Number(e.target.value); if (Number.isFinite(v) && v >= 30 && v <= 400) { if (st.orient === "flat") st.calibV = v; else st.calibH = v; changed(); } });
$("orientSeg").querySelectorAll("button").forEach(b => b.addEventListener("click", () => { st.orient = b.dataset.v; onGeomChange(); }));

$("btnFit").addEventListener("click", () => { st.zoom = 1; st.ox = 0; st.oy = 0; st.rot = 0; syncControls(); changed(); });
$("btnCenter").addEventListener("click", () => { st.ox = 0; st.oy = 0; changed(); });
$("btnMirror").addEventListener("click", () => { st.mirror = !st.mirror; changed(); });

function syncPresetUI() {
  $("presets").querySelectorAll(".preset").forEach(b => b.classList.toggle("on", b.dataset.id === st.preset));
}
function syncControls() {
  for (const [id, cfg] of Object.entries(sliders)) { const v = cfg.get(); $(id).value = v; $(id + "Out").textContent = cfg.out(v); }
  $("frameColor").value = st.frameColor; $("accentColor").value = st.accentColor; $("bgColor").value = st.bgColor;
  $("accentOn").checked = st.accentOn; $("bgOn").checked = st.bgOn; $("flip").checked = st.flip;
  $("label").value = st.label; $("badge").value = st.badge;
  $("labelPos").value = st.labelPos; $("badgeCorner").value = st.badgeCorner;
  $("res").value = String(st.res); $("calib").value = curCalib(); $("fit").value = st.fit;
  $("sizeSeg").querySelectorAll("button").forEach(b => { const on = b.dataset.v === st.size; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
  $("orientSeg").querySelectorAll("button").forEach(b => { const on = b.dataset.v === st.orient; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
  const flipOk = st.size === "2" || st.size === "4";
  $("flip").disabled = !flipOk; $("flipWrap").style.opacity = flipOk ? 1 : .45;
  $("sizeDesc").textContent = sizeByKey(st.size).desc;
  syncPresetUI();
}
function onGeomChange() { geom = buildGeom(st.size, st.orient, st.flip); syncControls(); changed(); }

// Roll20 snaps the CENTRE of a token to the centre of a hex. So in "roll20" mode the PNG is a square
// whose centre sits exactly on the centre of one footprint cell: after snapping, every cell lands on the grid.
function exportFrame(g, res) {
  const s = res / SQ3;
  if (st.fit !== "roll20") {
    const W = Math.max(1, Math.round(g.w * s)), H = Math.max(1, Math.round(g.h * s));
    return { x: 0, y: 0, w: W / s, h: H / s, W, H, s, anchor: [g.w / 2, g.h / 2] };
  }
  // The square side is a WHOLE number of Roll20 units (70 px each), so resizing by the corner handle
  // snaps to exactly the right size, and no numbers have to be typed.
  const calib = curCalib();
  const unitU = 70 / (calib / SQ3);                      // one Roll20 unit in geometry units (R = 1)
  let best = null;
  for (const [cx, cy] of g.centers) {
    const half = Math.max(cx, g.w - cx, cy, g.h - cy);
    const n = Math.max(1, Math.ceil(2 * half / unitU - 1e-6));
    const d = Math.hypot(cx - g.w / 2, cy - g.h / 2);
    if (!best || n < best.n || (n === best.n && d < best.d - 1e-6)) best = { cx, cy, n, d };
  }
  const hu = best.n * unitU / 2;
  const hp = Math.round(hu * s);
  return { x: best.cx - hu, y: best.cy - hu, w: 2 * hu, h: 2 * hu, W: 2 * hp, H: 2 * hp, s, anchor: [best.cx, best.cy], units: best.n };
}
function exportDims(g, res) { return exportFrame(g, res); }
function updateStats() {
  const d = exportDims(geom, st.res);
  const calib = curCalib();
  const k = calib / st.res;
  const sz = sizeByKey(st.size);
  const rw = d.W * k, rh = d.H * k;
  $("stats").innerHTML =
    `<dt>Файл PNG</dt><dd>${d.W} × ${d.H} px</dd>` +
    (d.units ? `<dt>Размер в Roll20</dt><dd><b style="color:var(--accent)">${d.units} × ${d.units} ${d.units < 5 ? "клетки" : "клеток"}</b></dd>` : "") +
    `<dt>Roll20, px</dt><dd>${fmt(rw)} × ${fmt(rh)}</dd>` +
    `<dt>Клетки</dt><dd>${sz.cells.length}</dd>`;
  $("fileDims").innerHTML = `PNG <b>${d.W}×${d.H}</b>`;
  $("readout").innerHTML =
    `<span class="chip">Size <b>${sz.big}</b></span>` +
    `<span class="chip">${sz.cells.length} ${sz.cells.length === 1 ? "клетка" : sz.cells.length < 5 ? "клетки" : "клеток"}</span>` +
    `<span class="chip">${st.orient === "flat" ? "Hex (V)" : "Hex (H)"}</span>` +
    (d.units ? `<span class="chip">в Roll20 тянуть до <b>${d.units}×${d.units}</b></span>` : "") +
    (st.mirror ? `<span class="chip">отражено</span>` : "");
}

function changed() {
  const z = $("zoom"); z.value = Math.round(st.zoom * 100); $("zoomOut").textContent = Math.round(st.zoom * 100) + "%";
  $("rot").value = Math.round(st.rot); $("rotOut").textContent = Math.round(st.rot) + "°";
  updateStats(); persist(); schedule();
}
function drawAll() { drawStage(); drawField(); }

/* ---------- stage interaction ---------- */
const pointers = new Map();
let pinch = null;
stage.addEventListener("pointerdown", e => {
  stage.setPointerCapture(e.pointerId);
  pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (pointers.size === 2) {
    const [a, b] = [...pointers.values()];
    pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), zoom: st.zoom };
  }
});
stage.addEventListener("pointermove", e => {
  const p = pointers.get(e.pointerId);
  if (!p) return;
  const dx = e.clientX - p.x, dy = e.clientY - p.y;
  p.x = e.clientX; p.y = e.clientY;
  if (pointers.size === 1) {
    st.ox += dx / (view.sd * geom.tb.w);
    st.oy += dy / (view.sd * geom.tb.h);
    changed();
  } else if (pointers.size === 2 && pinch) {
    const [a, b] = [...pointers.values()];
    const d = Math.hypot(a.x - b.x, a.y - b.y);
    st.zoom = Math.min(6, Math.max(0.1, pinch.zoom * d / pinch.d));
    changed();
  }
});
const endPtr = e => { pointers.delete(e.pointerId); if (pointers.size < 2) pinch = null; };
stage.addEventListener("pointerup", endPtr);
stage.addEventListener("pointercancel", endPtr);
stage.addEventListener("wheel", e => {
  e.preventDefault();
  if (e.shiftKey) {
    const dir = Math.sign(e.deltaY || e.deltaX);
    st.rot = ((st.rot + dir * 2 + 540) % 360) - 180;
    changed(); return;
  }
  const r = stage.getBoundingClientRect();
  zoomAt(e.clientX - r.left, e.clientY - r.top, Math.exp(-e.deltaY * 0.0015));
}, { passive: false });
stage.addEventListener("dblclick", () => { st.zoom = 1; st.ox = 0; st.oy = 0; st.rot = 0; changed(); });
stage.addEventListener("keydown", e => {
  const step = e.shiftKey ? 0.05 : 0.01;
  const map = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] };
  if (map[e.key]) { e.preventDefault(); st.ox += map[e.key][0]; st.oy += map[e.key][1]; changed(); }
  else if (e.key === "+" || e.key === "=") { e.preventDefault(); zoomAt(view.W / 2, view.H / 2, 1.05); }
  else if (e.key === "-") { e.preventDefault(); zoomAt(view.W / 2, view.H / 2, 1 / 1.05); }
});
function zoomAt(px, py, f) {
  const tb = geom.tb;
  const ux = (px - view.tx) / view.sd - (tb.x + tb.w / 2);
  const uy = (py - view.ty) / view.sd - (tb.y + tb.h / 2);
  const nz = Math.min(6, Math.max(0.1, st.zoom * f));
  const ff = nz / st.zoom;
  const Px = st.ox * tb.w, Py = st.oy * tb.h;
  st.ox = (ux + (Px - ux) * ff) / tb.w;
  st.oy = (uy + (Py - uy) * ff) / tb.h;
  st.zoom = nz;
  changed();
}

/* ---------- image loading ---------- */
function loadFile(file) {
  if (!file || !file.type.startsWith("image/")) { toast("Это не изображение. Подойдут PNG, JPG, WebP."); return; }
  const url = URL.createObjectURL(file);
  const im = new Image();
  im.onload = () => {
    img = im; isSample = false; imgName = file.name || "из буфера";
    $("imgName").textContent = imgName.length > 28 ? imgName.slice(0, 26) + "…" : imgName;
    $("sampleNote").hidden = true;
    st.zoom = 1; st.ox = 0; st.oy = 0; st.rot = 0; st.mirror = false;
    if (!st.label && file.name) {} // keep label as user set
    changed();
  };
  im.onerror = () => toast("Не удалось открыть файл. Попробуй другой формат.");
  im.src = url;
}
$("btnUpload").addEventListener("click", () => $("file").click());
$("file").addEventListener("change", e => { loadFile(e.target.files[0]); e.target.value = ""; });
let dragDepth = 0;
window.addEventListener("dragenter", e => { if ([...(e.dataTransfer?.types || [])].includes("Files")) { dragDepth++; $("dropVeil").hidden = false; } });
window.addEventListener("dragleave", () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) $("dropVeil").hidden = true; });
window.addEventListener("dragover", e => e.preventDefault());
window.addEventListener("drop", e => {
  e.preventDefault(); dragDepth = 0; $("dropVeil").hidden = true;
  const f = e.dataTransfer?.files?.[0]; if (f) loadFile(f);
});
window.addEventListener("paste", e => {
  const items = e.clipboardData?.items || [];
  for (const it of items) if (it.type.startsWith("image/")) { loadFile(it.getAsFile()); e.preventDefault(); return; }
});

/* ---------- export ---------- */
let downloads = null;
(async () => {
  try { downloads = window.claude && window.claude.use ? await window.claude.use("downloads") : null; } catch (e) { downloads = null; }
})();

function baseName() {
  const raw = (st.label.trim() || (isSample ? "token" : imgName.replace(/\.[^.]+$/, "")) || "token");
  return raw.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-+|-+$/g, "").slice(0, 40) || "token";
}
function sizeTag(key) { return key === "half" ? "size-half" : "size-" + key; }
function renderExport(sizeKey) {
  const g = buildGeom(sizeKey, st.orient, st.flip);
  const d = exportFrame(g, st.res);
  const c = document.createElement("canvas");
  renderToken(c, g, d.s, d);
  return c;
}
const toBlob = c => new Promise(res => c.toBlob(res, "image/png"));

async function saveBlob(filename, blob, fallbackCanvases) {
  if (downloads) {
    try { await downloads.save({ filename, data: blob }); toast("Сохранено: " + filename); return; }
    catch (err) {
      const code = err && err.code;
      if (code === "declined") { toast("Сохранение отменено."); return; }
      if (code === "rate_limited") { toast("Окно сохранения уже открыто."); return; }
      if (code === "too_large") { toast("Файл слишком большой. Выбери качество пониже."); return; }
    }
  }
  showFallback(fallbackCanvases);
}
function showFallback(list) {
  const box = $("modalImgs"); box.innerHTML = "";
  for (const { canvas, name } of list) {
    const f = document.createElement("figure");
    const im = document.createElement("img"); im.src = canvas.toDataURL("image/png"); im.alt = name;
    const cap = document.createElement("figcaption"); cap.textContent = `${name} · ${canvas.width}×${canvas.height}`;
    f.append(im, cap); box.appendChild(f);
  }
  $("modal").hidden = false;
}
$("modalClose").addEventListener("click", () => $("modal").hidden = true);
$("modal").addEventListener("click", e => { if (e.target === $("modal")) $("modal").hidden = true; });

$("btnPng").addEventListener("click", async () => {
  const c = renderExport(st.size);
  const name = `${baseName()}_${sizeTag(st.size)}_${st.orient === "flat" ? "hexV" : "hexH"}.png`;
  const blob = await toBlob(c);
  saveBlob(name, blob, [{ canvas: c, name }]);
});
$("btnZip").addEventListener("click", async () => {
  const list = SIZES.map(sz => ({ canvas: renderExport(sz.key), name: `${baseName()}_${sizeTag(sz.key)}_${st.orient === "flat" ? "hexV" : "hexH"}.png` }));
  if (!downloads || typeof JSZip === "undefined") { showFallback(list); return; }
  const zip = new JSZip();
  for (const it of list) zip.file(it.name, await toBlob(it.canvas));
  const blob = await zip.generateAsync({ type: "blob" });
  saveBlob(`${baseName()}_all-sizes.zip`, blob, list);
});

let toastT = 0;
function toast(msg) { const t = $("toast"); t.textContent = msg; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => t.hidden = true, 2600); }

/* ---------- sample art ---------- */
function makeSample() {
  const im = new Image();
  im.onload = () => schedule();
  im.src = "data:image/webp;base64,UklGRopKAABXRUJQVlA4IH5KAACQlAGdASr+ASMCPj0ejUSiIaERiMTUIAPEs7duX66nrt7Nfw3Ub2KE9akuOaNXzW783/n9uLLvwb+r513LPjj9jyldi/XX7Rem35z+6/+f/Lfmp80f+b6vv67/v/YK/qn+P/ZL12v2k94fmM/bP9vvds/4P7f+9P+zf8X2BP6H/jf/3/0PfN9U3/Qf93//+4x+3P//9n//1fu/8NH9q/7P7ce17///YA///to8Kf+2fpG+sfdDxv/UP0H+T+ZHxv/7Gav5Lrif0/8V7he3X928RT8v/pn3Y/HPFScQYK+MP8bsiNAv+gf4X1kP/D0I6i/SpGSGqb5dQy+AUbmhToYWM1WjdkU+Hss3Rp0YPeOOt14ue1QxMb5dQy+AWfy6WEVKytC+ggrUcTws8Rqcq3MCc3TzmozwUIQLT5dQy+AWfy6hfAMzOU2llM6RWEJT5WRWH65dfRVQ68cqQoevBQXZyPCw6IZUTfLqGXvj8YPOhvrN9Eqo5jM+YMhUP16/eiR1NwDcNwPQy1J306NlgUTJhqNUqp6nMqJvl1DL4BZ+OtlIdNg1vTIqHOSfILoP4tdwD4HJlQINdhnLAOC+CBeS1bZBCZV66Y5J9YBBHJcf+P0XjM3dpRaMIcUwPy6hfALP5dQtbt3H8Y+NLHcv6/o1xxoqNpEA2yylhtW+EPIzjIWKcj0VT5sfqGPMk63eNaDW9OscHdeiF+D3euRqg54YQFBj8dF8As/l1C+AVq74jAgeVx5sVxPR12J87hfpTvZPfR/PfwDY0n7hXYFzi0JgNzYVhh9fPBlak5otS06VekCziwDSjq38P9qX0QlXKfJWNZpdQy+AWfy6f9bPgf7RzLBZaS05Q1faTdOMQ6bbEnLQu0UaHzr0ierhJMmHXpeVxtOH53++qdLu64oSVTL1gGb/phWHlg6CDPv/QaIw9ybJmw7EFtESnojl8As/l1CwgOdr17Qq58Bh4i7P2BrwkDhGeEdTAlfRjRHsnaTvl5c5+jypdjucdzK9AcR7zIPPt7/GhejVE+POSopkNlwM2+yoTIFJgdERTh9PlViO7jycn4Xey+AWfdv3QPIsBDz8Ubads8JwuRxzJioktV1/ynkRB8GfhyASHMvjaLoUo74rNqe/30D9QlWaDGTF8/depbaf2Dhq/wUMW/UqzfxGxhAxdzDkUnAii0VcLp4hmSgA6UcaWDn6F9wpZKEs8As/l0QtKsakhSrH8L2lE65MpbbFxMkm56OFkS7awfZk+rjUpH4wIMKyjD7oRll2VRcxM1j9nba4WmOew8+H5+I/hKhbeG1vNTx7GodbDRipN3DIcuAvIORDItXFRtl0iX2vTExvl1C+ytL6rxqZVxrOBfIDj0N2k56Bxx9WXWXccLhLd3Lt33646SNb686m2WaIbuCfsE2XY+H9TM307HC5sGxH9KMUfO0oRevllnuDb7I4OQ5urhbWC56PsAGg8FW0l6tYbH8uoXwAUdk4TwSXl9tfB8jKoX/pUfWx0PReyTWF+lD3yk9L2IJZFvSWhkNohEK1zlBuFbMGnGBldLgTWWpLBebCn84DXngjuVR+rQNaArhP/PUno2N+PQ4IhQdgxTx96sOeuMJsubot5xR2KdPG6Yeb5gn9ZpHtTvnc51gGSmaULozB2UCxwKOZp6quEaR8kZZSY3gKo0QKuhd1DOExJjQRvsvLxKY+Qf+yWK/anSd/eBMLx8T3QJS1bG6N2ihmapWxeZvqpUv2WiK+lc7WLyIUkNLWLCDv3kB8kiOy4zSuVB/UCGszbw60quWmeuFBTf7OnxE9eDmHl1F0Ed8gIyuDStvUGLYNnvr82OY410gj5CjX7wwUczNiZOLxcsldXdWGuEjQkEN2qYGYroESNNgVo0KCAd6j4yt3/TGs5qg2Kvdwh8b09uDzxsJ+cE7olMU2so58UmzXXZXHZHn6TmVreycRWbrDJNLowei8T+shPjKO5s+InBokSTGxyicxpIatVyqv6Wz0CeMgMNf8iUOblimnE5HI7ouDX3pI6uC99C0LoBhSxbHj3FIk56rdUqqn6LvolILB5IU+K2MOLDPnlZYqCrpcvUxusTrSs5YAyEbMA4mXosUVpOkl911MwZ3J706bbkpcdlVvGS/c2hkdZ9iR+oPZfAXy3+CMDNuiiw5qBcq8WuQ/1X4uJiyF8H7cnuJfmWH9IDx8NLXDD9DgGaAtdb6MF2NTzkqb3ASfx7L2nrkT5uzD+kE5YnhMlHTaNMTlB57zMnbvRjaY7O1qaF+fcTHHOFTxvbL4BZ/LTYlIfMithzgoQG5N658bGF3EEpv2xJEdPsJgarui0VlrAm70RLqVqQeOEEkNn5fpQWo5YxLTcDgsm9mpnhucNkFvBq/9M2xJGYttbrsZxUD2GY1zdL/YBRsrr5VKMAs/l1C+LXTkn03oETrpOfURiR5NFHpqkupaQZANJlub9u3dDvLv/KD2qBhEi+NdNtqrswRq+nMYo70LYpHJVHqIROmASX8H7E8d7nFXXPEa4teLGMQAFdLP5dQvgFmsXwR/xrdDS1nKsYTP5lXnlZl4RBjcds5nBLv3ts8aoRkVs8XFbCXmWGwQfx8NX0ChJ2hu+Th0kqCV6IZIuB2CcC/EMcSJFjSSWPe2YkvOpx/SqJBasUccshr1zWD2XwCz+WpZf/nXslxyWY7JDE0eXQEdR7sNaaGwUFiwQhmmGoXMQJRn+sGCl3xOTlbFqqA1+JAqmsk+JEOtAXQprB898qBi7yjAA/jWo0Y6S7FfhL+AGbcoYIHQcjEyY2Xgqhhl8As/HlrZ+riPtn093XvotJzmBdTibBQoFtdC3x2lfDdL/+3g3YKTDJKAcfkywgc0QzfLzJNif1IsJae8VVoS3gpEOrFJ1ImwUYmVrXpqR1L/e/WCKHKAYEQyom+WsbzbIQXBox71K397ktdCcCVVPIgocT5SJXdUn//lMeswPwWja6ItwzW1nv0kwxJrfU+/mzUXWRYeXS2o5j4YgFRB5zWTeDgLe9p5wXDQPQ5r4BZ/LZOKni64zs99Rrj45Rhs3ZOazDenQeGBYi8apCFXxW/34SDMBnbN5iW3OVmzs3A9QZ5QFgqj88mj8rDdqSsXXYJqWvF4LBGofln6hAQBVPqdTW5JsFn8uoXpOKEj7E401P6fmiplYxFSCVGswvc7fvuss8KGpSnkVoPQj/CQ52A0IW1U5rxlY0+GOfT1XgIdNiZFCa+HgXPXvEAJUJKDrpV/CtF8ouJ77IcGJoPWgjvSG6CmrmfikRlLtPxMb4/aHLvRzkHOL+d0IQGo2X59qZCpaWo3dWbiPcCnxh2Zj3TKqJzkidBs9lTV1l4ZCNEUq+4LJLhGZbxuQZ0pk4Tgxv5Ev5pueylEGjci60Aqy82eRvGz1IAO3w3SlZEH2vJOxkXa6T4FHK6mo+tnypRq+ssA8As+9LtlPPImnKNEWeNyBGMxzBio0WpiuNHTyrmfeyUbAJ/XmNY1fzNbbtEQO9tNSR4kBOyAFrDBUsUgI2uk0WQ5bN13DJDBoNxb75EVuP+zhIa2QhMIOjw65j/fOACZpjtVzJL6evq6frLmHyQlYbfQw5Z3T0/bb33O4OF3nS/j13wdPSCLZl2wMRLEmHd7sPtJsgbRrgFtcKUor4Meauavoe4J+RK++S5CiCM7oxAxk3z8K7nenWVO+DXEYCpa2isNI0cWrZbr0RnjxsP6bJks2IOcwcFux0NHgnaw7702y6MXmyk14mRpNCzRjCYN7KFJCrgTQoeOOvpRwFjLAM3ReiPyUbeFLtvFhsPpK7tnY+wlYBcOJf1kA1crAY1aFlscyu4OURKCb1tUr4pmXUSYZeikxU02HAdoLymrcskkgr7XhOMGRYDTBSJn5K+BU11Hzy4pt5VLgILoCvP/5bNkvnNngoDiEzqBaurlM1FmDuliZz2vvyePJ0MPUF0BRbxX5gPbhxuzynLe+jVJgb/og0JJFJ4AujK4/dQy9oA9lowbxOkPjmngCpag25p5L1hUJ32OnF5w63cFPsyIHOAPbdQ9u+HvnKE5Na0fqVcVHV13UQhwRImlRHrZeuGUSqx69mRAvLamyz4UShk71RVFcGHB6rkxSMmkPc5aWSk+KkpZWG3+zx/m69PjFvR+iGaywftEIgw4AvyIPhiIwe1etY9VtotSx27+gJ6//97tpR0+8zlzJgJ9o1oZK0/EXcuw7sgbnPzh7Dgp6XDVgplRaurMIS7EnG9p2vHsXK4c8w+KfSVaG3yBIE9Isz5wocuVmsQ5K3D8wvWQDoucTHNNZPb8DvG9eZhPe82WSqiPvsyrdTEMAAD+/2y+s9iWsJcJ0FwAGeadGI9mxpSBmy1GU+rXWDyECKoy1+DZw+jobRKWMxPrd9NIZsqOr37m5lJ3xutTE1Y97+6JsSmgoTyUqKkzgJGVmsocxLAXy6fgS9rQnyM/uJXF6yS/Uva6mHLrrzw2isLxPfHyoFBrFv+W8borRcAaiyPUG6kJLtSeWpieZlooBQ3F9Z7/9fjjHGCD+s3gBmXsAACaoPYrmGjn3nqq54vXJQ+YNGe6RbqORcH+peGQS0rOwfm57ma9RqjVQB73FTWVcYFmNxpnrDuuzHDQQU9Z/gcghIwI0otdv2BNYCT0/WrLpRPLId+5G3gBUMZEAAjK0GK/5NspKRQeJBQKP2S+2h8yaTzTsLMb4NRQaW0fY1XYINFEDTO3VfxvCE7GpBkH44/ORZx9XHXKmgCGOUiwsZ8Z+ZTgAEbwUAAAABCHVgvTgo5TKWP1XjJSvbZqpGMcnrg1+4WkWrriG9//bwpDB1L2BVtdzcLWAB1QEELOc0ysYcP0Thu8qFlihrOulYtAPeZpVbD/3FYf20RGRCePzvI4B6r9taI5/qk7vJsD9ABUgqvJQqxhw9h51W/rOm/JZZchcdJxHdkk23d3J2cR3k3RRwSAve1jMxAechEdj4HKQsp9LC0AAAOR6nhDgJvYAxwWgL7TwuJ9gpm5Ic8VS1tpjDdwuF8DEkP/I1zxjubZ+C+XUn/pGs+Nd6rTIejcqpv452JMrO+PXazqljNmQ4rW84sc0dvTC6urUKGDzuxSBS8FgWrVHAydag6K+/HWZbtk0Jy7IecVtj1TyyWFJGxtGhb3ebTqutZhDT31Vt8kZXhrbryKISgKKlW51v2k4GrT1BlKbSlRW1oqAMdAgcTAZcn/p7EYwtY7QSYfTcZ8sYIEzlLuG5RBEUp51iXVNAM++DamkkAV+JvpWsooMHD8/IkKVs9R5cdwRu2LLLVSqhshwAAACHpcW6W5ft5Q2hv2M0wqUi5hISd5eYh42m73HVNX3GfOhm6o5wgpiE5HMXxbrWl/fWi+6/V0UhnQV7/8nAVGNiFLlHGJVtS+DwbsQM8l+/zdOArzi1PZeVeoE7VYpmnFTNupzE+/yX8xAwakmG+HOu98aFPmI5smdbt7FDG79fFDEh8ccw2dnYfnC70qTPx4Mv9V+DycOHokkg+HyIJ/et6gEcQAPuP4yA7bfZ2dcxmrr8ZeSwj7ExvzzRQkoa3OkLx6YhYItnHtLYlXI3E0FDXSXfbicVv45HlMUl0DDAenlKHKnTc0Krl2+bQdwyPnOHHF/fZfiWubiI+DYfzLB70Bgr7ecnvE5v+o20bvbjSqFfikAalXQvy91chKpnMCUQH0W0kX2yzGLedEvXEyTaZmQDuQ0ddrIgAAAAG8Dc2+QG+VfRzYdyhrawyb0hyDtvQBsGnyJ5Zdy0/wGj6hZs0tVquXH5679BFoVXglqfQfz8nhyAb1/G8wW7VBX6QuXjwz49iHtXq0SPKfMUZ7HVy8YKsZ0OCc21ZnJXIEpiolUkdpxGxbxjEQsb60vbBi2NfEKqH4ym86KLXcQfzoAwfRQjzN/Q9NEWrACGL/1cQjYoHpZvKzKg6CpO6mUhIX8K/R/hrfqp0hn+iPBujg4Zs6Ty7o98qtgpHL/ugjJkKOmpvn4nqyBQ8l60mcz62YY9TkFMKuxMVZ0+0vaaaFRbpET11aobPNjWgI/s5nQHgXXY9Xw3pSC6+tDGmBBqxHI5PuAoTuBZb/8c0sWZVfOgVbaRV+x+hv0UjxQaH8ik2489Di5XZk4fsekiVv8I5vi+HZaKb4V3Vly4dwFP8obINvhQod7+FBX/pCaMQ8Z8bGHTlSfATRm9Tcun2SkT6qcBhmZkdqP5o2gwANakAQdmyUEORAOft8AAENMA238mga32Ym8f9RhcrqXZtSNZpufImCorpxji+7e8ActHObmHDd2ZBeoN8lKac6jOozV8mz3VZtiM7caa0eNAN7sUUzPB6i8xH7FbbJmtB/LLgg/Xgt3r/Pd8yXHJnp0XTvW/VLXTQ+YBaWReYhk5t9MBzWelFJaHH8By7c9NmRi9MALV8CigMIzZuYp2hSqKhf1J/KKdaMizgs1Yi/29tC0uYu22IU7Wztoltl5gDz43NklYcZ9eTul+u3Atk7gt0fgDB02wb3QJTFh+jt+2dRzFaB+qmO4Q1bruA92W4E6ekEDwSS9A4R1X0jNpxg/S2n+xoZIADR1u+nSgkPazR6eSYbk8EOWicKo5ZO0CCYMmNjfmylKwphrBQi7kL6dOkQNL6UkDLCfvh4cI5wmjRvN+pxdBlvLEdfEYYrNlSNSjpU77AI54fSUphWLuI6OQIOt6oYlWU8Yf67R+QDLjcczGqWjpan3mpd8eccB/Mtpnn0GeNuGONHfXDGSvdcL2bnXVAyyITJGjIKABhIGVVEPK3b/F8EJSA2h9JXvwp1Gc3wZGDfoV8SzGowozNhdwC4tS8urfYBXxYK0JzNzdW9b0SV+mrrT2/P2bZAx7MYH5YtEYbmLg/ZtfPtvq1EalX4zerm5bKG/Iml6OymG7CZd+0IZ9AFHLOg15INiRSpTZlSlwDx38jAAOZ6nkVvXMZO5dznQHPpR/5leVNQNEoLmabeWNS+cxNMdrtL5K9XBB2Q8XjR+lBaLS9k84B0fg62E3hlat1JiT8/ZFnh0KRWzpNnx+FPuhobuniZu3PKtNHwEKg2jo3pa7dE/h2fHM11L9aP7XGsAD/Mk2X4Jrz2qzX81KWhz8P4CufhU/Zrsu1SREYVSlh3fPB66WzvVs8MFQeHZxI+w6ciadrlwxXfmZCvh20qQfYgOVdZNi/2ehSMr1xC8388NtMNcJq1NnvWrQV+YlZzhrHogjqlMy1+3T0GeFXNblQCDB5IdE0tZzRa09cG/GTV6++wTN/HtOXn2iKvITpAP4OILWMIihCecp9QiX0MYuUCXxWJDo3xV4HhfjiJFt0+FE1dx52gPBJXjiT0bh2gXGPOqgYwKeuyCmf4xmGiRtE+wplh+7zkst2Zhq2GNFyTiCq2vDD+KdNwKRyXKy4KmBHlN6nPRkyTN5fM/g9J1yJfjygbCbRk4GxxP5hdGyl8SmfI5CvJBjwBo+i6S5Y+27CXtfJVoMSowF9CoUaWV6sam6F6XOfhAgvy0ehO4iWr7vpteEt1cIC1AmiLUXSjaAN1jQ4rWtdqsl2puUJ78dfiyty8gZunAOL+OlgD3/WqxBouklEE3dpEQHlb8dBSZOh3txbQYKZgTcpuwvhu5luSsxjnRwiWfI38iiVvVhJGB/0QhOjbP5mNllCCMKW7AojKL4QAwpCupyIWAKktSixnT28SBnt4WWhHS7fTK/Ne05Oi9szwP1wgfb79Nqr480oyfxxerE79rV25Oc9Z4rKCvRPP8zM0eY/hBdyeftZZ8S8dQqmro7LoDOFfvWYjHfS+A3j8TGDXIiJjDu5+NRs+DzB7xQxfAwUG2uwIth4Q9CKeIECaZUOeHZ94jU8WvUTQZIpJk6mU004Rl5IiC+QMKlW2xEQtCQBlEUy/Wt51Q+a4SamqjZEBHXblYqLBaxHN2DCa/jFvN7WWNAxj96HnzokdIlTutKxn2kf4LxPmDRd75RIYZ1e+jKfENu1iJfBCASDwxxQzNMAAx5rCBU1U4/8nxnpHhNLt32oss65ej0O2WoUjrqUHdODi+C8DEI5nokTkkKF+FXlMkC9XIJwL+IYz3Hzvpa9pzRXSigrIYbqTfinLIsgCu5QHSgxGwyR2xzvEkRIg7+KdWp86JLXt35gL3yQs0y5NVJpGwCt2umZIB2PPE9I6fNPxY7g8fVRkwGsxA3HtoqRL2h6eruTlgad1qSouGlkNnh4ugfA53SwTlCM69O9vc9cJmHxKohQn7uWxa+jQNpLQOjGB2KXIR6ROh3LeHG0CdwKIshQmDKZ8dTNpQTwgHfZTxYmmi2VST+7A0gYKYsNV03+eJxO89nYjdvsY2wuKejYnkrHYnnOuKxq9v0uO4q/3vB910JDuAqjacFFw2kTYr5vxFw6/9mrih0Rr4UBvRCBAQ5pGR05NHgT69huHv/3jE23XKTANdOmnDMT1R16cbRfL/LwD9svVens3qBlu+MtILauZE0HfzEDReUWn9PbNkKdkQB0eklamQAPMvEIswp4f8DT2TiF9Tnmy0YwG+oqiBTFnmZDyjoBe5+11vuzr91MFe2POpiPtnIshgQ8NCFJ4N/2RF5PWGo9JyfZv2ujX9UizRI5BvmSorLOT64v1SFinj9kkAoSofndapQ8jfL9OOZ2AMG8Ez2kc3/uweOqHHCykSKbs7nb+hOoUzteGoPetk5oDMeriipBd6YyUoXLTjp3t5Gf828RcT9y2/Va3hSbHOjxYPSvloFu1eOsW/mxIPR77KNC5uWuK/QG43gCS4XsUotONRn8YoB0cEIDcWEQlrTfGPCwoERXle+UaPpSCLcvaBP1mA5r/4SXsCSjxT3sSf0pmpMabw+at0SLV9Cz1zCVGiN6FUjDl8GyGB7Mp3j81NMox1IEl7FZJYiFwNrWCBWb2GmNApZIov8XVHL5689ryHnJEnEAnomzGxhoAA+BJH5AjDPlVQI2AhIlVmtv3028KKlZYrUaFe0QrKYph6X3ZeUQHgo/J/zQ9zVgJr+Rm2bj/Fu0FTARsEsNI3IOX9Ebs0ZW5ntfwSZlWiy12Jtwr8/6hcyqNNwlw2kchbxXV9QCw3fQ8BkVFtt3UoFPIqurWlgBk/KcmucNi54AON5KIoA4eqQ50lceRDNCRnzEQBuIo3IKo2HVp6OtIDZgGxLl675zipgciYg3zSL5pdMi69T3Xw7nBUJDtixy0yQHN9kTpfiO2OWBb/DlI3rIgpqSBOy02EO8tagqjbvTSAoNOat6pldmFKkf9lY+v0n2/K/Vyhs5xn0AchS6lmn/0joQi81i8oVXpiT97TuwmdJw9jUbBlaoW84oP5FAqqgjrv6bMgl8Tp2HJJ7wCaAjOR8EcLca7vWLijEbReopGBy4ySf03q+lJU5ZfxXa/VeSQ89KHFMr/JnMnoFfW85JSdZovL7CAC6HCnZ/MEYduwKz7bVY54IXc15tRmGUoChPYlOZ+g8pxh0Mrqybw2fAeBM7GUtJ3tlruclHFo9vQU9yH8ao6k17KLE4m6O4kt1N0vt4M0qCXoglOaYwyPQQ3qtXZZS7rsexAJ7PqJrKF1kC9H+DX6wcEQVRq6izxTa0yRjNZNOC8w1dX2QGlyubQji8VcJgVntmT6E+v06dJPJoRce1I1AvQux5Dw+RZY71lq7DZpS4zoLRuSuCVb9ZA7MmNG6/WS3kncI8pz9dmv7ZR47lVzPPa4KU+c+YQyxLjaFIORa/Xf5lprf/BhrL/IMC25Qf3Cw5joLvwXsrNTr46hTjoawxmyo4eBWPUifcAuMOaC5fimWJ0IYS4nKwrnl2HwNNPQa2uzzdCwCWq0tO8sdvNDnlZ8ilQm59tUhqprn9IfutEfvvBNGoPHoC9PxgE/+9TPGj9V7q6pMXAQEF1nhPATRXmipbz1B2VOPjX8lfM578Vkqh50Dab8Ovhk9/vBOKeBx3YoaLAa27TnONNCkkYQ/l+nyG1Xzya0Fu70E/0MsJe3rcjTY4syp3+5vn9jBsQrdL2byLG9WYmqLwzdwwoBGSiKTcsIunNwP6zW2ijdkHVrPTQcpI7WNDlED5700oQdejdxKqDlg7Nr78/GTp+4utXEjL+Bx0KwW55ljD62FvEIGce0Z17tAlUNpMbWmmM/mAvxz7iwSuP2pFpMvL9TfMKvK2dhefIUxduAtvN1n789v2bXVqP9zyy4l4Z5GzuvgV37RqN3xZR9QKb53NkwRcJvuZFBD29bWdmp02e4V2JkyLGR9iQ9vuQlCtEsyhGf3rj9DHgGmrIoFPYxuDD5Vetun+M86ufYYe0EXwMJGEVcdGnuLuI084h3k6/KOAv/BueOUaCOPXjzn1NM5TsxovhNNTR6vXagFeiBwGvA9UcstXYDdm1TJ2RkCwLWGmi/azo/Gy3Q/7aNGuSbr12mT3yH/9LUtcJ0c3HFNCNQj+9TLvks3F+JM0TNXSHNmj/u77bVO41hEZDb+sJMj5g+Yk0lmdRG8pscAnetlobN4QzilW6kPYJhzV0T8b2hbvSMYKDhvSC3hrQZx4X7kN4yNWhytBjqSI268ePqAEh3UQ18DFjN1am93bdwJN0z8l9c1+7bjTt+7GlX7ED7a5pa0bIbKBKemGDW0ShPAREmAPYJjp5/nZaMw4Hmp1hKq+orCo6NipTKw+3ZdJUvxo2u19QrYzC743KMz+YfMgVPXZKpJvLizWCE+a4muOlCvvjTjKWZkUtGJRi4t3fkcncEp4925He7YuXkzkL+PAnNRIP4ZyouL88dyl4wH2mU35L3yzvZh4ie9AKYGefcAxnYPMRlD1fkef5q+arFTJhMIT5KFQfqJdJndBkJavYICQfHiL8rA2ylfcExbAPlT/Lc74f98h/kIbrJ0Y731eUgcTlnK6xosAl5plYD9MfKjYPDAEJhrjdZrWhA+A+phDt/cPv8/8yf/ptu7psRrW9Nt9frGIYo2JnbhF7ArxqXChHDr3p6j/Gg6SiyZnTDbLXf45MT07yzgHolWXRpkfMuySTBrxTMxuDYWKAeaf4PRX91ZzxrLVQw7FSB6TuxfRBJIrrqY1UoAghgZ9RmtlffqVCvU/2vgC8JNXPegbj7bZq9cn5SFEmm/f50V9GEWufp79tn2u1+nHKKJkPgyHNZcPlZot++usMwoINnsinybhdG1A9I8vrIygs56F4sf62NwL15S5H5QujrFepnhQ6apRFOQOe+Jkh7hrG8Ph/Kq513ewVlsB68Mhg5zbwhX7lMzLVv1Ogfd21NL5NuVWVmcvAyltPA2M3jtHixoyCCH+WIF4FABTBvYl3lk5moYn/C0vt04jqCE/ZfUOOp+y9hgC59jLCqk1JAj3bp591Be9v9NwphNcgX5EDhnSN86FMM+xiaizOaVpEXJHz+i5vExeM4f7tfvbv3FlxmvLGQqaaFLxQ86Iij+mO2o1EUFbHPhdO/GuGzgiSaIMMLcxsbvraPEbWO0TGI6HQE8njCaf6bq/lY6qDYlAlwHNaOdGg2aW5pvqQOSzOLSWH6olTVmflGN9EFQ23qRi2ysR9vak/q1x9bq2/6yUIRWdI15ToGGTRe2X2sZt7XrwjOjXE08wk2a7zdAQOyJPxSXbUPrgQfljCGJcfTPpXIP3D56fPhmVZZSAzE63Dt1l/uOSgIYcMZIkWEnT40vwQ1cc/X/G8V7wnf6hMWlHR1l8CbKSh/7acv43HhAZxIvtds0tXcNxSIu648KQCHQItG3oz3udrLmJi8qAbsnoh02AV0XkX2rDDJcuurLPP6OjNNeo5j4e5CjaB1D9TckSNd5w2SJhUQxevTLUw5MFeQX5pzLM9CAtx5Bm9n9LHg2rJGPmSY+LYg0Zvu5hNcBlOrLmhGr6Kone+fbQaHP/m6+IcPB7rBVQGdix7gLqFs0tDplX1be0SYr9V4ivonAKjgwmm56SNqIutS7U5qYZX72PclIRvXKGyi7kjvzA8NTYndsMfYVjEiQo6/82N9yRm5DAEbZTruCiX945BJb/Rk2ghDBgWjGyvtBq3i7sawZnvHrJp9cJYyTsOMc9fXWy5cV6RjpqUSqf+bng5otVwBCFZ05tPi3XX1XfS/iGnsJ1yarhrfJKdy4wotfU4oCvLxb5aPh9YQK44cFhtKu4jJzOkcTx5qMzdDxfK8QCA+Z0FWGD3Z/6cueKJ+3XcNy8K96YpVcA/w48Dey0b6nCuWxWqDaaIyeuxE/9kLxrDmD7Yhn/giFlwTirbeYIR+/a3HcvyDhFIAgFy5VQwVcmd+kN1g6TdGQd8Xt9EWKKIddhvgQ8QZtRswc/fnfU3vpIh336heqYdzmfmAICRb//uOpvxOF0rF+3AsgAGWsukQhaRw1QzlD6WmuzIw02HScKdiv1kFubNEoq6WkPyHxVgjwuDeyd4bH4GQU3BHMaRkFuilZXJdMDr1RLNB5azMZaMCUrkk22tsAl+XXYuhZoUHYiNf+hD1JQBYaE7HJhX4sfrtutyH55eOUTwVvn8h0IiCctncdy9yudR0Hv9rjVnPfBu0wdqAgq0tOT1w3iY8p4Izdlm/pwDr5znu2msYkl/s18/C9y/88Egf2IdrOIr0QU6TzfyJKeyzI6HJ3oggnexkMSOF35BygFcyVGAZREESYBhZYe6mwkAlYHQPdAvNtl51ugfHARHDDoWmp5ixf4y09iVnxYhKo+bna4QNqSsM/Cmil0RxmlCphM9ULxqIY4eTIelYHJ6uKqoqB73aypW5apkbJEpZGHbyTqQRzXjlfBBU9gM8nIdeAXIO80tHt684+OfR0HtmntF1CfqfFVUGhhv9wEcQ7H1KxmXQyqfMM7Gxh14uiw+DW+e7q83VsESyq1nJh7kCd+rPYKlDhGxCcV6hLD0m6s8AqZ0PF4DcRusaNffD2017C8lXWx8S6wMM0EfNhVrOJh7YgXwlRyv49f4GWP7lkXNRNiLqEYDnuxR7ASgWrHD8Is2yBEAyXChuw6K/mBOcl9V5omNpNFd1OCM7b4ROs3v/la0R18TqRNnEbhiQ0ZlnUZkDMkYep0Bac5TYjQT+/r9YLIKQw7shIz95IadiMT8z1l1uuHMnEQoZJf4FMLhbaOksM3X1Uq195ozT8hQiJt3tgu3TgEm/2nFIsviVoArhz+qAhX5HTQgf/rYQN7RxWzcRmyZzPYLZj8+Dht+a02xvb7w25pR1j28QeEoeYcPv5Mqn7v8gbSuZ1RzxyvXXv/3OMxiwgLxkP87KSRW8J75Qe7jpeltu1dVp4SaiPbmAAsyTgpVEffWZuGy+xZ45HO2CzD6M8h7AhfRXTMtEw6rBndbHbSxYAyfjrXZ2I1bnc4fI3FtkqS1045MtvAbe6z+Ur/3YWxeCXoanhPALMmQaYK7gjOURrZQuNmDKfiNoGPCcOSzXaeShnAuxrAWfXMtdoCvxwzimEWWYrp5/wK1x6O3oj1sWdbGUimIM36g9EE4zjuFF4L9I4psakLD8toKq0KC93ab3ThqqssET07HwgL/BYOuSlDOIhBXlMNsu+gFlXXWNSGzFhCYQWbEqVpunn7tm8zPDjQnzmXehE0gR5fFPijGg2t703Iv14ZefAh6WCTB6h4dnCde0F4RDmvrSuMKwIMOJ4oy+a+vf3cvj780IUs2JpvNjpPiOuyq9gAAAA1ZzB9sIp2yQ/F3P80bjw0ZCSnKCoqTPEVbUL8vpjTKQ5/K+8q9sEgbAuTU0R404lKDUJwEqP5bQXqPAi4CtmHElzJYEmyFd20iweO1M6wVxZBP57T4M/Rq53xjHxzmKRpaTcTexRK7PGQl2J4epWm8ApSgRboecYZqiga+WYW98pMvfuoLMPrTDANUTzEDKcfyUsEkgXD9Lo5PosNsm7dT1gVnxqhLnisMpo5CQgZx7H4zxo8qOoGi1cWzgIv3O2z3n8exzFmx9K4GDe2GqEIvv4W/qtBZ42VwbK/JzG4pRDlzWnInABnnKjdDopX45Th2Dq1Sogmu54TEVy/xGLNNMdFBI6G3k0Is3vMsR4Wqs9T/+4t98GYGy9ppTw0HIXsRhDdYkyA83+NA3HRdOeNSE3CgM10+SGCEiwUgeRuT2lbAMMy2Pos+RaDD4AjBYpJug3kXEDXB+vUwDMTwg0GVcXS1a23Sa46mUr9U46TOwAhqAcnYRXoDGw7ESQSJQ+d8hnrszkdpm+rQqFMnO09ReFuqoMYQLFA8Od58WGyH2WQYQP9VnXrnjebYeSaCSvRFupRImCiv3Od8AsUm2Oe83Vsvn6Vc7y6jvI+XZrDiNcfwD/eJbM0SLgPNxrxncSn/w2Z5XSJJfhL0s+owdLvryUGMBsa5h0+vYXKWqxZDYJl9+3PxJtRhAkmJZhYCVflhJIwwvbZhFAZTf5IxcD8QWMLPVDTlOpwco5DD1BM2soW33srP7mPG8QwsdcQuzjoHUGWEqqDq+D/wMzQ28RnLOHyCfvA6xlNIayqfo9fBsyIpGQH/+5Hh+IbzfJx4FFczW4/mrBFsMuCsR6cR2BqDq1uffeWQ6YfRzanSIfOcdda/VYhGGh8HZa6MFFozA2ZctEWpZgKXNDMqvU9Ocfa+cVVEGkwvEJ5UNJt2QFw2NsShN+EI/Wl0oh568ivfPZRfmRqPnuZUfO0pKYT6/CX91o3K9dagF4nO6QFbaCrSbQEFF2cKKd1LuTtkmzbzPYPjkigmOKVEL7QaW1DKxGj1g5U7/KDH9OBWTbykZVRuIb0LLcC//fPKPjvXR38S4q+AJTPrS+pQnqa6qLkgopAnwFYSOiZMNGznp0q0WXzDnWQe6JPisLZNfhRzBnNTC/078FZvJUSuieSt4xSc6nej5vr0vzSPQCDQq6kByecyvcQazZP9pp34tR1LYtEeAFXJinC0y1mqnmcI9JJZmqYgMmoLKQ13RDudLlr5TvTnR5zbRcppgxgakFjj91g4js8CGrNLBGOsO88I6ayhLNnGw4FbT8vlPfsazXJ1cQ8655UMcfLPWHskWqXJmzW/yvKp6/5b9Vn163H9+q+FcLbklvETsepKHvFowyHUiTUpveFcTH+dsGszD9olOxfEDA5iv1Afm9C7m9HTUaXvEbBE+/GG4ljtcc15V0Ik96qIKTGWKgKOSyuGIu0kXf1jEEb+/TohTwLaPWHp2zyi28QdBevmr8T/XmopTPVpl08vPk+LiRBr29n/H4+qGIZ5GzZXxq4i4N8fWuCbHjDFWt17AolyCxy5o/muiF8ztbTeynQp0lBw7y7vQ1Q+vHQNwv2ZZWwUu8qI6Tr36nWBrKMkiJHECzvk4oJ1zBoY4ZrMWaTXKyPXaxOL3R/hGe6vaE/3tYCPAWdx1nSWGF/b8T7E0mnnt97trO/QSJZ9VWbrvF1KgDlfGH/2tZ92EZdyBnqVcYIjphPmzs25JEBuK7e8l1kHOtACgITgxpsbazHn5Zi4tYbTe3PX5ymQXyWg9n+4n7tV+xPTXZQ8UlRwP/VKtiooq+9eC+kPKY7CP+KHP6ij3fG71hK4aDesLZztga7J9HDzcjPArcFCdI5lVDq7OiOmlarcVY5yO4n6ledoFs+N8BVnYZRI47libSNW0I/HaGNVkpE+/9hnrejnrjNkI56a66e2G7bcL0Sw2Cok+JSd2r7WnNevcZYQrMr7SK//mDBG+iiCy0AhxHPBCI2Jq8RlBVp4SewbRHvm9iK4WDl46vaNWhnymv+oNyLlVkxu1/TkfcWNwAAAAFZBLpThaLCz1a7wBaufVt4vF/J2naM9bBZOr6K29lM12lxtcWVLT8OANg0O6h4sWXK77WJzfAFYnkibuq/QpWLIclz57XoWvXDZ8LUCpQ9mmdKRmC7F+Oc2yEYWlEehaYqdZLdLlkRD+XBCZkmyuWcVtGEhFrYad8IE/tjVMaN8TupjwUc4r0IWAqEj5Twmf8dSaRm5BRURzgldp0woDaDbLiMdFKmmIMqittHrNh8cGE3Xsk3wIgNJlGh15MzGxC2Bo3WkHbhy33CKuj+M5yJK4KxDDjfGgKFMD4DWoOcIZESKRE0eihjNll+q7KvUcoYHMEdEm9pQKq8kKGmr69RRqiIAK7VtgbvgqHIJJkJSPBpxr6iqY0IW+O7EvpUnmj5GNNOOoSGkbo4unUP0J+A4D+uqX5p9j7Pkc4DA8z9GuMph60Dp1TVLfmiAyFOMwDlGPFr+FZtlsQ06znCAF1TqZjIQevGSnObnp9upYzOAk//TlnJx0wROzaD1aPIlid8Ab5KTFWAUH4jlARPOE56AAACEF4kxy55SxND/6LcsQBHUaEBPLQDqPh3539c1ySdkxPOfwWHnIWtkIDZ9rcCdl3qJ0tUHkbvX66G1q/f++nBmMF0/j+ovSFFOpT3/oog0rG5YHS1C0SRwFIkL8AZZAi3E8QsTcbCA6TWeN79YiXXrgEAki444fuUK5D6m+c/ZQw9h1dwO6NCmUPUC2TcdRllLJrtOAvH/wKMSqczR3hiD1rSdnAUL9umCfmt6mN5NWMc8e0nqR0i+mF6TJ9qAxDpQa1tr0g9DzIBOUsGi3YSg8RK3CDLFh4d2Qps+c8xigzbjFgvrc37/MAyj6jVRHFhJxW+AzaTXkbw0g1wby869WxXw2b+pt99zzqUoNaADZrrTVnPqbT9XmbU8AdeNj4treRUezV9kpuwyVwMVhq3G6nXQS8YraaS4wb/TK2jcMeGhWkaBcEFZ4mmTycx7G4vViWtkk6XV5Q+XA95XHPNOoMvSH3CC84lrXs4EedLZJ5OIk65RsVB9zzMsE8CrRFKkRLb48C0FPFe2uarcE0PSMPjdFAVno23WrdrXjVyMJuiU9pbwQtX3v47d3lxA/IWiMVbbSlygBXp6S5/izn3Xiv+y8WLGRPK9S4shF0xYVFP59P5ZsLf0cZLOGpVPhE/V4lD/P6ylQJaWBypoy6Nuicv4IvNpgUU0ILyKtbOfUijEh9YGAACq75LEjsxAu+loKVkVz5VwKhixmJhTBshjUMi8jBc4vChNH1/cRIZAx8C1O/o77LX5oqz/HB1WomLLEjAkt/WK2CP0GBYJFUnMCw0433xrNWfSX2gYvCm7NSc9IYMRlWM8XVSQW3NldM+VkiBLzD+BVitdI7knbwjGII1QqVjZec/QYpyOK6NL1Jx/hY9Ist5Wz3ap/2qHaml1jNJosB71ZDkdLiy4AmG1grdPrdaZeYUHG5M4e8TnAW6oOs0FrOsKX2z4Bw8fL86PTTI+NbcBGFmsNd6Yup4HQtdY1J+izoL+sqoQ3qU0Vui8Q2wOX50s0fcixxMKFC2x4AGmvyyHJ6wXdEqxxulBeF/sANHy3XlvQw3rSRX9weaP9CUctMDyvHcTJ9KSiewlIQRNQ49tvo/lI7FG4EvLjmg5NBkaWlWnswYUt/yP8nKZ+xcAQdd7xXmssuNPrSJsAlnbZZ6GF3cSXE3LhdKxE880TKH0fy550lGXZYQtGg182AAAdoS7zFpKVj+MP6fpKeaHu2GnAMPkhrPSpEFf/iEyPNf6glzj9bhb4R75YhvPbIJkxcsKzWDlWknNL1pX8l16lTC8a9uL42hS/dyq4BycpocYb6s9EPFFU9ZOvc2hCpVDmmHUZFoYTNidM8Cx6ys79BUUc031NU8N8CqEy5FSUHwr1sTW8cpZ1ZiRfRMhb2l+TnjqxK1hs/mUdYzLqvGfIpPrQ0QUk/E9fkD2Sqccod1kWD6/mkJAhFhr5dKjKka58yJgCFAL5EB9mMelD+3dPMfnKMopcXRSC85tyvc3KBoUs9CWbbsUZN0lElsLA6ujBba63zuaC34QSwnXAwrwFx26SZTzLwX8NtOPS/ecjTuZaZg8WhCyyYqCBAuJQmF22yTgGTPOUHrGbiww6sitPJuVejh54n79jrkd2Ko5hoIs1aBjjdddn2sgA8pSBbvGW/UC1jR2Rkm8ahaMnBO7WFcb8PXORKec3X0ZKhyIvCmWN3sOyaKFsvyeSRkzTmt+nDZDNBZHr8PRQ5rtIc8pFlHXO1SiO+HghBbbWSSjmuvlSHeQlokllW+N5EfhkKJZ3ICECN03M0IRM4rztVS8C9jeYFbbySGK9I2JU/v2qYoTrCMtrVQspdplqXhCrmBeHOdO1zEPFm2iJA0kEsSUzXXH+njgUPcZ/0djsyPniA0HimBmKmp8hC35ZH4kvBUo54roJcLknyvH8pRbxE9atu5ACFwhqM+6S6gAVWWyAzDRg1AmczIKDzb/Xd8AWSA96EU08sO/lWaMyka6OrBhekHh+sSRS3ilhLxJq3Gq5pv+JWH2YyR1tiQKg2ZsDHjYV0Kfo0vjp9xwXFfMUh9+6cNgyUm2uxgPiU+bSX6A2HM/0la98Sum1bAMRROYvQHnPSS/vwPHFQy05CuAUKgxEG/VuyVcqeiSB9wlw/VyW909UnozNCYKGAL+EaDAW1R2PIkeqdOrWU+rD3hdOOxlEDWAbNy3WrQGGo/OiuA5s4Uf1kokX52xycBkIWP+Z1ZNRzYKn9Fu4pwbAo1B/5G8soMPH1ePYidrGqT1Cr0l8AkFKprMFq1+mcVMoHoejyjzOCVe8WQUUqHRqhGBH2EW8e58+nM3uS21OPAjLMDNymz5W7SMXjKhkEzBsACw5e+9YLZ3szColP2RB/r7EtTRnfNLCwmlwzH8zmp4An4SndeCes0F9qtBwSDo6LI1TPXxzxPTqyG3CaJdfy2R+trxp8qxBIH53EME5RQNdylN1n5sBC/074uoNVbWdZf4OOF/A1mpqLxWiTIepx70HnFyIqQWDlrkb1vY7vfdmGenxawAqDQAA9I2wN7pAPilrfmQQIvuEOUKlxhSogR2FK7WrcXGbzUiPln+jyITiJmlBK93ogFhk0gWtigclIhHm1x6CxTnHhbvSCW/Onmxlnxc4mm4Mh4FcMBT00TkAOQZLqm+HQjVAJHWzDAwRW0KRDcysKwVetDSnAPI6QoeHqOsTE/uyBBCj0cfOrUgz9gnjd53gsDFhd18oWvElFdYSp1R1TJ0vyPc1JUiyDGx/yF6hfrYzxqPkrDOeLaAuKoru9fv2COJGSKdBSxfHL31XDyPjLUj9/Uwrmes7NXP1XmE8aYI7YzHgbg+SCEiY3+XDnMZVkO/Rg3h13Nl70Co7izqpI/eP0SHRxpQ+9gum45rbPeCMbiEIyjtyjOH+A7bosPt2+K/XE/RnWIpVBcxOaiJCmupcjSDCHxfcqIuwfzeC3a3/oUb+1oKqXe2ZVh9wbTMbgNCmTm1oZqwH+2qij5OZ0ighI2BQGwPgQtegWwY4AEpljDGgGpS+fPUybiOsUpqnC/pWQ4Pz6/82znVli1vCRq3lwzFJNQAuNevvUTXZZbX+LwcNqF+tmcSk03X/KPhQN3g2s3iljdgeqYQ0RMw+nwnFgooZGAlBm/7xAhAIUNQ8X2GwtG+BRQYBNx3AK+F3ZqVL4nTZiuV3v4fmg3HlS/tEHOHFmYlSj8p4p6HsSzYERKUP+p/tBjw3fwvcs/u2pRrLG4QF7jGRRSg+BVSyxugXGnMjUDbHwHqruvtmRajIbhgrWTNK8a+3yl28s+3/VTyB/sOVUcMX9crZVFnskDF4cxTNXlQ2BmEtnXtUMfSakr6fOnxBDuqKAvw5jQuDZGGzs5bbo9xbB6FSHMVPTeOMFQRJqxysOU4JYd/yyd+Fzc7s9iCU4JMEVSgKmQfxgSRcWQDkVNndXVOfeH457FUDCqioT34MTuXZ+1R7pHp+ktWSvQepC9HaIHiyrPt+aSWy835WjMBmQRFNVYj4UtJNg34TJbOtUU2lRcVTN+tM+ZJ+MAYSCGUe9VgMAA+o21jE+bwQEK1djSCWyBrmsTBSIzd6JbUz9N++zJ6VDuVwdIO0Vt/VMbxHtQ/8V+hg6bVXDG1dFILS6MHRHDat/iuMnGIW5asDeJix9EUtSLpPzNUafYQ8yD+X1U7YLFXL7NMkpECN/SmYlda1sY3x90wgT6MpTAl6LjljFWD8KS5d/snC4Shdf4pN+jwXll2YNcBnkLmVhP4QiHzKTYDCeAh/ECAcapycLhYaksLKpxhfRbQB8aEnniTBasT52hjz0yNJXbxDmxpNheyD0HNkNhp5Uvl7YSrYUQhxv2wP2ZjJ6Ewr2faoB7F3iml1F7c4Xw7E51ZRc/+4pcvjmPPMenSgUXicTX+9SPWqV05TkCfLLjnl23snV9pqAVvEQW0xvee2MkzmI/qZsKJtT9Y8DqeysAGdVaWz6EfYH9OeCMNJFwd+N6/xX+lHHiIX9bnajhkEH4YKq/ceZEtZ1plAK3Fj2WZowAAAAgW01kcIucsCKbu+MTnJa90Qy6dWR83i2zdLglYVQ1ijvPxYQFN7zXvFqJqgVJYO1j8K75V2GJxqqsZSrqGWh8bZc0W1eznSwHz9qiHOGgx9cUHzwjZ7V9eTzEg3lFDf1BUY11oQ36PNNz2SNoNQ40qUvISQCbkJYLOKW7UO7wv8I3HZWnqcV0MUWvUoLnavwNyFTxE4lQ1z7kMUR6z8Aw70ph2RfNZCgSiI73vyPjG01VizPGrhhYP28butgUXQP+NYzo/lsQB7LVssCPVsqiYGafH13tfIn+jN2s+DWOEwsNoVTxMeROdlMQUUl7mYkToLZ0+3opeDPluqXkuf1vjpLpl7NAWLp/3wPri1Jn540FbYa9ctQQKZmQ/1BELtq1lAtjhmafMHKEKX7WnMV0lDPTlbqjueA7IpSmHHTAyVCnVYQk2osPhhCJ2BE6sEP+oZGfzNvHgQOyZ/6qi1StE3LLOONIbyhIC7+Ai/E+wAHdFxhzHPS4J5oIVUJIqpzXJGcpKilT6d62iYxLZuZ3zZrHfei6CCbQS9635DTTvnYJkDs2ONglc9wT8kjJ+MUMyfeWxMnAbYoHcYqMKdC8bPcQ67GARHk8XJV3Y9bLbat2ECe/CRb5aT5yerjHpkdzBGgAeP/kdiLYA84DJ7Ok0D2Xs6+a7cs1F9KgmlOqpKI37y2QTvA+nlpvNCRBDrlX73aKXfWJRGv7sP1X8X6uzE7SLPy8Nq8EhFKKps7KgkhWJcZV/9zy4EikfWZQR6KBqTcoty4NMPbdgLW3JH+wwJQwAofnzJmagyxYasAK7pgM/xK+PdibWOim0lZz9QN7cA0+eW2mZxrTlatH7Hp8+QL1ZNuycuwaIzFOjlenfQVZVZIUpBbvsFb4dBT6k4qbiyHT2XasmedKwL9YAdsZh/j67Afdvj1tLb3vHYocgIkgmi5Pc5j1OW736i5fEBPAqTxNq098wrBMWR/ddCxPnovgTuCAq8bgQylAOoSrWJvNzNiYzm/oHB/gFKD80ndsh0tud896QzjpO1+lws7uW3wAMDkWhaErAJVpeUKDVu6MfvWBJaR8THS8MaXXkIVw84S4JewVEEpcCeRzmZ4mZh7QPUUy0A0AGEs4zm+QhIPGhW2JQHPDb816S7AwniG/mmADvt2t8fQiLz1Tu5CJkLugKLeGZkFo/8+IIDZEclM9lfl/W3/gOqqS+1FsigmTuqIxpPfRuAm6pfGvCarI4IWofEumtzUDW4hmW3LIuIya+VQ6EgD4A2HEzNmYTa+VbBh5RiP8szdyu1SGBJxohp4q4+WiKumltku8UqAbar1hTIiKG+qe8NqNcNkAbhIWix0aJKBi0o3SctnOnEEOKMZWneJnlAIhi7ktqPG+N+qM6SyoK/5fd+wSu3FZtDVIwW3howKl+xC/vEqdp5rrtikanz0h+FFsLlfuo8pncPoR7kQjZRQi6ZuPfaJTHpX6OWf3aFO5g34xKdl9ATOoh7WXzYWAMqLQ6YdExCyBkjuGWM5JCWHcyrgdt5YJNQaIHQAAtSMzKt4a8Px4f66G7VrRBY4FAB9TC6x3EsEKaL0GCHPzYpPooRwXtNiKWpEHFVCeF1QEpv94etxGD0ZDmsdu2KGUY96Ej5+ECuCy8MkI/fRnNWE8aibfujJG44tMIy2gTW6Mn6Zc3T5S9hDCs0vjMDMk+9jf01m1FzjH1QqJIY3HIYRJQIXThdNW421/iL83EDK9xXFj6O1xcyl9o//nfevxVpjCOSuocjK83qzAFyxn82AzHLforrmZmAgZf3fg4UH+DJdU8llotrv3SdkUHoCgH0VOgM6frIf2VAaOYczlJJCWqUHIcCcNsf2GQ/x/RNpCQqg2xK/J2laNQRY7KUV0DUuvPbr8GbeKfMO1tiyIEEINqUM6Mj+tcDc+JWBgzp3PKgACUjReE/f2AmPnbDU3bjICFIQxK2lcITDuJ9tjREkztKv6LRdPNQBkfMhFwwbc4bMgt+CeHyLjBT5Hz9M4C4cwFtvb9HphdZF3hQOTIPcWPYL9RnPV5lSXtx+Fh/4OALcKVPCAzIACNBXJ76bPPCnkB2Mn0APULaAKuD2pc4cVlQR9haB6aK5UHsGC3JhBYya6OH/53PhH76aElxH/hn0arl5/qauuuXy3IlAiJr8GTmFkRr8qEaGhiiON+ySXVjrT2rBOn/ioXmh5hnOlRJIT46TmidgDEBaR5BffMuVHWND3YiV7GqMIE/lVWTlxf1ijVM4oNaHN2HGUVEhY4qd4qTmYJVVf5r/XgzWTWbDM64EpWAVoykuQWNmLYRAQwyNFo9o1J2edCkwLMCPYQrQAJInBvv/YGnZCt7QMlsCRTbsxlr98Vx4niR5xF4seo7AsVlCZKCG+nQaaFUjkAXPw7cO2JTeR7aIS+dh6iM/dvwAYEHbuPbS98v0JZ/qenXJ4M1mvgLFOFtzwT+6Il5lWSgu481i8n6zkcd+uZp8gjhrcZ5cfO9LSzF4mYTi+8PhOtYxBp8O5KBYKLed75MPlAp8TXs1jA7oHGoGPWh/CvX2DVtZirCC3tcCMALPHf0IcfHu6FRgdqC1861BmLtXckejSKCHYmHqmORU78Y0ckLgCbvB0U0D9n3HDEi6+Y4rXtELTPQ2Pmz07P9KiUeYtOXxpjOZw5vFDp37SXs1yMHhnTUZUKjNyZWuHmym4y0gNcjTkbBdpjEesWDVvMYeDIOD+gbs2+Mx9U+3UUfCTZJ1e7PRiv735ESfo9HDsBvZfcXSZRPxcEcVeaD23CKNr1XuTSI0qNWu0knTPGnSqNOzXbfyNADQPitK34u1RObScnF7ed3jywpY8IgUJqRv+mBkidOQ+EMqrdN4Oh8TPDG225vXr+L3h0KbJ0LUZCe80YNQ0fGzjdwQrFW4BCYJijEQVcdwE1OBKxZVWtVg4slA9aP1mrouYMcBnJ0UUFfHFfJiGHHwkQOeA4Nc4kB9KFnrEdSgZoHbTtjK24TkPSqHDKBrib8Yvsz8AGZyud9eGjv19iK/Kw6i8IGuamxm84itFSC7WW1MDUUBWkYqrhREBRQMzanDrOMqqAGNoKDj+Qdb5PAxtKn8S/oFCDjAIOLXHy1f3TLlYeMsQfRT4qQZDi/R6+2C97m1nwyF4AFLuno7Ax16EmVuceLyBzDpZxFSAvA2Wxu5fqXiEyntVF0HMAt1w/nvtTUZsmyIEfbrrnhebXehS4pIS1vcUif98xy4pYJZ9eiXK4rLi83RA0eVyIdepPwE1mLhQF24gL08a7f/hnw3ukWrB2pDC3kWp9xDIRBoVt2rPNkLiI6i/KsDuAtYtNdN4TA0DXUB5ERrUw1RGF8rUslx0uWcBdqWLOT5ZlMP8rqFbiww+9fBVQrwcylwlq/4PvKKt9cvbyg2tRJ/YO9kvdpPii1s/7QvfzdVn2/fTKNz6S0oqRKsXhWfyLpLOd27rD3oSQnB6aBgKXERhRXswcJXdNHrlb/EdzNj9kZfP/2IGlbFCKed2UMKCFx9Wf+5qZCKFF+DQkSX2CmvhPb+khFDWaiBbLzkaIywABnqa5M5iE/eYpkTWi4baQQfJ9CQTGHzgtKByVWY3eF/AQr19L8l8qB1i3kyFCqmLkcoVQCe+YiMaJOsQ7oa9N73TiM5uWlWB0uLpQBB12TQdo07JcLhurhbd2BVhiSWA4ge4Kk1zOtS/tsziwuWRZZdq1WaXaluehSWq80drf6wpKtuKbQcmm/tMK5Ml4cmV3gK0CB9CL4wLtpIJXNMllcYDIWVT21ICnZuJZm8zo+/WGLplpoMEVPFQVZKHc8gPikktsgxUhxHWb9IC0wuY9p9IcXsLN0yXtqeFVZ6vYIfJgvEwS/YLbImldvKQXc0o6B63f9KvWiIxjWfzok+3cCdvPHLokZ2JDJ19KzuQFbT99vZ4fibLHYKK/XDpDIYxx7MzdlyJVi4Y7h8qyYBBK+Cam7ZbbzHSCFaCtCJkk+COn1ZYvEZMl+xvQKLbNiZkn4XqPHXpFnhSTlVenf4j3eljK/HCFVvkMkjBPIzyVpEAEv2rRIl8vW1lD4hBYV12vI4Z/R/CmZzSWECZDKg/X+m5l1Ll1X2qot7cEgjuYbqZcogl4TjWELt4kjipx2ADifBAuJMef95Y5aEM1UKfWCGOyiyzYyyi27AzbBDzSB537ssrdJf0De9P3u61+tdhLg9tC5b7hbWAyBCZRBysUkYDlcT9vZsppdfwewB+P9Ubcwls0qIOv8QaftunCnILbFIJqb1qyNvqflmM4SozHBsqhf7/6qUNOjTkaV0A0Fp+bVU5Lz7n5u10sbohLr9iuzEnoERgknvcMQvbF64gFHvoQC0X4lqwWrP2lD26c6yHD1e97SyPNlHTWoDhtiAs9qs9HOB+X3nSKTNFlSGDdyWv6R1dv4piKi9wBs5OkjIxH5uuL+dLv77EvIn18Oo7Hh3SY0rtN3/mFQBNKidbe9UKKcfMV9g1O+9A8yQf1qr377964jbUUvDruLDHQ9XMs6nsW0KdUuHv+S09ntqMvZ/XAEyCmb2Gn1nKAwtFNJX7jVGXOpywTNFKVpzBQi/u0hEDUu4nQtnDm+9AnD74yWmK6sbtlCzNWEfXUYgrnqLgJah73iR+sdqtwDLz/Krx2KZP0k89EWTpjZosYqv3q2FUYVQYisH6yykMO3qPxLoxsZ0hM+cd2rIZX0b7lr3phcbCuRU6YLJ8cbaq+LDjtEvIkGb1oFkFgjBVjcB0H2OU/lnqfyTTAEx64vxH7F8CYlZOjsspoReOHfJ3n70+hojTnc2NgUJABQcUML+xjNUvTrAntFRU8oP2Q31cNDJQiC6MWcte+oPE1zp5msUS3Wyic+VbXveuGYYKbwbB64JcgMVCF/Ao1/q+2RswbzcOMVCRlG4pgUuQlNfZEKaBF8vG1xHlnKNwbQmSH7GO1E6G2CIK8s+gi57GI8XIOswqP2tVa8wlUg1O70ii+K1QQSPnJk+OBDbxshD1jdniHbgncOsryq/lmEo8FPVoGuHXolRthhF0FCJfV+O8OIp3rgtI978JsGQexZhniEjncr4f3GJuVity65lFDA48uq71j+SLWm3Uk0X8/5dRuTcWU9+JXUX2k9gfAlI1CAxAAAAAAAAAAAzNmPysW7vsBH1Lpn35gWEAAAAAAAA==";
  return im;
}

/* ---------- boot ---------- */
buildSizeSeg(); buildPresets();
geom = buildGeom(st.size, st.orient, st.flip);
syncControls(); updateStats();
new ResizeObserver(schedule).observe(stageWrap);
new ResizeObserver(schedule).observe(field.parentElement);
window.matchMedia("(prefers-color-scheme: dark)").addEventListener?.("change", schedule);
new MutationObserver(schedule).observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
if (document.fonts && document.fonts.ready) document.fonts.ready.then(schedule);
schedule();
})();
