# Встраивает редактор гекс-токенов (lancer-hex-tokens-source) в УЛАН//ТЕРМИНАЛ как вкладку «🎨 Токены» → pc/m26.js.
# Изменения относительно исходника:
#  • размеры 1 и ½ в режиме Roll20 сохраняются так же, как для Foundry (PNG впритык к гексу);
#  • значки (номер в углу) убраны;
#  • сохранение — обычным скачиванием файла (ссылка с download), ZIP собирается встроенным упаковщиком без внешних библиотек;
#  • id элементов с префиксом tk_, стили ограничены контейнером .tkapp, шрифты — локальные запасные (интернет не нужен);
#  • арт можно взять прямо из программы (рамы из книг, корабли «Флота»), а также открыть редактор кнопкой «🎨 Токен» у НИП и у меха пилота.
import re,os,sys
H=os.path.dirname(os.path.abspath(__file__))
SRC=sys.argv[1] if len(sys.argv)>1 else os.path.join(H,'..','tok_in','lancer-hex-tokens-source')
OUT=sys.argv[2] if len(sys.argv)>2 else os.path.join(H,'..','pc','m26.js')
js=open(os.path.join(SRC,'app.js'),encoding='utf-8').read()
html=open(os.path.join(SRC,'index.html'),encoding='utf-8').read()
css=open(os.path.join(SRC,'styles.css'),encoding='utf-8').read()
def sub(s,a,b,n=1):
    c=s.count(a);assert c==n,(c,a[:80]);return s.replace(a,b)

# ---------------- разметка ----------------
body=html[html.index('<div class="app">'):html.index('<script src="app.js">')]
body=re.sub(r'\s*<header class="top">.*?</header>','',body,flags=re.S)
body=re.sub(r'\s*<div class="two">\s*<div><label class="lbl" for="badge">.*?</select></div>\s*</div>','',body,flags=re.S)
assert 'badge' not in body
body=sub(body,'<div class="upload">\n          <button class="btn primary wide" id="btnUpload" type="button">Загрузить изображение</button>',
 '<div class="upload">\n          <button class="btn primary wide" id="btnUpload" type="button">Загрузить изображение</button>\n          <select id="artPick" aria-label="Арт из программы"><option value="">— или арт из программы —</option></select>')
body=sub(body,'<option value="roll20">Под Roll20 — квадрат в целых клетках, центр в гексе</option>',
 '<option value="roll20">Под Roll20 — для размеров 2–4 квадрат в целых клетках, центр в гексе; 1 и ½ — впритык, как для Foundry</option>')
body=sub(body,'<li>Перетащи PNG на карту — он встанет размером в одну клетку.</li>',
 '<li>Перетащи PNG на карту — он встанет размером в одну клетку. Для размеров <b>1</b> и <b>½</b> больше ничего делать не нужно: файл впритык к гексу, как для Foundry.</li>')
body=sub(body,'<li>Потяни за угловую ручку до размера из строки «Размер в Roll20»','<li>Для размеров 2–4 потяни за угловую ручку до размера из строки «Размер в Roll20»')
body=sub(body,'id="file" accept="image/*"','id="file" accept="image/*,.jfif,.jpe,.pjpeg,.pjp,.avif,.webp,.gif,.bmp"')
body=re.sub(r'\b(id|for)="([A-Za-z]+)"',lambda m:f'{m.group(1)}="tk_{m.group(2)}"',body)
body='<div class="tkapp">'+body.strip()+'</div>'
# стили, которые шли атрибутом style (их не режет CSP? — style-src 'unsafe-inline' разрешает)
body=body.strip()

# ---------------- стили: всё внутри .tkapp ----------------
css=re.sub(r':root\{.*?\}\s*','',css,count=1,flags=re.S)
css=re.sub(r'@media \(prefers-color-scheme: dark\)\{\s*:root:not\(\[data-theme="light"\]\)\{.*?\}\s*\}\s*','',css,flags=re.S)
css=re.sub(r':root\[data-theme="dark"\]\{.*?\}\s*','',css,flags=re.S)
VARS=('.tkapp{color-scheme:dark;--bg:#0E1216;--panel:#161B21;--panel-2:#1C222A;--ink:#E2E7ED;--muted:#8A95A2;--line:#29313B;'
      '--accent:#E9A441;--accent-ink:#1B1204;--accent-soft:rgba(233,164,65,.14);--stage:#0A0D10;--check-a:#141920;--check-b:#10141A;'
      '--grid:rgba(226,231,237,.14);--field:#2B3530;--field-grid:rgba(220,235,225,.22);'
      '--display:"Chakra Petch","Bahnschrift","Arial Narrow",sans-serif;--body:"IBM Plex Sans","Segoe UI",Roboto,sans-serif;'
      '--mono:"IBM Plex Mono",ui-monospace,"Cascadia Mono",Consolas,monospace;'
      'color:var(--ink);font-family:var(--body);font-size:14px;line-height:1.45}\n')
out=[]
for rule in re.findall(r'(@media[^{]*\{(?:[^{}]*\{[^{}]*\})*\s*\}|[^{}@]+\{[^{}]*\})',css,flags=re.S):
    rule=rule.strip()
    if rule.startswith('@media'):
        head,inner=rule.split('{',1);inner=inner.rsplit('}',1)[0]
        rr=[]
        for r2 in re.findall(r'[^{}]+\{[^{}]*\}',inner):
            sel,decl=r2.split('{',1);rr.append(','.join(('.tkapp '+x.strip()) if not x.strip().startswith('*') else '.tkapp *' for x in sel.split(','))+'{'+decl)
        out.append(head+'{'+''.join(rr)+'}');continue
    sel,decl=rule.split('{',1);sels=[]
    for x in sel.split(','):
        x=x.strip()
        if x in ('html','body','html,body'):continue
        if x=='*':sels.append('.tkapp,.tkapp *');continue
        if x=='.app':sels.append('.tkapp .app');continue
        if x in ('.toast','.modal') or x.startswith('.modal ') or x.startswith('.toast'):sels.append('.tkapp '+x);continue
        sels.append('.tkapp '+x)
    if sels:out.append(','.join(sels)+'{'+decl)
css=VARS+'\n'.join(out)+'\n.tkapp .upload select{flex:1 1 180px;width:auto}\n.tkapp{padding:2px 0 24px}\n'

# ---------------- логика ----------------
js=js.strip()
assert js.startswith('(() => {') and js.endswith('})();')
js=js[len('(() => {'):-len('})();')]
js=sub(js,'  if (saved) for (const k of PERSIST) if (k in saved) st[k] = saved[k];',
 '  const VAL = { size: v => ["half","1","2","3","4"].includes(v), orient: v => v === "flat" || v === "pointy", preset: v => typeof v === "string" && /^[a-z]{1,12}$/.test(v), labelPos: v => v === "bottom" || v === "top", fit: v => v === "roll20" || v === "tight", res: v => [140,280,420,560].includes(+v),\n'
 '    frameColor: v => typeof v === "string" && /^#[0-9a-fA-F]{6}$/.test(v), accentColor: v => typeof v === "string" && /^#[0-9a-fA-F]{6}$/.test(v), bgColor: v => typeof v === "string" && /^#[0-9a-fA-F]{6}$/.test(v),\n'
 '    flip: v => typeof v === "boolean", accentOn: v => typeof v === "boolean", bgOn: v => typeof v === "boolean",\n'
 '    frameW: v => Number.isFinite(v) && v >= 0 && v <= 20, accentW: v => Number.isFinite(v) && v >= 0.5 && v <= 8, accentGap: v => Number.isFinite(v) && v >= 0 && v <= 8, vignette: v => Number.isFinite(v) && v >= 0 && v <= 100, cells: v => Number.isFinite(v) && v >= 0 && v <= 100,\n'
 '    calibV2: v => Number.isFinite(v) && v >= 30 && v <= 400, calibH2: v => Number.isFinite(v) && v >= 30 && v <= 400 };\n'
 '  if (saved && typeof saved === "object") for (const k of PERSIST) if (k in saved && VAL[k] && VAL[k](saved[k])) st[k] = k === "res" ? +saved[k] : saved[k];')
js=sub(js,'  if (saved && saved.calibV2) st.calibV = saved.calibV2;\n  if (saved && saved.calibH2) st.calibH = saved.calibH2;',
 '  if (saved && VAL.calibV2(saved.calibV2)) st.calibV = saved.calibV2;\n  if (saved && VAL.calibH2(saved.calibH2)) st.calibH = saved.calibH2;')
js=sub(js,'  if (!file || !file.type.startsWith("image/")) { toast("Это не изображение. Подойдут PNG, JPG, WebP."); return; }\n  const url = URL.createObjectURL(file);\n  const im = new Image();\n  im.onload = () => {\n',
 '  if (!file) return;\n  if (file.size > 40e6) { toast("Файл больше 40 МБ — уменьшите картинку."); return; }\n  const url = URL.createObjectURL(file);\n  const im = new Image();\n  im.onload = () => {\n    URL.revokeObjectURL(url);\n    if (im.naturalWidth * im.naturalHeight > 64e6) { toast("Картинка слишком большая (больше 64 Мп)."); return; }\n')
js=sub(js,'  im.onerror = () => toast("Не удалось открыть файл. Попробуй другой формат.");','  im.onerror = () => { URL.revokeObjectURL(url); toast("Не удалось открыть файл. Попробуй другой формат."); };')
js=sub(js,'  im.onerror = () => { URL.revokeObjectURL(url); toast("Не удалось открыть файл. Попробуй другой формат."); };',
 '  im.onerror = () => { URL.revokeObjectURL(url); toast("Браузер не смог прочитать этот файл как картинку (например, HEIC с iPhone или не картинка). Сохраните его как PNG/JPG/WebP."); };')
js=sub(js,'  const f = e.dataTransfer?.files?.[0]; if (f) loadFile(f);',
 '  const f = e.dataTransfer?.files?.[0]; if (f) loadFile(f);\n  else toast("Перетащена ссылка, а не файл. Сохраните картинку на компьютер и перетащите файл — или в браузере ПКМ → «Копировать картинку» и Ctrl+V здесь.");')
js=sub(js,'  for (const it of items) if (it.type.startsWith("image/")) { loadFile(it.getAsFile()); e.preventDefault(); return; }',
 '  for (const it of items) if (it.kind === "file") { loadFile(it.getAsFile()); e.preventDefault(); return; }')
js=sub(js,'const $ = id => document.getElementById(id);','const $ = id => ROOT.querySelector("#tk_" + id);')
js=sub(js,'function css(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }',
          'function css(name) { return getComputedStyle(ROOT).getPropertyValue(name).trim(); }')
# значки убраны
js=sub(js,'  label: "Assault", labelPos: "bottom", badge: "1", badgeCorner: "tr",','  label: "", labelPos: "bottom",')
js=sub(js,'"bgOn","labelPos","badgeCorner","res"','"bgOn","labelPos","res"')
js=sub(js,'  if (st.badge.trim()) drawBadge(ctx, geom, s, fw);\n','')
i=js.index('function drawBadge(');j=js.index('function drawGrid(');js=js[:i]+js[j:]
js=sub(js,'for (const id of ["label", "badge"])','for (const id of ["label"])')
js=sub(js,'for (const id of ["labelPos", "badgeCorner"])','for (const id of ["labelPos"])')
js=sub(js,'  $("label").value = st.label; $("badge").value = st.badge;\n  $("labelPos").value = st.labelPos; $("badgeCorner").value = st.badgeCorner;',
          '  $("label").value = st.label;\n  $("labelPos").value = st.labelPos;')
assert 'badge' not in js.lower(),'badge left'
# размеры 1 и ½: в режиме Roll20 — как для Foundry (впритык к гексу)
js=sub(js,'  if (st.fit !== "roll20") {\n    const W','  if (st.fit !== "roll20" || g.count === 1) {   // 1 и ½ — одна клетка: файл впритык к гексу, как для Foundry\n    const W')
js=sub(js,'const aligned = st.fit === "roll20" ||','const aligned = st.fit === "roll20" || geom.count === 1 ||')
# имена файлов — латиницей (кириллица в имени скачиваемого файла теряется в части браузеров и VTT)
js=sub(js,'  return raw.toLowerCase().replace(/[^\\p{L}\\p{N}]+/gu, "-")','  const TR = {а:"a",б:"b",в:"v",г:"g",д:"d",е:"e",ё:"e",ж:"zh",з:"z",и:"i",й:"y",к:"k",л:"l",м:"m",н:"n",о:"o",п:"p",р:"r",с:"s",т:"t",у:"u",ф:"f",х:"h",ц:"ts",ч:"ch",ш:"sh",щ:"sch",ъ:"",ы:"y",ь:"",э:"e",ю:"yu",я:"ya"};\n  return raw.toLowerCase().replace(/[а-яё]/g, c => TR[c]).replace(/[^a-z0-9]+/g, "-")')
# перетаскивание и вставка — только когда вкладка открыта
js=sub(js,'window.addEventListener("dragenter", e => {','window.addEventListener("dragenter", e => { if (!ROOT.isConnected) return;')
js=sub(js,'window.addEventListener("drop", e => {\n  e.preventDefault();','window.addEventListener("drop", e => {\n  if (!ROOT.isConnected) return;\n  e.preventDefault();')
js=sub(js,'window.addEventListener("dragover", e => e.preventDefault());','window.addEventListener("dragover", e => { if (ROOT.isConnected) e.preventDefault(); });')
js=sub(js,'window.addEventListener("paste", e => {','window.addEventListener("paste", e => { if (!ROOT.isConnected) return;')
# сохранение: обычная загрузка файла; ZIP — встроенный упаковщик
i=js.index('let downloads = null;');j=js.index('function baseName()')
js=js[:i]+'''/* сохранение: обычное скачивание файла браузером */
function dl(filename, blob) {
  const a = document.createElement("a"); const url = URL.createObjectURL(blob);
  a.href = url; a.download = filename; a.style.display = "none"; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 4000);
}
/* мини-ZIP без сжатия (PNG и так сжат) */
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = b => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
async function makeZip(files) {
  const enc = new TextEncoder(), parts = [], cen = []; let off = 0;
  for (const f of files) {
    const data = new Uint8Array(await f.blob.arrayBuffer()), name = enc.encode(f.name), crc = crc32(data);
    const lh = new DataView(new ArrayBuffer(30));
    lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, 0, true);
    lh.setUint32(14, crc, true); lh.setUint32(18, data.length, true); lh.setUint32(22, data.length, true); lh.setUint16(26, name.length, true);
    parts.push(lh, name, data);
    const ch = new DataView(new ArrayBuffer(46));
    ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true);
    ch.setUint32(16, crc, true); ch.setUint32(20, data.length, true); ch.setUint32(24, data.length, true); ch.setUint16(28, name.length, true); ch.setUint32(42, off, true);
    cen.push(ch, name); off += 30 + name.length + data.length;
  }
  const cs = cen.reduce((a, p) => a + p.byteLength, 0), end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, cs, true); end.setUint32(16, off, true);
  return new Blob([...parts, ...cen, end], { type: "application/zip" });
}

'''+js[j:]
i=js.index('async function saveBlob(');j=js.index('function showFallback(')
js=js[:i]+'''async function saveBlob(filename, blob, fallbackCanvases) {
  try { dl(filename, blob); toast("Сохранено: " + filename); }
  catch (e) { showFallback(fallbackCanvases); }
}
'''+js[j:]
i=js.index('$("btnZip").addEventListener(');j=js.index('let toastT = 0;')
js=js[:i]+'''$("btnZip").addEventListener("click", async () => {
  const list = SIZES.map(sz => ({ canvas: renderExport(sz.key), name: `${baseName()}_${sizeTag(sz.key)}_${st.orient === "flat" ? "hexV" : "hexH"}.png` }));
  const files = []; for (const it of list) files.push({ name: it.name, blob: await toBlob(it.canvas) });
  saveBlob(`${baseName()}_all-sizes.zip`, await makeZip(files), list);
});

'''+js[j:]
# внешний вход: открыть редактор с готовым артом, подписью, размером и цветом
js=sub(js,'/* ---------- boot ---------- */','''/* ---------- вход из программы ---------- */
function loadSrc(src, name) {
  const im = new Image();
  im.onload = () => { img = im; isSample = false; imgName = name || "арт"; $("imgName").textContent = imgName.length > 28 ? imgName.slice(0, 26) + "…" : imgName; $("sampleNote").hidden = true;
    st.zoom = 1; st.ox = 0; st.oy = 0; st.rot = 0; st.mirror = false; changed(); };
  im.onerror = () => toast("Не удалось открыть арт.");
  im.src = src;
}
function sizeKeyOf(v) { const n = Number(v); return n === 0.5 ? "half" : n >= 1 && n <= 4 ? String(Math.round(n)) : st.size; }
TOK.open = o => {
  o = o || {};
  if (o.label != null) st.label = String(o.label).slice(0, 24);
  if (o.size != null) st.size = sizeKeyOf(o.size);
  if (o.preset) { const p = PRESETS.find(x => x.id === o.preset); if (p) { st.preset = p.id; st.frameColor = p.frame; st.accentColor = p.accent; } }
  if (o.src) loadSrc(o.src, o.name); else if (o.sample) { img = makeSample(); isSample = true; imgName = "заглушка"; $("imgName").textContent = imgName; $("sampleNote").hidden = false; st.zoom = 1; st.ox = 0; st.oy = 0; st.rot = 0; }
  onGeomChange();
};
TOK.schedule = () => schedule();
$("artPick").addEventListener("change", e => { const v = e.target.value; e.target.value = ""; if (!v) return; const it = TOK.arts().find(a => a.key === v); if (it) { if (!st.label) st.label = it.label || ""; loadSrc(it.src, it.name); syncControls(); } });
TOK.fillArts = () => { const sel = $("artPick"); const arts = TOK.arts(); const groups = {}; arts.forEach(a => (groups[a.grp] = groups[a.grp] || []).push(a));
  sel.innerHTML = '<option value="">— или арт из программы —</option>' + Object.entries(groups).map(([g, l]) => `<optgroup label="${g.replace(/"/g, "&quot;")}">${l.map(a => `<option value="${a.key}">${a.name.replace(/</g, "&lt;")}</option>`).join("")}</optgroup>`).join(""); };

/* ---------- boot ---------- */''')

M26='''/* ============================== v30: редактор гекс-токенов ==============================
   Вкладка «🎨 Токены»: собранный из lancer-hex-tokens-source редактор (см. tokens/mk_m26.py) — PNG для Roll20 / Foundry,
   арт из программы, кнопки «🎨 Токен» у НИП и у меха пилота. Файл сгенерирован, правьте исходник и mk_m26.py. */
const TOK={};
{const st=document.createElement('style');st.textContent=__CSS__;document.head.appendChild(st)}
const ROOT=(()=>{const d=document.createElement('div');d.innerHTML=__HTML__;return d.firstElementChild})();
(() => {
"use strict";
'''+js+'''
})();
/* ---------- арт из программы ---------- */
TOK.arts=()=>{const out=[];try{const fr=PCD.frames.filter(f=>ART&&ART[f.id]);fr.sort((a,b)=>a.name.localeCompare(b.name,'ru'));
  fr.forEach(f=>out.push({key:'f:'+f.id,grp:'Рамы',name:f.name,label:f.name,src:ART[f.id]}));
  if(typeof BGART==='object'&&BGART){const nm=id=>{const x=[...(BG.hulls||[]),...(BG.npcCap||[]),...(BG.npcEsc||[]),...(BG.escorts||[]),...(BG.wings||[])].find(y=>y.id===id);return x?(x.ru||x.name||id):id};
    Object.keys(BGART).forEach(id=>out.push({key:'b:'+id,grp:'Корабли «Флота»',name:nm(id),label:nm(id),src:BGART[id]}))}}catch(e){}return out};
TOK.fillArts();
/* ---------- вкладка ---------- */
V19.push('tok');
{const o=renderTabs;renderTabs=function(){o();const t=document.getElementById('tabs');if(!t||t.querySelector('[data-v="tok"]'))return;
  const html=`<button class="tab ${S.view==='tok'?'on':''}" data-act="view" data-v="tok">🎨 Токены</button>`;const r=t.querySelector('.tab[data-v="ref"]');
  if(r)r.insertAdjacentHTML('beforebegin',html);else t.insertAdjacentHTML('beforeend',html)}}
{const o=renderMain;renderMain=function(){if(S.view!=='tok')return o();const m=document.getElementById('main');
  if(ROOT.parentElement!==m){m.innerHTML='';m.appendChild(ROOT)}TOK.schedule()}}
{const o=renderSide;renderSide=function(){if(S.view!=='tok')return o();const s=document.getElementById('side');
  const arts=TOK.arts();
  s.innerHTML=`<div class="side-hd"><b>🎨 Токены</b></div><p class="muted" style="font-size:12px;margin:6px 12px">Гекс-токены для Roll20 и Foundry: загрузите арт или возьмите из программы, выберите размер и сохраните PNG. Кнопка «🎨 Токен» есть и у НИП в Библиотеке, и у меха пилота.</p>
   <div class="side-sub">Арт рам</div><div class="clist">${arts.filter(a=>a.grp==='Рамы').map(a=>`<button class="citem" data-tok="${esc(a.key)}"><span><b>${esc(a.name)}</b></span></button>`).join('')}</div>
   <div class="side-sub">Корабли «Флота»</div><div class="clist">${arts.filter(a=>a.grp!=='Рамы').map(a=>`<button class="citem" data-tok="${esc(a.key)}"><span><b>${esc(a.name)}</b></span></button>`).join('')}</div>`}}
document.addEventListener('click',e=>{const b=e.target.closest('[data-tok]');if(!b)return;const a=TOK.arts().find(x=>x.key===b.dataset.tok);if(!a)return;
  TOK.open({src:a.src,name:a.name,label:a.label,size:a.key.startsWith('f:')?(P.F[a.key.slice(2)]||{stats:{size:1}}).stats.size:3,preset:a.key.startsWith('f:')?'pilot':'neutral'})});
/* игроку вкладка тоже доступна (m9 пропускает вид 'tok') */
{const o=renderTabs;renderTabs=function(){o();try{const t=document.getElementById('tabs');if(t&&isPlayer()&&!t.querySelector('[data-v="tok"]')){const r=t.querySelector('.tab[data-v="ref"]');const html=`<button class="tab ${S.view==='tok'?'on':''}" data-act="view" data-v="tok">🎨 Токены</button>`;if(r)r.insertAdjacentHTML('beforebegin',html);else t.insertAdjacentHTML('beforeend',html)}}catch(e){}}}
/* ---------- «🎨 Токен» у НИП и у меха ---------- */
function tokGo(o){S.view='tok';render();TOK.open(o)}
{const o=viewLib;viewLib=function(){let h=o();try{if(S.tplView)return h;const c=cls(S.cls);if(!c)return h;
  h=h.replace('<div class="addbar">','<div class="addbar"><button class="btn sm" data-tokgo="npc" title="Сделать гекс-токен этого НИП">🎨 Токен</button>')}catch(e){}return h}}
document.addEventListener('click',e=>{const b=e.target.closest('[data-tokgo]');if(!b)return;
  if(b.dataset.tokgo==='npc'){const c=cls(S.cls);if(!c)return;const st=effStats(c,S.tier,getTplSel(c.id).tpls,getSel(c.id),getTplSel(c.id).ch);tokGo({label:c.name,size:st.size,preset:getTplSel(c.id).tpls.includes('ultra')?'ultra':getTplSel(c.id).tpls.includes('elite')?'elite':'enemy',sample:true});return}
  if(b.dataset.tokgo==='mech'){const p=curP();if(!p)return;const m=curM(p),f=P.F[m.frame],st=mechStats(p,m);tokGo({label:(p.callsign||m.name||f.name),size:st.size,preset:'pilot',src:ART&&ART[f.id]?ART[f.id]:null,name:f.name,sample:!(ART&&ART[f.id])})}});
{const o=viewMech;viewMech=function(p){let h=o(p);try{h=h.replace('<label class="fl">Имя меха','<button class="btn sm" data-tokgo="mech" style="align-self:flex-start;margin-bottom:6px">🎨 Токен этого меха</button><label class="fl">Имя меха')}catch(e){}return h}}
'''
import json
M26=M26.replace('__CSS__',json.dumps(css,ensure_ascii=False)).replace('__HTML__',json.dumps(body,ensure_ascii=False))
open(OUT,'w',encoding='utf-8').write(M26)
print('ok',OUT,len(M26))
