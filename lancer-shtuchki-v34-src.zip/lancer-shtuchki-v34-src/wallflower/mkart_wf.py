# Арт рам Wallflower: слои картинок страницы собираются заново (фон-подложка страницы отбрасывается), белый фон → прозрачный.
import pymupdf,io,json,base64,sys,os
from PIL import Image
import numpy as np
H=os.path.dirname(os.path.abspath(__file__))
d=pymupdf.open(sys.argv[1] if len(sys.argv)>1 else '/root/.claude/uploads/d0819c7c-129e-5c04-9991-5764081b769c/cb825167-No_Room_for_a_Wallflower_Act_1.pdf')
ART=sys.argv[2] if len(sys.argv)>2 else os.path.join(H,'..','pc','art.json')
PAGES={'mf_kidd':179,'mf_tokugawa_alt_enkidu':185,'mf_genghis_alt_worldkiller_genghis_mk_i':187,'mf_swallowtail_alt_swallowtail_ranger_variant':189}
def img_rgba(xref):
    pix=pymupdf.Pixmap(d,xref)
    if pix.colorspace and pix.colorspace.n>3: pix=pymupdf.Pixmap(pymupdf.csRGB,pix)
    if pix.alpha: pass
    sm=d.extract_image(xref).get('smask',0)
    im=Image.open(io.BytesIO(pix.tobytes('png'))).convert('RGBA')
    if sm:
        m=pymupdf.Pixmap(d,sm);mi=Image.open(io.BytesIO(m.tobytes('png'))).convert('L').resize(im.size);im.putalpha(mi)
    else:
        a=np.asarray(im).astype(np.int16)
        edge=np.concatenate([a[0,:,:3],a[-1,:,:3],a[:,0,:3],a[:,-1,:3]])
        if edge.mean()>230:
            dist=np.max(255-a[...,:3],axis=2);al=np.clip((dist-6)*12,0,255).astype(np.uint8);im.putalpha(Image.fromarray(np.minimum(al,a[...,3].astype(np.uint8))))
    return im
def compose(n,scale=2.4,largest=False):
    p=d[n-1];A=p.rect.get_area()
    inf=[i for i in p.get_image_info(xrefs=True) if pymupdf.Rect(i['bbox']).get_area()<A*0.9 and pymupdf.Rect(i['bbox']).get_area()>2500]
    if largest:inf=[max(inf,key=lambda i:pymupdf.Rect(i['bbox']).get_area())]
    clip=pymupdf.Rect(inf[0]['bbox'])
    for i in inf[1:]:clip|=pymupdf.Rect(i['bbox'])
    clip&=p.rect
    W,Hh=int(clip.width*scale),int(clip.height*scale);C=Image.new('RGBA',(W,Hh),(0,0,0,0))
    for i in inf:
        r=pymupdf.Rect(i['bbox']);im=img_rgba(i['xref']).resize((max(1,int(r.width*scale)),max(1,int(r.height*scale))),Image.LANCZOS)
        C.alpha_composite(im,(int((r.x0-clip.x0)*scale),int((r.y0-clip.y0)*scale)))
    bb=C.getchannel('A').point(lambda v:255 if v>20 else 0).getbbox()
    if bb:C=C.crop(bb)
    C.thumbnail((800,800),Image.LANCZOS);return C
art=json.load(open(ART)) if os.path.exists(ART) else {}
os.makedirs(os.path.join(H,'art'),exist_ok=True)
for fid,n in PAGES.items():
    img=compose(n,largest=(fid=='mf_kidd'));img.save(os.path.join(H,'art',fid+'.png'))
    b=io.BytesIO();img.save(b,'WEBP',quality=80,method=4)
    art[fid]='data:image/webp;base64,'+base64.b64encode(b.getvalue()).decode();print(fid,img.size,len(b.getvalue())//1024,'KB')
json.dump(art,open(ART,'w'))
