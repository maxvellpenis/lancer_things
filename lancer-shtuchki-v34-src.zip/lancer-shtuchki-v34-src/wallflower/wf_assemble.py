# Добавляет в pcdata.json снаряжение игроков из «No Room for a Wallflower, Act 1»: числа из wallflower-data 2.1.0, тексты из wf_ru.json.
# Повторный запуск безопасен: прежние записи WF удаляются.
import json,os,sys
H=os.path.dirname(os.path.abspath(__file__))
WD=os.environ.get('WFDATA',os.path.join(H,'..','wfdata','lib'))
PCD=sys.argv[1] if len(sys.argv)>1 else os.path.join(H,'..','pc','pcdata.json')
J=lambda f:json.load(open(os.path.join(WD,f+'.json')))
RU=json.load(open(os.path.join(H,'wf_ru.json')))
d=json.load(open(PCD))
for k in ('frames','weapons','systems','mods','talents','gear','reserves'):d[k]=[x for x in d[k] if x.get('book')!='WF']
ROLE={'Striker':'Нападающий','Defender':'Защитник','Support':'Поддерживающий','Controller':'Оператор','Artillery':'Артиллерист','Balanced':'Универсальный'}
WS={'Auxiliary':'Вспомогательное','Main':'Основное','Heavy':'Тяжелое','Superheavy':'Сверхтяжелое'}
WT={'Melee':'ОББ','CQB':'ОБД','Rifle':'Винтовка','Launcher':'ПУ','Cannon':'Пушка','Nexus':'Звено'}
TAGRU={k:v['n'] for k,v in d['tags'].items()}
d['tags']['tg_exotic']=dict(n='Экзотическое Снаряжение',d='Снаряжение вне обычной системы лицензий: выдаётся ГМом как награда. Не повышает УЛ и не считается рангом лицензии. Ставится и снимается только при Полном Ремонте; одновременно можно установить не больше **двух** предметов с этой меткой (владеть — сколько угодно). Уничтоженное чинится и перепечатывается как обычно.')
VARIANT={'Everest':'mf_standard_pattern_i_everest','Tokugawa':'mf_tokugawa','Genghis':'mf_genghis','Swallowtail':'mf_swallowtail'}
rng=lambda a:[{'t':x['type'],'v':x['val']} for x in (a or [])]
dmg=lambda a:[{'t':x.get('type','variable').lower(),'v':x['val']} for x in (a or [])]
tags=lambda a:[[x['id'],x.get('val')] for x in (a or [])]
tagtxt=lambda tg:[TAGRU.get(t[0],t[0]).replace('{VAL}',str(t[1] if t[1] is not None else 'X')) for t in tg if t[0] in TAGRU]
def lic(x):
    if x.get('source')=='EXOTIC':return 'EXOTIC','','Экзотика',0
    if x.get('license')=='Kidd':return 'IPS-N','mf_kidd','Kidd',x.get('license_level') or 0
    return x.get('source') or '','','',0
for f in J('frames'):
    r=RU['frames'][f['id']];cs=f['core_system'];rc=r['core']
    tr=[dict(name=n,en=t['name'],text=b,bonuses=t.get('bonuses'),use=t.get('use')) for (n,b),t in zip(r['traits'],f['traits'])]
    core=dict(name=rc['name'],en=cs['name'],aname=rc.get('aname'),atext=rc.get('atext',''),atags=rc.get('atags',''),act=cs.get('activation'),use=cs.get('use'),
              pname=rc.get('pname'),ptext=rc.get('ptext'),integrated=cs.get('integrated') or [],bonuses=cs.get('active_bonuses'))
    if cs.get('counters'):core['counters']=[dict(id=c['id'],name='Куб Роджера',min=c.get('min',0),max=c.get('max',6),default_value=c.get('default_value',1)) for c in cs['counters']]
    o=dict(id=f['id'],name=r['name'],en=f['name'],src=f['source'],ll=f['license_level'],role='/'.join(ROLE.get(m,m) for m in f['mechtype']),
        mounts=f['mounts'],stats=f['stats'],traits=tr,core=core,page=r['page'],book='WF')
    if f.get('variant'):o['variant']=VARIANT[f['variant']]
    d['frames'].append(o)
for w in J('weapons'):
    r=RU['items'][w['id']];src,l,ln,ll=lic(w)
    o=dict(id=w['id'],name=r['name'],en=w['name'],src=src,lic=l,licn=ln,ll=ll,mount=w['mount'],type=w['type'],
           dmg=dmg(w.get('damage')),rng=rng(w.get('range')),tags=tags(w.get('tags')),sp=w.get('sp') or 0,text=r['text'],page=r['page'],book='WF')
    if w['id']=='mw_tokugawa_alt_enkidu_integrated':o['src']='';o['integ']=1
    if src=='EXOTIC':o['exo']=1
    o['rutags']=', '.join([f"{WS.get(w['mount'],w['mount'])} {WT.get(w['type'],w['type'])}"]+tagtxt(o['tags'])+([f"{o['sp']} СП"] if o['sp'] else []))
    d['weapons'].append(o)
DEPS={
 'ms_omnibus_plate':[dict(n='Омнибусная Платформа',hp=10,ev=5,ed=None,ar=0,size=1,inst=1,type='Deployable')],
 'ms_forge_2_subaltern_squad':[dict(n='Проект FORGE-2',hp=5,ev=5,ed=None,ar=0,size=1,inst=1,type='Deployable')],
 'ms_smokestack_heatsink':[dict(n='Пилон SMOKESTACK',hp=5,ev=10,ed=10,ar=0,size=0.5,inst=1,type='Deployable')],
 'ms_exo_markeys_fusebox':[dict(n='Заряд Марки',hp=10,ev=5,ed=5,ar=0,size=0.5,inst=1,type='Mine')],
}
for s in J('systems'):
    r=RU['items'][s['id']];src,l,ln,ll=lic(s);tg=tags(s.get('tags'))
    o=dict(id=s['id'],name=r['name'],en=s['name'],src=src,lic=l,licn=ln,ll=ll,sp=s.get('sp') or 0,type=s.get('type','System'),
           tags=tg,rutags=', '.join(([f"{s['sp']} СП"] if s.get('sp') else [])+tagtxt(tg)),text=r['text'],bonuses=s.get('bonuses'),page=r['page'],book='WF')
    acts=[dict(name=a.get('name') or r['name'],act=a.get('activation'),tech=bool(a.get('tech_attack'))) for a in s.get('actions',[])]
    if acts:o['acts']=acts
    if s['id'] in DEPS:o['deps']=DEPS[s['id']]
    if src=='EXOTIC':o['exo']=1
    d['systems'].append(o)
for t in J('talents'):
    r=RU['talents'][t['id']]
    rk=[dict(name=n,en=x['name'],text=b,bonuses=x.get('bonuses'),integrated=x.get('integrated') or [],counters=x.get('counters')) for (n,b),x in zip(r['ranks'],t['ranks'])]
    d['talents'].append(dict(id=t['id'],name=r['name'],en=t['name'],ranks=rk,page=r['page'],book='WF'))
for g in J('pilot_gear'):
    r=RU['gear'][g['id']];tg=tags(g.get('tags'))
    o=dict(id=g['id'],name=r['name'],en=g['name'],type=g['type'],tags=tg,rng=rng(g.get('range')),dmg=dmg(g.get('damage')),bonuses=g.get('bonuses'),
           text=r['text'],rutags=', '.join(tagtxt(tg)),page=r['page'],book='WF',exo=1)
    if g['id']=='ms_exo_anti_armor_signature_weapon':o['flav']='sig';o['tags'].append(['tg_set_damage_type',None])
    if g['type']=='Armor':o['flav']='armor';o['resist']=['energy']
    d['gear'].append(o)
for rid,(n,ty,tx) in RU['reserves'].items():
    d['reserves'].append(dict(id=rid,type=ty,name=n,text=tx,page=58,book='WF'))
json.dump(d,open(PCD,'w'),ensure_ascii=False,indent=0)
print('WF:',{k:sum(1 for x in d[k] if x.get('book')=='WF') for k in ('frames','weapons','systems','talents','gear','reserves')})
