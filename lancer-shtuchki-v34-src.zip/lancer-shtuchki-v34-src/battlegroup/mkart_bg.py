# Арт корпусов Battlegroup: верх страницы над заголовком, белый фон → прозрачный.
import pymupdf,io,subprocess,json,sys,os,base64
from PIL import Image,ImageChops
import numpy as np
sys.path.insert(0,'.');import bg_hulls
d=pymupdf.open('/mnt/user-data/uploads/Lancer_-_Battlegroup-2.pdf')
os.makedirs('shipimg/out',exist_ok=True)
MB=[]
def title_top(img):
    p='shipimg/_t.png';img.convert('L').save(p)
    r=subprocess.run(['tesseract',p,'stdout','--psm','3','tsv'],capture_output=True,text=True).stdout.splitlines()[1:]
    best=None;MB.clear()
    for ln in r:
        f=ln.split('\t')
        if len(f)<12:continue
        w=f[11].strip().upper()
        if w in('GMS','HA','FKS','IPS-N','SSC','IRS-N','IPS'):MB.append((int(f[6]),int(f[7]),int(f[8]),int(f[9])))
        if 'CLASS' in w or w in('GMS','HA','FKS','IPS-N','SSC','IRS-N'):
            top=int(f[7]);h=int(f[9])
            if top>img.height*0.12 and (best is None or top<best[0]):best=(top,h,w)
    return best
def to_alpha(img):
    a=np.asarray(img.convert('RGB')).astype(np.int16)
    dist=np.max(255-a,axis=2)  # 0 = белый
    alpha=np.clip((dist-6)*12,0,255).astype(np.uint8)
    out=Image.fromarray(np.dstack([a.astype(np.uint8),alpha]),'RGBA')
    return out
def art(page,key):
    pix=d[page-1].get_pixmap(dpi=150);img=Image.open(io.BytesIO(pix.tobytes('png'))).convert('RGB')
    W,H=img.size;tt=title_top(img)
    y1=(tt[0]-int(tt[1]*(1.9 if 'CLASS' in tt[2] else 0.5))) if tt else int(H*0.42)
    if tt and tt[2]!='CLASS' and False:pass
    crop=img.crop((0,0,W,y1))
    # убрать номер раздела в углах
    from PIL import ImageDraw
    dr=ImageDraw.Draw(crop)
    for (x,y,w,h) in MB:dr.rectangle((x-6,y-6,x+w+6,y+h+6),fill='white')
    dr.rectangle((int(W*0.93),0,W,int(H*0.14)),fill='white');dr.rectangle((0,0,int(W*0.06),int(H*0.14)),fill='white')
    # заголовок производителя (красный текст строкой) — обрезаем по белому зазору снизу
    a=np.asarray(crop).astype(np.int16);nw=(np.max(255-a,axis=2)>25)
    rows=nw.sum(1);ys=np.where(rows>3)[0]
    if len(ys)==0:return None
    # ищем нижнюю границу арта: последний ряд перед белым промежутком ≥ 8px снизу вверх от y1
    ybot=ys[-1]
    gap=0;cut=None
    for y in range(ybot,-1,-1):
        if rows[y]<=3:gap+=1
        else:
            if gap>=10 and cut is None and y<ybot-5:
                # всё, что ниже — подпись производителя, если она невысокая
                if ybot-(y+gap)<H*0.05:cut=y+1
            gap=0
    if cut:crop=crop.crop((0,0,W,cut))
    im=to_alpha(crop);bb=im.getchannel('A').point(lambda v:255 if v>20 else 0).getbbox()
    if bb:im=im.crop(bb)
    im.thumbnail((900,600),Image.LANCZOS);im.save(f'shipimg/out/{key}.png')
    b=io.BytesIO();im.save(b,'WEBP',quality=80,method=4)
    return 'data:image/webp;base64,'+base64.b64encode(b.getvalue()).decode(),im.size,len(b.getvalue())
OUT={}
for h in bg_hulls.HULLS:
    r=art(h['page'],h['id'])
    if r:OUT[h['id']]=r[0];print(h['id'],r[1],r[2]//1024,'KB')
json.dump(OUT,open('../pc/bgart.json','w'))
print('total KB',sum(len(v) for v in OUT.values())//1024)
