# Сборка данных Battlegroup в pc/bgdata.json
import json,sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import bg_hulls,bg_weap,bg_sys,bg_ew,bg_npc1,bg_npc2,bg_ref,bg_gm
def clean(o):
    if isinstance(o,dict): return {k:clean(v) for k,v in o.items() if v is not None}
    if isinstance(o,list): return [clean(x) for x in o]
    return o
D=dict(hulls=bg_hulls.HULLS,weapons=bg_weap.WEAPONS,systems=bg_sys.SYSTEMS,escorts=bg_ew.ESCORTS,wings=bg_ew.WINGS,aceUps=bg_ew.ACE_UPS,
       npcCap=bg_npc1.NPC_CAP,npcEsc=bg_npc2.NPC_ESC,npcAce=bg_npc2.NPC_ACE,ref=bg_ref.SECTIONS,gm=bg_gm.GM)
D=clean(D)
# проверки
ids=set()
for k in ['hulls','weapons','systems','escorts','wings','npcCap','npcEsc','npcAce']:
    for x in D[k]:
        assert x['id'] not in ids,(k,x['id']); ids.add(x['id'])
out=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','pc','bgdata.json')
json.dump(D,open(out,'w'),ensure_ascii=False,separators=(',',':'))
print('ok',os.path.getsize(out))
