import pymupdf,subprocess,sys,os
from concurrent.futures import ThreadPoolExecutor
d=pymupdf.open('/mnt/user-data/uploads/Lancer_-_Battlegroup-2.pdf')
pages=[int(x) for x in sys.argv[1:]]
def go(n):
    out=f'ocr/p{n:03d}'
    if os.path.exists(out+'.txt'):return
    pix=d[n-1].get_pixmap(dpi=300);pix.save(out+'.png')
    subprocess.run(['tesseract',out+'.png',out,'--psm','3'],capture_output=True)
    os.remove(out+'.png')
for n in pages: go(n)
