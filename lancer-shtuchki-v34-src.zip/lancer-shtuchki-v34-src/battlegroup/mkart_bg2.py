import pymupdf,io,json,base64,sys
from PIL import Image
import numpy as np
d=pymupdf.open('/mnt/user-data/uploads/Lancer_-_Battlegroup-2.pdf')
blank=pymupdf.Pixmap(pymupdf.csRGB,pymupdf.IRect(0,0,1,1),1);blank.clear_with(0)
def clusters(p):
    inf=p.get_image_info(xrefs=True);A=p.rect.width*p.rect.height
    big=[i for i in inf if (i['bbox'][2]-i['bbox'][0])*(i['bbox'][3]-i['bbox'][1])>A*0.25]
    small=[pymupdf.Rect(i['bbox']) for i in inf if i not in big and (i['bbox'][2]-i['bbox'][0])*(i['bbox'][3]-i['bbox'][1])>300]
    cl=[]
    for r in small:
        m=[c for c in cl if (c+(-12,-12,12,12)).intersects(r)]
        for c in m:cl.remove(c);r=r|c
        cl.append(r)
    # повторное слияние
    ch=True
    while ch:
        ch=False
        for a in cl:
            for b in cl:
                if a is not b and (a+(-12,-12,12,12)).intersects(b):cl.remove(a);cl.remove(b);cl.append(a|b);ch=True;break
            if ch:break
    return big,sorted(cl,key=lambda r:(r.x0))
if __name__=='__main__':
    for n in [113,169,171,173,184,188,189,190]:
        big,cl=clusters(d[n-1]);print(n,len(big),[[round(x) for x in c] for c in cl])

def render(n,clip):
    doc=pymupdf.open('/mnt/user-data/uploads/Lancer_-_Battlegroup-2.pdf');p=doc[n-1]
    big,_=clusters(p)
    for i in big:p.replace_image(i['xref'],pixmap=blank)
    pix=p.get_pixmap(dpi=200,clip=clip,alpha=True)
    img=Image.open(io.BytesIO(pix.tobytes('png'))).convert('RGBA')
    a=np.asarray(img).astype(np.int16);rgb=a[...,:3];al=a[...,3]
    dist=np.max(255-rgb,axis=2);al2=np.minimum(al,np.clip((dist-6)*12,0,255))
    img=Image.fromarray(np.dstack([rgb.astype(np.uint8),al2.astype(np.uint8)]),'RGBA')
    bb=img.getchannel('A').point(lambda v:255 if v>20 else 0).getbbox()
    if bb:img=img.crop(bb)
    img.thumbnail((900,600),Image.LANCZOS);return img
MAP={'pipecleaner':(113,0),'corsair':(169,0),'hivequeen':(171,0),'manowar':(173,0),'daggerflight':(184,0),'roughnecks':(188,0),'furies':(189,0),'stalwarts':(190,0),'wardogs':(190,1)}
def run():
    art=json.load(open('../pc/bgart.json'))
    for k,(n,ci) in MAP.items():
        _,cl=clusters(d[n-1]);img=render(n,cl[ci]);img.save(f'shipimg/out2_{k}.png')
        b=io.BytesIO();img.save(b,'WEBP',quality=80,method=4);art[k]='data:image/webp;base64,'+base64.b64encode(b.getvalue()).decode();print(k,img.size,len(b.getvalue())//1024)
    json.dump(art,open('../pc/bgart.json','w'))

def img_rgba(xref):
    pix=pymupdf.Pixmap(d,xref)
    if pix.colorspace and pix.colorspace.n>3: pix=pymupdf.Pixmap(pymupdf.csRGB,pix)
    sm=d.extract_image(xref).get('smask',0)
    im=Image.open(io.BytesIO(pix.tobytes('png'))).convert('RGBA')
    if sm:
        m=pymupdf.Pixmap(d,sm);mi=Image.open(io.BytesIO(m.tobytes('png'))).convert('L').resize(im.size)
        im.putalpha(mi)
    else:
        a=np.asarray(im).astype(np.int16)
        edge=np.concatenate([a[0,:,:3],a[-1,:,:3],a[:,0,:3],a[:,-1,:3]])
        if edge.mean()<40:  # чёрный фон (режим наложения «экран»)
            lum=np.max(a[...,:3],axis=2);al=np.clip(lum*2,0,255).astype(np.uint8)
            rgb=np.clip(a[...,:3]*255/np.maximum(al[...,None],1),0,255).astype(np.uint8)
            im=Image.fromarray(np.dstack([rgb,al]),'RGBA')
        elif edge.mean()>235:
            dist=np.max(255-a[...,:3],axis=2);al=np.clip((dist-6)*12,0,255).astype(np.uint8);im.putalpha(Image.fromarray(np.minimum(al,a[...,3].astype(np.uint8))))
    return im
def compose(n,clip,scale=2.6):
    p=d[n-1];W,H=int(clip.width*scale),int(clip.height*scale);C=Image.new('RGBA',(W,H),(0,0,0,0))
    for i in p.get_image_info(xrefs=True):
        r=pymupdf.Rect(i['bbox'])
        if not clip.contains(r) and not (r&clip).get_area()>r.get_area()*0.8:continue
        if r.get_area()>p.rect.get_area()*0.25:continue
        im=img_rgba(i['xref']).resize((max(1,int(r.width*scale)),max(1,int(r.height*scale))),Image.LANCZOS)
        C.alpha_composite(im,(int((r.x0-clip.x0)*scale),int((r.y0-clip.y0)*scale)))
    bb=C.getchannel('A').point(lambda v:255 if v>20 else 0).getbbox()
    if bb:C=C.crop(bb)
    C.thumbnail((900,600),Image.LANCZOS);return C
def run2():
    art=json.load(open('../pc/bgart.json'))
    for k,(n,ci) in MAP.items():
        _,cl=clusters(d[n-1]);img=compose(n,cl[ci]);img.save(f'shipimg/out2_{k}.png')
        b=io.BytesIO();img.save(b,'WEBP',quality=80,method=4);art[k]='data:image/webp;base64,'+base64.b64encode(b.getvalue()).decode();print(k,img.size,len(b.getvalue())//1024)
    json.dump(art,open('../pc/bgart.json','w'))
