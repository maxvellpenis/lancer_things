# -*- coding: utf-8 -*-
# Бои «Dustgrave»: ситреп, окружение, цели и силы противника для 3/4/5 ИП — для загрузки в «Бой» одной кнопкой.
import json,os
def I(n,c,o=(),t=(),pc=3,note='',upg=None,label=None,ch=()):
    d=dict(n=n,c=c,o=list(o),t=list(t),pc=pc,ch=list(ch))
    if note:d['note']=note
    if upg:d['upg']=upg
    if label:d['label']=label
    return d
def G(name,items,note=''):return dict(name=name,items=items,note=note)
def E(id,name,en,page,mission,sitrep,groups,details,obj='',env=''):return dict(id='dg_'+id,book='DG',name=name,en=en,page=page,mission=mission,sitrep=sitrep,obj=obj,env=env,groups=groups,details=details)
IN=['dg_industrial'];SO=['dg_specop'];HO=['dg_horror']
ENC=[
E('bloodsport','Кровавый спорт','Bloodsport',34,'Миссия 1: Субальтерн','особый',
 [G('Волна 1',[I(2,'monster',['rampage']),I(1,'monster',['rampage'],pc=4),I(1,'monster',['rampage'],pc=5)]),
  G('Волна 2',[I(1,'wrecker',t=IN,ch=['in-rivet']),I(1,'assassin'),I(1,'sentinel'),I(1,'pyro',pc=4),I(1,'assassin',pc=5)]),
  G('Волна 3',[I(1,'assassin'),I(1,'sentinel'),I(1,'witch'),I(1,'pyro',pc=4),I(1,'sentinel',pc=5)]),
  G('Волна 4 — чемпион',[I(1,'bastion',t=['elite']+IN,ch=['in-wrecker','in-saw'],label='БРУТ',note='Циркулярная Пила вместо Роторного Гранатомёта',
     upg=[dict(pc=4,t=['veteran'],ch=['vt-legend']),dict(pc=5,t=['commander'],ch=['cm-march'])])])],
 'Гладиаторские бои в Кратерной Яме. ИП начинают в центре; в каждой четверти карты — зона входа [Взрыв]2 (лифты). В конце раунда, где осталось два НИП или меньше, входит следующая волна (можно раньше, если игроки тянут время). Бой кончается, если мехи ИП уничтожены, они сдались или все враги побеждены.\nДля 5 ИП добавьте Бруту и шаблон **Командир** (Быстрый Марш).\n**Награда**: один ИП берёт **Шар-Крушитель Брута** или **Щит Брута** (экзотика).',env='Опасности арены'),
E('dustbranded','Пыльные Клейма','Dustbranded',36,'Миссия 1: Субальтерн','Оборона (Lancer, стр. 272)',
 [G('Основные силы',[I(1,'engineer',t=IN,ch=['in-drill']),I(1,'barricade',t=IN,ch=['in-wrecker']),I(1,'breacher'),I(1,'sentinel'),I(1,'berserker',['nailgun'],pc=4),I(1,'barricade',t=IN,ch=['in-wrecker'],pc=5)]),
  G('Подкрепления',[I(1,'engineer',t=IN,ch=['in-drill']),I(1,'support',t=IN,ch=['in-cutter']),I(1,'sentinel',pc=4),I(1,'berserker',['nailgun'],pc=5)])],
 'Зона развёртывания ИП — она же цель — в центре. Бой 6 раундов; в конце 6-го в зоне должно быть меньше четырёх мехов Пыльных Клейм, иначе ИП задавлены. В конце любого раунда можно вводить до двух врагов в зоне врага/входа.\n**Поражение**: ИП катапультируются, Пыльные Клейма забирают мехи; печать новых — отношение Лайрана −3.',env='Удушливая пыль'),
E('magenta','Услуга Мадженты','A Magenta Favor',40,'Миссия 1: Субальтерн','Прорыв (Lancer, стр. 271), изменённый',
 [G('Основные силы',[I(1,'support',t=['veteran','commander']+IN,ch=['in-drill','in-rivet','cm-march','vt-legend'],label='ДУРСТ СЛОТЕР'),I(1,'engineer',t=IN,ch=['in-drill']),
   I(1,'barricade',t=IN,ch=['in-wrecker'],pc=4),I(1,'berserker',['nailgun'],pc=5)]),
  G('Подкрепления',[I(1,'sentinel'),I(1,'berserker',['nailgun']),I(1,'berserker',['nailgun'],pc=4),I(1,'barricade',t=IN,ch=['in-wrecker'],pc=5)])],
 'ИП стартуют в своей зоне, враги — в зоне врага/цели напротив; подкрепления — из зон входа. Дурст Слотер должен быть чётко отмечен.\n**Победа**: в конце 6-го раунда ИП в зоне цели больше, чем НИП, и мех Дурста уничтожен — отношение Мадженты +3. **Частичная победа**: ИП больше, но Дурст цел. **Частичное поражение**: Дурст уничтожен, но НИП в зоне не меньше — отношение Мадженты −2. **Поражение**: НИП больше и Дурст цел — отношение Мадженты падает до 0.',env='Удушливая пыль'),
E('talon','В когтях у Когтей','In the Talon’s Grasp',42,'Миссия 1: Субальтерн','Эвакуация (Lancer, стр. 270), изменённая',
 [G('Первая волна (конец 1-го раунда)',[I(1,'cataphract',t=SO,ch=['so-machete'],label='Нельсон ИПС-Н'),I(1,'breacher',['flechette'],SO,label='Калибан ИПС-Н',note='Размер ½'),I(1,'berserker',t=SO,ch=['so-gyrojet'],label='Чёрная Борода ИПС-Н'),
   I(1,'support',t=SO,ch=['so-machete','so-sensor'],pc=4,label='Ланкастер ИПС-Н'),I(1,'breacher',['flechette'],SO,pc=5,label='Калибан ИПС-Н',note='Размер ½')]),
  G('Вторая волна (конец 2-го или 3-го раунда)',[I(1,'cataphract',t=SO,ch=['so-machete'],label='Нельсон ИПС-Н'),I(1,'bastion',['deathcount'],['veteran']+SO,ch=['so-node','so-bulwark'],label='Дрейк ИПС-Н',note='в книге также «Ultra option: Ravager Turret» — это опция Ультра, без шаблона Ультра не добавляется'),
   I(1,'berserker',t=SO,ch=['so-gyrojet'],pc=4,label='Чёрная Борода ИПС-Н'),I(1,'support',t=SO,ch=['so-machete'],pc=5,label='Ланкастер ИПС-Н')])],
 'ИП пробираются через руины к заброшенной базе Пыльных Клейм за субальтерном. Зона развёртывания ИП — она же зона эвакуации — на дальнем краю от зоны цели. Мех двигает субальтерна, начав стандартное перемещение рядом с ним: ставит его в любое соседнее с собой пространство (иначе субальтерн не двигается; нельзя, если рядом враг; в отсек не влезает). Вначале врагов на поле нет — все входят из зон входа двумя волнами. Бой кончается, как только субальтерн в зоне эвакуации.\n**Поражение**: не вывезли к концу 10-го раунда — Когти исчезают с ним; отношение Лайрана −2.',obj='Субальтерн (Размер ½, Неразрушимый)',env='Удушливая пыль'),
E('elevator','Подъёмник','Elevator Pitch',44,'Миссия 1: Субальтерн','Сопровождение (Lancer, стр. 270), изменённое',
 [G('Первая волна',[I(1,'assassin',['devilcough'],['veteran','commander']+SO,ch=['so-node','cm-disc','vt-acro','vt-slip','vt-legend'],label='Штёртебекер ИПС-Н',note='Размер 1'),
   I(1,'breacher',['flechette'],SO,label='Калибан ИПС-Н',note='Размер ½'),I(1,'cataphract',t=SO,ch=['so-machete'],label='Нельсон ИПС-Н'),
   I(1,'support',t=SO,ch=['so-machete','so-sensor'],pc=4,label='Ланкастер ИПС-Н'),I(1,'breacher',['flechette'],SO,pc=5,label='Калибан ИПС-Н',note='Размер ½')]),
  G('Подкрепления (1–2 за раунд)',[I(1,'berserker',t=SO,ch=['so-gyrojet'],label='Чёрная Борода ИПС-Н'),I(1,'breacher',['flechette'],SO,label='Калибан ИПС-Н',note='Размер ½'),
   I(1,'cataphract',t=SO,ch=['so-machete'],pc=4,label='Нельсон ИПС-Н'),I(1,'breacher',['flechette'],SO,pc=5,label='Калибан ИПС-Н',note='Размер ½')])],
 'Зона ИП — на одном краю, зона эвакуации — на другом; зона врага — в центре, зоны входа — сверху и снизу. Субальтерна двигают, как в бою 2Б. У ИП **8 раундов**, чтобы довести его до зоны эвакуации. Подкрепления входят в конце раунда, по 1–2.\n**Поражение**: Когти забирают субальтерна; отношение Лайрана −2.',obj='Субальтерн (Размер ½, Неразрушимый)',env='Удушливая пыль'),
E('mesmer','МесмерТранс','MesmerTrance',54,'Миссия 2: Виктор Вирга','Осада (новый, см. Справочник)',
 [G('Основные силы',[I(1,'wrecker',t=HO,ch=['ho-quad','ho-redund']),I(1,'assault',t=HO,ch=['ho-whip']),I(1,'goliath',t=HO,ch=['ho-limbs','ho-maw']),I(1,'operator',t=HO,ch=['ho-terror']),
   I(1,'priest',t=HO,ch=['ho-redund'],pc=4),I(1,'monster',['spiky'],HO,ch=['ho-artif','ho-limbs'],pc=4),I(1,'priest',t=HO,ch=['ho-redund'],pc=5),I(1,'wrecker',t=HO,ch=['ho-quad','ho-redund'],pc=5)]),
  G('Если ИП штурмуют без союзников',[I(1,'goliath',t=HO,ch=['ho-limbs','ho-maw'])]),
  G('Подкрепления',[I(1,'assault',t=HO,ch=['ho-whip']),I(1,'assassin',t=HO,ch=['ho-terror','ho-redund']),I(1,'specter',t=HO,ch=['ho-phase']),
   I(1,'monster',['spiky'],HO,ch=['ho-artif','ho-limbs'],pc=4),I(1,'operator',t=HO,ch=['ho-terror'],pc=4),I(1,'assault',t=HO,ch=['ho-whip'],pc=5),I(1,'goliath',t=HO,ch=['ho-limbs','ho-maw'],pc=5)])],
 'Ситреп **Осада**: ИП начинают в своей зоне, враги — напротив. Четыре зоны цели — под контролем врага. Находясь в зоне, ИП может **протоколом** захватить её, если в ней ИП не меньше, чем НИП; захваченную зону потерять нельзя. Для победы к концу 6-го раунда нужно контролировать **три** зоны. Бой всегда длится 6 раундов; подкрепления — по обычным правилам.\n**Поражение**: защитники отступают вглубь комплекса; в следующем бою — ещё один НИП.',env='Удушливая пыль, МесмерТранс'),
E('industrial','Страдание в промышленных масштабах','Suffering on an Industrial Scale',56,'Миссия 2: Виктор Вирга','Снос (новый, см. Справочник)',
 [G('Основные силы',[I(1,'wrecker',t=HO,ch=['ho-quad','ho-redund']),I(1,'goliath',t=HO,ch=['ho-limbs','ho-maw']),I(1,'operator',t=HO,ch=['ho-terror']),I(1,'priest',t=HO,ch=['ho-redund']),
   I(1,'goliath',t=HO,ch=['ho-limbs','ho-maw'],pc=4),I(1,'monster',['spiky'],HO,ch=['ho-artif','ho-limbs'],pc=4),I(1,'monster',['spiky'],HO,ch=['ho-artif','ho-limbs'],pc=5)]),
  G('Если ИП проиграли «МесмерТранс»',[I(1,'assault',t=HO,ch=['ho-whip'])]),
  G('Подкрепления',[I(1,'assault',t=HO,ch=['ho-whip']),I(1,'assassin',t=HO,ch=['ho-terror','ho-redund']),I(1,'monster',['spiky'],HO,ch=['ho-artif','ho-limbs'],pc=4),I(1,'specter',t=HO,ch=['ho-phase'],pc=4),
   I(1,'assault',t=HO,ch=['ho-whip'],pc=5),I(1,'assassin',t=HO,ch=['ho-terror','ho-redund'],pc=5)])],
 'Ситреп **Снос**: ИП начинают в своей зоне, враги — напротив. В половине карты врага — пять **Узлов Управления** (Размер 3, **15/20/25 ПЗ**). ИП должны уничтожить все узлы за **8 раундов**. Подкрепления — по обычным правилам.\n**Поражение**: Вирга сможет чинить ужасы — в следующем бою ещё один НИП.',obj='5 Узлов Управления (Размер 3, 15/20/25 ПЗ)',env='МесмерТранс, Автоматические ремонтные станции'),
E('transcend','Трансценденция','Transcendence',62,'Миссия 2: Виктор Вирга','особый',
 [G('Основные силы',[I(1,'dg_virga'),I(1,'goliath',t=HO,ch=['ho-limbs','ho-maw']),I(1,'monster',['spiky'],HO,ch=['ho-artif','ho-limbs']),I(1,'assault',t=HO,ch=['ho-whip']),
   I(1,'assassin',t=HO,ch=['ho-terror','ho-redund'],pc=4),I(1,'assault',t=HO,ch=['ho-whip'],pc=5)]),
  G('Если прошлый бой проигран',[I(1,'goliath',t=HO,ch=['ho-limbs','ho-maw'])]),
  G('ХЕПРИ — когда щит Вирги падает до 0',[I(1,'dg_khepri',note='ПЗ: 50 × число игроков')])],
 'Бой с «боссом» в две фазы. Сначала Вирга с **Усилением Щита 30/40/50**; когда щит истощён, появляется **ХЕПРИ** и защищает его. Уничтожив тело ХЕПРИ, ИП могут покончить с Виргой. На всё — **8 раундов**.\n**Победа**: Вирга убит до конца 8-го раунда. **Поражение**: если он жив в конце 8-го, ИП могут остаться ещё на раунд или бежать; если он жив и в конце 9-го — вознесение Вирги уничтожает ИП.',env='МесмерТранс'),
E('birds','Удар в спину (необязательный)','Backstabbing Birds',68,'Миссия 2: Виктор Вирга','Оборона (Lancer, стр. 272), изменённая',
 [G('Когти',[I(1,'breacher',t=['veteran','commander']+SO,ch=['so-gyrojet','so-machete','so-jump','so-node','cm-march','vt-slip','vt-legend'],label='ЛЕОНОРА МАКГРАТ'),
   I(1,'assault',['autotarget'],['veteran']+SO,ch=['so-munitions','so-bulwark','vt-legend','vt-selfrep'],label='Металмарк СШК'),
   I(1,'scout',['spotter','exposeweak'],['veteran']+SO,ch=['so-sensor'],label='Ласточкин Хвост СШК'),
   I(1,'sniper',t=['veteran']+SO,ch=['so-machete','vt-fake','vt-head'],label='Мёртвая Голова СШК'),
   I(1,'ronin',t=['veteran']+SO,ch=['so-gyrojet','vt-reflex'],label='Атлас СШК',note='Размер ½'),
   I(1,'hailstorm',['hades'],['veteran']+SO,ch=['so-gyrojet','so-munitions','vt-limitless'],pc=4,label='Монарх СШК',note='Размер 2'),
   I(1,'assault',['autotarget'],['veteran']+SO,ch=['so-munitions','so-bulwark','vt-legend','vt-selfrep'],pc=5,label='Металмарк СШК')])],
 'Когти штурмуют «Объятия Династа», чтобы захватить Эмили. ИП начинают в центре; большая зона развёртывания ИП — она же зона цели. Бой 6 раундов: в конце 6-го в зоне должно быть **меньше двух** мехов Когтей, иначе ИП задавлены. После боя можно провести Полный Ремонт.\n**Перегорание подавителя**: если ИП не нашли бэкдор в Подавителях МесмерТранса, в начале любого раунда ГМ выбирает одного ИП с подавителем: его подавитель уничтожен, а он **Заклинен** до конца своего следующего хода.\n**Без свидетелей**: если ИП раскрыли Когтей, те стараются убить пилотов уничтоженных мехов.'),
]
json.dump(ENC,open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'dg_enc.json'),'w'),ensure_ascii=False)
print('ok',len(ENC))
