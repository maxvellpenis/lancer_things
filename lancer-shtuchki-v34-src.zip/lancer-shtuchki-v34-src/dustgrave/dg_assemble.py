# Добавляет в pcdata.json снаряжение игроков из «Dustgrave»: числа из dustgrave-data 2.0.3, тексты из dg_ru.json.
# Повторный запуск безопасен: прежние записи DG удаляются.
import json,os,sys
H=os.path.dirname(os.path.abspath(__file__))
DD=os.environ.get('DGDATA',os.path.join(H,'..','dgdata','lib'))
PCD=sys.argv[1] if len(sys.argv)>1 else os.path.join(H,'..','pc','pcdata.json')
J=lambda f:json.load(open(os.path.join(DD,f+'.json')))
RU=json.load(open(os.path.join(H,'dg_ru.json')))
d=json.load(open(PCD))
for k in ('frames','weapons','systems','mods','talents','gear','reserves','cbs'):d[k]=[x for x in d[k] if x.get('book')!='DG']
ROLE={'Striker':'Нападающий','Defender':'Защитник','Support':'Поддерживающий','Controller':'Оператор','Artillery':'Артиллерист','Balanced':'Универсальный'}
WS={'Auxiliary':'Вспомогательное','Main':'Основное','Heavy':'Тяжелое','Superheavy':'Сверхтяжелое'}
WT={'Melee':'ОББ','CQB':'ОБД','Rifle':'Винтовка','Launcher':'ПУ','Cannon':'Пушка','Nexus':'Звено'}
TAGRU={k:v['n'] for k,v in d['tags'].items()}
VARIANT={'Raleigh':'mf_raleigh','Monarch':'mf_monarch'}
PROF={'Regular Swing':'Обычный замах','Explosive Swing':'Взрывной замах','Standard':'Обычный','Superheavy':'Как Сверхтяжёлое'}
rng=lambda a:[{'t':x['type'],'v':x['val']} for x in (a or [])]
dmg=lambda a:[{'t':x.get('type','variable').lower(),'v':x['val']} for x in (a or [])]
tags=lambda a:[[x['id'],x.get('val')] for x in (a or [])]
tagtxt=lambda tg:[TAGRU.get(t[0],t[0]).replace('{VAL}',str(t[1] if t[1] is not None else 'X')) for t in tg if t[0] in TAGRU]
def lic(x):
    if x.get('source')=='EXOTIC':return 'EXOTIC','','Экзотика',0
    return 'GMS','','GMS',0
for f in J('frames'):
    r=RU['frames'][f['id']];cs=f['core_system'];rc=r['core']
    tr=[dict(name=n,en=t['name'],text=b,bonuses=None,use=t.get('use')) for (n,b),t in zip(r['traits'],f['traits'])]
    core=dict(name=rc['name'],en=cs['name'],aname=rc.get('aname'),atext=rc.get('atext',''),atags=rc.get('atags',''),act=cs.get('activation'),use=cs.get('use'),
              pname=rc.get('pname'),ptext=rc.get('ptext'),integrated=cs.get('integrated') or [],bonuses=None)
    o=dict(id=f['id'],name=r['name'],en=f['name'],src=f['source'],ll=f['license_level'],role='/'.join(ROLE.get(m,m) for m in f['mechtype']),
        mounts=f['mounts'],stats=f['stats'],traits=tr,core=core,page=r['page'],book='DG',variant=VARIANT[f['variant']])
    d['frames'].append(o)
for w in J('weapons'):
    r=RU['items'][w['id']];src,l,ln,ll=lic(w)
    o=dict(id=w['id'],name=r['name'],en=w['name'],src=src,lic=l,licn=ln,ll=ll,mount=w['mount'],type=w['type'],
           dmg=dmg(w.get('damage')),rng=rng(w.get('range')),tags=tags(w.get('tags')),sp=w.get('sp') or 0,text=r['text'],page=r['page'],book='DG')
    if w.get('profiles'):
        o['profiles']=[dict(name=PROF.get(p['name'],p['name']),dmg=dmg(p.get('damage')),rng=rng(p.get('range')),tags=tags(p.get('tags'))) for p in w['profiles']]
        if not o['dmg']:o['dmg']=o['profiles'][0]['dmg']
        if not o['rng']:o['rng']=o['profiles'][0]['rng']
    if src=='EXOTIC':o['exo']=1
    o['rutags']=', '.join([f"{WS.get(w['mount'],w['mount'])} {WT.get(w['type'],w['type'])}"]+tagtxt(o['tags'])+([f"{o['sp']} СП"] if o['sp'] else []))
    d['weapons'].append(o)
for s in J('systems'):
    r=RU['items'][s['id']];src,l,ln,ll=lic(s);tg=tags(s.get('tags'))
    o=dict(id=s['id'],name=r['name'],en=s['name'],src=src,lic=l,licn=ln,ll=ll,sp=s.get('sp') or 0,type=s.get('type','System'),
           tags=tg,rutags=', '.join(([f"{s['sp']} СП"] if s.get('sp') else [])+tagtxt(tg)),text=r['text'],bonuses=s.get('bonuses'),page=r['page'],book='DG')
    acts=[dict(name=a.get('name') or r['name'],act=a.get('activation'),tech=bool(a.get('tech_attack'))) for a in s.get('actions',[])]
    if acts:o['acts']=acts
    if s.get('talent_id'):o['tal']=[s['talent_id'],s.get('talent_rank',1)]
    if src=='EXOTIC':o['exo']=1
    d['systems'].append(o)
for t in J('talents'):
    r=RU['talents'][t['id']]
    rk=[dict(name=n,en=x['name'],text=b,bonuses=None,integrated=x.get('integrated') or [],counters=[dict(c,name={'transcendence_die':'Куб Трансценденции','intel_die':'Куб Разведданных'}.get(c['id'],c['name'])) for c in (x.get('counters') or [])] or None) for (n,b),x in zip(r['ranks'],t['ranks'])]
    d['talents'].append(dict(id=t['id'],name=r['name'],en=t['name'],ranks=rk,page=r['page'],book='DG'))
for c in J('core_bonuses'):
    r=RU['cb'][c['id']];d['cbs'].append(dict(id=c['id'],name=r['name'],en=c['name'],src=c['source'],text=r['text'],bonuses=None,page=r['page'],book='DG'))
for g in J('pilot_gear'):
    r=RU['gear'][g['id']];tg=tags(g.get('tags'))
    o=dict(id=g['id'],name=r['name'],en=g['name'],type=g['type'],tags=tg,rng=rng(g.get('range')),dmg=dmg(g.get('damage')),bonuses=g.get('bonuses'),
           text=r['text'],rutags=', '.join(tagtxt(tg)),page=r['page'],book='DG')
    if any(t[0]=='tg_exotic' for t in tg):o['exo']=1
    if g['type']=='Armor':o['flav']='armor'
    d['gear'].append(o)
for rid,(n,ty,tx) in RU['reserves'].items():
    d['reserves'].append(dict(id=rid,type=ty,name=n,text=tx,page=29 if ty=='Tactical' else 30,book='DG'))
json.dump(d,open(PCD,'w'),ensure_ascii=False,indent=0)
print('DG:',{k:sum(1 for x in d[k] if x.get('book')=='DG') for k in ('frames','weapons','systems','talents','gear','reserves','cbs')})
