# Арт рам Dustgrave: картинки страниц с альфа-маской (Штёртебекер — разворот стр. 76–77 склеивается), → art.json.
import pymupdf,io,json,base64,sys,os
from PIL import Image
H=os.path.dirname(os.path.abspath(__file__))
d=pymupdf.open(sys.argv[1] if len(sys.argv)>1 else '/mnt/user-data/uploads/Dustgrave.pdf')
ART=sys.argv[2] if len(sys.argv)>2 else os.path.join(H,'..','pc','art.json')
def img(x):
    pix=pymupdf.Pixmap(d,x)
    if pix.colorspace and pix.colorspace.n>3:pix=pymupdf.Pixmap(pymupdf.csRGB,pix)
    im=Image.open(io.BytesIO(pix.tobytes('png'))).convert('RGBA');sm=d.extract_image(x).get('smask',0)
    if sm:m=pymupdf.Pixmap(d,sm);im.putalpha(Image.open(io.BytesIO(m.tobytes('png'))).convert('L').resize(im.size))
    return im
def fin(im):
    bb=im.getchannel('A').point(lambda v:255 if v>20 else 0).getbbox()
    if bb:im=im.crop(bb)
    im.thumbnail((800,800),Image.LANCZOS);return im
S=img(598)  # основная часть разворота (мех целиком); правая страница — плащ и клинок
OUT={'mf_störtebeker':fin(S),'mf_micro_monarch':fin(img(631))}
art=json.load(open(ART));os.makedirs(os.path.join(H,'art'),exist_ok=True)
for k,im in OUT.items():
    im.save(os.path.join(H,'art',k.replace('ö','o')+'.png'));bb=io.BytesIO();im.save(bb,'WEBP',quality=80,method=4)
    art[k]='data:image/webp;base64,'+base64.b64encode(bb.getvalue()).decode();print(k,im.size,len(bb.getvalue())//1024,'KB')
json.dump(art,open(ART,'w'))
