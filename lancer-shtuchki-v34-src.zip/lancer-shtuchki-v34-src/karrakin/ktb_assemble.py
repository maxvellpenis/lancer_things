# Добавляет в pcdata.json содержимое «Field Guide to the Karrakin Trade Baronies»: числа из ktb-data 2.0.1, тексты из ktb_ru.json.
# Повторный запуск безопасен: прежние записи KTB удаляются.
import json,os,sys
H=os.path.dirname(os.path.abspath(__file__))
KD=os.environ.get('KTBDATA',os.path.join(H,'..','ktbdata','lib'))
PCD=sys.argv[1] if len(sys.argv)>1 else os.path.join(H,'..','pc','pcdata.json')
J=lambda f:json.load(open(os.path.join(KD,f+'.json')))
RU=json.load(open(os.path.join(H,'ktb_ru.json')))
d=json.load(open(PCD))
for k in ('frames','weapons','systems','mods','talents'):d[k]=[x for x in d[k] if x.get('book')!='KTB']
ROLE={'Striker':'Нападающий','Defender':'Защитник','Support':'Поддерживающий','Controller':'Оператор','Artillery':'Артиллерист','Balanced':'Универсальный'}
WS={'Auxiliary':'Вспомогательное','Main':'Основное','Heavy':'Тяжелое','Superheavy':'Сверхтяжелое'}
WT={'Melee':'ОББ','CQB':'ОБД','Rifle':'Винтовка','Launcher':'ПУ','Cannon':'Пушка','Nexus':'Звено'}
for k,v in RU['tags'].items():d['tags'][k]=v
TAGRU={k:v['n'] for k,v in d['tags'].items()}
VARIANT={'Black Witch':'mf_black_witch','Minotaur':'mf_minotaur'}
LICID={'White Witch':'mf_white_witch','Emperor':'mf_emperor'}
rng=lambda a:[{'t':x['type'],'v':x['val']} for x in (a or [])]
dmg=lambda a:[{'t':x.get('type','variable').lower(),'v':x['val']} for x in (a or [])]
tags=lambda a:[[x['id'],x.get('val')] for x in (a or [])]
tagtxt=lambda tg:[TAGRU.get(t[0],t[0]).replace('{VAL}',str(t[1] if t[1] is not None else 'X')) for t in tg if t[0] in TAGRU]
def lic(x):
    ln=x.get('license') or ''
    return LICID.get(ln,''),ln
for f in J('frames'):
    r=RU['frames'][f['id']];cs=f['core_system'];rc=r['core']
    tr=[]
    for (n,b),t in zip(r['traits'],f['traits']):
        bon=t.get('bonuses')
        if bon and any(str(x.get('val','')).find('{grit}')>=0 for x in bon):bon=[{'id':'hp_nogrit','val':1}]
        tr.append(dict(name=n,en=t['name'],text=b,bonuses=bon,use=t.get('use')))
    core=dict(name=rc['name'],en=cs['name'],aname=rc.get('aname'),atext=rc.get('atext',''),atags=rc.get('atags',''),act=cs.get('activation'),use=cs.get('use'),
              pname=rc.get('pname'),ptext=rc.get('ptext'),integrated=cs.get('integrated') or [],bonuses=cs.get('active_bonuses'))
    o=dict(id=f['id'],name=r['name'],en=f['name'],src=f['source'],ll=f['license_level'],role='/'.join(ROLE.get(m,m) for m in f['mechtype']),
        mounts=f['mounts'],stats=f['stats'],traits=tr,core=core,page=r['page'],book='KTB')
    if f.get('variant'):o['variant']=VARIANT[f['variant']]
    d['frames'].append(o)
for w in J('weapons'):
    r=RU['items'][w['id']];l,ln=lic(w)
    o=dict(id=w['id'],name=r['name'],en=w['name'],src=w.get('source') or '',lic=l,licn=ln,ll=w.get('license_level') or 0,mount=w['mount'],type=w['type'],
           dmg=dmg(w.get('damage')),rng=rng(w.get('range')),tags=tags(w.get('tags')),sp=w.get('sp') or 0,text=r['text'],page=r['page'],book='KTB')
    if w.get('profiles'):
        o['profiles']=[dict(name=RU['prof'].get(p['name'],p['name']),dmg=dmg(p.get('damage')),rng=rng(p.get('range')),tags=tags(p.get('tags'))) for p in w['profiles']]
        if not o['dmg']:o['dmg']=o['profiles'][0]['dmg']
        if not o['rng']:o['rng']=o['profiles'][0]['rng']
    if w['id']=='mw_emperor_integrated':o['src']='';o['lic']='';o['licn']=''
    if w['id']=='mw_ferrofluid_lance':o['tags']=[t for t in o['tags'] if t[0]!='tg_round']
    o['rutags']=', '.join([f"{WS.get(w['mount'],w['mount'])} {WT.get(w['type'],w['type'])}"]+tagtxt(o['tags'])+([f"{o['sp']} СП"] if o['sp'] else []))
    d['weapons'].append(o)
for s in J('systems'):
    r=RU['items'][s['id']];l,ln=lic(s);tg=tags(s.get('tags'))
    o=dict(id=s['id'],name=r['name'],en=s['name'],src=s.get('source') or 'SSC',lic=l,licn=ln,ll=s.get('license_level') or 0,sp=s.get('sp') or 0,type=s.get('type','System'),
           tags=tg,rutags=', '.join(([f"{s['sp']} СП"] if s.get('sp') else [])+tagtxt(tg)),text=r['text'],bonuses=s.get('bonuses'),page=r['page'],book='KTB')
    acts=[dict(name=a.get('name') or r['name'],act=a.get('activation'),tech=bool(a.get('tech_attack'))) for a in s.get('actions',[])]
    if acts:o['acts']=acts
    if s['id']=='ms_ferrospike_barrier':o['deps']=[dict(n='Феррошиповый Барьер',hp=20,ev=5,ed=None,ar=0,size=2,inst=1,type='Deployable')]
    d['systems'].append(o)
for t in J('talents'):
    r=RU['talents'][t['id']]
    rk=[dict(name=n,en=x['name'],text=b,bonuses=x.get('bonuses'),integrated=x.get('integrated') or [],counters=x.get('counters')) for (n,b),x in zip(r['ranks'],t['ranks'])]
    d['talents'].append(dict(id=t['id'],name=r['name'],en=t['name'],ranks=rk,page=r['page'],book='KTB'))
d['bonds']=json.load(open(os.path.join(H,'ktb_bonds.json')))
d['ktbstatus']=RU['status']
json.dump(d,open(PCD,'w'),ensure_ascii=False,indent=0)
print('KTB:',{k:sum(1 for x in d[k] if x.get('book')=='KTB') for k in ('frames','weapons','systems','talents')},'bonds',len(d['bonds']['bonds']))
