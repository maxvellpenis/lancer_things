# Добавляет в pcdata.json снаряжение игроков из «Siren's Song, A Mountain's Remorse»: числа из @massif/ssmr-data 1.7.0, тексты из ss_ru.json.
# Повторный запуск безопасен: прежние записи SS удаляются.
import json,os,sys
H=os.path.dirname(os.path.abspath(__file__))
DD=os.environ.get('SSDATA',os.path.join(H,'..','ssdata','package','lib'))
PCD=sys.argv[1] if len(sys.argv)>1 else os.path.join(H,'..','pc','pcdata.json')
J=lambda f:json.load(open(os.path.join(DD,f+'.json')))
RU=json.load(open(os.path.join(H,'ss_ru.json')))
d=json.load(open(PCD))
for k in ('frames','weapons','systems','mods','talents','gear','reserves','cbs'):d[k]=[x for x in d[k] if x.get('book')!='SS']
ROLE={'Striker':'Нападающий','Defender':'Защитник','Support':'Поддерживающий','Controller':'Оператор','Artillery':'Артиллерист','Balanced':'Универсальный'}
WS={'Auxiliary':'Вспомогательное','Main':'Основное','Heavy':'Тяжелое','Superheavy':'Сверхтяжелое'}
WT={'Melee':'ОББ','CQB':'ОБД','Rifle':'Винтовка','Launcher':'ПУ','Cannon':'Пушка','Nexus':'Звено'}
TAGRU={k:v['n'] for k,v in d['tags'].items()}
VARIANT={'Blackbeard':'mf_blackbeard'}
rng=lambda a:[{'t':x['type'],'v':x['val']} for x in (a or [])]
dmg=lambda a:[{'t':x.get('type','variable').lower(),'v':x['val']} for x in (a or [])]
tags=lambda a:[[x['id'],x.get('val')] for x in (a or []) if x['id'] not in ('tg_quick_action','tg_free_action','tg_reaction','tg_full_action')]
tagtxt=lambda tg:[TAGRU.get(t[0],t[0]).replace('{VAL}',str(t[1] if t[1] is not None else 'X')) for t in tg if t[0] in TAGRU]
for f in J('frames'):
    r=RU['frames'][f['id']];cs=f['core_system'];rc=r['core']
    tr=[dict(name=n,en=t['name'],text=b,bonuses=t.get('bonuses'),use=t.get('use')) for (n,b),t in zip(r['traits'],f['traits'])]
    core=dict(name=rc['name'],en=cs['name'],aname=rc.get('aname'),atext=rc.get('atext',''),atags=rc.get('atags',''),act=cs.get('activation'),use=cs.get('use'),
              pname=rc.get('pname'),ptext=rc.get('ptext'),integrated=cs.get('integrated') or [],bonuses=cs.get('active_bonuses'))
    o=dict(id=f['id'],name=r['name'],en=f['name'],src=f['source'],ll=f['license_level'],role='/'.join(ROLE.get(m,m) for m in f['mechtype']),
        mounts=f['mounts'],stats=f['stats'],traits=tr,core=core,page=r['page'],book='SS',variant=VARIANT[f['variant']])
    d['frames'].append(o)
for w in J('weapons'):
    r=RU['items'][w['id']]
    o=dict(id=w['id'],name=r['name'],en=w['name'],src='',lic='',licn='',ll=0,mount=w['mount'],type=w['type'],integ=1,
           dmg=dmg(w.get('damage')),rng=rng(w.get('range')),tags=tags(w.get('tags')),sp=w.get('sp') or 0,text=r['text'],page=r['page'],book='SS')
    o['rutags']=', '.join([f"{WS.get(w['mount'],w['mount'])} {WT.get(w['type'],w['type'])}"]+tagtxt(o['tags']))
    d['weapons'].append(o)
ACT={'ms_exo_mist_feathers':'Quick','ms_exo_emi_theater':'Quick','ms_exo_upgraded_network_array':'Free'}
for s in J('systems'):
    r=RU['items'][s['id']];tg=tags(s.get('tags'))
    o=dict(id=s['id'],name=r['name'],en=s['name'],src='EXOTIC',lic='',licn='Экзотика',ll=0,sp=s.get('sp') or 0,type=s.get('type','System'),
           tags=tg,rutags=', '.join(([f"{s['sp']} СП"] if s.get('sp') else [])+tagtxt(tg)),text=r['text'],bonuses=s.get('bonuses'),page=r['page'],book='SS',exo=1)
    if s['id'] in ACT:o['acts']=[dict(name=r['name'],act=ACT[s['id']],tech=False)]
    d['systems'].append(o)
for t in J('talents'):
    r=RU['talents'][t['id']]
    rk=[dict(name=n,en=x['name'],text=b,bonuses=x.get('bonuses'),integrated=x.get('integrated') or [],counters=None) for (n,b),x in zip(r['ranks'],t['ranks'])]
    rk[1]['counters']=[dict(id='ctr_orator',name='Кубы Оратора',min=0,max=3,default_value=1)]
    d['talents'].append(dict(id=t['id'],name=r['name'],en=t['name'],ranks=rk,page=r['page'],book='SS'))
for g in J('pilot_gear'):
    r=RU['gear'][g['id']];tg=tags(g.get('tags'))
    d['gear'].append(dict(id=g['id'],name=r['name'],en=g['name'],type=g['type'],tags=tg,rng=[],dmg=[],bonuses=None,text=r['text'],rutags=', '.join(tagtxt(tg)),page=r['page'],book='SS',exo=1))
for rid,(n,ty,tx) in RU['reserves'].items():
    d['reserves'].append(dict(id=rid,type=ty,name=n,text=tx,page=51,book='SS'))
json.dump(d,open(PCD,'w'),ensure_ascii=False,indent=0)
print('SS:',{k:sum(1 for x in d[k] if x.get('book')=='SS') for k in ('frames','weapons','systems','talents','gear','reserves')})
