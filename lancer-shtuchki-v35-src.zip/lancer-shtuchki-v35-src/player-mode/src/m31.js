/* ===== v35: «очень классные хб от максвелла» — вкладка «Персонаж» вместо «Связи» (ОБОД//НАРРАТИВ, база) ===== */
const HB_ST=[['int','ИНТ'],['rea','РЕА'],['lvk','ЛВК'],['tex','ТЕХ'],['har','ХАР'],['vol','ВОЛЯ'],['udc','УДЧ'],['sko','СКО'],['tel','ТЕЛ'],['emp','ЭМП']];
let HB_ON=!!LS.get('hb_on',false);
const hbOf=p=>{if(!p.hb||typeof p.hb!=='object')p.hb={st:{},rr:0,chut:0,luck:0};return p.hb};
const hbBudget=p=>5+(+p.ll||0),hbUsed=p=>HB_ST.reduce((s,[k])=>s+(hbOf(p).st[k]||0),0);
{const o=cleanPilot;cleanPilot=function(raw,k){const p=o(raw,k);try{const h=raw&&raw.hb&&typeof raw.hb==='object'?raw.hb:{},st={};
  HB_ST.forEach(([s])=>{const v=num(h.st&&h.st[s],0,10,0);if(v)st[s]=v});p.hb={st,rr:num(h.rr,0,10,0),chut:num(h.chut,0,40,0),luck:num(h.luck,0,20,0)}}catch(e){}return p}}
function charView(p){const h=hbOf(p),used=hbUsed(p),bud=hbBudget(p),rr=h.rr;
  const v=viewPilot(p),i=v.indexOf('<h2>Снаряжение пилота</h2>'),j=v.indexOf('<h2>Резервы',i),gear=i>=0?v.slice(i,j>i?j:undefined):'';
  const trig=PCD.skills.filter(s=>p.skills[s.id]).map(s=>`<button class="btn sm" data-hb="trig" data-v="${s.id}">${esc(s.name)} +${p.skills[s.id]*2}</button>`).join('')+(p.custom||[]).map((c,k)=>`<button class="btn sm" data-hb="ctrig" data-v="${k}">${esc(c.name||'Свой')} +${(c.rank||1)*2}</button>`).join('');
  const ab=[[1,'Боевое чутьё',`Очки чутья на сессию: ранг × 2 = ${rr*2}. 1 очко — урон по тебе от одного попадания −1; 1 очко — +1 Точность на одну атаку; 2 очка — прицельный выстрел без Помех.`],[3,'Двойной выстрел','Раз за ход после атаки можно атаковать вторую цель в пределах 3 клеток от первой с +1 Помехой.']];
  return `<h2>Характеристики <span class="muted" style="font-size:12px;text-transform:none">очки: ${used}/${bud}</span></h2>
  <div class="hb-grid">${HB_ST.map(([k,l])=>{const x=h.st[k]||0;return `<div class="hb-st"><button class="hb-roll" data-hb="roll" data-v="${k}">${l}</button><div class="hb-v">${x}</div>
   <div><button class="pm" data-hb="st" data-v="${k}" data-d="-1" ${x<=0?'disabled':''}>−</button><button class="pm" data-hb="st" data-v="${k}" data-d="1" ${x>=10||used>=bud?'disabled':''}>+</button></div></div>`}).join('')}</div>
  <div class="row-btns" style="margin:8px 0"><span class="ntag">Удача: <button class="pm" data-hb="luck" data-d="-1">−</button><b>${h.luck}</b>/${h.st.udc||0}<button class="pm" data-hb="luck" data-d="1">+</button></span>
   <button class="btn sm" data-hb="sess">Новая сессия</button></div>
  <h2>Роль: Стрелок <span class="ntag">ранг <button class="pm" data-hb="rr" data-d="-1">−</button><b>${rr}</b><button class="pm" data-hb="rr" data-d="1">+</button></span></h2>
  ${rr>=1?`<div class="row-btns"><span class="ntag">Чутьё: <button class="pm" data-hb="chut" data-d="-1">−</button><b>${h.chut}</b>/${rr*2}<button class="pm" data-hb="chut" data-d="1">+</button></span></div>`:''}
  ${ab.filter(a=>rr>=a[0]).map(a=>`<div class="trait"><b>Ранг ${a[0]}. ${a[1]}</b><div>${esc(a[2])}</div></div>`).join('')}
  <h2>Навыки</h2><div class="row-btns">${trig||'<span class="muted">Навыков-триггеров нет — добавьте во вкладке «Пилот».</span>'}</div>
  ${gear}`}
{const o=viewPc;viewPc=function(){if(!HB_ON)return o();const ob=bondView;bondView=charView;try{return o().replace('data-v="bond">Связь</button>','data-v="bond">Персонаж</button>')}finally{bondView=ob}}}
document.addEventListener('click',e=>{const b=e.target.closest('[data-hb]');if(!b||b.disabled)return;const a=b.dataset.hb;
  if(a==='tog'){HB_ON=!HB_ON;LS.set('hb_on',HB_ON);b.classList.toggle('on',HB_ON);if(S.view==='pc')pcRender();return}
  const p=curP();if(!p)return;const h=hbOf(p),d=+b.dataset.d||0,v=b.dataset.v;
  if(a==='st'){const x=h.st[v]||0;if(d>0&&(hbUsed(p)>=hbBudget(p)||x>=10))return;h.st[v]=Math.max(0,x+d)}
  else if(a==='roll'){const r=rnd(20),x=h.st[v]||0;pcLog(p,'Проверка '+HB_ST.find(s=>s[0]===v)[1],`d20 [${r}] ${sgn(x)} = ${r+x}`)}
  else if(a==='trig'){const s=PCD.skills.find(x=>x.id===v);if(s)pcOpenTrigger(p,s.name,p.skills[v]);return}
  else if(a==='ctrig'){const c=(p.custom||[])[+v];if(c)pcOpenTrigger(p,c.name||'Свой',c.rank||1);return}
  else if(a==='luck')h.luck=Math.max(0,Math.min(h.st.udc||0,h.luck+d));
  else if(a==='chut')h.chut=Math.max(0,Math.min(h.rr*2,h.chut+d));
  else if(a==='rr')h.rr=Math.max(0,Math.min(10,h.rr+d));
  else if(a==='sess'){h.luck=h.st.udc||0;h.chut=h.rr*2}
  pcRender()});
try{const l=document.querySelector('.logo');if(l&&!document.querySelector('[data-hb="tog"]'))l.insertAdjacentHTML('afterend',`<button class="btn sm hb-btn ${HB_ON?'on':''}" data-hb="tog">очень классные хб от максвелла</button>`)}catch(e){}
